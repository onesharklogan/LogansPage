import test from 'node:test';
import assert from 'node:assert/strict';
import {LEARNER_ORIGIN,LEARNER_APP_ORIGINS,LEARNER_AUTH_URL,learnerConfiguration} from '../lib/learner/google-config.mjs';
import {createLearnerOriginAdapter} from '../lib/learner/request-origin.mjs';
import {createGoogleAuthHandler} from '../lib/learner/google-auth-route.mjs';
import {createGoogleIdentityProvider} from '../lib/learner/google-identity.mjs';
import {restrictToPrivateOwner} from '../lib/learner/private-owner.mjs';
const env={LEARNER_GOOGLE_READY:'true',NEON_AUTH_BASE_URL:LEARNER_AUTH_URL,NEON_AUTH_COOKIE_SECRET:'test-cookie-secret-only-01234567890123456789',LEARNER_CSRF_SECRET:'test-csrf-secret-only-01234567890123456789',LEARNER_DATABASE_URL:'postgresql://learner_runtime:test-only@database.invalid/teacher_studio'};
const config=origin=>learnerConfiguration({...env,LEARNER_APP_ORIGIN:origin});
const request=(origin,path='/',headers={},init={})=>new Request(origin+path,{...init,headers:{host:new URL(origin).host,...headers}});
test('unset origin preserves old deployment; both exact deployment origins work with unchanged auth and database',()=>{
 assert.equal(learnerConfiguration(env).origin,LEARNER_ORIGIN);
 assert(Object.isFrozen(LEARNER_APP_ORIGINS));
 for(const origin of LEARNER_APP_ORIGINS){const c=config(origin);assert.equal(c.origin,origin);assert.equal(c.baseUrl,LEARNER_AUTH_URL);assert.equal(c.databaseUrl,env.LEARNER_DATABASE_URL);assert(Object.isFrozen(c));}
});
test('invalid configured origins fail closed rather than falling back',()=>{
 for(const origin of ['',null,false,123,'https://evil.test','http://dailybalancelogan.onrender.com','https://dailybalancelogan.onrender.com/','https://dailybalancelogan.onrender.com:443','https://DAILYBALANCELOGAN.onrender.com',' https://dailybalancelogan.onrender.com','https://dailybalancelogan.onrender.com.evil.test','https://dailybalancelogan.onrender.com@evil.test','https://dailybalancelogan.onrender.com?x=1','https://dailybalancelogan.onrender.com#x',...LEARNER_APP_ORIGINS.map(o=>o+'/learner/sign-in')])assert.equal(config(origin),null,String(origin));
 for(const origin of LEARNER_APP_ORIGINS){assert.equal(learnerConfiguration({...env,LEARNER_APP_ORIGIN:origin,LEARNER_GOOGLE_READY:'false'}),null);assert.equal(learnerConfiguration({...env,LEARNER_APP_ORIGIN:origin,NEON_AUTH_BASE_URL:'https://other-auth.test'}),null);}
});
test('each fixed-origin service admits its own HTTPS host and bind adapter, rejects other host and forwarding spoofing',async()=>{
 for(const origin of LEARNER_APP_ORIGINS){let calls=0;const handler=createLearnerOriginAdapter(async r=>{calls++;assert.equal(new URL(r.url).origin,origin);return new Response(null,{status:204});},{origin,port:'3000'});
 assert.equal((await handler(request(origin))).status,204);
 assert.equal((await handler(new Request('https://0.0.0.0:3000/api/learner/session',{headers:{host:new URL(origin).host,'x-forwarded-proto':'https'}}))).status,204);
 for(const other of LEARNER_APP_ORIGINS.filter(o=>o!==origin))assert.equal((await handler(request(other))).status,403);
 for(const headers of [{host:'evil.test'},{'x-forwarded-host':'evil.test'},{'x-forwarded-host':LEARNER_APP_ORIGINS.map(o=>new URL(o).host).join(',')},{'x-forwarded-proto':'http'},{'x-forwarded-proto':'https,http'}])assert.equal((await handler(request(origin,'/',headers))).status,403);
 assert.equal(calls,2);
 }
});
test('OAuth callbacks and post origin stay service-specific, never cross-host even between allowed deployments',async()=>{
 for(const origin of LEARNER_APP_ORIGINS){let calls=0;const handler=createGoogleAuthHandler({config:config(origin),handlers:{POST:async()=>{calls++;return Response.json({ok:true});}}});
 const post=(callbackOrigin,postOrigin=origin)=>request(origin,'/api/learner-auth/sign-in/social',{origin:postOrigin,'sec-fetch-site':'same-origin','content-type':'application/json'},{method:'POST',body:JSON.stringify({provider:'google',callbackURL:callbackOrigin+'/learner/sign-in',errorCallbackURL:callbackOrigin+'/learner/sign-in?error=oauth',disableRedirect:true})});
 assert.equal((await handler(post(origin))).status,200);
 for(const other of LEARNER_APP_ORIGINS.filter(o=>o!==origin)){assert.equal((await handler(post(other))).status,400);assert.equal((await handler(post(origin,other))).status,403);}
 assert.equal(calls,1);
 }
});
test('both configured origins preserve verified Google issuer/subject and owner restriction',async()=>{
 const now=Date.now(),auth={getSession:async()=>({data:{user:{id:'same-neon-user',email:'lbranjord@gmail.com',emailVerified:true},session:{id:'same-valid-session-id',userId:'same-neon-user',expiresAt:new Date(now+3600000)}}}),listAccounts:async()=>({data:[{providerId:'google',accountId:'same-google-subject',userId:'same-neon-user'}]})};
 const principals=[];
 for(const origin of LEARNER_APP_ORIGINS){const provider=restrictToPrivateOwner(createGoogleIdentityProvider({issuer:config(origin).baseUrl,includeEmail:true,now:()=>now,authForRequest:()=>auth}));principals.push(await provider.resolve(request(origin)));}
 assert.deepEqual(principals[0],principals[1]);assert.equal(principals[0].issuer,LEARNER_AUTH_URL);assert.equal(principals[0].subject,'same-google-subject');
});
