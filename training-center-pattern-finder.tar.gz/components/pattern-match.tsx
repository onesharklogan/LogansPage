'use client';

import {useEffect,useMemo,useRef,useState,type PointerEvent,type KeyboardEvent} from 'react';
import AppHeader from './app-navigation';
import PatternCandles from './pattern-candles';
import TradeSessionCalendar from './trade-session-calendar';
import {PatternSavePanel,type PatternSnapshot} from './pattern-encyclopedia';
import {patternStudySnapshot} from '../lib/pattern-study-snapshot.mjs';
import LearnerAccountControl from './learner-account-control';
import {learnerClient} from '../lib/learner/client.mjs';
import {loadChartMatchSessions} from './chart-match-data.mjs';
import {historicalPrefix} from '../lib/chart-match.mjs';
import {buildPatternWindow,rankPatternMatches} from '../lib/pattern-match.mjs';
import {validPatternSelection,placePatternSelection,draggedPatternSelection,patternPointerBar,randomPatternSession} from '../lib/pattern-selection.mjs';
import styles from './pattern-match.module.css';

type Session=Awaited<ReturnType<typeof loadChartMatchSessions>>[number];
type Match=Awaited<ReturnType<typeof rankPatternMatches>>['matches'][number];
const MATCH_LIMIT=10;
const matchKey=(match:{id:string;startBar:number})=>`${match.id}:${match.startBar}`;
type Gesture={pointer:number;source:string;anchor:number;x:number;original:{start:string;end:string};moved:boolean};
const errorMessage=(error:unknown)=>error instanceof Error?error.message:'The comparison could not be completed. Please try again.';
const visibleCandles=(source:Session,count:number)=>historicalPrefix(source.chart,count,{useEma:true,minBars:2}).map((c,i)=>({...c,t:source.chart.current[i].t}));

/** Read-only catalog study. No simulator, stored account state, uploads or outcome ranking. */
export default function PatternMatch(){
 const [selected,setSelected]=useState<string[]>([]);const dirtyDraft=useRef(false),pendingSave=useRef(false);
 const [sessions,setSessions]=useState<Session[]>([]),[loadState,setLoadState]=useState('Loading historical charts…'),[loadError,setLoadError]=useState(''),[retry,setRetry]=useState(0);
 const [savedDraft,setSavedDraft]=useState(false);
 const rejected=useRef(new Set<string>());
 const [sourceChartWidth,setSourceChartWidth]=useState<number|undefined>(undefined);
 const [title,setTitle]=useState(''),[description,setDescription]=useState(''),[saving,setSaving]=useState(false);
 const savedMetadata=useRef(''),metadataDirty=useRef(false);metadataDirty.current=JSON.stringify([title,description])!==savedMetadata.current&&(!!title||!!description);
 const [sourceId,setSourceId]=useState(''),[range,setRange]=useState({start:'1',end:'15'});
 const [matches,setMatches]=useState<Match[]>([]),[status,setStatus]=useState(''),[error,setError]=useState(''),[busy,setBusy]=useState(false),[searched,setSearched]=useState(false);
 const job=useRef<AbortController|null>(null),epoch=useRef(0),resultEpoch=useRef(-1),alive=useRef(true),gesture=useRef<Gesture|null>(null),svg=useRef<SVGSVGElement>(null),latestSource=useRef(sourceId);latestSource.current=sourceId;
 const [calendar,setCalendar]=useState<number|null>(null),calendarRequest=useRef<number|null>(null),calendarSequence=useRef(0),calendarTrigger=useRef<HTMLButtonElement>(null),calendarFocus=useRef(false);
 const calendarEntries=useMemo(()=>sessions.map(session=>session.reference),[sessions]);
 const source=useMemo(()=>sessions.find(s=>s.reference.id===sourceId),[sessions,sourceId]),total=source?.chart.current.length??0,start=Number(range.start),end=Number(range.end),valid=validPatternSelection(start,end,total);
 const query=useMemo(()=>{if(!source||!valid)return null;try{return buildPatternWindow(source,start,end);}catch{return null;}},[source,start,end,valid]);
 const sourceBars=useMemo(()=>source?visibleCandles(source,total):[],[source,total]);
 useEffect(()=>{const node=svg.current;if(!node)return;const measure=()=>{const width=node.getBoundingClientRect?.().width;if(width&&Number.isFinite(width))setSourceChartWidth(width);};measure();if(typeof ResizeObserver==='undefined')return;const observer=new ResizeObserver(measure);observer.observe(node);return()=>observer.disconnect();},[source?.reference.id]);
 const resultSessions=useMemo(()=>new Map(matches.map(match=>{const candidate=sessions.find(s=>s.reference.id===match.id);return [match.id,candidate?visibleCandles(candidate,candidate.chart.current.length):[]];})),[sessions,matches]);
 function releaseGesture(){const g=gesture.current;gesture.current=null;if(g&&svg.current?.hasPointerCapture?.(g.pointer))svg.current.releasePointerCapture(g.pointer);}
 function cancelGesture(){const g=gesture.current;releaseGesture();if(g&&g.source===latestSource.current)setRange(g.original);}
 function stop(){epoch.current++;job.current?.abort();job.current=null;setBusy(false);}
 function invalidate(){rejected.current.clear();setSavedDraft(false);setSelected([]);stop();setMatches([]);setSearched(false);setError('');setStatus('');}
 // Retain a draft through temporary verification, but never carry an account's
 // authored text or save candidate into another account or a logged-out visit.
 useEffect(()=>{let owner=learnerClient.captureContext();if(owner?.mode!=='account')owner=null;const check=()=>{if(owner&&!learnerClient.ownsCapture(owner)){releaseGesture();invalidate();setTitle('');setDescription('');setSaving(false);savedMetadata.current='';metadataDirty.current=false;dirtyDraft.current=false;pendingSave.current=false;owner=null;}const current=learnerClient.captureContext();if(current?.mode==='account')owner=current;};const unsubscribe=learnerClient.subscribe(check);check();return()=>{unsubscribe();};},[]);
 function openCalendar(){if(!alive.current||pendingSave.current||calendarRequest.current!==null)return;cancelGesture();const token=++calendarSequence.current;calendarRequest.current=token;setCalendar(token);}
 function closeCalendar(token:number){if(!alive.current||calendarRequest.current!==token)return;calendarRequest.current=null;calendarFocus.current=true;setCalendar(null);}
 function loadSource(next:Session){
  cancelGesture();invalidate();latestSource.current=next.reference.id;setSourceId(next.reference.id);
  const selection=placePatternSelection(1,15,next.chart.current.length);setRange({start:String(selection.start),end:String(selection.end)});
 }
 function chooseSource(id:string,token:number){if(pendingSave.current||!alive.current||calendarRequest.current!==token)return;const next=sessions.find(session=>session.reference.id===id);if(!next||next.chart.current.length<2)return;loadSource(next);closeCalendar(token);}
 function randomSource(event:{detail?:number}){
  if(pendingSave.current||!alive.current||(event.detail??0)>1)return;
  const next=randomPatternSession(sessions,latestSource.current);if(!next)return;
  // Retire any picker callback before switching, including callbacks retained by a closing dialog.
  calendarRequest.current=null;calendarFocus.current=false;setCalendar(null);loadSource(next);setStatus(`Loaded ${next.reference.date}. Pattern reset to bars 1–${Math.min(15,next.chart.current.length)}.`);
 }
 useEffect(()=>{if(calendar===null&&calendarFocus.current){calendarFocus.current=false;calendarTrigger.current?.focus({preventScroll:true});}},[calendar]);
 function setSelection(next:{start:number;end:number}){if(pendingSave.current)return;invalidate();setRange({start:String(next.start),end:String(next.end)});}
 useEffect(()=>{alive.current=true;return()=>{alive.current=false;calendarRequest.current=null;epoch.current++;job.current?.abort();releaseGesture();}},[]);
 useEffect(()=>{
  const controller=new AbortController();let current=true;setLoadError('');setLoadState('Loading and verifying historical charts…');
  const timeout=setTimeout(()=>{controller.abort();if(current){setLoadError('Chart loading timed out. Please retry.');setLoadState('');}},15000);
  loadChartMatchSessions({signal:controller.signal}).then(rows=>{if(!current||controller.signal.aborted)return;const available=rows.filter(row=>row.chart.current.length>=2);setSessions(available);const initial=available.at(-1);if(initial&&initial.chart.current.length>=2){latestSource.current=initial.reference.id;setSourceId(initial.reference.id);const selection=placePatternSelection(1,15,initial.chart.current.length);setRange({start:String(selection.start),end:String(selection.end)});}setLoadState('');}).catch(err=>{if(current&&!controller.signal.aborted){setLoadError(errorMessage(err));setLoadState('');}}).finally(()=>clearTimeout(timeout));
  return()=>{current=false;clearTimeout(timeout);controller.abort();};
 },[retry]);
 useEffect(()=>{const cancel=()=>cancelGesture(),hidden=()=>{if(document.hidden)cancel();};window.addEventListener('blur',cancel);window.addEventListener('pagehide',cancel);document.addEventListener('visibilitychange',hidden);return()=>{window.removeEventListener('blur',cancel);window.removeEventListener('pagehide',cancel);document.removeEventListener('visibilitychange',hidden);};},[]);
 useEffect(()=>{const leave=()=>!pendingSave.current&&(!(metadataDirty.current||dirtyDraft.current)||window.confirm('Discard unsaved pattern notes?'));const unload=(event:BeforeUnloadEvent)=>{if(metadataDirty.current||dirtyDraft.current||pendingSave.current){event.preventDefault();event.returnValue='';}};const click=(event:MouseEvent)=>{if(!dirtyDraft.current&&!event.defaultPrevented&&(event.target as Element)?.closest?.('a[href]')&&!leave()){event.preventDefault();event.stopPropagation();}};window.addEventListener('beforeunload',unload);document.addEventListener('click',click);return()=>{window.removeEventListener('beforeunload',unload);document.removeEventListener('click',click);};},[]);
 async function search(){
  if(!query||!alive.current||gesture.current||pendingSave.current||job.current)return;rejected.current.clear();setSavedDraft(false);stop();const token=epoch.current,controller=new AbortController();job.current=controller;setBusy(true);setMatches([]);setError('');setSearched(false);setStatus('Comparing candle patterns…');
  try{const result=await rankPatternMatches(query,sessions,{earlierOnly:false,limit:MATCH_LIMIT,signal:controller.signal,onProgress:progress=>{if(alive.current&&epoch.current===token)setStatus(`Comparing patterns… ${progress.scanned.toLocaleString()} windows checked`);}});
   if(!alive.current||controller.signal.aborted||epoch.current!==token)return;
   resultEpoch.current=token;setMatches(result.matches);setSelected(result.matches.map(m=>`${m.id}:${m.startBar}`));setSearched(true);setStatus(`${result.matches.length} closest patterns from ${result.eligibleSessions} eligible sessions · ${result.scanned.toLocaleString()} windows compared${result.skippedSessions?` · ${result.skippedSessions} unavailable sessions skipped`:''}.`);
  }catch(err){if(alive.current&&epoch.current===token&&!controller.signal.aborted){setError(errorMessage(err));setStatus('');}}finally{if(alive.current&&epoch.current===token){job.current=null;setBusy(false);}}
 }
 async function replaceUnchecked(){
  if(!query||!searched||savedDraft||!alive.current||gesture.current||pendingSave.current||job.current)return;
  const kept=matches.filter(match=>selected.includes(matchKey(match))),omitted=matches.filter(match=>!selected.includes(matchKey(match)));
  if(!omitted.length)return;
  const excluded=new Set([...rejected.current,...omitted.map(matchKey)]),slots=MATCH_LIMIT-kept.length;
  stop();const token=epoch.current,controller=new AbortController();job.current=controller;setBusy(true);setError('');setStatus('Finding replacements for unchecked matches…');
  try{
   const result=await rankPatternMatches(query,sessions,{earlierOnly:false,limit:slots,excludedKeys:[...excluded],retainedWindows:kept.map(({id,startBar,endBar})=>({id,startBar,endBar})),signal:controller.signal});
   if(!alive.current||controller.signal.aborted||epoch.current!==token)return;
   const refreshed=[...kept,...result.matches];rejected.current=excluded;resultEpoch.current=token;setMatches(refreshed);setSelected(refreshed.map(matchKey));
   setStatus(`${kept.length} checked matches kept · ${result.matches.length} replacements found.${result.matches.length<slots?' No more eligible matches are available for this selection.':''}`);
  }catch(err){if(alive.current&&epoch.current===token&&!controller.signal.aborted){resultEpoch.current=token;setError(errorMessage(err));setStatus('Replacement search failed. Your matches and selections are unchanged. Try again.');}}
  finally{if(alive.current&&epoch.current===token){job.current=null;setBusy(false);}}
 }
 function pointerDown(event:PointerEvent<SVGSVGElement>){
  if(pendingSave.current||!source||event.button!==0||gesture.current)return;const anchor=patternPointerBar(event.clientX,event.currentTarget.getBoundingClientRect(),total);if(anchor===null)return;
  const g:Gesture={pointer:event.pointerId,source:sourceId,anchor,x:event.clientX,original:{...range},moved:false};
  try{event.currentTarget.setPointerCapture(event.pointerId);}catch{return;}
  gesture.current=g;event.currentTarget.focus({preventScroll:true});invalidate();
 }
 function pointerMove(event:PointerEvent<SVGSVGElement>){
  const g=gesture.current;if(!g||g.pointer!==event.pointerId||g.source!==latestSource.current)return;
  if(Math.abs(event.clientX-g.x)>4)g.moved=true;if(!g.moved)return;
  const rect=event.currentTarget.getBoundingClientRect(),clamped=Math.max(rect.left+rect.width*.024,Math.min(rect.left+rect.width*.928,event.clientX)),bar=patternPointerBar(clamped,rect,total);
  if(bar!==null){event.preventDefault();const next=draggedPatternSelection(g.anchor,bar,total);setRange({start:String(next.start),end:String(next.end)});}
 }
 function pointerUp(event:PointerEvent<SVGSVGElement>){
  const g=gesture.current;if(!g||g.pointer!==event.pointerId)return;if(g.source!==latestSource.current){releaseGesture();return;}
  pointerMove(event);if(!g.moved){const length=Number(g.original.end)-Number(g.original.start)+1,next=placePatternSelection(g.anchor,Number.isFinite(length)?length:15,total);setRange({start:String(next.start),end:String(next.end)});}releaseGesture();
 }
 function chartKeys(event:KeyboardEvent<SVGSVGElement>){
  if(pendingSave.current||event.defaultPrevented||event.nativeEvent.isComposing||event.ctrlKey||event.metaKey||event.altKey)return;
  if(event.key==='Escape'){event.preventDefault();cancelGesture();return;}
  if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key)||!source)return;event.preventDefault();cancelGesture();
  setSelection(placePatternSelection(event.key==='Home'?1:event.key==='End'?total:start+(event.key==='ArrowLeft'?-1:1),valid?end-start+1:15,total));
 }
 const prepared=useMemo(()=>{if(!query||!searched||busy||resultEpoch.current!==epoch.current)return {snapshot:null,error:''};try{return {snapshot:patternStudySnapshot(query,matches.filter(m=>selected.includes(`${m.id}:${m.startBar}`)),sessions,{earlierOnly:false,limit:MATCH_LIMIT}) as PatternSnapshot,error:''};}catch(e){return {snapshot:null,error:errorMessage(e)};}},[query,searched,busy,matches,selected,sessions]),candidate=prepared.snapshot;
 const previewCharts=useMemo(()=>candidate?Object.fromEntries(sessions.filter(s=>[candidate.source,...candidate.matches].some(e=>e.chartId===s.reference.id)).map(s=>[s.reference.id,s.chart])):{},[candidate,sessions]);

 return <div className={styles.page}><AppHeader section="PATTERN FINDER" current="/pattern-match"><LearnerAccountControl onBeforeNavigate={()=>!pendingSave.current&&(!(dirtyDraft.current||metadataDirty.current)||window.confirm('Discard unsaved pattern notes?'))} navigationWarning="Signing in leaves this page. Unsaved pattern selections and notes are not stored."/></AppHeader><main className={styles.main}>
  <header className={styles.intro}><div><p className={styles.eyebrow}>SMALL PATTERNS · BIG LIBRARY</p><h1>Pattern Finder</h1><p className={styles.notice}>Select 2–25 bars and find 10 matches. Add a title and optional description when you save to your encyclopedia.</p><p>Highlight a small stretch of chart. Find the same kind of price action across historical sessions.</p></div><nav className={styles.introActions} aria-label="Pattern tools"><a className={styles.encyclopediaButton} href="/pattern-encyclopedia">Pattern Encyclopedia <span aria-hidden="true">↗</span></a><a href="/chart-match">Screenshot matching ↗</a></nav></header>
  {loadState&&<p role="status" className={styles.notice}>{loadState}</p>}{loadError&&<div role="alert" className={styles.error}><p>{loadError}</p><button onClick={()=>setRetry(n=>n+1)}>Retry charts</button></div>}
  {source&&<>
   <section className={styles.panel} aria-labelledby="pattern-select-title"><div className={styles.sectionHeader}><h2 id="pattern-select-title"><span>1</span> Select your pattern</h2><span className={styles.instrument}>MES · 5 minute · EMA20</span></div>
    <fieldset disabled={saving} className={styles.controls}><label>Source session<button ref={calendarTrigger} type="button" aria-haspopup="dialog" aria-expanded={calendar!==null} onClick={openCalendar}>{source.reference.date} · Choose date</button></label><button type="button" disabled={saving} onClick={randomSource}><svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 6h3c5 0 7 12 12 12h3m-4-4 4 4-4 4M3 18h3c2 0 4-3 6-6s4-6 6-6h3m-4-4 4 4-4 4"/></svg> Random Session</button><label>Start bar<input type="number" min="1" max={total-1} step="1" value={range.start} onChange={event=>{cancelGesture();invalidate();setRange(r=>({...r,start:event.target.value}));}}/></label><label>End bar<input type="number" min="2" max={total} step="1" value={range.end} onChange={event=>{cancelGesture();invalidate();setRange(r=>({...r,end:event.target.value}));}}/></label><div className={styles.lengths} aria-label="Pattern length">{[2,10,15,20,25].map(n=><button key={n} aria-pressed={valid&&end-start+1===n} onClick={()=>{cancelGesture();setSelection(placePatternSelection(Number.isFinite(start)?start:1,n,total));}}>{n} bars</button>)}</div></fieldset>
    <p className={styles.small}>{source.reference.title}</p>
    <p id="pattern-selection-help" className={styles.help}>Drag across 2–25 candles, or tap a candle to place the selected length. Use the bar fields or slider for precise selection on a phone. Arrow keys move the selection.</p>
    <div className={styles.sourceChart}><PatternCandles ref={svg} candles={sourceBars} selection={Number.isInteger(start)&&Number.isInteger(end)&&start>=1&&end>=start&&end<=total?{start,end}:undefined} label={`${source.reference.date} source chart. Highlight 2 to 25 consecutive bars.`} interactive tabIndex={0} aria-describedby="pattern-selection-help" onPointerDown={pointerDown} onPointerMove={pointerMove} onPointerUp={pointerUp} onPointerCancel={cancelGesture} onLostPointerCapture={cancelGesture} onKeyDown={chartKeys}/></div>
    <label className={styles.slider}>Move pattern <input disabled={saving} type="range" min="1" max={Math.max(1,total-(valid?end-start+1:15)+1)} value={Math.min(Math.max(1,Number.isFinite(start)?start:1),total-(valid?end-start+1:15)+1)} onChange={event=>{cancelGesture();setSelection(placePatternSelection(Number(event.target.value),valid?end-start+1:15,total));}} aria-label="Move pattern start bar"/><span>{valid?`Bars ${start}–${end}`:'Choose 2–25 bars'}</span></label>
    {!valid&&<p role="alert" className={styles.error}>Choose 2–25 consecutive bars within this session. The highlighted range is not searched until it is valid.</p>}
   </section>
   <section className={styles.queryRow} aria-label="Selected pattern and search"><div className={styles.queryPreview}><div className={styles.sectionHeader}><h2>Your pattern</h2><span>{valid?`${end-start+1} bars · ${source.reference.date}`:'No valid selection'}</span></div>{query?<PatternCandles candles={query.candles} referenceCandles={sourceBars} referenceWidth={sourceChartWidth} startBar={start} label={`Selected pattern, bars ${start} to ${end}`} compact/>:<p>Select a valid range above to preview it here.</p>}</div><div className={styles.searchPanel}><h2><span>2</span> Find 10 matches</h2><p className={styles.small}>No title or description needed to search.</p><p>Matches can start anywhere in a session. Price level and size are normalized, while candle direction, bodies, wicks and EMA shape stay meaningful.</p><div className={styles.actions}><button className={styles.primary} disabled={!query||busy||saving} onClick={()=>void search()}>{busy?'Finding patterns…':'Find 10 matches'}</button>{busy&&<button onClick={()=>{stop();resultEpoch.current=epoch.current;setStatus('Search canceled. Your selection and any previous matches are unchanged.');}}>Cancel search</button>}</div></div></section>
   <p className={styles.status} role="status" aria-live="polite">{status}</p>{(error||prepared.error)&&<p role="alert" className={styles.error}>{error||prepared.error}</p>}
   {searched&&<section aria-labelledby="pattern-results-title"><div className={styles.resultsHeading}><h2 id="pattern-results-title">Closest patterns</h2><span>Distance ↓ lower is closer · 0 = identical features</span></div>{matches.length===0&&<div className={styles.notice}>No eligible patterns were found. Try another range or source session.</div>}
    <p>Uncheck examples you do not want, then re-check for more matches. Checked examples stay; omitted examples will not return until you start a new search or change the selection.</p><div className={styles.actions}><button disabled={busy||saving||savedDraft||!matches.some(match=>!selected.includes(matchKey(match)))} onClick={()=>void replaceUnchecked()}>Re-check for more matches</button><a href="/pattern-encyclopedia">Open encyclopedia</a></div><div className={styles.grid}>{matches.map((match,index)=><article className={styles.card} key={`${match.id}:${match.startBar}`}><label className={styles.checkbox}><input type="checkbox" disabled={busy||saving||savedDraft} checked={selected.includes(`${match.id}:${match.startBar}`)} onChange={e=>{setSelected(old=>e.target.checked?[...old,`${match.id}:${match.startBar}`]:old.filter(key=>key!==`${match.id}:${match.startBar}`));}}/>Include in saved study</label><div className={styles.cardHeading}><div><span className={styles.rank}>#{index+1}</span> <time dateTime={match.date}>{match.date}</time></div></div><div className={styles.fullChart} tabIndex={0} role="region" aria-label={`${match.date} full session chart; scroll horizontally on smaller screens`}><PatternCandles candles={resultSessions.get(match.id)??[]} startBar={1} selection={{start:match.startBar,end:match.endBar}} label={`Historical match ${index+1}, ${match.date}. Full historical session, ${resultSessions.get(match.id)?.length??0} observed bars. Box: bars ${match.startBar} to ${match.endBar}.`} fullSession/></div><div className={styles.cardFooter}><span>Bars {match.startBar}–{match.endBar} · {match.startTime.slice(11,16)}–{match.endTime.slice(11,16)}</span></div><details className={styles.breakdown}><summary>Why this match?</summary><p>Distance by feature, lower is closer. Features use only the pattern and preceding context.</p><ul>{Object.entries(match.components).filter(([,value])=>typeof value==='number').map(([name,value])=><li key={name}>{name}: {(value as number).toFixed(3)}</li>)}</ul></details></article>)}</div>
   </section>}

   {candidate&&<section className={styles.panel} aria-labelledby="pattern-save-title"><h2 id="pattern-save-title"><span>3</span> Save your pattern</h2><p>Add a title to save these results. Description is optional.</p><div className={styles.metadata}><label htmlFor="pattern-title">Title<input id="pattern-title" type="text" maxLength={120} disabled={saving||savedDraft} value={title} onChange={event=>{setTitle(event.target.value);}} placeholder="e.g. Two-bar reversal"/></label><label htmlFor="pattern-description">Description<textarea id="pattern-description" maxLength={10000} rows={3} disabled={saving||savedDraft} value={description} onChange={event=>{setDescription(event.target.value);}} placeholder="What defines this pattern?"/></label>{savedDraft&&<p className={styles.small}>Pattern saved. Find matches again to start another study, or open the saved pattern to edit it.</p>}</div><div className={styles.actions}><PatternSavePanel key={`${epoch.current}:${selected.join(',')}`} creationAction initialTitle={title} initialDescription={description} onSaved={entry=>{setSavedDraft(true);setTitle(entry.title);setDescription(entry.description);savedMetadata.current=JSON.stringify([entry.title,entry.description]);metadataDirty.current=false;}} candidateSnapshot={candidate} previewCharts={previewCharts} onDirtyChange={value=>{dirtyDraft.current=value;}} onPendingChange={value=>{pendingSave.current=value;setSaving(value);}}/></div></section>}

   <p className={styles.small}>The 2024 charts use TradeStation @MES data. Continuous-contract adjustment and Chicago timezone are not independently verified. July 18, 2024 is missing, and EMA uses available bars only. Similarity across sources is a study aid.</p>
   <details className={styles.method}><summary>How matching works</summary><p>Each candidate has the same number of bars as your selection. The search compares the close path, relative candle bodies and wicks, bullish/bearish direction, EMA20 position and slope, and up to five preceding candles. Price translation and positive scale are removed; bearish patterns are not flipped into bullish ones.</p><p>EMA20 retains the original historical warmup. No candles after a candidate’s last matched bar, later returns, trade results or future pivots enter its distance. Scores describe feature similarity only and are not calibrated probabilities. Results stay in this page’s memory and are cleared when you leave. Saved studies stay in your private encyclopedia.</p></details>
  </>}
 </main>{calendar!==null&&<TradeSessionCalendar key={calendar} entries={calendarEntries} initialId={sourceId} title="Choose source session" helpText="Choose an available date to load its chart and reset the pattern to the first 15 available bars (or fewer in a short session). Close keeps your current pattern and results. Arrow keys or W A S D move between dates; Enter or Space opens the focused date." onChoose={id=>chooseSource(id,calendar)} onClose={()=>closeCalendar(calendar)}/>}</div>;
}
