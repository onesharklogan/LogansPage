import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const read=p=>readFileSync(new URL('../components/'+p,import.meta.url),'utf8');
test('Daily Balance retains the header, gates empty controls and distinguishes load errors',()=>{
 const ui=read('daily-dashboard.tsx');
 assert.doesNotMatch(ui,/Saved to your account · Chicago time|Tasks count equally within each category/);
 assert.match(ui,/<AppHeader section="DAILY DASHBOARD".*\n \{data&&<>\n <div className=\{styles.hero\}/);
 assert.match(ui,/role="alert" className=\{styles.error\}.*>Refresh<\/button>/);
 assert.match(ui,/!data\?\(!error&&<div className=\{styles.empty\} role="status"><LoadingIndicator/);
 assert.match(ui,/<div hidden=\{!data\}>\{lifeLessonsEnabled&&<LifeLessons owner=\{data\?\.context\}\/>\}<ImprovementsNotes\/><\/div>/);
 assert.match(read('improvements-notes.tsx'),/if\(!saved\).*role="alert".*Retry notes.*<LoadingIndicator/);
 assert.match(read('hourly-reminders.tsx'),/!saved&&ownerKey.*role="alert".*Retry reminders.*<LoadingIndicator/);
});
test('completed goals are compact and actionable, keeping empty categories in the main grid',()=>{
 const ui=read('daily-dashboard.tsx'),css=read('daily-dashboard.module.css');
 assert.match(ui,/const complete=count>0&&done>=count&&patternsDone>=patternGoal/);
 assert.match(ui,/const hourlyComplete=data\?\.hourly.completedHours.length===HOURLY_HOURS.length/);
 assert.match(ui,/complete\?<>.*✓ Complete/);
 assert.match(ui,/hourlyComplete\?<>.*✓ Complete/);
 assert.match(ui,/complete,element:c.id==='trading'\?<a.*href="\/training">\{content\}<\/a>:<button/);
 assert.match(ui,/className=\{styles.completedCategories\} aria-label="Completed categories"/);
 assert.match(css,/\.completedCategories \.completeCard\{[^}]*min-height:54px/);
});
