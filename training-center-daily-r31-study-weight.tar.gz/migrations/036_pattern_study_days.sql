-- Additive private daily markers; application rollback can leave these rows safely in place.
BEGIN;
CREATE TABLE IF NOT EXISTS learner_app.pattern_study_days (
 account_id uuid NOT NULL,
 pattern_id uuid NOT NULL,
 day_key date NOT NULL,
 studied_at bigint NOT NULL CHECK(studied_at>0),
 PRIMARY KEY(account_id,pattern_id,day_key),
 FOREIGN KEY(account_id,pattern_id) REFERENCES learner_app.pattern_entries(account_id,pattern_id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS pattern_study_owner_day ON learner_app.pattern_study_days(account_id,day_key);
REVOKE ALL ON learner_app.pattern_study_days FROM PUBLIC;
GRANT SELECT,INSERT ON learner_app.pattern_study_days TO learner_runtime;
COMMIT;
