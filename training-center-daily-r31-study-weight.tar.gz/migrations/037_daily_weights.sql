-- PREPARED ONLY. Additive private Daily Balance storage; no existing rows changed.
BEGIN;
CREATE TABLE IF NOT EXISTS learner_app.daily_weights (
 account_id uuid NOT NULL REFERENCES learner_app.accounts(id),
 day_key text NOT NULL CHECK(day_key ~ '^\d{4}-\d{2}-\d{2}$'),
 pounds_tenths integer NOT NULL CHECK(pounds_tenths BETWEEN 10 AND 15000),
 revision integer NOT NULL DEFAULT 1 CHECK(revision>0),
 updated_at bigint NOT NULL,
 PRIMARY KEY(account_id,day_key)
);
COMMENT ON TABLE learner_app.daily_weights IS 'Private owner weight by Chicago calendar day. Separate from scores, shared exports and trading history.';
REVOKE ALL ON learner_app.daily_weights FROM PUBLIC;
GRANT SELECT,INSERT ON learner_app.daily_weights TO learner_runtime;
GRANT UPDATE(pounds_tenths,revision,updated_at) ON learner_app.daily_weights TO learner_runtime;
COMMIT;
