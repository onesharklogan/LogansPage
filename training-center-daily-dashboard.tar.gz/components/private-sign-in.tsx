'use client';
import {useState,useRef,useEffect} from 'react';
import {browserGoogleDriver} from '../lib/learner/google-driver.mjs';
export default function PrivateSignIn(){
 const[busy,setBusy]=useState(false),[error,setError]=useState('');const active=useRef<AbortController|null>(null);
 useEffect(()=>()=>active.current?.abort(),[]);
 async function signIn(){if(active.current)return;const controller=new AbortController();active.current=controller;setBusy(true);setError('');try{const driver=await browserGoogleDriver();await driver.signIn({signal:controller.signal});}catch{if(!controller.signal.aborted)setError('Sign-in did not finish. Please try again with your Google account.');}finally{if(active.current===controller){active.current=null;setBusy(false);}}}
 async function switchAccount(){if(active.current)return;const controller=new AbortController();active.current=controller;setBusy(true);setError('');try{await(await browserGoogleDriver()).signOut({signal:controller.signal});setError('Signed out. Continue with your Google account.');}catch{setError('Could not sign out. Please try again.');}finally{active.current=null;setBusy(false);}}
 return <main className="training-main" style={{maxWidth:560,margin:'12vh auto',padding:24}}><p>YOUR DAILY SPACE</p><h1>Welcome back</h1><p>Your dashboard and trading practice are private. Sign in with your Google account to continue.</p><button type="button" disabled={busy} onClick={()=>void signIn()}>{busy?'Connecting…':'Continue with Google'}</button><p><button type="button" disabled={busy} onClick={()=>void switchAccount()}>Use a different Google account</button></p>{error&&<p role="status">{error}</p>}</main>;
}
