import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
const read=p=>fs.readFileSync(new URL('../'+p,import.meta.url),'utf8');
test('legacy simulator and marker menus retain trading tools and expose all-things hub',()=>{for(const path of ['public/modules/market-direction.html','public/modules/chart-marker.html']){const html=read(path);assert.match(html,/>All-things hub<\/a>/);assert.match(html,/href="\/training"[^>]*>Trading home<\/a>/);assert.match(html,/href="\/pattern-encyclopedia"/);}});
