import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {readCatalogWithEmptyRetry} from '../lib/catalog-empty-retry.mjs';
const empty={patterns:[],nextCursor:null};
test('empty active catalog retries once and adopts recovered entries',async()=>{
 let calls=0;const recovered={patterns:[{id:'existing'}],nextCursor:null};
 assert.equal(await readCatalogWithEmptyRetry(async()=>++calls===1?empty:recovered),recovered);assert.equal(calls,2);
});
test('persistent empty response is bounded to two reads',async()=>{
 let calls=0;assert.equal(await readCatalogWithEmptyRetry(async()=>{calls++;return empty;}),empty);assert.equal(calls,2);
});
test('search, trash, pagination, stale account and nonempty results never auto-retry',async()=>{
 for(const options of [{search:'abc'},{trash:true},{more:true},{isCurrent:()=>false}]) {let calls=0;await readCatalogWithEmptyRetry(async()=>{calls++;return empty;},options);assert.equal(calls,1);}
 for(const result of [{patterns:[{}],nextCursor:null},{patterns:[],nextCursor:'next'}]) {let calls=0;await readCatalogWithEmptyRetry(async()=>{calls++;return result;});assert.equal(calls,1);}
});
test('initial and retry errors remain errors, never a false empty success',async()=>{
 for(const failAt of [1,2]) {let calls=0;await assert.rejects(readCatalogWithEmptyRetry(async()=>{if(++calls===failAt)throw new Error('Unavailable');return empty;}),/Unavailable/);assert.equal(calls,failAt);}
});
test('empty hint and visible theme-token simulator icon are present; unwanted matcher copy is gone',()=>{
 const read=p=>fs.readFileSync(new URL('../'+p,import.meta.url),'utf8');
 assert.match(read('components/pattern-encyclopedia.tsx'),/You may need to refresh/);
 assert.match(read('app/training/page.tsx'),/data-tool-icon="simulator"/);
 assert.doesNotMatch(read('app/training/page.tsx'),/<i \/>/);
 assert.doesNotMatch(read('components/pattern-match.tsx'),/No title or description needed to search|Matches can start anywhere in a session/);
});
test('gallery explanation follows the cover with no boxed-bars or updated captions',()=>{
 const s=fs.readFileSync(new URL('../components/pattern-encyclopedia.tsx',import.meta.url),'utf8');
 const card=s.slice(s.indexOf('<ul className={styles.list}'),s.indexOf('</ul>'));
 assert.ok(card.indexOf('styles.coverChart')<card.indexOf('styles.cardDescription'));
 assert.doesNotMatch(card,/Full session · Boxed bars|Updated \{/);
 assert.match(card,/aria-label=\{`Open pattern:/);
 assert.match(card,/Restore/);
});
test('trading style is optional while finding and travels through creation, edit and catalog',()=>{
 const read=p=>fs.readFileSync(new URL('../'+p,import.meta.url),'utf8');
 const finder=read('components/pattern-match.tsx'),editor=read('components/pattern-encyclopedia.tsx');
 assert.match(finder,/id="pattern-trading-style"/);
 assert.match(finder,/initialTradingStyle=\{tradingStyle\}/);
 assert.match(finder,/setTradingStyle\(entry.tradingStyle\?\?''\)/);
 assert.match(finder,/setTradingStyle\(''\)/);
 assert.match(editor,/initialTradingStyle=\{initialTradingStyle\}/);
 assert.match(editor,/tradingStyle:initialTradingStyle\?\?draft.tradingStyle/);
 assert.match(editor,/draft.tradingStyle===action.draft.tradingStyle/);
 assert.match(editor,/tradingStyle:remote.tradingStyle\?\?''/);
 assert.match(editor,/item.tradingStyle&&<p className=\{styles.cardTradingStyle\}/);
 assert.match(editor,/No trading style yet/);
});
