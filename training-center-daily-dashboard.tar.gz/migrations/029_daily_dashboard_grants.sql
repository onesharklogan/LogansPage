-- Prepared only. Apply after 028 with explicit deployment approval.
BEGIN;
GRANT SELECT,INSERT ON learner_app.daily_tasks,learner_app.daily_items TO learner_runtime;
GRANT UPDATE(title,category,active,revision) ON learner_app.daily_tasks TO learner_runtime;
GRANT UPDATE(title,category,active,completed,revision,updated_at) ON learner_app.daily_items TO learner_runtime;
-- No DELETE or changes to trading history grants.
COMMIT;
