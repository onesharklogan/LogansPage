-- Prepared only. Explicit approval required before applying to production.
BEGIN;
ALTER TABLE learner_app.daily_tasks ADD COLUMN IF NOT EXISTS points integer NOT NULL DEFAULT 0 CHECK(points BETWEEN 0 AND 100);
ALTER TABLE learner_app.daily_items ADD COLUMN IF NOT EXISTS points integer NOT NULL DEFAULT 0 CHECK(points BETWEEN 0 AND 100);
GRANT UPDATE(points) ON learner_app.daily_tasks,learner_app.daily_items TO learner_runtime;
COMMIT;
