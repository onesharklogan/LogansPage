BEGIN;
CREATE TABLE IF NOT EXISTS learner_app.daily_tasks (
 account_id uuid NOT NULL REFERENCES learner_app.accounts(id),
 task_id uuid NOT NULL,
 category text NOT NULL CHECK(category IN ('family','fitness','trading','career','self','meditation')),
 title text NOT NULL CHECK(length(title) BETWEEN 1 AND 160),
 active boolean NOT NULL DEFAULT true,
 revision integer NOT NULL DEFAULT 1 CHECK(revision>0),
 created_at bigint NOT NULL,
 PRIMARY KEY(account_id,task_id)
);
CREATE TABLE IF NOT EXISTS learner_app.daily_items (
 account_id uuid NOT NULL,
 day_key text NOT NULL CHECK(day_key ~ '^\d{4}-\d{2}-\d{2}$'),
 task_id uuid NOT NULL,
 category text NOT NULL CHECK(category IN ('family','fitness','trading','career','self','meditation')),
 title text NOT NULL CHECK(length(title) BETWEEN 1 AND 160),
 active boolean NOT NULL DEFAULT true,
 completed boolean NOT NULL DEFAULT false,
 revision integer NOT NULL DEFAULT 1 CHECK(revision>0),
 updated_at bigint NOT NULL,
 PRIMARY KEY(account_id,day_key,task_id),
 FOREIGN KEY(account_id,task_id) REFERENCES learner_app.daily_tasks(account_id,task_id)
);
COMMENT ON TABLE learner_app.daily_items IS 'Independent daily goals. Trading history resets never modify these rows. Past-day task titles are snapshots.';
REVOKE ALL ON learner_app.daily_tasks,learner_app.daily_items FROM PUBLIC;
COMMIT;
