import {NextResponse,type NextRequest} from 'next/server';
import {privateSiteAccess} from './lib/learner/private-owner.mjs';
import {verifyPrivateOwnerRequest} from './lib/learner/runtime.mjs';
import {isRetiredTeacherPage} from './lib/portal/retired-teacher.mjs';
import {speakChartAccess} from './lib/speak-chart/access.mjs';
import {handleRenderRequest} from './lib/portal/render-runtime.mjs';
import {teacherRouteAccess,lessonRouteAccess} from './lib/portal/teacher-route-guard.mjs';

export async function proxy(request:NextRequest) {
  const access=await privateSiteAccess(request,verifyPrivateOwnerRequest);
  if(!access.allowed){
    const headers={'Cache-Control':'private, no-store','Vary':'Cookie','Referrer-Policy':'no-referrer'};
    if(request.nextUrl.pathname.startsWith('/api/')||request.nextUrl.pathname.startsWith('/_next/')||request.headers.get('rsc')==='1'||request.headers.get('accept')?.includes('text/x-component'))return NextResponse.json({code:access.status===503?'auth_unavailable':'owner_only',error:access.status===503?'Sign-in verification is temporarily unavailable.':'Sign in with the owner’s Google account.'},{status:access.status===503?503:access.status===401?401:403,headers});
    const response=NextResponse.redirect(new URL('/sign-in',request.url),303);for(const [key,value]of Object.entries(headers))response.headers.set(key,value);return response;
  }
  if(access.public){const response=NextResponse.next();response.headers.set('Cache-Control','private, no-store');return response;}
  const path=request.nextUrl.pathname;
  const protectedTeacher=path==='/speak-the-chart'||path.startsWith('/speak-the-chart/')||path==='/library'||path.startsWith('/library/')||path==='/studio'||path.startsWith('/studio/')||path==='/editor'||path.startsWith('/editor/')||path==='/admin/lesson-preview'||path.startsWith('/admin/lesson-preview/')||path==='/admin/modules'||path.startsWith('/admin/modules/');
  if(!protectedTeacher&&!isRetiredTeacherPage(path)){const response=NextResponse.next();response.headers.set('Cache-Control','private, no-store');response.headers.set('Vary','Cookie');return response;}
  if(isRetiredTeacherPage(request.nextUrl.pathname)) return NextResponse.redirect(new URL('/',request.url),303);
  const guard=request.nextUrl.pathname==='/speak-the-chart'||request.nextUrl.pathname.startsWith('/speak-the-chart/')?speakChartAccess:request.nextUrl.pathname==='/library'||request.nextUrl.pathname.startsWith('/library/')?lessonRouteAccess:teacherRouteAccess;
  const result=await guard(request,handleRenderRequest);
  if(result.allowed){const response=NextResponse.next();response.headers.set('Cache-Control','private, no-store');return response;}
  // The owner gate permits its exact sign-in routes; teacher access keeps its separate login.
  const response=NextResponse.redirect(new URL('/admin',request.url),303);
  response.headers.set('Cache-Control','private, no-store');return response;
}
export const config={matcher:['/:path*']};
