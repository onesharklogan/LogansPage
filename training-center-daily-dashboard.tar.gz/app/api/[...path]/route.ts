import { handleRenderRequest } from '@/lib/portal/render-runtime.mjs';
import {verifyPrivateOwnerRequest} from '@/lib/learner/runtime.mjs';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const GET = async (request: Request) => {
  const access=await verifyPrivateOwnerRequest(request);
  if(!access.ok)return Response.json({code:access.status===503?'auth_unavailable':'owner_only',error:'Private owner sign-in is required.'},{status:access.status,headers:{'Cache-Control':'private, no-store'}});
  return handleRenderRequest(request);
};
export const POST = GET;
export const PATCH = GET;
export const DELETE = GET;
export const PUT = GET;
export const OPTIONS = GET;
export const HEAD = GET;
