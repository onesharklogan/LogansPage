import {learnerConfiguration} from '../../../lib/learner/google-config.mjs';
import LearnerSignInReturn from '../../../components/learner-sign-in-return';
export const dynamic='force-dynamic';
export const metadata={title:'PATC Sign In',robots:{index:false,follow:false},referrer:'no-referrer' as const};
export default function Page(){if(!learnerConfiguration())return <main className="training-main"><h1>Sign-in is temporarily unavailable</h1><p role="status">Private access cannot be verified right now. Your saved history has not been changed.</p><a href="/sign-in">Return to sign-in</a></main>;return <LearnerSignInReturn/>;}
