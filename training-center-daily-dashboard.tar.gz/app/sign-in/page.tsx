import PrivateSignIn from '../../components/private-sign-in';
export const dynamic='force-dynamic';
export const metadata={title:'Sign in · Daily dashboard',robots:{index:false,follow:false},referrer:'no-referrer' as const};
export default function Page(){return <PrivateSignIn/>;}
