import DailyDashboard from '../components/daily-dashboard';
export const dynamic='force-dynamic';
export const metadata={title:'Daily Dashboard',description:'A little progress in every part of your day.'};
export default function Home(){return <DailyDashboard/>;}
