/** Select one loss without sorting or changing the session's complete trade history.
 * Equal losses keep their original execution order.
 * @template {{points:number}} T
 * @param {readonly T[]} trades
 * @returns {T | null}
 */
export function biggestLoss(trades) {
  return trades.reduce((worst, trade) => Number.isFinite(trade.points) && trade.points < 0 && (!worst || trade.points < worst.points) ? trade : worst, /** @type {T | null} */ (null));
}
