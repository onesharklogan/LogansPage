import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {requestAppearance} from '../lib/appearance-server.mjs';
const origin='https://learner.test',configuration=()=>({origin});
const headers=cookie=>new Headers({host:'learner.test',...(cookie?{cookie}:{})});
test('first paint uses a read-only verified profile for each request without sharing appearance',async()=>{
 const calls=[];
 const request=async r=>{calls.push(r);const id=r.headers.get('cookie');return Response.json({profile:{id},context:{accountId:id},preferences:{appearance:id==='A'?'light':'dark'}});};
 assert.equal(await requestAppearance(headers('A'),{configuration,request}),'light');
 assert.equal(await requestAppearance(headers('B'),{configuration,request}),'dark');
 assert.equal(await requestAppearance(headers(),{configuration,request}),'dark');
 assert.equal(calls.length,2);
 for(const call of calls){assert.equal(call.method,'GET');assert.equal(call.url,origin+'/api/learner/profile');assert.equal(call.headers.get('host'),'learner.test');}
});
test('unverified, expired, disabled and failed accounts default dark without guessing stored preferences',async()=>{
 for(const request of [async()=>Response.json({preferences:{appearance:'light'}}),async()=>Response.json({profile:{id:'A'},context:{accountId:'B'},preferences:{appearance:'light'}}),async()=>Response.json({}, {status:401}),async()=>{throw Error('offline');}])assert.equal(await requestAppearance(headers('A'),{configuration,request}),'dark');
 const request=async()=>{assert.fail('must not request another host or disabled auth');};
 assert.equal(await requestAppearance(new Headers({host:'foreign.test',cookie:'A'}),{configuration,request}),'dark');
 assert.equal(await requestAppearance(headers('A'),{configuration:()=>null,request}),'dark');
});
test('layout resolves appearance before rendering and client preserves only initial pending verification',()=>{
 const layout=fs.readFileSync(new URL('../app/layout.tsx',import.meta.url),'utf8');
 assert.match(layout,/await requestAppearance\(await headers\(\)\)/);
 assert.match(layout,/data-appearance=\{appearance\}/);
 assert.match(layout,/parent\.location\.origin===location\.origin/);
 const provider=fs.readFileSync(new URL('../components/appearance-provider.tsx',import.meta.url),'utf8');
 assert.match(provider,/!snapshot.ready&&!snapshot.reconcileRequired&&!snapshot.signOutNeeded&&!snapshot.error/);
 assert.doesNotMatch(provider,/(?:localStorage|sessionStorage)\s*\./);
});
