import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {randomUUID,createHash} from 'node:crypto';
import {PGlite} from '@electric-sql/pglite';
import {metadata,validatePattern} from '../lib/learner/pattern-encyclopedia.mjs';
import {PatternRepository} from '../lib/learner/pattern-repository.mjs';
import {createPatternClient} from '../lib/pattern-encyclopedia-client.mjs';
const root=new URL('../',import.meta.url);
const meta={title:'Study',description:'Description',expectation:'Continuation',notes:'',tags:[],exampleNotes:{}};
test('trading style is optional bounded text; omitted legacy command remains byte-for-byte stable',()=>{
 assert.deepEqual(metadata(meta),meta);assert.equal(Object.hasOwn(metadata(meta),'tradingStyle'),false);
 assert.equal(metadata({...meta,tradingStyle:'x'.repeat(500)}).tradingStyle.length,500);
 for(const tradingStyle of [null,42,'x'.repeat(501),'bad\u0001'])assert.throws(()=>metadata({...meta,tradingStyle}));
});
test('JSON metadata supports create/list/detail/edit/replay/conflict/trash/restore and legacy updates without migration',async()=>{
 const db=new PGlite();try{
 await db.exec('CREATE SCHEMA learner_app; CREATE TABLE learner_app.accounts(id uuid PRIMARY KEY); CREATE TABLE learner_app.schema_migrations(version integer,description text);');
 await db.exec(await readFile(new URL('migrations/025_pattern_encyclopedia.sql',root),'utf8'));
 const now=Date.now(),account={id:randomUUID(),generation:1},session={session_tag:'test',expires_at:now+1e6},principal={expiresAt:now+1e6};await db.query('INSERT INTO learner_app.accounts VALUES($1)',[account.id]);
 const repository=new PatternRepository({patternEncyclopediaEnabled:true,owned:(_p,_n,_f,fn)=>fn(db,account,session,now),check(){}});
 const raw=await readFile(new URL('public/charts/mes1-2026-11-05-81.json',root)),chart=JSON.parse(raw),sha=createHash('sha256').update(raw).digest('hex');
 const snapshot={version:1,algorithmVersion:'pattern-v1',matchedAt:new Date(now).toISOString(),searchOptions:{earlierOnly:false,limit:10},source:{chartId:chart.id,chartSha256:sha,startBar:2,endBar:3},matches:[]};
 const make=extra=>validatePattern({id:randomUUID(),...meta,...extra,snapshot},now);
 const write=(command)=>repository.write(principal,{},command,now,async(id,hash)=>{assert.equal(id,chart.id);assert.equal(hash,sha);return chart;});
 const pattern=make({tradingStyle:'Buy the pullback after confirmation.'}),id=pattern.id,command={action:'create',id,requestId:randomUUID(),pattern};
 const first=await write(command);assert.equal(first.pattern.tradingStyle,pattern.tradingStyle);assert.equal((await write(command)).duplicate,true);
 const list=await repository.list(principal,now,{state:'active',limit:25,cursor:null,sort:'alphabetical',query:'pullback'});assert.equal(list.patterns.length,1);assert.equal(list.patterns[0].tradingStyle,pattern.tradingStyle);
 assert.equal((await repository.detail(principal,id,now)).pattern.tradingStyle,pattern.tradingStyle);
 // Older clients omit the new field: keep its saved value without altering their command fingerprint.
 const oldUpdate={action:'update',id,requestId:randomUUID(),revision:1,changes:metadata({...meta,title:'Old client edit'})};
 assert.equal((await write(oldUpdate)).pattern.tradingStyle,pattern.tradingStyle);assert.equal((await write(oldUpdate)).duplicate,true);
 await assert.rejects(write({...oldUpdate,requestId:randomUUID()}),e=>e.status===409);
 const edited=await write({action:'update',id,requestId:randomUUID(),revision:2,changes:metadata({...meta,tradingStyle:'Sell only at resistance.'})});assert.equal(edited.pattern.tradingStyle,'Sell only at resistance.');
 for(const [action,revision] of [['delete',3],['restore',4]])assert.equal((await write({action,id,requestId:randomUUID(),revision})).pattern.tradingStyle,'Sell only at resistance.');
 const legacy=make({}),legacyCommand={action:'create',id:legacy.id,requestId:randomUUID(),pattern:legacy};assert.equal((await write(legacyCommand)).pattern.tradingStyle,'');
 await db.query("UPDATE learner_app.pattern_receipts SET response=jsonb_set(response,'{pattern}',(response->'pattern')-'tradingStyle') WHERE request_id=$1",[legacyCommand.requestId]);
 assert.equal((await write(legacyCommand)).pattern.tradingStyle,'');
 const cleared=await write({action:'update',id,requestId:randomUUID(),revision:5,changes:metadata({...meta,tradingStyle:''})});assert.equal(cleared.pattern.tradingStyle,'');
 // Client verifies a supplied field, tolerates a legacy missing field and exposes blank.
 const context=first.context,capture={context},client={captureContext:()=>capture,getSnapshot:()=>({ready:true,mode:'account',context,csrfToken:'test'}),guard:()=>true};
 const getClient=payload=>createPatternClient({client,fetcher:async()=>Response.json(payload)});
 const oldResponse=structuredClone(first);delete oldResponse.pattern.tradingStyle;
 assert.equal((await getClient(oldResponse).get(id)).pattern.tradingStyle,'');
 await assert.rejects(getClient(first).create({...pattern,tradingStyle:'Different'},randomUUID()),e=>e.code==='invalid_response');
 const invalid=structuredClone(first);invalid.pattern.tradingStyle=42;await assert.rejects(getClient(invalid).get(id),e=>e.code==='invalid_response');
 }finally{await db.close();}
});
