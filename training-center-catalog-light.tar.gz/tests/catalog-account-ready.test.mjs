import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {waitForCatalogAccount} from '../lib/catalog-account-ready.mjs';
function fixture(){let ready=false,owns=true,revalidating=true;const listeners=new Set();return {client:{guard:()=>ready&&owns,ownsCapture:()=>owns,getSnapshot:()=>({revalidating}),subscribe:f=>{listeners.add(f);return()=>listeners.delete(f);}},set(values){({ready=ready,owns=owns,revalidating=revalidating}=values);for(const f of listeners)f();},listeners};}
test('initial catalog and searches paused by account verification resume without Refresh',async()=>{
 for(const query of ['', 'Mobile edit']){const f=fixture();let calls=0;const pending=waitForCatalogAccount(f.client,{}).then(()=>{calls++;return query;});assert.equal(calls,0);f.set({ready:true,revalidating:false});assert.equal(await pending,query);assert.equal(calls,1);assert.equal(f.listeners.size,0);}
});
test('new search/unmount aborts stale waiting job and releases subscription',async()=>{
 const f=fixture(),a=new AbortController();const old=waitForCatalogAccount(f.client,{},a.signal);a.abort();await assert.rejects(old,/canceled/);assert.equal(f.listeners.size,0);
 const latest=waitForCatalogAccount(f.client,{});f.set({ready:true});await latest;assert.equal(f.listeners.size,0);
});
test('changed owner, verification failure and timeout never dispatch a read',async()=>{
 for(const change of [{owns:false},{revalidating:false}]){const f=fixture();const wait=waitForCatalogAccount(f.client,{});f.set(change);await assert.rejects(wait,/verification/);assert.equal(f.listeners.size,0);}
 const f=fixture();await assert.rejects(waitForCatalogAccount(f.client,{},undefined,5),/verification/);assert.equal(f.listeners.size,0);
});
test('catalog gets retained owner and cancels previous effect instead of silently returning on guard',()=>{
 const s=fs.readFileSync(new URL('../components/pattern-encyclopedia.tsx',import.meta.url),'utf8');
 assert.match(s,/<PatternContent id=\{id\} owner=\{account.capture\}/);
 assert.match(s,/<PatternCatalog owner=\{owner\}/);
 assert.match(s,/await waitForCatalogAccount\(learnerClient,capture.current,signal\)/);
 assert.match(s,/void load\(false,controller.signal\)/);
 assert.doesNotMatch(s,/async function load\([^)]*\)\{if\(locked.current\|\|!learnerClient.guard/);
});
