import PatternMatch from '../../components/pattern-match';
export const metadata={title:'PATC Pattern Match',description:'Highlight 2–25 bars and study similar historical MES candle patterns. Similarity is not a prediction.'};
export default function PatternMatchPage(){return <PatternMatch/>;}
