'use client';
import {useEffect,useRef,useState,type FormEvent} from 'react';
import LoadingIndicator from './loading-indicator';
import styles from './life-lessons.module.css';

type Owner={accountId:string;generation:number;sessionTag:string};
type Lesson={id:string;text:string;createdAt:string;revision:number;removed:boolean};
type Page={context:Owner;lessons:Lesson[];nextCursor:string|null};
const key=(owner?:Owner)=>owner?JSON.stringify([owner.accountId,owner.generation,owner.sessionTag]):'';
async function request(url:string,init?:RequestInit){
 const response=await fetch(url,{...init,credentials:'same-origin',cache:'no-store'});
 if(!response.ok)throw Object.assign(new Error('Could not confirm your life lessons. Try again.'),{status:response.status});
 return await response.json();
}
export default function LifeLessons({owner}:{owner?:Owner}){
 const ownerKey=key(owner),shownOwner=useRef(ownerKey);shownOwner.current=ownerKey;
 const active=useRef(''),epoch=useRef(0),controller=useRef<AbortController|null>(null),csrf=useRef('');
 const submission=useRef<{id:string;text:string}|null>(null),input=useRef<HTMLTextAreaElement>(null);
 const [page,setPage]=useState<Page|null>(null),[text,setText]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState(''),[status,setStatus]=useState('');
 const [removedView,setRemovedView]=useState(false),[editing,setEditing]=useState<Lesson|null>(null),[editText,setEditText]=useState('');
 const current=(ticket:number,k:string)=>ticket===epoch.current&&active.current===k&&shownOwner.current===k;
 async function run(work:(signal:AbortSignal,ticket:number,k:string)=>Promise<void>){
  const k=active.current;if(!k||k!==shownOwner.current||controller.current)return;
  const ticket=++epoch.current,job=new AbortController();controller.current=job;setBusy(true);setError('');setStatus('');
  try{await work(job.signal,ticket,k);}catch(e){
   if(!current(ticket,k))return;
   if([401,403].includes((e as {status?:number}).status??0)){csrf.current='';setPage(null);}
   setError(e instanceof Error?e.message:'Could not confirm your life lessons. Try again.');
  }finally{if(controller.current===job)controller.current=null;if(current(ticket,k))setBusy(false);}
 }
 function load(cursor?:string,removed=removedView){
  void run(async(signal,ticket,k)=>{
   if(!csrf.current){const session=await request('/api/learner/session',{signal});
    if(!session.profile||key(session.context)!==k||typeof session.csrfToken!=='string')throw Object.assign(new Error('Your account changed. Reload Daily Balance.'),{status:401});
    if(!current(ticket,k))return;csrf.current=session.csrfToken;
   }
   const qs=new URLSearchParams();if(cursor)qs.set('cursor',cursor);if(removed)qs.set('state','removed');
   const next:Page=await request('/api/learner/life-lessons'+(qs.size?'?'+qs:''),{signal});
   if(key(next.context)!==k)throw Object.assign(new Error('Your account changed. Reload Daily Balance.'),{status:401});
   if(current(ticket,k)){setRemovedView(removed);setEditing(null);setEditText('');setPage(previous=>cursor&&previous?{...next,lessons:[...previous.lessons,...next.lessons.filter(lesson=>!previous.lessons.some(existing=>existing.id===lesson.id))]}:next);}
  });
 }
 useEffect(()=>{
  if(!ownerKey){setBusy(false);return;}
  if(active.current!==ownerKey){active.current=ownerKey;csrf.current='';submission.current=null;setPage(null);setText('');setEditText('');setEditing(null);setRemovedView(false);setError('');setStatus('');load(undefined,false);}
  else if(!page)load();
  return()=>{epoch.current++;controller.current?.abort();controller.current=null;};
 },[ownerKey]);
 useEffect(()=>{
  if(!text.trim()&&!editText.trim())return;
  const warn=(e:BeforeUnloadEvent)=>{e.preventDefault();e.returnValue='';};
  window.addEventListener('beforeunload',warn);return()=>window.removeEventListener('beforeunload',warn);
 },[text,editText]);
 function add(event:FormEvent){
  event.preventDefault();const trimmed=text.trim();if(!page||!trimmed||!csrf.current||controller.current||key(page.context)!==ownerKey)return;
  if(submission.current?.text!==trimmed)submission.current={id:crypto.randomUUID(),text:trimmed};
  const command=submission.current;
  void run(async(signal,ticket,k)=>{
   const saved:{context:Owner;lesson:Lesson}=await request('/api/learner/life-lessons',{method:'POST',signal,headers:{'Content-Type':'application/json','X-CSRF-Token':csrf.current},body:JSON.stringify({context:page.context,...command})});
   if(key(saved.context)!==k||saved.lesson?.id!==command.id||saved.lesson?.text!==command.text)throw new Error('Save not confirmed. Your draft is still here.');
   if(!current(ticket,k))return;
   setPage(previous=>previous?{...previous,lessons:[saved.lesson,...previous.lessons.filter(lesson=>lesson.id!==saved.lesson.id)]}:previous);
   submission.current=null;setText('');setStatus('Lesson saved.');
  });
 }
 useEffect(()=>{if(status==='Lesson saved.'&&!busy)input.current?.focus();},[status,busy]);
 function mutate(action:'edit'|'remove'|'restore',lesson:Lesson){
  if(!page||!csrf.current||controller.current||key(page.context)!==ownerKey)return;
  const nextText=editText.trim();if(action==='edit'&&!nextText)return;
  const command={context:page.context,id:lesson.id,revision:lesson.revision,action,...(action==='edit'?{text:nextText}:{})};
  void run(async(signal,ticket,k)=>{
   const saved:{context:Owner;lesson:Lesson}=await request('/api/learner/life-lessons',{method:'POST',signal,headers:{'Content-Type':'application/json','X-CSRF-Token':csrf.current},body:JSON.stringify(command)});
   if(key(saved.context)!==k||saved.lesson?.id!==lesson.id||saved.lesson.removed!==(action==='remove')||(action==='edit'&&saved.lesson.text!==nextText))throw new Error('Lesson change not confirmed. Try again.');
   if(!current(ticket,k))return;
   setPage(previous=>previous?{...previous,lessons:action==='edit'?previous.lessons.map(item=>item.id===lesson.id?saved.lesson:item):previous.lessons.filter(item=>item.id!==lesson.id)}:previous);
   setEditing(null);setEditText('');
   setStatus(action==='edit'?'Lesson updated.':action==='remove'?'Lesson moved to Trash. You can restore it anytime.':'Lesson restored.');
  });
 }
 const visible=page&&ownerKey===active.current&&key(page.context)===ownerKey?page:null;
 return <section className={styles.panel} aria-labelledby="life-lessons-heading">
  <h2 id="life-lessons-heading">New life lessons</h2>
  {!visible?(error&&ownerKey===active.current?<><p className={styles.error} role="alert">{error}</p><button type="button" onClick={()=>load()}>Retry lessons</button></>:<p role="status"><LoadingIndicator size="small" label="Loading life lessons…" /></p>):<>
   <button type="button" disabled={busy||!!editing} onClick={()=>load(undefined,!removedView)}>{removedView?'Back to lessons':'View Trash'}</button>
   {!removedView&&<form onSubmit={add}><label htmlFor="life-lesson">What did you learn?</label><textarea ref={input} id="life-lesson" rows={3} maxLength={2000} disabled={busy} value={text} onChange={e=>setText(e.target.value)} placeholder="A lesson you want to remember…" /><button disabled={busy||!text.trim()}>Add lesson</button></form>}
   {error&&<p className={styles.error} role="alert">{error}</p>}{status&&<p role="status">{status}</p>}
   {visible.lessons.length?<ul>{visible.lessons.map(lesson=><li key={lesson.id}>
    {editing?.id===lesson.id?<form onSubmit={e=>{e.preventDefault();mutate('edit',lesson);}}>
     <label htmlFor="edit-life-lesson">Edit lesson</label><textarea id="edit-life-lesson" autoFocus value={editText} onChange={e=>setEditText(e.target.value)} maxLength={2000} rows={3} disabled={busy}/>
     <div className={styles.actions}><button disabled={busy||!editText.trim()}>Save changes</button><button type="button" disabled={busy} onClick={()=>{setEditing(null);setEditText('');}}>Cancel</button></div>
    </form>:<><span>{lesson.text}</span><div className={styles.actions}>{removedView?<button type="button" disabled={busy} onClick={()=>mutate('restore',lesson)}>Restore</button>:<>
     <button type="button" className={styles.iconAction} disabled={busy||!!editing} aria-label="Edit lesson" title="Edit lesson" onClick={()=>{setEditing(lesson);setEditText(lesson.text);}}>
      <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m4 16-.9 4.9L8 20l12-12-4-4L4 16Zm10-10 4 4" /></svg>
     </button>
     <button type="button" className={styles.iconAction} disabled={busy||!!editing} aria-label="Move lesson to Trash" title="Move lesson to Trash" onClick={()=>{if(window.confirm('Move this lesson to Trash? You can restore it later.'))mutate('remove',lesson);}}>
      <svg viewBox="8 6 20 23" aria-hidden="true" focusable="false"><path d="M12 13h12m-10 0 1 12h6l1-12m-6 0v-3h4v3m-3 3v6m2-6v6" /></svg>
     </button>
    </>}</div></>}
   </li>)}</ul>:<p>{removedView?'Trash is empty.':'No life lessons yet.'}</p>}
   {error&&<button type="button" disabled={busy} onClick={()=>load()}>Reload lessons</button>}
   {visible.nextCursor&&<button type="button" disabled={busy||!!editing} onClick={()=>load(visible.nextCursor!)}>Show older lessons</button>}
  </>}
 </section>;
}
