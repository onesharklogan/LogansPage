import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {favoritePriceView,initialView,resetViewAxis,replayViewport} from '../lib/trade-simulator-view.mjs';
test('favorite scale applies only to vertical navigation, falls back exactly to default with no favorite',()=>{
 const manual={...initialView(),xZoom:2,offset:20,follow:false,priceCenter:200,priceSpan:10,yZoom:3,manualPrice:true,rightPadding:1};
 const baseline=resetViewAxis(manual,'price');
 for(const value of [null,undefined,NaN,Infinity,-1,9,'2'])assert.deepEqual(favoritePriceView(manual,value),baseline);
 assert.deepEqual(favoritePriceView(manual,.25),{...baseline,yZoom:.25});assert.deepEqual(favoritePriceView(manual,8),{...baseline,yZoom:8});
 assert.deepEqual(favoritePriceView(initialView(),null),initialView());
 const chart={prior:[],current:[{l:100,h:200,c:180},{l:-9000,h:9000,c:0}]};
 const original=replayViewport(chart,0,[],900,430,initialView()), favorite=replayViewport(chart,0,[],900,430,favoritePriceView(initialView(),.5));
 assert.equal(favorite.visible.length,1);assert.equal(favorite.visible[0].l,100);
 assert.equal(favorite.hi-favorite.lo,2*(original.hi-original.lo));
});
test('save and reset controls use owner adapter and do not run or save a trade',()=>{
 const s=fs.readFileSync(new URL('../components/trade-simulator.tsx',import.meta.url),'utf8'),save=s.slice(s.indexOf('async function savePriceScale'),s.indexOf('function axisDown'));
 assert.match(s,/scaleSupported&&<>.*Save Scale.*Reset Scale/s);
 assert.match(save,/store\.saveFavoriteTradeScale\(profileAccess\.profile,value,\{guard\}\)/);
 assert.doesNotMatch(save,/checkpoint\(|commit\(|placeBracket\(/);
 assert.match(s,/setNavigation\(nav=>favoritePriceView\(nav,favoriteTradeScale.current\)\)/);
});
