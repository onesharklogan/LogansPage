-- Additive account preference only; null preserves the existing default scale.
BEGIN;
SET LOCAL lock_timeout = '5s';
ALTER TABLE learner_app.accounts
 ADD COLUMN favorite_trade_scale double precision
 CONSTRAINT learner_favorite_trade_scale_check CHECK (favorite_trade_scale BETWEEN 0.25 AND 8);
GRANT SELECT (favorite_trade_scale), UPDATE (favorite_trade_scale) ON learner_app.accounts TO learner_runtime;
COMMIT;
