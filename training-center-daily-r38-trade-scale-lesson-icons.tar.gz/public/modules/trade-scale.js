/** The Trade Simulator's existing vertical zoom range. */
export const validFavoriteTradeScale=value=>typeof value==='number'&&Number.isFinite(value)&&value>=.25&&value<=8;
