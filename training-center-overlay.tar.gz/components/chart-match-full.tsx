'use client';
import {chartSourceNotice} from '../lib/session-source.mjs';

import {useEffect,useMemo,useRef,useState,type PointerEvent,type KeyboardEvent} from 'react';
import AppHeader from './app-navigation';
import LoadingIndicator from './loading-indicator';
import LearnerAccountControl from './learner-account-control';
import LearnerProfiles from '../public/modules/learner-profiles.js';
import {loadSimulatorCatalog,loadSimulatorChart} from './trade-simulator-data.mjs';
import {buildCalendar} from '../lib/session-calendar.mjs';
import {fullChartFrame,validateFullChart,type FullChartRequest,type ViewerChart} from '../lib/chart-match-full.mjs';
import {initialView,replayPoint,dragView,zoomTime,panTime,resetViewAxis,priceAxisHandle,hiddenRevealed,focusHidden,type ViewNavigation,type ReplayGeometry} from '../lib/trade-simulator-view.mjs';
import styles from './chart-match-full.module.css';

type Gesture={id:number;key:string;x:number;y:number;sx:number;sy:number;mode:'plot'|'price'|'time';view:ReplayGeometry;nav:ViewNavigation};
const fit=()=>resetViewAxis(initialView(),'fit');
const format=(v:number)=>v.toFixed(2);
const direction=(key:string)=>({w:'ArrowUp',a:'ArrowLeft',s:'ArrowDown',d:'ArrowRight'}[key.toLowerCase()]||key);
const keyBlocked=(event:KeyboardEvent)=>event.defaultPrevented||event.nativeEvent?.isComposing||event.nativeEvent?.keyCode===229||event.keyCode===229||event.ctrlKey||event.metaKey||event.altKey||(event.shiftKey&&event.key!=='+');

/** Read-only chart view: no simulator instance, profile gate, attempt or persistent view state. */
export default function ChartMatchFull({request,initialError='',learnerAccounts=false}:{request:FullChartRequest|null;initialError?:string;learnerAccounts?:boolean}){
  const key=request?request.sessionId+':'+request.endBar:'invalid';
  const [loaded,setLoaded]=useState<{key:string;chart:ViewerChart|null;error:string}>({key:'',chart:null,error:''});
  const [retry,setRetry]=useState(0),[revealed,setRevealed]=useState(false),[ema,setEma]=useState(true),[navigation,setNavigation]=useState<ViewNavigation>(fit);
  const [size,setSize]=useState({width:900,height:430}),[name,setName]=useState<string|null>(null),[message,setMessage]=useState('');
  const page=useRef<HTMLDivElement>(null),host=useRef<HTMLDivElement>(null),svg=useRef<SVGSVGElement>(null),gesture=useRef<Gesture|null>(null),generation=useRef(0),actionEpoch=useRef(0),alive=useRef(true),latestKey=useRef(key);
  const [accountPanelOpen,setAccountPanelOpen]=useState(false),accountPanel=useRef(false),accountMode=useRef(learnerAccounts);accountMode.current=learnerAccounts;
  latestKey.current=key;
  const chart=loaded.key===key?loaded.chart:null,error=initialError||(!request?'This chart link is invalid. Open a full chart from a Chart Match result.':'')||(loaded.key===key?loaded.error:''),loading=!!request&&!chart&&!error;
  const renderEpoch=actionEpoch.current,currentState=useRef({chart,error});currentState.current={chart,error};
  const frame=useMemo(()=>chart&&request?fullChartFrame(chart,request.endBar,revealed,size.width,size.height,navigation):null,[chart,request?.endBar,revealed,size.width,size.height,navigation]);
  const view=frame?.geometry,hidden=chart&&frame?hiddenRevealed(chart,frame.index,frame.geometry):null;
  function release(){const drag=gesture.current;gesture.current=null;if(drag&&svg.current?.hasPointerCapture?.(drag.id))svg.current.releasePointerCapture(drag.id)}
  function cancelDrag(){const drag=gesture.current;release();if(drag&&drag.key===latestKey.current)setNavigation(drag.nav)}
  useEffect(()=>{alive.current=true;return()=>{alive.current=false;generation.current++;release()}},[]);
  useEffect(()=>{
    cancelDrag();actionEpoch.current++;setRevealed(false);setNavigation(fit());setMessage('');
    if(!request)return;
    const controller=new AbortController(),epoch=++generation.current;
    setLoaded({key,chart:null,error:''});
    const timeout=setTimeout(()=>{controller.abort();if(alive.current&&generation.current===epoch&&latestKey.current===key)setLoaded({key,chart:null,error:'Chart loading timed out. Retry, or return to Chart Match.'})},12000);
    (async()=>{try{
      const entries=await loadSimulatorCatalog({signal:controller.signal}),model=buildCalendar(entries),reference=model.entries.find(entry=>entry.id===request.sessionId);
      if(controller.signal.aborted||!alive.current||generation.current!==epoch||latestKey.current!==key)return;
      if(!reference)throw Error('This session is not in the available chart catalog.');
      const data=validateFullChart(await loadSimulatorChart(reference,{signal:controller.signal}),request);
      if(!controller.signal.aborted&&alive.current&&generation.current===epoch&&latestKey.current===key)setLoaded({key,chart:data,error:''});
    }catch{if(!controller.signal.aborted&&alive.current&&generation.current===epoch&&latestKey.current===key)setLoaded({key,chart:null,error:'The session or matched endpoint could not be verified. Retry, or return to Chart Match.'});}finally{clearTimeout(timeout)}})();
    return()=>{clearTimeout(timeout);controller.abort()};
  },[key,retry]);
  useEffect(()=>{
    const refresh=()=>{if(accountMode.current){setName(null);return;}try{const s=LearnerProfiles.read();setName(s.ok&&LearnerProfiles.validLearnerId(s.active?.learnerId)?s.active.name:null)}catch{setName(null)}};
    refresh();for(const event of ['storage','focus','pageshow'])window.addEventListener(event,refresh);
    return()=>{for(const event of ['storage','focus','pageshow'])window.removeEventListener(event,refresh)};
  },[]);
  useEffect(()=>{
    const node=host.current;if(!node)return;
    const resize=()=>{const rect=node.getBoundingClientRect();if(rect.width>0&&rect.height>0){cancelDrag();setSize({width:Math.max(100,rect.width),height:Math.max(100,rect.height)})}};
    resize();const observer=typeof ResizeObserver==='undefined'?null:new ResizeObserver(resize);observer?.observe(node);window.addEventListener('resize',resize);window.visualViewport?.addEventListener('resize',resize);
    return()=>{observer?.disconnect();window.removeEventListener('resize',resize);window.visualViewport?.removeEventListener('resize',resize)};
  },[!!chart]);
  useEffect(()=>{const stop=()=>cancelDrag();const visibility=()=>{if(document.hidden)stop()};window.addEventListener('blur',stop);window.addEventListener('pagehide',stop);document.addEventListener('visibilitychange',visibility);return()=>{window.removeEventListener('blur',stop);window.removeEventListener('pagehide',stop);document.removeEventListener('visibilitychange',visibility)}},[]);
  const ready=()=>!accountPanel.current&&alive.current&&latestKey.current===key&&renderEpoch===actionEpoch.current&&currentState.current.chart===chart&&currentState.current.error===error&&!!chart&&!!view&&!error;
  function retryChart(){if(accountPanel.current||!request||!alive.current||latestKey.current!==key||renderEpoch!==actionEpoch.current)return;cancelDrag();actionEpoch.current++;generation.current++;setLoaded({key,chart:null,error:''});setRetry(value=>value+1)}
  function reset(mode:'fit'|'price'|'time'){if(!ready())return;cancelDrag();setNavigation(nav=>resetViewAxis(nav,mode))}
  function adjustTime(factor:number){if(!ready()||!view)return;cancelDrag();setNavigation(nav=>zoomTime(nav,factor,view))}
  function toggleRemaining(){if(!ready())return;cancelDrag();setRevealed(value=>!value);setNavigation(fit())}
  function pointerDown(event:PointerEvent<SVGSVGElement>){
    if(!ready()||!view||event.button!==0||![event.clientX,event.clientY].every(Number.isFinite))return;
    if((event.target as Element).closest('[data-hidden-control]'))return;
    if(gesture.current){cancelDrag();return}
    const rect=event.currentTarget.getBoundingClientRect();if(!rect.width||!rect.height)return;
    const x=(event.clientX-rect.left)*view.width/rect.width,y=(event.clientY-rect.top)*view.height/rect.height;
    event.preventDefault();event.stopPropagation();
    gesture.current={id:event.pointerId,key,x:event.clientX,y:event.clientY,sx:view.width/rect.width,sy:view.height/rect.height,mode:x>=view.width-view.right?'price':y>=view.height-view.bottom?'time':'plot',view,nav:navigation};
    try{event.currentTarget.setPointerCapture(event.pointerId)}catch{gesture.current=null;return}
    const axis=(event.target as Element).closest<SVGGElement>('[data-axis]');(axis||event.currentTarget).focus?.({preventScroll:true});
  }
  function pointerMove(event:PointerEvent<SVGSVGElement>){
    const drag=gesture.current;if(!drag||drag.id!==event.pointerId||drag.key!==key||!ready())return;
    if(![event.clientX,event.clientY].every(Number.isFinite)){cancelDrag();return}
    event.preventDefault();setNavigation(dragView(drag.nav,drag.mode,(event.clientX-drag.x)*drag.sx,(event.clientY-drag.y)*drag.sy,drag.view));
  }
  function pointerEnd(event:PointerEvent<SVGSVGElement>,cancel=false){
    const drag=gesture.current;if(!drag||drag.id!==event.pointerId)return;
    if(cancel||![event.clientX,event.clientY].every(Number.isFinite)){cancelDrag();return}
    pointerMove(event);release();
  }
  function keys(event:KeyboardEvent<SVGSVGElement>){
    if(keyBlocked(event)||!ready()||!view||(event.target as Element).closest('[data-hidden-control],input,textarea,select,button,[contenteditable]'))return;
    const pressed=direction(event.key),mode=(event.target as Element).closest('[data-axis]')?.getAttribute('data-axis')||'plot';
    if(pressed==='Escape'){event.preventDefault();event.stopPropagation();cancelDrag();return}
    if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','+','=','-'].includes(pressed))return;
    event.preventDefault();event.stopPropagation();cancelDrag();
    if(pressed==='Home'){reset(mode==='price'?'price':mode==='time'?'time':'fit');return}
    if(['+','=','-'].includes(pressed)){adjustTime(pressed==='-'?1/1.2:1.2);return}
    if(mode==='price'){if(['ArrowUp','ArrowDown'].includes(pressed))setNavigation(nav=>dragView(nav,'price',0,pressed==='ArrowUp'?-24:24,view));return}
    if(mode==='time'){if(['ArrowLeft','ArrowRight'].includes(pressed))adjustTime(pressed==='ArrowLeft'?1.2:1/1.2);return}
    if(pressed==='ArrowLeft'||pressed==='ArrowRight')setNavigation(nav=>panTime(nav,pressed==='ArrowLeft'?'left':'right',view));
    else setNavigation(nav=>dragView(nav,'plot',0,pressed==='ArrowUp'?30:-30,view));
  }
  function showHidden(){if(!ready()||!chart||!frame||!hidden)return;cancelDrag();setNavigation(nav=>focusHidden(nav,frame.geometry,hidden,chart,frame.index))}
  async function fullscreen(){if(!ready())return;try{if(document.fullscreenElement===page.current)await document.exitFullscreen();else if(page.current?.requestFullscreen)await page.current.requestFullscreen();else throw Error('unsupported')}catch{if(alive.current&&latestKey.current===key&&actionEpoch.current===renderEpoch)setMessage('Full screen is unavailable in this browser. The chart already fills this tab.')}}
  return <div className={styles.page} ref={page}>
    {chartSourceNotice(chart)&&<p data-session-source>{chartSourceNotice(chart)}</p>}
    <AppHeader section="CHART MATCH · FULL" current="/chart-match">{learnerAccounts?<LearnerAccountControl onOpenChange={open=>{accountPanel.current=open;if(open)cancelDrag();setAccountPanelOpen(open);}} navigationWarning="This read-only chart does not save a practice attempt. Account history belongs only to completed simulator practice."/>:name&&<span className={styles.profile} title="Existing local browser profile. This read-only chart does not save a practice attempt."><small>Local learner</small><strong>{name}</strong></span>}</AppHeader>
    <main className={styles.main} inert={accountPanelOpen}><h1 className={styles.srOnly}>Full matched chart</h1>
      {error||loading||!chart||!request?<div className={styles.error} role={error?'alert':'status'}><p>{error||<LoadingIndicator label="Loading the verified MES session…"/>}</p>{error&&request&&<button type="button" onClick={retryChart}>Retry chart</button>}<a href="/chart-match">Back to Chart Match</a></div>:<>
        <div className={styles.caption}><strong>{chart.date} · MES · matched bar {request.endBar}</strong><span>{frame!.index+1}/{chart.current.length} shown · read-only</span></div>
        <div className={styles.host} ref={host}><svg ref={svg} className={styles.chart} viewBox={'0 0 '+size.width+' '+size.height} preserveAspectRatio="none" role="group" tabIndex={0} aria-label={'MES '+chart.date+'. Matched opening through bar '+request.endBar+'. '+(revealed||request.endBar>=chart.current.length?'Full session revealed.':'Only matched prefix revealed. Remaining candles hidden.')} aria-describedby="match-full-help" onPointerDown={pointerDown} onPointerMove={pointerMove} onPointerUp={event=>pointerEnd(event)} onPointerCancel={event=>pointerEnd(event,true)} onLostPointerCapture={()=>cancelDrag()} onKeyDown={keys} onDoubleClick={event=>{const target=(event.target as Element).closest('[data-axis]')?.getAttribute('data-axis');if(target==='price'||target==='time'){event.preventDefault();reset(target)}}}>
          <defs><clipPath id="match-full-plot"><rect x={view!.left} y={view!.top} width={view!.width-view!.left-view!.right} height={view!.height-view!.top-view!.bottom}/></clipPath></defs>
          <rect width={size.width} height={size.height} fill="#000"/>
          {Array.from({length:5},(_,i)=>{const price=view!.hi-(view!.hi-view!.lo)*i/4,y=replayPoint(0,price,view!).y;return <g key={i} pointerEvents="none"><line x1={view!.left} x2={view!.width-view!.right} y1={y} y2={y} stroke="#203248"/><text x={view!.width-6} y={y+4} textAnchor="end" fill="#8ea8be" fontSize="11">{format(price)}</text></g>})}
          <g clipPath="url(#match-full-plot)" data-layer="visible-candles">{view!.visible.map(c=>{const o=replayPoint(c.slot,c.o,view!),h=replayPoint(c.slot,c.h,view!),l=replayPoint(c.slot,c.l,view!),close=replayPoint(c.slot,c.c,view!),color=c.c>=c.o?'#67dfb3':'#f18da6',w=Math.max(.7,view!.step*.56);return <g key={c.slot} opacity={c.prior?.78:1} data-current-index={c.prior?undefined:c.index} data-prior={c.prior}><rect x={o.x-view!.step/2} y={view!.top} width={view!.step} height={view!.height-view!.top-view!.bottom} fill={c.prior?'#23304066':'transparent'}/><line x1={h.x} x2={h.x} y1={h.y} y2={l.y} stroke={color} strokeWidth={Math.min(1.4,Math.max(.6,view!.step*.3))}/><rect x={o.x-w/2} y={Math.min(o.y,close.y)} width={w} height={Math.max(1,Math.abs(o.y-close.y))} fill={color}/><title>{(c.prior?'Prior context':'Bar '+(c.index+1))+' · '+c.t+' · O '+c.o+' H '+c.h+' L '+c.l+' C '+c.c}</title>{!c.prior&&<text x={o.x} y={Math.max(view!.top+10,h.y-7)} textAnchor="middle" fontSize={Math.max(7,Math.min(10,view!.step/1.35))} fill="#a2b0c1">{c.index+1}</text>}</g>})}
            {ema&&view!.visibleEma.length>1&&<path data-indicator="ema20" d={view!.visibleEma.map((point,index)=>{const p=replayPoint(point.slot,point.value,view!);return(index?'L':'M')+' '+p.x+' '+p.y}).join(' ')} fill="none" stroke="#f6c760" strokeWidth="2" pointerEvents="none"/>}
            {ema&&view!.visibleEma.length===1&&<circle data-indicator="ema20" cx={replayPoint(view!.visibleEma[0].slot,view!.visibleEma[0].value,view!).x} cy={replayPoint(view!.visibleEma[0].slot,view!.visibleEma[0].value,view!).y} r="3" fill="#f6c760"/>}
            {view!.priorClose!==null&&<line x1={view!.left} x2={view!.width-view!.right} y1={replayPoint(0,view!.priorClose,view!).y} y2={replayPoint(0,view!.priorClose,view!).y} stroke="#e4cc95" strokeWidth="1.25" strokeDasharray="5 5"/>}
            <line data-matched-endpoint={request.endBar} x1={frame!.matchedX} x2={frame!.matchedX} y1={view!.top} y2={view!.height-view!.bottom} stroke="#ffcf7c" strokeWidth="2" strokeDasharray="5 4" pointerEvents="none"/>
          </g>
          {frame!.matchedX>=view!.left&&frame!.matchedX<=view!.width-view!.right&&<text x={Math.max(view!.left+45,Math.min(view!.width-view!.right-95,frame!.matchedX))} y={view!.top-12} textAnchor="middle" fill="#ffcf7c" fontSize="11">Matched to {request.endBar}</text>}
          {view!.visible.filter((c,i)=>i===0||!c.prior&&c.index%Math.max(6,Math.ceil(48/view!.step/6)*6)===0).map(c=><text key={c.slot} x={replayPoint(c.slot,0,view!).x} y={view!.height-17} fill={c.prior?'#758496':'#90a2b9'} fontSize="10" textAnchor="middle">{c.t?.slice(-5)}</text>)}
          <g className={styles.timeAxis} data-axis="time" role="slider" tabIndex={0} aria-label="Time scale. Drag horizontally; Left or A widens candles, Right or D narrows candles, Home resets." aria-valuemin={.05} aria-valuemax={4} aria-valuenow={navigation.xZoom}><rect x={0} y={view!.height-view!.bottom} width={view!.width-view!.right} height={view!.bottom} fill="#24415c" fillOpacity=".14"/></g>
          <g className={styles.axis} data-axis="price" role="slider" aria-orientation="vertical" tabIndex={0} aria-label="Price scale. Drag up or down; Up or W zooms in, Down or S zooms out, Home resets." aria-valuemin={.25} aria-valuemax={8} aria-valuenow={navigation.yZoom}><rect {...priceAxisHandle(view!)} fill="#24415c" fillOpacity=".22"/><text x={view!.width-view!.right/2} y={18} textAnchor="middle" fill="#c7dfef" fontSize="10" pointerEvents="none">↕ DRAG</text></g>
          {hidden&&<g className={styles.hiddenButton} data-hidden-control="true" role="button" tabIndex={0} aria-label={hidden.label} onClick={event=>{event.stopPropagation();showHidden()}} onKeyDown={event=>{if(!keyBlocked(event)&&(event.key==='Enter'||event.key===' ')){event.preventDefault();event.stopPropagation();showHidden()}}}><rect x={view!.width-view!.right-48} y={0} width={44} height={44} rx={7} fill="#142638" stroke="#45617b"/><text x={view!.width-view!.right-26} y={28} textAnchor="middle" fill="#dcecf7" fontSize={24} pointerEvents="none">{{left:'←',right:'→',up:'↑',down:'↓','up-left':'↖','up-right':'↗','down-left':'↙','down-right':'↘'}[hidden.direction]}</text></g>}
        </svg>{message&&<p className={styles.message} role="status">{message}</p>}</div>
        <div className={styles.tools} aria-label="Chart view controls"><button type="button" onClick={()=>reset('fit')}>Fit</button><button type="button" aria-label="Show more candles" onClick={()=>adjustTime(1/1.2)}>−</button><button type="button" aria-label="Larger candles" onClick={()=>adjustTime(1.2)}>+</button><button type="button" aria-pressed={ema} onClick={()=>{if(ready())setEma(value=>!value)}}>EMA20</button><button type="button" aria-label="Toggle full screen" onClick={fullscreen}>⛶</button><button type="button" className={styles.reveal} disabled={request.endBar>=chart.current.length} onClick={toggleRemaining}>{request.endBar>=chart.current.length?'All session bars shown':revealed?'Hide remaining candles':'Reveal remaining '+(chart.current.length-request.endBar)+' candles'}</button></div>
        <p id="match-full-help" className={styles.srOnly}>Read-only historical chart. Drag the plot to pan, the right price axis to scale prices, and the bottom time axis to change candle width. Arrow keys or W A S D move the focused chart or axis. Plus and minus change candle width. Home fits. Fit leaves a candle-width right margin. Matching is not a prediction; remaining candles stay hidden until you reveal them. No practice score or history is saved.</p>
      </>}
    </main>
  </div>;
}
