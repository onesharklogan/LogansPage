'use client';
import {useEffect,useMemo,useRef,useState} from 'react';
import {loadHistoryCandleIndex} from '../public/modules/history-candle-data.js';
import {failedChartDays} from '../lib/failed-charts-book.mjs';
import styles from './failed-charts-book.module.css';
const points=(n:number)=>`${n>0?'+':''}${n.toLocaleString('en-US',{maximumFractionDigits:2})}`;
function Chart({source,large=false}:{source:any;large?:boolean}){
 const bars=source.candles;
 if(!bars?.length)return <p>Original OHLC chart unavailable. No replacement candles generated.</p>;
 const low=Math.min(...bars.map((b:any)=>b.l)),high=Math.max(...bars.map((b:any)=>b.h)),pad=Math.max((high-low)*.08,.5),bottom=low-pad,top=high+pad;
 const x=(i:number)=>12+(i+.5)*640/bars.length,y=(p:number)=>24+(top-p)/(top-bottom)*240;
 return <svg viewBox="0 0 720 300" role="img" aria-label={`Full historical candlestick chart for ${source.id}. ${bars.length} original candles.`} className={large?styles.largeChart:styles.chart}>
 {[bottom,(bottom+top)/2,top].map(p=><g key={p}><line x1="12" x2="652" y1={y(p)} y2={y(p)} stroke="#263c50"/><text x="662" y={y(p)+4} fill="#adc2d5" fontSize="12">{p.toFixed(2)}</text></g>)}
 {bars.map((b:any,i:number)=><g key={i} stroke={b.c>=b.o?'#69d5ad':'#ff819c'}><line x1={x(i)} x2={x(i)} y1={y(b.h)} y2={y(b.l)}/><rect x={x(i)-2.4} y={y(Math.max(b.o,b.c))} width="4.8" height={Math.max(1,Math.abs(y(b.o)-y(b.c)))} fill={b.c>=b.o?'#69d5ad':'#ff819c'}/></g>)}
 {[0,Math.floor(bars.length/2),bars.length-1].map(i=><text key={i} x={x(i)} y="289" textAnchor={i===0?'start':i===bars.length-1?'end':'middle'} fill="#adc2d5" fontSize="12">Bar {i+1}</text>)}
 </svg>;
}
/** Receives only the current guarded owner's completed history; no writes or simulator actions. */
export default function FailedChartsBook({rows,canAct}:{rows:any[];canAct:()=>boolean}){
 const review=useRef<HTMLElement>(null);
 const [page,setPage]=useState(0),[open,setOpen]=useState(false),[index,setIndex]=useState<any>(null),[error,setError]=useState(''),[retry,setRetry]=useState(0),[mode,setMode]=useState('all'),[sort,setSort]=useState('worst'),[selected,setSelected]=useState<string|null>(null);
 useEffect(()=>{if(!open)return;const controller=new AbortController();setError('');loadHistoryCandleIndex({signal:controller.signal}).then(data=>{if(!controller.signal.aborted)setIndex(data);}).catch(()=>{if(!controller.signal.aborted)setError('The verified chart library could not be loaded. Your history is unchanged.');});return()=>controller.abort();},[open,retry]);
 const book=useMemo(()=>failedChartDays(rows,index,{mode,sort}),[rows,index,mode,sort]),position=book.days.findIndex((d:any)=>d.id===selected),day=book.days[position],lastPage=Math.max(0,Math.ceil(book.days.length/12)-1),currentPage=Math.min(page,lastPage);
 useEffect(()=>{if(selected){review.current?.scrollIntoView({block:'nearest'});review.current?.focus({preventScroll:true});}},[selected]);
 function act(fn:()=>void){if(canAct())fn();}
 return <section className={styles.book} aria-label="Failed Charts Book">
 <button type="button" className={styles.launch} aria-expanded={open} onClick={()=>act(()=>setOpen(!open))}><span aria-hidden="true">▥</span> Failed Charts Book <span>{open?'Close book':'Open graphical review'}</span></button>
 {open&&<div className={styles.content}><h4>Failed Charts Book</h4><p>Each card is a completed practice session with a negative overall result, after netting all its winning and losing trades. Replays stay separate, so a later win never hides an earlier failed session. Dates on charts are historical market dates.</p>
 <div className={styles.controls}><label>Orders <select value={mode} onChange={e=>act(()=>{setMode(e.target.value);setSelected(null);setPage(0);})}><option value="all">Market + limit</option><option value="market">Market only</option><option value="limit">Limit only</option></select></label><label>Sort <select value={sort} onChange={e=>act(()=>{setSort(e.target.value);setPage(0);})}><option value="worst">Largest loss first</option><option value="recent">Latest chart date</option></select></label></div>
 <p className={styles.note}>Points use each simulator’s original scoring, not cash P&amp;L. Full-day candles are for hindsight review. Shapes are not automatic day-type diagnoses.</p>
 {error?<p role="alert">{error} <button type="button" onClick={()=>act(()=>setRetry(n=>n+1))}>Retry charts</button></p>:!index?<p role="status">Loading verified historical charts…</p>:<>
 <p role="status"><strong>{book.days.length} losing sessions</strong> / {book.total} completed sessions in this history selection. {book.incomplete>0&&`${book.incomplete} session(s) excluded because outcomes are incomplete. `}{book.unresolved>0&&`${book.unresolved} losing session(s) have no verified chart match. `}</p>
 {!book.days.length?<p>No verified net-losing sessions in this selection.</p>:<>
 {day&&<article ref={review} tabIndex={-1} className={styles.review} aria-label="Selected failed chart"><div className={styles.controls}><button type="button" disabled={position===0} onClick={()=>act(()=>setSelected(book.days[position-1].id))}>← Previous</button><strong>{position+1} / {book.days.length} · {day.date}</strong><button type="button" disabled={position===book.days.length-1} onClick={()=>act(()=>setSelected(book.days[position+1].id))}>Next →</button><button type="button" onClick={()=>act(()=>setSelected(null))}>Close enlarged chart</button></div><div className={styles.chartScroll}><Chart source={day.source} large/></div><p><strong className={styles.loss}>{points(day.points)} points</strong> · {day.attempts.length} completed attempts</p><details><summary>Session result details</summary><ul>{day.attempts.map((a:any)=><li key={a.id}>{a.mode==='market'?'Market':'Limit'} · {points(a.points)} points · {a.completedAt?new Date(a.completedAt).toLocaleString():'Completion date unavailable'}</li>)}</ul></details></article>}
 <div className={styles.controls}><button type="button" disabled={currentPage===0} onClick={()=>act(()=>setPage(currentPage-1))}>Previous page</button><span>Page {currentPage+1} of {lastPage+1} · All {book.days.length} sessions available</span><button type="button" disabled={currentPage===lastPage} onClick={()=>act(()=>setPage(currentPage+1))}>Next page</button></div><div className={styles.grid}>{book.days.slice(currentPage*12,(currentPage+1)*12).map((d:any)=><button type="button" key={d.id} className={styles.card} aria-pressed={selected===d.id} aria-label={`Enlarge ${d.date}, ${points(d.points)} points, ${d.attempts.length} attempts`} onClick={()=>act(()=>setSelected(d.id))}><div className={styles.cardTitle}><strong>{d.date}</strong><span className={styles.loss}>{points(d.points)} pts</span></div><Chart source={d.source}/><span>{d.attempts[0].mode==='market'?'Market':'Limit'} · {d.attempts[0].completedAt?new Date(d.attempts[0].completedAt).toLocaleString():'Date unavailable'} · Tap to enlarge</span></button>)}</div>
 </>}
 </>}
 </div>}
 </section>;
}
