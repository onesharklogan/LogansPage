'use client';

import {useEffect,useRef,useState} from 'react';

type GuestVisits={total:number;today:number;last7Days:number;since:string|null;days:{date:string;visits:number}[]};
const count=(value:unknown):value is number=>Number.isSafeInteger(value)&&Number(value)>=0;
function valid(value:GuestVisits):boolean {
 return !!value&&count(value.total)&&count(value.today)&&count(value.last7Days)&&(value.since===null||typeof value.since==='string'&&Number.isFinite(Date.parse(value.since)))&&Array.isArray(value.days)&&value.days.length<=30&&value.days.every(day=>/^\d{4}-\d{2}-\d{2}$/.test(day.date)&&count(day.visits));
}

export default function AdminGuestVisits(){
 const [data,setData]=useState<GuestVisits|null>(null),[error,setError]=useState(''),[loading,setLoading]=useState(true),[refresh,setRefresh]=useState(0);
 const epoch=useRef(0),request=useRef<AbortController|null>(null);
 useEffect(()=>{
  let alive=true;
  function clear(){epoch.current++;request.current?.abort();setData(null);setError('');setLoading(false);}
  async function load(){
   clear();if(document.hidden)return;
   const controller=new AbortController(),ticket=++epoch.current;request.current=controller;setLoading(true);
   const current=()=>alive&&!controller.signal.aborted&&ticket===epoch.current&&!document.hidden;
   try{
    const response=await fetch('/api/author/guest-visits',{credentials:'same-origin',cache:'no-store',redirect:'error',signal:controller.signal});
    if(!response.ok)throw Error(response.status===503?'Guest visit counts are unavailable. Counting may not be enabled yet.':response.status===401||response.status===403?'Administrator access is required to view guest visit counts.':'Guest visit counts could not be loaded. Try refreshing.');
    const body=await response.json();if(!valid(body))throw Error('Guest visit counts could not be loaded. Try refreshing.');
    if(current())setData(body);
   }catch(e){if(current())setError(e instanceof Error?e.message:'Guest visit counts could not be loaded. Try refreshing.');}
   finally{if(current())setLoading(false);}
  }
  const restore=()=>{void load();},visibility=()=>{if(document.hidden)clear();else restore();};
  window.addEventListener('pagehide',clear);window.addEventListener('focus',restore);window.addEventListener('pageshow',restore);document.addEventListener('visibilitychange',visibility);
  void load();
  return()=>{alive=false;epoch.current++;request.current?.abort();window.removeEventListener('pagehide',clear);window.removeEventListener('focus',restore);window.removeEventListener('pageshow',restore);document.removeEventListener('visibilitychange',visibility);};
 },[refresh]);
 return <section className="panel" aria-labelledby="guest-visits-heading" style={{marginBlock:'1rem',minWidth:0}}>
  <div className="toolbar-actions" style={{justifyContent:'space-between',flexWrap:'wrap'}}><h2 id="guest-visits-heading">Guest visits</h2><button className="quiet-button" type="button" disabled={loading} onClick={()=>{epoch.current++;request.current?.abort();setData(null);setError('');setRefresh(value=>value+1);}}>Refresh guest counts</button></div>
  <p>Anonymous app sessions, not unique people or accounts. Visits across public app pages in the same tab count once for up to 24 hours. No guest trading history is collected.</p>
  {loading&&<p role="status">Loading guest visit counts…</p>}
  {error&&<p className="notice error" role="alert">{error}</p>}
  {data&&<>
   <dl style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(130px,1fr))',gap:'1rem',marginBlock:'1rem'}}>
    {([['Total sessions',data.total],['Today (UTC)',data.today],['Last 7 days (UTC)',data.last7Days]] as const).map(([label,value])=><div key={label}><dt>{label}</dt><dd style={{margin:0,fontSize:'1.8rem',fontWeight:700}}>{value.toLocaleString()}</dd></div>)}
   </dl>
   <p className="field-help">{data.since?`First recorded session ${new Date(data.since).toISOString().slice(0,10)} (UTC). `:'No anonymous sessions have been recorded yet. '}Earlier visits are not backfilled. Signed-in learner and teacher visits are excluded.</p>
   <details><summary>Daily anonymous sessions · latest 30 calendar days (UTC)</summary>{data.days.length?<ul style={{listStyle:'none',padding:0}}>{data.days.map(day=><li key={day.date} style={{display:'flex',justifyContent:'space-between',gap:'1rem',maxWidth:360,paddingBlock:'.3rem'}}><time dateTime={day.date}>{day.date}</time><span>{day.visits.toLocaleString()}</span></li>)}</ul>:<p>No daily counts are available yet.</p>}</details>
  </>}
 </section>;
}
