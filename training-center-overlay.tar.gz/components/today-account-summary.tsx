'use client';
import {useEffect,useState} from 'react';
import {deriveTodayHistory} from '../lib/today-history.mjs';
import {formatProfitFactor} from '../public/modules/learner-stats.js';
import styles from './learner-trader-stats.module.css';

const TITLES=['Market Order','Limit Order'];
/** Account overview only: all devices, scoped to today's saved completion date. */
export default function TodayAccountSummary({stats}:{stats:any}){
 const [,refreshDay]=useState(0);
 useEffect(()=>{
  let timer:ReturnType<typeof setTimeout>;
  function schedule(){clearTimeout(timer);const now=new Date(),next=new Date(now);next.setHours(24,0,0,25);timer=setTimeout(wake,next.getTime()-now.getTime());}
  function wake(){refreshDay(value=>value+1);schedule();}
  schedule();window.addEventListener('focus',wake);window.addEventListener('pageshow',wake);
  return()=>{clearTimeout(timer);window.removeEventListener('focus',wake);window.removeEventListener('pageshow',wake);};
 },[]);
 const timeZone=Intl.DateTimeFormat().resolvedOptions().timeZone||'UTC',now=new Date().toISOString();
 const pages=[0,1].map(page=>deriveTodayHistory(stats,page,{timeZone,now}));
 return <section className={styles.overview} aria-label="Today's practice">
  <p className={styles.caption}><strong>Today</strong> · {pages[0].date} · {timeZone}</p>
  <dl className={styles.summary}>{pages.map((page,index)=><div key={index}><dt>{TITLES[index]} Charts Completed Today:</dt><dd>{page.count}</dd><small>Profit Factor <strong>{formatProfitFactor(page)}</strong></small>{!page.complete&&<small>Outcomes verified: {page.covered} / {page.count}</small>}</div>)}</dl>
  <p className={styles.caption}>Completed today in device time · All devices · Replays included. Open Trade History for your all-time totals and daily trends.</p>
 </section>;
}
