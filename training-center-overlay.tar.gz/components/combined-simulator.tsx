'use client';
import {useEffect,useRef,useState} from 'react';
import AccountMarketDirection from './account-market-direction';
import ProfiledTradeSimulator from './profiled-trade-simulator';
import CombinedSimulatorHistory from './combined-simulator-history';
import {switchDecision,safeSessionSeed} from '../lib/combined-simulator.mjs';
import Profiles from '../public/modules/learner-profiles.js';
import {learnerClient} from '../lib/learner/client.mjs';
import './combined-simulator.css';

type Mode='market'|'limit';
type Replay={mode:Mode;attemptId?:string;sessionKey?:string};
type Controller={status:()=>any;suspend:()=>void;resume:()=>void;replay:(target:Replay)=>void};
/** Both original scoring engines remain intact. Hidden modes cannot advance or receive shortcuts. */
export default function CombinedSimulator({accountsEnabled=false,initialMode='market',marketSource='/modules/market-direction.html',initialHistory=false}:{accountsEnabled?:boolean;initialMode?:Mode;marketSource?:string;initialHistory?:boolean}){
 const [mode,setMode]=useState<Mode>(initialMode),[visited,setVisited]=useState({market:initialMode==='market',limit:initialMode==='limit'}),[ready,setReady]=useState(false),[history,setHistory]=useState(false),[notice,setNotice]=useState(''),[confirmation,setConfirmation]=useState<{mode:Mode;message:string}|null>(null);
 const active=useRef<Mode>(initialMode),historyVisible=useRef(false),controllers=useRef<Partial<Record<Mode,Controller>>>({}),seeds=useRef<Partial<Record<Mode,any>>>({}),pendingReplay=useRef<Replay|null>(null),pendingHistory=useRef(initialHistory),alive=useRef(false),toolbar=useRef<HTMLButtonElement>(null),confirmButton=useRef<HTMLButtonElement>(null),confirmationOwner=useRef<any>(null);
 const facade=useRef<any>(null);
 function current(){return controllers.current[active.current];}
 function canAct(){return alive.current&&!confirmationOwner.current&&Object.values(controllers.current).every(controller=>switchDecision(controller?.status()).allowed);}
 function openHistory(){
  if(!alive.current||confirmationOwner.current)return;
  current()?.suspend();historyVisible.current=true;setHistory(true);setNotice('');
 }
 function closeHistory(){historyVisible.current=false;setHistory(false);current()?.resume();toolbar.current?.focus();}
 function performSwitch(next:Mode){
  const previous=active.current,controller=controllers.current[previous];
  if(!switchDecision(controller?.status()).allowed){setNotice('The current save needs attention before changing modes.');return;}
  const status=controller?.status();controller?.suspend();if(!switchDecision(controller?.status()).allowed){confirmationOwner.current=null;setConfirmation(null);controller?.resume();setNotice('The attempt could not be saved. Retry the save before switching modes.');return;}
  if(!controllers.current[next]&&!seeds.current[next])seeds.current[next]=safeSessionSeed(status?.session);
  active.current=next;confirmationOwner.current=null;setConfirmation(null);setMode(next);setVisited(v=>({...v,[next]:true}));
  controllers.current[next]?.resume();
  setNotice(next==='limit'?'Limit order simulation is on. Place an entry, stop and target. Market practice stays paused.':'Market order simulation is on. Limit orders and positions stay paused until you return.');
 }
 function requestSwitch(next:Mode){
  if(next===active.current||confirmationOwner.current||historyVisible.current)return;
  const controller=current(),status=controller?.status(),decision=switchDecision(status),target=controllers.current[next]?.status(),rewind=status?.session&&target?.session&&status.session.id===target.session.id&&status.session.index>target.session.index;
  if(rewind){decision.confirm=true;decision.message=(decision.message?decision.message+' ':'')+'The other mode is paused at bar '+(target.session.index+1)+'. You have already seen through bar '+(status.session.index+1)+' on this chart. Resuming is review practice; no unseen-candle result is implied.';}
  if(!decision.allowed){setNotice(decision.message||'Finish saving before changing modes.');return;}
  controller?.suspend();if(!switchDecision(controller?.status()).allowed){controller?.resume();setNotice('The attempt could not be saved. Retry the save before switching modes.');return;}
  if(decision.confirm){confirmationOwner.current={controller,identity:status?.identity,mode:active.current};setConfirmation({mode:next,message:decision.message||'Your attempt will remain paused.'});return;}
  performSwitch(next);
 }
 function cancelSwitch(){confirmationOwner.current=null;setConfirmation(null);current()?.resume();toolbar.current?.focus();}
 function confirmSwitch(){const owner=confirmationOwner.current;if(!owner||owner.controller!==current()||owner.identity!==current()?.status()?.identity){cancelSwitch();setNotice('Your profile changed. Choose a mode again.');return;}performSwitch(confirmation!.mode);}
 function replay(target:Replay){
  if(!canAct())return;historyVisible.current=false;setHistory(false);pendingReplay.current=target;
  if(target.mode!==active.current)performSwitch(target.mode);else current()?.resume();
  const controller=controllers.current[target.mode];if(controller?.status()?.ready&&switchDecision(controller.status()).allowed){pendingReplay.current=null;controller.replay(target);}
 }
 useEffect(()=>{
  alive.current=true;
  const host={hasPendingReplay:(candidate:Mode)=>pendingReplay.current?.mode===candidate,navigationReady:()=>Object.values(controllers.current).every(controller=>switchDecision(controller?.status()).allowed),isActive:(candidate:Mode)=>alive.current&&active.current===candidate&&!historyVisible.current&&!confirmationOwner.current,history:openHistory,initialSession:(candidate:Mode)=>seeds.current[candidate]||null,initialReplay:(candidate:Mode)=>initialMode===candidate?new URLSearchParams(window.location.search).get('replay'):null,
   register:(candidate:Mode,controller:Controller)=>{const previous=controllers.current[candidate];controllers.current[candidate]=controller;if(!previous&&(active.current!==candidate||historyVisible.current||confirmationOwner.current))controller.suspend();const status=controller.status();if(status?.ready&&switchDecision(status).allowed&&active.current===candidate){if(pendingReplay.current?.mode===candidate){const replay=pendingReplay.current;pendingReplay.current=null;controller.resume();controller.replay(replay);}else if(pendingHistory.current){pendingHistory.current=false;openHistory();}}return()=>{if(controllers.current[candidate]===controller)delete controllers.current[candidate];};}};
  facade.current=host;(window as any).PriceActionCombined=host;setReady(true);
  const identity=()=>{if(accountsEnabled){const snapshot=learnerClient.getSnapshot();return snapshot.epoch+':'+(snapshot.profile?.id||snapshot.mode||'unverified');}try{const profile=Profiles.read(window.localStorage).active;return profile?.learnerId+':'+profile?.key;}catch{return 'unavailable';}};let lastIdentity=identity();
  const changed=()=>{const next=identity();if(next===lastIdentity)return;lastIdentity=next;seeds.current={};if(confirmationOwner.current){confirmationOwner.current=null;setConfirmation(null);setNotice('Profile verification changed. Your practice remains paused.');}pendingReplay.current=null;};
  const unsubscribe=accountsEnabled?learnerClient.subscribe(changed):()=>{};window.addEventListener('storage',changed);
  return()=>{alive.current=false;Object.values(controllers.current).forEach(controller=>controller?.suspend());unsubscribe();window.removeEventListener('storage',changed);if((window as any).PriceActionCombined===host)delete(window as any).PriceActionCombined;};
 },[accountsEnabled]);
 useEffect(()=>{if(confirmation)confirmButton.current?.focus();},[confirmation]);
 return <div className="combined-simulator" data-simulator-mode={mode}>
  <div className="combined-simulator-toolbar" aria-label="Simulator mode">
   <strong>Trade Simulator <span>{mode==='market'?'Market orders':'Limit orders'}</span></strong>
   <button ref={toolbar} type="button" aria-pressed={mode==='limit'} aria-controls="combined-limit-panel" disabled={!ready||history||!!confirmation} onClick={()=>requestSwitch(mode==='market'?'limit':'market')}>Limit order simulation <b>{mode==='limit'?'ON':'OFF'}</b></button>
   <button type="button" disabled={!ready||!!confirmation} aria-expanded={history} onClick={history?closeHistory:openHistory}>Combined history</button>
  </div>
  {notice&&<p className="combined-mode-notice" role="status">{notice}</p>}
  {confirmation&&<section className="combined-mode-confirm" role="dialog" aria-modal="true" aria-labelledby="combined-switch-title" onKeyDown={event=>{if(event.key==='Escape'){event.preventDefault();cancelSwitch();}if(event.key==='Tab'){event.preventDefault();const buttons=event.currentTarget.querySelectorAll('button');(document.activeElement===buttons[0]?buttons[1]:buttons[0])?.focus();}}}><h2 id="combined-switch-title">Pause and switch modes?</h2><p>{confirmation.message}</p><button type="button" onClick={confirmSwitch}>Pause and switch</button><button type="button" ref={confirmButton} onClick={cancelSwitch}>Keep practicing</button></section>}
  <div hidden={history} inert={history||!!confirmation}>
   <section id="combined-market-panel" data-combined-market hidden={mode!=='market'} inert={mode!=='market'} aria-label="Market order simulation">
    {ready&&visited.market&&(accountsEnabled?<AccountMarketDirection source={marketSource}/>:<iframe className="market-direction-frame" src={marketSource} title="Trade Simulator: market orders" allow="fullscreen"/>)}
   </section>
   <section id="combined-limit-panel" hidden={mode!=='limit'} inert={mode!=='limit'} aria-label="Limit order simulation">{ready&&visited.limit&&<ProfiledTradeSimulator accountsEnabled={accountsEnabled}/>}</section>
  </div>
  {history&&<CombinedSimulatorHistory accountsEnabled={accountsEnabled} onClose={closeHistory} onReplay={replay} canAct={canAct}/>}
 </div>;
}
