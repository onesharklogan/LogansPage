import type {SVGProps} from 'react';

type Candle={o:number;h:number;l:number;c:number;ema?:number|null;t?:string};
type Props={candles:Candle[];startBar?:number;selection?:{start:number;end:number};label:string;compact?:boolean;interactive?:boolean}&SVGProps<SVGSVGElement>;

/** Scale is computed only from the supplied visible candles, never a hidden suffix. */
export default function PatternCandles({candles,startBar=1,selection,label,compact=false,interactive=false,...props}:Props){
 const width=1000,height=compact?430:380,left=24,right=72,top=38,bottom=34;
 if(!candles.length)return null;
 const values=candles.flatMap(c=>[c.l,c.h,...(Number.isFinite(c.ema)?[c.ema as number]:[])]),lo=Math.min(...values),hi=Math.max(...values),range=Math.max(.01,hi-lo),pad=range*.1,min=lo-pad,max=hi+pad;
 const step=(width-left-right)/candles.length,x=(i:number)=>left+step*(i+.5),y=(p:number)=>top+(max-p)/(max-min)*(height-top-bottom);
 const selected=(i:number)=>!selection||i+startBar>=selection.start&&i+startBar<=selection.end;
 const ema=candles.map((c,i)=>Number.isFinite(c.ema)?`${i?'L':'M'}${x(i)} ${y(c.ema as number)}`:'').join(' ');
 return <svg viewBox={`0 0 ${width} ${height}`} width="100%" role={interactive?'group':'img'} aria-label={label} {...props}>
  <rect width={width} height={height} fill="#08131f" rx="8"/>
  {[0,.25,.5,.75,1].map((p,i)=>{const price=min+(max-min)*p;return <g key={i} pointerEvents="none"><line x1={left} x2={width-right} y1={y(price)} y2={y(price)} stroke="#1c3042"/><text x={width-8} y={y(price)+5} textAnchor="end" fontSize={compact?19:12} fill="#8ba1b6">{price.toFixed(2)}</text></g>;})}
  {selection&&<rect data-pattern-highlight x={left+Math.max(0,selection.start-startBar)*step} y={top-10} width={Math.max(0,Math.min(candles.length,selection.end-startBar+1)-Math.max(0,selection.start-startBar))*step} height={height-top-bottom+15} fill="#8bdcc018" stroke="#8bdcc0" strokeWidth="1.5" pointerEvents="none"/>}
  {candles.map((c,i)=>{const color=c.c>=c.o?'#67dfb3':'#f18da6',w=Math.min(step*.58,compact?32:18),n=i+startBar;return <g key={i} opacity={selected(i)?1:.38} pointerEvents="none" data-pattern-bar={n}>
   <line x1={x(i)} x2={x(i)} y1={y(c.h)} y2={y(c.l)} stroke={color} strokeWidth={compact?2:1.4}/>
   <rect x={x(i)-w/2} y={Math.min(y(c.o),y(c.c))} width={w} height={Math.max(1.5,Math.abs(y(c.o)-y(c.c)))} fill={color}/>
   {(compact||candles.length<=25||n%5===0||n===1)&&<text x={x(i)} y={Math.max(18,y(c.h)-9)} textAnchor="middle" fontSize={compact?21:12} fill={selected(i)?'#b2c5d7':'#6b8094'}>{n}</text>}
   <title>{`Bar ${n}${c.t?' · '+c.t:''} · O ${c.o} H ${c.h} L ${c.l} C ${c.c}`}</title>
  </g>;})}
  <path d={ema} fill="none" stroke="#f6c760" strokeWidth={compact?4:2} strokeLinejoin="round" pointerEvents="none" data-pattern-ema/>
  <text x={left} y={height-10} fontSize={compact?19:12} fill="#8ba1b6">{candles[0].t?.slice(11,16)||`Bar ${startBar}`}</text><text x={width-right} y={height-10} textAnchor="end" fontSize={compact?19:12} fill="#8ba1b6">{candles.at(-1)?.t?.slice(11,16)||`Bar ${startBar+candles.length-1}`} · Chicago</text>
 </svg>;
}
