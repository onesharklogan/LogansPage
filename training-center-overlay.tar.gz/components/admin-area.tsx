"use client";
import LoadingIndicator from './loading-indicator';
import { useCallback, useEffect, useRef, useState } from 'react';
import AppHeader from './app-navigation';
import PasswordSignIn from './password-sign-in';
import ManageAuthors from './manage-authors';
import AdminInvitations from './admin-invitations';
import TeacherGoogleSignIn from './teacher-google-sign-in';

type AdminStatus = { ownerBindingAvailable?:boolean;googleConfigured?:boolean;googleSignedIn?:boolean;googleEmail?:string|null;authMode?:'google'|'password'|null; author: boolean; csrfToken: string | null; passwordConfigured: boolean; authorEmail: string | null; authorRole: 'admin' | 'author' | null; storageReady: boolean };
export default function AdminArea() {
  const [status, setStatus] = useState<AdminStatus | null>(null), [loading, setLoading] = useState(true), [busy, setBusy] = useState(false), [error, setError] = useState('');
  const logoutInFlight = useRef(false);
  const mounted = useRef(false), generation = useRef(0), currentRequest = useRef<AbortController | null>(null);
  const refresh = useCallback(async () => {
    if(!mounted.current)return;
    const request = new AbortController(), requestGeneration = ++generation.current;
    currentRequest.current?.abort(); currentRequest.current = request;
    setLoading(true); setStatus(null); setError('');
    try {
      const response = await fetch('/api/status', { credentials: 'same-origin', cache: 'no-store', signal: request.signal });
      if (!response.ok) throw new Error('Author access could not be checked. Please try again.');
      const next = await response.json();
      if (typeof next.author !== 'boolean' || typeof next.passwordConfigured !== 'boolean') throw new Error('The author access response was invalid.');
      if (mounted.current && !request.signal.aborted && requestGeneration === generation.current) setStatus(next);
    } catch (problem) {
      if (mounted.current && !request.signal.aborted && requestGeneration === generation.current) { setStatus(null); setError(problem instanceof Error ? problem.message : 'Author access could not be checked.'); }
    } finally { if (mounted.current && requestGeneration === generation.current) setLoading(false); }
  }, []);
  useEffect(() => { mounted.current = true; void refresh(); const check=()=>void refresh(); window.addEventListener('focus',check);window.addEventListener('pageshow',check); return () => { mounted.current = false; generation.current++; currentRequest.current?.abort();window.removeEventListener('focus',check);window.removeEventListener('pageshow',check); }; }, [refresh]);
  const renderedGeneration=generation.current;
  async function logout() {
    if (!mounted.current||loading||renderedGeneration!==generation.current||logoutInFlight.current || !status?.csrfToken) return;
    const ticket=renderedGeneration;
    logoutInFlight.current = true; setBusy(true); setError('');
    try {
      const response = await fetch('/api/auth/logout', { method: 'POST', credentials: 'same-origin', cache: 'no-store', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': status.csrfToken }, body: '{}' });
      if (!response.ok) throw new Error('Sign-out could not be confirmed. Refresh to check your current access.');
      if(mounted.current&&ticket===generation.current)await refresh();
    } catch (problem) { if (mounted.current&&ticket===generation.current) setError(problem instanceof Error ? problem.message : 'Sign-out could not be confirmed.'); }
    finally { logoutInFlight.current = false; if (mounted.current) setBusy(false); }
  }
  return <div className="training-center"><AppHeader section="ADMIN" current="/admin" teacher={!!status?.author}>{status?.author ? <><span className="app-account-name" title={status.authorEmail || 'Approved author'}>{status.authorEmail || 'Author'}</span><button className="quiet-button" disabled={busy} onClick={logout}>{busy ? <LoadingIndicator label="Signing out…" size="small" /> : 'Sign out'}</button></> : <span className="app-account-name">Author sign in</span>}</AppHeader><main className="admin-main"><p className="eyebrow">TEACHER ACCESS</p><h1>{status?.author ? 'Teacher Area' : 'Admin'}</h1><p className="admin-intro">Use your Google sign-in for approved teaching access. Administrators can invite and manage other administrators.</p>{error && <div className="notice error" role="alert"><span>{error}</span><button className="quiet-button" disabled={loading} onClick={() => void refresh()}>Check access again</button></div>}{loading ? <section className="panel admin-login-panel" aria-busy="true"><p role="status"><LoadingIndicator label="Checking author access…" /></p></section> : !status ? <section className="panel admin-login-panel"><h2>Author access could not be checked</h2><p>Use “Check access again” above. The public training tool remains available without sign-in.</p></section> : status.author ? <><section className="panel admin-session"><div><h2>Teaching workspace</h2><p>Manage published Lessons or open the slide editor.</p><div className="toolbar-actions"><a className="primary-button" href="/admin/modules">Manage Lessons</a><a className="quiet-button" href="/studio">Open Teacher Studio</a>{status.authorRole === 'admin' && <><a className="quiet-button" href="/admin/trader-history">Trader history</a><a className="quiet-button" href="/speak-the-chart">Speak the Chart</a></>}</div></div></section><section className="panel admin-session"><div><p className="eyebrow">SIGNED IN</p><h2>{status.authorRole === 'admin' ? 'Administrator access' : 'Author access'}</h2>{status.authorEmail && <p className="admin-account">{status.authorEmail}</p>}<p className="field-help">{status.authorRole === 'admin' ? 'You can manage author access below and review saved simulator history when administrator history review is enabled.' : 'Your account is approved. Only administrators can manage author access.'}</p></div><button className="quiet-button" disabled={busy} onClick={logout}>{busy ? <LoadingIndicator label="Signing out…" size="small" /> : 'Sign out'}</button></section>{status.authorRole === 'admin' && status.csrfToken && status.googleConfigured && <AdminInvitations csrfToken={status.csrfToken} currentEmail={status.authorEmail} onAccessChange={refresh}/>}
{status.authorRole === 'admin' && status.csrfToken && <ManageAuthors csrfToken={status.csrfToken} currentEmail={status.authorEmail} onMembershipChange={refresh} />}</> : status.googleConfigured ? <section className="panel admin-login-panel"><h2>{status.googleSignedIn?'Google account not approved':'Sign in with Google'}</h2>{status.googleSignedIn?<><p>{status.googleEmail} has no approved teacher access. Ask an administrator for a recipient-bound invitation.</p><a className="quiet-button" href="/">Open profile to sign out or switch Google accounts</a></>:<TeacherGoogleSignIn onReturn={()=>void refresh()}/>}<button className="quiet-button" type="button" disabled={loading} onClick={()=>void refresh()}>Check access</button>{status.ownerBindingAvailable&&<a className="primary-button" href="/admin/activate-google">Link my Google admin access</a>}{!status.googleSignedIn&&status.passwordConfigured&&<details><summary>Legacy password access</summary><PasswordSignIn onSignedIn={refresh}/></details>}</section> : status?.passwordConfigured && status.storageReady ? <section className="panel admin-login-panel"><h2>Sign in to your account</h2><PasswordSignIn onSignedIn={refresh} /></section> : <section className="panel admin-login-panel"><h2>Password sign-in is not available yet</h2><p>The administrator sign-in configuration is not ready. The public training tool does not require sign-in.</p><button className="quiet-button" disabled>Password sign-in unavailable</button></section>}</main><footer className="training-footer"><span>Price Action Center</span><a href="/market-direction">Market Orders Simulator</a></footer></div>;
}
