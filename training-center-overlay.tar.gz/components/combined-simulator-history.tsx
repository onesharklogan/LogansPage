'use client';
import {useEffect,useRef,useState,type MouseEvent} from 'react';
import {learnerClient} from '../lib/learner/client.mjs';
import {readCombinedLocalHistory,localHistoryOwnerCurrent} from '../lib/combined-simulator-history.mjs';
import FailedChartsBook from './failed-charts-book';
import LearnerTraderStats from './learner-trader-stats';
import LoadingIndicator from './loading-indicator';

export type CombinedHistoryReplay={mode:'market'|'limit';attemptId?:string;sessionKey?:string};
type Props={accountsEnabled:boolean;onClose:()=>void;onReplay:(target:CombinedHistoryReplay)=>void;refreshKey?:number;canAct?:()=>boolean};
const points=(value:number)=>`${value>0?'+':''}${value.toLocaleString('en-US',{maximumFractionDigits:2})}`;

function AccountHistory({onClose,onReplay,refreshKey=0,canAct=()=>true}:Props){
 const [snapshot,setSnapshot]=useState(learnerClient.getSnapshot);
 useEffect(()=>{const unsubscribe=learnerClient.subscribe(setSnapshot);return()=>{unsubscribe();};},[]);
 const capture=learnerClient.captureContext();
 const ready=!!capture&&learnerClient.guard(capture)&&snapshot.authConfigured;
 function replay(event:MouseEvent<HTMLAnchorElement>){
  event.preventDefault();
  if(event.type!=='click'||event.button!==0||!ready||!capture||!learnerClient.guard(capture)||!canAct())return;
  const url=new URL(event.currentTarget.href),attemptId=url.searchParams.get('replay');
  if(!attemptId||!['/market-direction','/trade-simulator'].includes(url.pathname))return;
  onReplay({mode:url.pathname==='/market-direction'?'market':'limit',attemptId});
 }
 if(!ready)return <p role="status">{snapshot.error||'Verifying the current profile before showing history…'}</p>;
 if(capture.mode==='guest')return <><p>Guest practice is not saved. Sign in to keep combined market and limit order history.</p><button type="button" className="quiet-button" onClick={onClose}>Back to simulator</button></>;
 return <LearnerTraderStats client={learnerClient} page={2} onPage={()=>{}} onBack={onClose} onReplay={replay} canAct={()=>!!capture&&learnerClient.guard(capture)&&canAct()} refreshKey={refreshKey} backLabel="Back to simulator"/>;
}

function LocalHistory({onClose,onReplay,refreshKey=0,canAct=()=>true}:Props){
 const [loaded,setLoaded]=useState<ReturnType<typeof readCombinedLocalHistory>|null>(null),[error,setError]=useState(''),[revision,setRevision]=useState(0);
 useEffect(()=>{
  setLoaded(null);setError('');
  try{setLoaded(readCombinedLocalHistory(window.localStorage));}catch(error){setError(error instanceof Error?error.message:'History could not be read safely.');}
 },[revision,refreshKey]);
 useEffect(()=>{
  const refresh=()=>{setLoaded(null);setRevision(v=>v+1);};
  window.addEventListener('storage',refresh);window.addEventListener('focus',refresh);
  return()=>{window.removeEventListener('storage',refresh);window.removeEventListener('focus',refresh);};
 },[]);
 const current=loaded&&typeof window!=='undefined'&&localHistoryOwnerCurrent(loaded,window.localStorage)?loaded:null;
 function replay(row:NonNullable<typeof loaded>['rows'][number]){
  if(!current||!canAct()||!localHistoryOwnerCurrent(current,window.localStorage))return;
  onReplay({mode:row.mode as 'market'|'limit',...('attemptId' in row?{attemptId:row.attemptId}:{}),...('sessionKey' in row?{sessionKey:row.sessionKey}:{})});
 }
 return <>
  <div style={{display:'flex',gap:8,flexWrap:'wrap'}}><button type="button" className="quiet-button" onClick={onClose}>Back to simulator</button><button type="button" className="quiet-button" onClick={()=>setRevision(v=>v+1)}>Refresh history</button></div>
  {!current?<p role={error?'alert':'status'}>{error||<LoadingIndicator label="Checking your saved history…"/>}</p>:<>
   <p><strong>{current.profile.name}</strong> · Browser-local history · {current.rows.length} recorded completed attempts</p>
   <p className="muted">Market and limit order attempts are shown together, including recorded replays. Saved points keep each mode’s original scoring. Unfinished runs are excluded; older unrecorded attempts and scores are not reconstructed.</p>
   {(current.missingMarketCount>0||current.unavailable>0)&&<p role="status">{current.missingMarketCount>0&&`${current.missingMarketCount} earlier market session completion(s) have no saved score. `}{current.unavailable>0&&`${current.unavailable} saved record(s) could not be displayed safely. `}Existing history has not been changed.</p>}
   <FailedChartsBook rows={current.rows} canAct={()=>!!current&&canAct()&&localHistoryOwnerCurrent(current,window.localStorage)}/>
   {!current.rows.length?<p>No completed attempts with recorded results yet.</p>:<ol aria-label="Trade History: market and limit orders" style={{listStyle:'none',padding:0,display:'grid',gap:12}}>{current.rows.map(row=><li key={row.id} style={{border:'1px solid #344254',borderRadius:10,padding:14,display:'flex',flexWrap:'wrap',gap:12,justifyContent:'space-between'}}><div style={{minWidth:0,overflowWrap:'anywhere'}}><strong>{row.mode==='market'?'Market order':'Limit order'} · {row.title}</strong><p style={{margin:'6px 0'}}>{points(row.points)} points · {row.completedAt?new Date(row.completedAt).toLocaleString():'Completion date unavailable'}</p>{row.legacy&&<small>Original saved session result</small>}</div><button type="button" className="quiet-button" onClick={()=>replay(row)}>Replay</button></li>)}</ol>}
  </>}
 </>;
}

/** One read-only history surface for both engines. Never migrates, resets or writes history. */
export default function CombinedSimulatorHistory(props:Props){
 const heading=useRef<HTMLHeadingElement>(null);
 useEffect(()=>{heading.current?.focus({preventScroll:true});},[]);
 return <section className="simulator-history" data-combined-history="true" aria-labelledby="combined-history-title" onKeyDown={event=>{event.stopPropagation();if(event.key==='Escape'){event.preventDefault();props.onClose();}}}>
  <h2 id="combined-history-title" ref={heading} tabIndex={-1}>Trade History</h2>
  {props.accountsEnabled?<AccountHistory {...props}/>:<LocalHistory {...props}/>}
 </section>;
}
