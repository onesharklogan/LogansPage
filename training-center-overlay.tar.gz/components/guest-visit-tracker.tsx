'use client';

import {useEffect} from 'react';
import {usePathname} from 'next/navigation';
import {learnerClient} from '../lib/learner/client.mjs';
import {recordGuestVisit} from '../public/modules/guest-visits.js';

const PUBLIC_ROUTES=new Set(['/','/market-direction','/trade-simulator','/chart-marker','/chart-match','/chart-match/full']);
/** Only public top-level pages report; the server verifies actual anonymous identity. */
export default function GuestVisitTracker(){
 const pathname=usePathname();
 useEffect(()=>{
  if(!pathname||!PUBLIC_ROUTES.has(pathname))return;
  let alive=true;
  const record=()=>{if(alive&&!document.hidden&&window.top===window.self)void recordGuestVisit();};
  const verifiedMode=(snapshot:ReturnType<typeof learnerClient.getSnapshot>)=>snapshot.ready&&!snapshot.revalidating&&!snapshot.reconcileRequired&&!snapshot.signOutNeeded&&!snapshot.error&&!snapshot.busy?(snapshot.mode==='guest'&&!snapshot.profile?'guest':snapshot.mode==='account'&&snapshot.profile?'account':null):null;
  let previousMode=verifiedMode(learnerClient.getSnapshot());
  const unsubscribe=learnerClient.subscribe((snapshot:ReturnType<typeof learnerClient.getSnapshot>)=>{
   if(!alive)return;const mode=verifiedMode(snapshot);if(!mode)return;
   const signedOut=previousMode==='account'&&mode==='guest';previousMode=mode;if(signedOut)record();
  });
  window.addEventListener('pageshow',record);document.addEventListener('visibilitychange',record);record();
  return()=>{alive=false;unsubscribe();window.removeEventListener('pageshow',record);document.removeEventListener('visibilitychange',record);};
 },[pathname]);
 return null;
}
