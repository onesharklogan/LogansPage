'use client';

import {useId,useLayoutEffect,useRef,useState} from 'react';
import type {Trade} from '../lib/trade-simulator.mjs';
import {EXIT_LABELS} from '../lib/trade-simulator-view.mjs';

type Candle={t?:string;o:number;h:number;l:number;c:number};
type Props={trades:Trade[];candles:Candle[];title:string;active?:boolean;canAcknowledge?:()=>boolean;onComplete:()=>void};
const price=(n:number)=>n.toFixed(2);
const css=`.limit-trade-review{box-sizing:border-box;width:min(760px,calc(100vw - 24px));max-height:calc(100dvh - 24px);overflow:auto;margin:auto;padding:20px;border:1px solid #47647d;border-radius:16px;background:#0c1927;color:#e5eff8;box-shadow:0 24px 90px #0009}.limit-trade-review::backdrop{background:#020812cc}.limit-trade-review h2{font-size:24px;margin:6px 0}.limit-trade-review p{color:#adc2d5;line-height:1.5}.limit-trade-review svg{display:block;width:100%;height:auto;background:#08121e;border:1px solid #30465a;border-radius:10px}.limit-trade-review dl{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:16px 0}.limit-trade-review dl div{padding:10px;background:#132639;border-radius:8px}.limit-trade-review dt{color:#adc2d5;font-size:12px}.limit-trade-review dd{margin:4px 0 0;font-weight:600;overflow-wrap:anywhere}.limit-trade-review small{display:block;color:#adc2d5;font-weight:400}.limit-trade-review button{width:100%;min-height:48px;border:1px solid #8ac7ff;border-radius:9px;background:#285d89;color:white;font:inherit;font-weight:700;cursor:pointer}.limit-trade-review button:focus-visible{outline:3px solid #ffcf7c;outline-offset:3px}.limit-trade-review .ltr-positive{color:#9ee5bc}.limit-trade-review .ltr-negative{color:#ff9aa9}@media(max-width:440px){.limit-trade-review{padding:14px}.limit-trade-review h2{font-size:21px}.limit-trade-review dl{gap:7px}.limit-trade-review dd{font-size:14px}}`;

/** Review is presentation only: no simulator advances, scoring or history writes. */
export default function LimitTradeReview({trades,candles,title,active=true,canAcknowledge=()=>true,onComplete}:Props){
  const [index,setIndex]=useState(0),dialog=useRef<HTMLDialogElement>(null),ok=useRef<HTMLButtonElement>(null),accepted=useRef(-1),done=useRef(false),lastClick=useRef(-Infinity);
  const titleId=useId(),helpId=useId(),trade=trades[index];
  useLayoutEffect(()=>{
    if(!active)return;
    const node=dialog.current!,previous=document.activeElement as HTMLElement|null,overflow=document.body.style.overflow;
    document.body.style.overflow='hidden';node.showModal();ok.current?.focus({preventScroll:true});
    return()=>{node.close();document.body.style.overflow=overflow;if(previous?.isConnected&&!previous.closest('[inert]'))previous.focus({preventScroll:true});};
  },[active]);
  useLayoutEffect(()=>{ok.current?.focus({preventScroll:true});dialog.current?.scrollTo?.({top:0});},[index]);
  function acknowledge(){
    const now=performance.now();
    // Stale handlers, key repeat, and double clicks must never acknowledge another slide.
    if(!active||!canAcknowledge()||done.current||accepted.current>=index||now-lastClick.current<350)return;
    lastClick.current=now;accepted.current=index;
    if(index+1<trades.length)setIndex(index+1);else{done.current=true;onComplete();}
  }
  const start=trade?Math.max(0,trade.entryIndex-5):0,end=trade?Math.min(candles.length-1,trade.exitIndex+5):0,rows=trade?candles.slice(start,end+1):[];
  const values=rows.flatMap(c=>[c.h,c.l]).concat(trade?[trade.entryPrice,trade.exitPrice,trade.stop,trade.target]:[]),low=values.length?Math.min(...values):0,high=values.length?Math.max(...values):1,pad=Math.max((high-low)*.12,.5),lo=low-pad,hi=high+pad;
  const x=(i:number)=>18+(i-start+.5)*570/Math.max(1,rows.length),y=(p:number)=>28+(hi-p)/(hi-lo)*220;
  return <dialog ref={dialog} className="limit-trade-review" aria-modal="true" aria-labelledby={titleId} aria-describedby={helpId} onCancel={e=>e.preventDefault()} onKeyDown={e=>{e.stopPropagation();if(e.key==='Escape'||e.key==='Tab'||((e.key==='Enter'||e.key===' ')&&e.repeat)){e.preventDefault();if(e.key==='Tab')ok.current?.focus();}}}>
    <style>{css}</style><small>SESSION COMPLETE · LIMIT ORDERS</small><h2 id={titleId}>{trade?`Trade ${index+1} of ${trades.length} · ${trade.side==='buy'?'Long':'Short'}`:'No executed trades'}</h2>
    <p id={helpId}>{title}. {trade?'Review this trade, then tap OK to continue. Every trade needs your acknowledgment.':'No limit order filled in this attempt. Tap OK to return to the completed chart.'}</p>
    {trade&&<div key={index} aria-live="polite" aria-atomic="true">
      <svg viewBox="0 0 680 290" role="img" aria-label={`Trade ${index+1} chart. Entry candle ${trade.entryIndex+1} at ${price(trade.entryPrice)}, exit candle ${trade.exitIndex+1} at ${price(trade.exitPrice)}. Historical candles ${start+1} to ${end+1}.`}>
        {[lo,(lo+hi)/2,hi].map(p=><g key={p}><line x1="18" x2="588" y1={y(p)} y2={y(p)} stroke="#263c50"/><text x="600" y={y(p)+4} fill="#adc2d5" fontSize="13">{price(p)}</text></g>)}
        {rows.map((c,i)=><g key={i} stroke={c.c>=c.o?'#9ee5bc':'#ff9aa9'}><line x1={x(start+i)} x2={x(start+i)} y1={y(c.h)} y2={y(c.l)}/><rect x={x(start+i)-Math.min(6,200/rows.length)} y={y(Math.max(c.o,c.c))} width={Math.min(12,400/rows.length)} height={Math.max(1,Math.abs(y(c.o)-y(c.c)))} fill={c.c>=c.o?'#9ee5bc':'#ff9aa9'}/></g>)}
        <line x1={x(trade.entryIndex)} y1={y(trade.entryPrice)} x2={x(trade.exitIndex)} y2={y(trade.exitPrice)} stroke="#ffcf7c" strokeWidth="2" strokeDasharray="5 4"/>
        <circle cx={x(trade.entryIndex)} cy={y(trade.entryPrice)} r="6" fill="#8ac7ff" stroke="#fff"/><text x={x(trade.entryIndex)} y="18" textAnchor="middle" fill="#8ac7ff" fontSize="13">Entry</text>
        <circle cx={x(trade.exitIndex)} cy={y(trade.exitPrice)} r="6" fill="#ffcf7c" stroke="#fff"/><text x={x(trade.exitIndex)} y="269" textAnchor="middle" fill="#ffcf7c" fontSize="13">Exit</text>
      </svg>
      <dl><div><dt>Entry</dt><dd>{price(trade.entryPrice)}<small>Candle {trade.entryIndex+1} · {trade.entryTime||'Time unavailable'}</small></dd></div><div><dt>Exit · {EXIT_LABELS[trade.reason as keyof typeof EXIT_LABELS]||trade.reason}</dt><dd>{price(trade.exitPrice)}<small>Candle {trade.exitIndex+1} · {trade.exitTime||'Time unavailable'}</small></dd></div><div><dt>Stop / target</dt><dd>{price(trade.stop)} / {price(trade.target)}</dd></div><div><dt>Result · points, not cash</dt><dd className={trade.points<0?'ltr-negative':'ltr-positive'}>{trade.points>0?'+':''}{price(trade.points)} points</dd></div></dl>
      {trade.ambiguous&&<p>Both exits were touched in one candle. The simulator’s conservative stop-first result is unchanged.</p>}
    </div>}
    <p>Full-day candles are now available for review only. Your score still uses only candles revealed during practice.</p>
    <button ref={ok} type="button" onClick={acknowledge}>OK · {index+1<trades.length?'Next trade':'Finish review'}</button>
  </dialog>;
}
