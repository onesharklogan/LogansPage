'use client';
import {useEffect,useState} from 'react';
import {deriveTodayHistory} from '../lib/today-history.mjs';
import {formatProfitFactor} from '../public/modules/learner-stats.js';
import styles from './today-history-summary.module.css';

const number=(value:number)=>value.toLocaleString(undefined,{maximumFractionDigits:2});
export default function TodayHistorySummary({stats,page}:{stats:any;page:number}){
 const [,refreshDay]=useState(0);
 useEffect(()=>{
  let timer:ReturnType<typeof setTimeout>;
  function schedule(){clearTimeout(timer);const now=new Date(),next=new Date(now);next.setHours(24,0,0,25);timer=setTimeout(wake,next.getTime()-now.getTime());}
  function wake(){refreshDay(value=>value+1);schedule();}
  schedule();window.addEventListener('focus',wake);window.addEventListener('pageshow',wake);
  return()=>{clearTimeout(timer);window.removeEventListener('focus',wake);window.removeEventListener('pageshow',wake);};
 },[]);
 const timeZone=Intl.DateTimeFormat().resolvedOptions().timeZone||'UTC',today=deriveTodayHistory(stats,page,{timeZone,now:new Date().toISOString()});
 const noResults=!today.count,unavailable=noResults?'No data':!today.complete?'N/A':!today.samples?'No outcomes':null;
 const net=today.complete?today.totals.grossProfit-today.totals.grossLoss:null;
 const outcomes=page===0?'closed legs':page===1?'closed trades':'closed legs / trades';
 const cards=[['Charts completed',number(today.count)],['Net points',noResults?'No data':net===null?'N/A':`${net>0?'+':''}${number(net)}`],['Profit factor',unavailable||formatProfitFactor(today)],['Win rate',unavailable||(today.winRate===null?'N/A':`${number(today.winRate*100)}%`)]];
 return <section className={styles.panel} aria-label="Today at a glance">
  <div className={styles.heading}><h4>Today at a glance</h4><span>{today.date} · {timeZone}</span></div>
  <p className={styles.note}>Completed today in device time · Replays included</p>
  <dl className={styles.cards}>{cards.map(([label,value])=><div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl>
  {noResults?<p className={styles.note}>No saved completed charts today. Finish a practice session, then refresh stats.</p>:!today.complete?<p className={styles.warning}>Outcomes verified for {today.covered} of {today.count} completed charts. Points, profit factor and win rate are unavailable until every chart’s outcomes can be verified.</p>:<p className={styles.note}>{today.totals.wins} {today.totals.wins===1?'win':'wins'} · {today.totals.losses} {today.totals.losses===1?'loss':'losses'} · {today.totals.flats} flat · {today.samples} {outcomes}{today.samples?' · Flats count in win rate':''}</p>}
  {today.carry&&<p className={styles.note}>Points include saved Finish carry through Final Bar.</p>}
  <p className={styles.note}>Saved through {new Date(today.asOf).toLocaleString()} · Refresh stats for new completions.</p>
 </section>;
}
