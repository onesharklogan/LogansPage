/** Bounded, owner-directed screenshot transcription. Historical acquisition code stays frozen. */
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { run as verifyAdditional } from './normalize-2026-additional-sessions.mjs';
import { run as verify2025 } from './normalize-2025-sessions.mjs';
import { run as verifyRemaining } from './normalize-2025-remaining-sessions.mjs';

export const BATCH = 'mes-2026-user-screenshots-nov03-05';
export const DATES = Object.freeze(['2026-11-03', '2026-11-04', '2026-11-05']);
export const BASELINE_SHA256 = '0cb02086a1889a93816ce4075df588de9699ba39dff852fabad4b09872329b93';
export const SOURCES = Object.freeze([
  { date: DATES[0], filename: 'third-transcription.csv', transcriptionCsvSha256: 'a6aab13f10197d40731febccab0e4577612f92264e73b40a985bdb16a95995a3', rowsSha256: 'd261eb2c65aa5e530b7a16aa713eda36a3f6b1ba46bfa771d5391866ba813f7c', imageSha256: 'd1fb52cb89e920babdd5d680b558eaec2f817421e928c54c97ab36b69df4ad95', timezoneEvidence: 'America/Chicago visible in supplied image footer' },
  { date: DATES[1], filename: 'second-transcription.csv', transcriptionCsvSha256: 'e096320a3d505793c376559192cd08eb0ac32073573edb07693d11ba907f12a0', rowsSha256: 'f9a16992524ad7aceeea44a250a41f153581054d667dbfa401c325bee7bc366a', imageSha256: 'c42839df23b7332e2eef32205fd31bbcea61442fd37c746f58d0d9ba469c96cd', timezoneEvidence: 'America/Chicago visible in supplied image footer' },
  { date: DATES[2], filename: 'transcription.csv', transcriptionCsvSha256: '9d4d750e9a8eec38c78fc9674f52a7ffcf76b743f86f37dc6ccbb9ba3dd7487d', rowsSha256: '115110a8795298a86b614438c8060a50406a4d3d1f40afe744221d5537baae27', imageSha256: '310b5b3a2fcf38a38c75107a94468162823cb7a4b5c94557b906401bff65f92f', timezoneEvidence: 'Inherited from matching prior-session overlap and adjacent supplied images' },
]);
export const sha = value => createHash('sha256').update(value).digest('hex');
const json = value => JSON.stringify(value, null, 2) + '\n';
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const fail = message => { throw Error(message); };
const validPrice = value => Number.isFinite(value) && value > 0 && value < 1e9 && Number.isInteger(value * 4);
const closeRow = ({ t, c }) => ({ t, c });
const read = (root, name) => fs.readFileSync(path.join(root, name));
const load = (root, name) => JSON.parse(read(root, name));
const chartName = date => `public/charts/mes1-${date}-81.json`;
const timestamp = (date, minutes) => `${date} ${String(Math.floor(minutes / 60)).padStart(2, '0')}:${String(minutes % 60).padStart(2, '0')}`;

export function validateRows(rows, date) {
  const index = DATES.indexOf(date), priorDate = index > 0 ? DATES[index - 1] : '2026-11-02';
  if (index < 0 || !Array.isArray(rows) || rows.length !== 93) fail('Expected exactly 12 prior and 81 current screenshot rows.');
  rows.forEach((row, i) => {
    if (!row || !same(Object.keys(row).sort(), ['c', 'h', 'l', 'o', 't']) ||
      row.t !== (i < 12 ? timestamp(priorDate, 855 + i * 5) : timestamp(date, 510 + (i - 12) * 5)) ||
      ![row.o, row.h, row.l, row.c].every(validPrice) || row.l > Math.min(row.o, row.c) ||
      row.h < Math.max(row.o, row.c) || row.l > row.h) fail('Invalid screenshot OHLC, date, cadence, or tick at row ' + (i + 1));
  });
  return rows;
}

export function parseTranscription(csv, date) {
  const lines = csv.trim().split(/\r?\n/);
  if (lines.shift() !== 'bar,date,time,open,high,low,close') fail('Unexpected screenshot transcription header.');
  const rows = lines.map((line, i) => {
    const cells = line.split(',');
    if (cells.length !== 7 || cells[0] !== (i < 12 ? `Prior ${i + 1}` : String(i - 11)) ||
      cells.slice(3).some(value => !/^\d+(?:\.\d+)?$/.test(value))) fail('Invalid screenshot transcription ordinal or number.');
    const [o, h, l, c] = cells.slice(3).map(Number);
    return { t: cells[1] + ' ' + cells[2], o, h, l, c };
  });
  return validateRows(rows, date);
}

export function frozenBaseline(root, catalog = load(root, 'public/charts/catalog.json'), references = load(root, 'data/chart-references.json')) {
  const bytes = read(root, 'data/mes-2026-screenshot-baseline.json');
  if (sha(bytes) !== BASELINE_SHA256) fail('Frozen457 manifest changed.');
  const manifest = JSON.parse(bytes), ids = new Set(manifest.existingCharts.map(row => row.id));
  if (manifest.version !== 1 || manifest.existingCount !== 457 || ids.size !== 457 ||
    !Array.isArray(catalog?.sessions) || !Array.isArray(references) ||
    new Set(catalog.sessions.map(row => row.id)).size !== catalog.sessions.length ||
    new Set(catalog.sessions.map(row => row.date)).size !== catalog.sessions.length ||
    new Set(references.map(row => row.id)).size !== references.length ||
    new Set(references.map(row => row.date)).size !== references.length) fail('Invalid frozen457 or duplicate catalog identities.');
  const baselineCatalog = { ...catalog, sessions: catalog.sessions.filter(row => ids.has(row.id)) };
  const baselineReferences = references.filter(row => ids.has(row.id));
  if (sha(json(baselineCatalog)) !== manifest.baselineCatalogSha256 ||
    sha(JSON.stringify(baselineReferences) + '\n') !== manifest.baselineReferencesSha256) fail('Frozen457 catalog or references changed.');
  for (const row of manifest.existingCharts) if (sha(read(root, `public/charts/${row.id}.json`)) !== row.sha256) fail('Frozen457 chart changed: ' + row.id);
  for (const row of manifest.frozenFiles) if (sha(read(root, row.path)) !== row.sha256) fail('Frozen acquisition file changed: ' + row.path);
  return { manifest, baselineCatalog, baselineReferences, extraCatalog: catalog.sessions.filter(row => !ids.has(row.id)), extraReferences: references.filter(row => !ids.has(row.id)) };
}

export function planScreenshotSessions(root, datasets, sourceRecords) {
  const envelope = frozenBaseline(root), seed = load(root, chartName('2026-11-02'));
  const seedReference = envelope.baselineCatalog.sessions.find(row => row.id === seed.id);
  if (seedReference?.sha256 !== '6167c90f523e31933de71b3b4a4e8ca18dabec0712b1a589383e1f789ced1883' || seed.warmup.length !== 891) fail('Unexpected retained November 2 seed.');
  if (!Array.isArray(datasets) || datasets.length !== 3 || !Array.isArray(sourceRecords) || sourceRecords.length !== 3) fail('The bounded batch requires all three sessions.');
  const files = new Map(), newCatalog = [], newReferences = [], contexts = [];
  const warmup = [...seed.warmup.map(closeRow), ...seed.current.map(closeRow)];
  let previous = seed.current, previousDate = seed.date;
  for (let i = 0; i < DATES.length; i++) {
    const date = DATES[i], rows = validateRows(datasets[i], date), sourceRecord = sourceRecords[i], expected = SOURCES[i];
    if (!same(Object.keys(sourceRecord || {}).sort(), ['date', 'imageSha256', 'rowsSha256', 'timezoneEvidence', 'transcriptionCsvSha256']) ||
      ['date', 'imageSha256', 'timezoneEvidence', 'transcriptionCsvSha256', 'rowsSha256'].some(key => sourceRecord[key] !== expected[key]) ||
      !/^[a-f0-9]{64}$/.test(sourceRecord.transcriptionCsvSha256) || sourceRecord.rowsSha256 !== sha(JSON.stringify(rows))) fail('Screenshot source identity differs.');
    if (!same(rows.slice(0, 12), previous.slice(-12))) fail('Screenshot prior OHLC conflicts with actual preceding session: ' + date);
    if (warmup.length !== 972 + i * 81 || warmup.some((b, n) => !validPrice(b.c) || b.t.slice(0, 10) >= date || (n && b.t <= warmup[n - 1].t)) ||
      !same(warmup.slice(-81), previous.map(closeRow))) fail('Causal warmup differs from retained/observed history.');
    const current = rows.slice(12), id = `mes1-${date}-81`, title = `MES1! · ${date} · 81 bars`;
    const emaSeed = { initialization: 'first-observed-close', period: 20, firstTimestamp: warmup[0].t, firstClose: warmup[0].c,
      retainedChartId: seed.id, retainedChartSha256: seedReference.sha256, retainedThrough: seed.current.at(-1).t,
      retainedRows: 972, appendedTranscribedRows: i * 81 };
    const chart = { version: 1, id, title, date, range: 'extended', instrument: 'MES', intervalMinutes: 5, timezone: 'America/Chicago',
      source: { kind: 'historical', label: 'User-supplied OHLC table screenshot, independently transcribed and compared with its image',
        acquisitionMethod: 'User-supplied screenshot transcription', batch: BATCH, imageSha256: expected.imageSha256,
        sourceRowsSha256: sourceRecord.rowsSha256, sourceTranscriptionCsvSha256: sourceRecord.transcriptionCsvSha256,
        timezoneEvidence: expected.timezoneEvidence,
        instrumentAssignment: 'Existing MES catalog context and exact preceding-session OHLC overlap; symbol and provider not independently verified',
        independentlyExchangeVerified: false, providerVerified: false, warmupSeed: emaSeed },
      rights: { publicationAuthorization: 'user-directed', licenseStatus: 'not-verified',
        statement: 'Included at the account owner’s explicit direction. Redistribution rights and source authenticity were not independently verified; no license-cleared claim is made.' },
      current, prior: previous.slice(-12), warmup: warmup.map(closeRow),
      previousSession: { date: previousDate, barCount: 81, endTime: '15:10', bars: previous,
        source: 'observed-export-session', sourceRowsSha256: sha(JSON.stringify(previous)) } };
    const bytes = json(chart), digest = sha(bytes);
    files.set(chartName(date), bytes);
    newCatalog.push({ id, title, date, kind: 'historical', range: 'extended', instrument: 'MES', intervalMinutes: 5, url: `/charts/${id}.json`, sha256: digest });
    newReferences.push({ id, date, sha256: digest, timestamps: current.map(b => b.t) });
    contexts.push({ id, date, currentBars: 81, previousDate, previousBars: 81, priorStart: chart.prior[0].t, priorEnd: chart.prior.at(-1).t, warmupRows: warmup.length, ...emaSeed });
    warmup.push(...current.map(closeRow));previous = current;previousDate = date;
  }
  const catalog = { ...envelope.baselineCatalog, sessions: [...envelope.baselineCatalog.sessions, ...newCatalog].sort((a, b) => a.date.localeCompare(b.date)) };
  const references = [...envelope.baselineReferences, ...newReferences].sort((a, b) => a.date.localeCompare(b.date));
  files.set('public/charts/catalog.json', json(catalog));files.set('data/chart-references.json', JSON.stringify(references) + '\n');
  const provenance = { version: 1, batch: BATCH, readiness: 'IMAGE_TRANSCRIPTION_AUDITED', selectedDates: DATES, selectedCount: 3,
    baselineManifest: 'data/mes-2026-screenshot-baseline.json', baselineManifestSha256: BASELINE_SHA256,
    sourceRecords, observedRowsIncludingOverlaps: 279, uniqueCurrentRows: 243, overlapAudit: { checkedPriorOhlcRows: 36, conflictingRows: 0 },
    newCharts: newCatalog.map(({ id, date, sha256 }) => ({ id, date, sha256 })), contexts,
    warmupPolicy: 'Retain the November 2 chart’s complete causal close history and append the supplied complete sessions in order. No new EMA seed, synthetic prices, inferred candles, volume, or resampling.',
    previousSessionSourceNote: 'The legacy observed-export-session discriminator denotes observed OHLC context. November 3 and 4 context was transcribed from user screenshots, not acquired from a provider export.',
    publicVerification: 'Reconstruct each 93-row source from the exact prior12/current81 chart values and check its row digest. Original screenshot pixels and private CSV files are not distributed.',
    marketDataCaveat: 'User-supplied screenshot values, not independently exchange-verified. Instrument is assigned from matching existing MES context; screenshot provider and symbol are not independently verified. Redistribution rights are not independently verified.' };
  files.set('data/mes-2026-screenshot-provenance.json', json(provenance));
  return { files, catalog, references, provenance, envelope };
}

export function verifyScreenshotSessions(root) {
  const provenance = load(root, 'data/mes-2026-screenshot-provenance.json');
  const datasets = DATES.map(date => { const chart = load(root, chartName(date));return [...chart.prior, ...chart.current]; });
  const plan = planScreenshotSessions(root, datasets, provenance.sourceRecords);
  if (!same(plan.provenance, provenance)) fail('Screenshot provenance differs from reconstructed evidence.');
  for (const [name, text] of plan.files) if (read(root, name).toString('utf8') !== text) fail('Screenshot output is absent or stale: ' + name);
  if (plan.envelope.extraCatalog.length !== 3 || plan.envelope.extraReferences.length !== 3) fail('Undeclared sessions outside the screenshot batch.');
  return { status: 'PASS', addedSessions: 3, totalSessions: 460, existingPreserved: 457, observedRows: 279, currentRows: 243, checkedPriorOhlcRows: 36, conflictingRows: 0 };
}

/** A temporary read-only projection removes only this verified batch. No old verifier is weakened. */
export function verifyHistoricalBaselines(root) {
  verifyScreenshotSessions(root);
  const { baselineCatalog, baselineReferences } = frozenBaseline(root);
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'ohlc-frozen457-'));
  try {
    for (const directory of ['data', 'public/charts']) {
      fs.mkdirSync(path.join(temp, directory), { recursive: true });
      for (const file of fs.readdirSync(path.join(root, directory))) {
        if ((directory === 'data' && file === 'chart-references.json') || (directory === 'public/charts' && (file === 'catalog.json' || DATES.some(date => file === `mes1-${date}-81.json`)))) continue;
        fs.symlinkSync(path.resolve(root, directory, file), path.join(temp, directory, file));
      }
    }
    fs.writeFileSync(path.join(temp, 'public/charts/catalog.json'), json(baselineCatalog));
    fs.writeFileSync(path.join(temp, 'data/chart-references.json'), JSON.stringify(baselineReferences) + '\n');
    return { additional2026: verifyAdditional(temp, { check: true }), first2025: verify2025(temp, { check: true }), remaining2025: verifyRemaining(temp, { check: true }) };
  } finally { fs.rmSync(temp, { recursive: true, force: true }); }
}

export function generate(root, inputDirectory, { audited = false } = {}) {
  if (!audited) fail('Independent screenshot transcription audit must be completed before generation.');
  const datasets = [], records = [];
  for (const source of SOURCES) {
    const csv = fs.readFileSync(path.join(inputDirectory, source.filename));
    const rows = parseTranscription(csv.toString('utf8'), source.date);datasets.push(rows);
    records.push({ date: source.date, imageSha256: source.imageSha256, rowsSha256: sha(JSON.stringify(rows)), transcriptionCsvSha256: sha(csv), timezoneEvidence: source.timezoneEvidence });
  }
  const plan = planScreenshotSessions(root, datasets, records);
  for (const [name, text] of plan.files) fs.writeFileSync(path.join(root, name), text);
  return verifyScreenshotSessions(root);
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  const rootAt = process.argv.indexOf('--root'), inputAt = process.argv.indexOf('--inputs');
  const root = rootAt >= 0 ? process.argv[rootAt + 1] : fileURLToPath(new URL('../', import.meta.url));
  if (!root) fail('--root requires a directory.');
  if (process.argv.includes('--check')) console.log(JSON.stringify({ screenshots: verifyScreenshotSessions(root), historical: verifyHistoricalBaselines(root) }, null, 2));
  else { if (inputAt < 0 || !process.argv[inputAt + 1]) fail('Generation requires --inputs with a private CSV directory.');console.log(JSON.stringify(generate(root, process.argv[inputAt + 1], { audited: process.argv.includes('--audited') }), null, 2)); }
}
