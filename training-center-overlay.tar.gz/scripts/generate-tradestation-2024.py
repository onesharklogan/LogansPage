"""Deterministic additive 2024 chart preparation. Never writes the source export."""
import argparse, collections, csv, datetime as dt, hashlib, io, json, pathlib

SOURCE_SHA = 'bc9e5f7714df4974b6bfc109ee52df2486895e6f7744d3b79fd12e0482829820'
BATCH = 'tradestation-2024-20261110'
CLOSED = ['2024-01-01', '2024-03-29', '2024-12-25']
MISSING = ['2024-07-18']
SHORT42 = ['2024-01-15','2024-02-19','2024-05-27','2024-06-19','2024-07-04','2024-09-02','2024-11-28']
SHORT45 = ['2024-07-03','2024-11-29','2024-12-24']
SOURCE_URL = 'https://drive.google.com/file/d/1ON4yplbp86otvHdo49P69fHcSxZF9AIw/view'
sha = lambda b: hashlib.sha256(b if isinstance(b,bytes) else b.encode()).hexdigest()
compact = lambda x: json.dumps(x,ensure_ascii=False,separators=(',',':'))
pretty = lambda x: json.dumps(x,ensure_ascii=False,indent=2)+'\n'

def price(raw):
    n = float(raw)
    if not 0 < n < 1e9 or n*4 != int(n*4): raise ValueError('Invalid price')
    return int(n) if n.is_integer() else n

def read_source(source):
    data=source.read_bytes()
    if sha(data) != SOURCE_SHA: raise ValueError('Unrecognized immutable source hash')
    raw=list(csv.DictReader(io.StringIO(data.decode())))
    if len(raw)!=205521: raise ValueError('Raw row count differs')
    days=collections.defaultdict(list); previous=''
    for ordinal,r in enumerate(raw,1):
        if int(r['Row'])!=ordinal or r['Symbol']!='@MES' or r['BarInterval']!='5' or r['BarStatus']!='2' or r['RTHStartHHmm']!='830' or r['RTHEndHHmm']!='1515': raise ValueError('Unexpected source metadata')
        stamp=dt.datetime.strptime(r['BarEndTime'],'%Y-%m-%d %H:%M:%S')
        if stamp.strftime('%Y-%m-%d')!=r['SessionDate'] or stamp.weekday()>4 or stamp.minute%5 or r['BarEndTime']<=previous: raise ValueError('Invalid timestamp')
        previous=r['BarEndTime']
        bar={'t':(stamp-dt.timedelta(minutes=5)).strftime('%Y-%m-%d %H:%M'),'o':price(r['Open']),'h':price(r['High']),'l':price(r['Low']),'c':price(r['Close'])}
        if not bar['l']<=min(bar['o'],bar['c'])<=max(bar['o'],bar['c'])<=bar['h']: raise ValueError('Invalid OHLC')
        days[r['SessionDate']].append(bar)
        if int(r['SessionBar'])!=len(days[r['SessionDate']]): raise ValueError('Invalid session ordinal')
    return raw,days

def generate(source,baseline,out):
    raw,days=read_source(source)
    selected=[d for d in days if d.startswith('2024-')]
    if len(selected)!=258 or sum(len(days[d]) for d in selected)!=20517: raise ValueError('2024 count mismatch')
    weekdays=[str(dt.date(2024,1,1)+dt.timedelta(days=i)) for i in range(366) if (dt.date(2024,1,1)+dt.timedelta(days=i)).weekday()<5]
    if sorted(set(weekdays)-set(selected))!=sorted(CLOSED+MISSING): raise ValueError('2024 missing-date set changed')
    for d in selected:
        expected=42 if d in SHORT42 else 45 if d in SHORT45 else 81
        if len(days[d])!=expected: raise ValueError('Unexpected session count: '+d)
        for i,b in enumerate(days[d]):
            if b['t']!=(dt.datetime.fromisoformat(d+' 08:30')+dt.timedelta(minutes=5*i)).strftime('%Y-%m-%d %H:%M'): raise ValueError('Missing internal bar: '+d)
    catalog=json.loads((baseline/'public/charts/catalog.json').read_text()); refs=json.loads((baseline/'data/chart-references.json').read_text())
    if len(catalog['sessions'])!=460 or len(refs)!=460 or any(r['date'].startswith('2024') for r in catalog['sessions']): raise ValueError('Expected frozen460 baseline')
    for r in catalog['sessions']:
        if sha((baseline/('public'+r['url'])).read_bytes())!=r['sha256']: raise ValueError('Changed baseline chart')
    out.mkdir(parents=True,exist_ok=True)
    def put(name,text):
        target=out/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(text)
    history=[];new=[];newrefs=[];contexts=[]
    all_dates=list(days)
    for date,bars in days.items():
        if date.startswith('2024-'):
            warmup=[{'t':b['t'],'c':b['c']} for b in history[-2000:]]
            previousDate=all_dates[all_dates.index(date)-1];previousBars=days[previousDate]
            missing_prior=[d for d in MISSING if previousDate<d<date]
            warmup_gaps=[d for d in MISSING if warmup[0]['t'][:10]<d<date]
            count=len(bars);id=f'mes1-{date}-{count}'
            title=f'TradeStation @MES · {date} · {count} bars'
            quality={'previousObservedDate':previousDate,'missingPreviousSessionDates':missing_prior,'missingDatesInWarmup':warmup_gaps,'emaRecomputed':True,'timezoneInferred':True,
              'warnings':(['July 18, 2024 is missing. Prior context is July 17, not the preceding trading day. The displayed change spans the missing session.'] if missing_prior else [])}
            chart={'version':1,'id':id,'title':title,'date':date,'range':'extended','instrument':'MES','intervalMinutes':5,'timezone':'America/Chicago',
              'source':{'kind':'historical','label':'TradeStation @MES 5m; continuous adjustment unverified; Chicago inferred; EMA20 uses available bars','symbol':'@MES','provider':'TradeStation','batch':BATCH,'timestampMeaning':'bar open; source BarEndTime minus five minutes','sourceExportSha256':SOURCE_SHA,'sourceFileUrl':SOURCE_URL,'backAdjustment':None,'adjustmentEvidence':'The 2025–2026 overlap has the signature of additive back-adjustment; not verified in export metadata. Prices are preserved without offsets.','timezoneEvidence':'Inferred from 08:35–15:15 end stamps and DST-spanning overlap with Chicago app sessions; not explicitly present in CSV.','independentlyExchangeVerified':False,'emaPolicy':'EMA20 on available RTH closes, alpha 2/21, first close of the last 2000 observed prior bars initializes the calculation. No overnight bars, synthetic fills, or TradeStation EMA values.','dataQuality':quality},
              'rights':{'publicationAuthorization':'user-directed','licenseStatus':'not-verified','statement':'Included at the account owner’s direction. Redistribution rights and source authenticity are not independently verified; no license-cleared claim is made.'},
              'current':bars,'prior':previousBars[-12:],'warmup':warmup,
              'previousSession':{'date':previousDate,'barCount':len(previousBars),'endTime':previousBars[-1]['t'][11:],'bars':previousBars,'source':'observed-export-session','sourceRowsSha256':sha(compact(previousBars))}}
            text=pretty(chart);digest=sha(text);put('public/charts/'+id+'.json',text)
            new.append({'id':id,'title':title,'date':date,'kind':'historical','range':'extended','instrument':'MES','intervalMinutes':5,'url':'/charts/'+id+'.json','sha256':digest})
            newrefs.append({'id':id,'date':date,'sha256':digest,'timestamps':[b['t'] for b in bars]})
            contexts.append({'id':id,'date':date,'currentBars':count,'previousDate':previousDate,'previousBars':len(previousBars),'warmupBars':len(warmup),'missingPreviousSessionDates':missing_prior,'missingDatesInWarmup':warmup_gaps})
        history.extend(bars)
    baseline_manifest={'version':1,'existingCount':460,'catalogSha256':sha((baseline/'public/charts/catalog.json').read_bytes()),'referencesSha256':sha((baseline/'data/chart-references.json').read_bytes()),'existingCharts':[{k:r[k] for k in ['id','date','sha256']} for r in catalog['sessions']]}
    # Include only the actual rows required to reproduce every added chart and its causal context.
    oldest=min(json.loads((out/('public'+r['url'])).read_text())['warmup'][0]['t'] for r in new)
    source_rows=[r for r in raw if oldest<=((dt.datetime.strptime(r['BarEndTime'],'%Y-%m-%d %H:%M:%S')-dt.timedelta(minutes=5)).strftime('%Y-%m-%d %H:%M')) and r['SessionDate']<='2024-12-31']
    buf=io.StringIO();writer=csv.DictWriter(buf,fieldnames=list(raw[0]),lineterminator='\n');writer.writeheader();writer.writerows(source_rows);observed=buf.getvalue()
    put('data/tradestation-2024-observed.csv',observed)
    coverage={'version':1,'year':2024,'sourceSha256':SOURCE_SHA,'observedSessions':258,'observedBars':20517,'fullSessions':248,'short42Dates':SHORT42,'short45Dates':SHORT45,'absentHolidayWeekdays':CLOSED,'unexplainedMissingDates':MISSING,'internalMissingBars':[],'badOhlcRows':0,'duplicateTimestamps':0,'scope':'08:30–15:15 regular-session export; shortened futures holiday sessions included; not overnight data.','calendarEvidence':'Absent weekdays and shortened observed sessions reconciled to NYSE 2024 published holiday/early-close calendar; futures holiday sessions are preserved as observed, not inferred from NYSE closure.','calendarUrl':'https://ir.theice.com/press/news-details/2021/NYSE-Group-Announces-2022-2023-and-2024-Holiday-and-Early-Closings-Calendar/default.aspx'}
    put('data/tradestation-2024-coverage.json',pretty(coverage));put('data/tradestation-2024-baseline.json',pretty(baseline_manifest))
    prov={'version':1,'batch':BATCH,'readiness':'OBSERVED_ROWS_VALIDATED_WITH_DISCLOSED_GAP','rawSourceSha256':SOURCE_SHA,'sourceFileUrl':SOURCE_URL,'observedCsv':'data/tradestation-2024-observed.csv','observedCsvSha256':sha(observed),'sourceSubsetRows':len(source_rows),'coverageFile':'data/tradestation-2024-coverage.json','coverageSha256':sha(pretty(coverage)),'baselineManifestSha256':sha(pretty(baseline_manifest)),'selectedCount':258,'selectedDates':selected,'newCharts':[{k:r[k] for k in ['id','date','sha256']} for r in new],'contexts':contexts,'limitations':['July 18 is absent; July 19 context is the previous available July 17 session.','Chicago timezone inferred, not explicitly exported.','@MES vendor continuous series has back-adjustment signature, not the unadjusted TradingView series.','EMA20 recomputed from available RTH closes; source EMA, overnight bars, bid/ask and intrabar paths are not supplied.','No independent exchange validation or redistribution-license verification.']}
    put('data/tradestation-2024-provenance.json',pretty(prov))
    put('public/charts/catalog.json',pretty({**catalog,'sessions':sorted(catalog['sessions']+new,key=lambda x:x['date'])}))
    put('data/chart-references.json',compact(sorted(refs+newrefs,key=lambda x:x['date']))+'\n')
    return coverage

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',type=pathlib.Path,required=True);p.add_argument('--baseline',type=pathlib.Path,required=True);p.add_argument('--out',type=pathlib.Path,required=True);a=p.parse_args()
    print(pretty(generate(a.source,a.baseline,a.out)))
