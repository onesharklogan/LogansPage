/** Additive @MES source envelope; historical chart bytes and verifiers stay frozen. */
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {createHash} from 'node:crypto';
export const BATCH='tradestation-2024-20261110';
export const SOURCE_SHA256='bc9e5f7714df4974b6bfc109ee52df2486895e6f7744d3b79fd12e0482829820';
export const SUBSET_SHA256='204d254679a9c30d12707efbd078b7afde2569965f5aa536d34ce22ee218918a';
export const BASELINE_SHA256='9d4579f1ba7654027429747607506ab336f4d244e3cad46e3be56e91cdf52d07';
export const COVERAGE_SHA256='ce77272f293c7c29d3de9369c819773c9438de545b866caafaf69aeb1d63b99d';
export const CLOSED_DATES=Object.freeze(['2024-01-01','2024-03-29','2024-12-25']);
export const MISSING_DATES=Object.freeze(['2024-07-18']);
export const SHORT42=Object.freeze(['2024-01-15','2024-02-19','2024-05-27','2024-06-19','2024-07-04','2024-09-02','2024-11-28']);
export const SHORT45=Object.freeze(['2024-07-03','2024-11-29','2024-12-24']);
export const sha=value=>createHash('sha256').update(value).digest('hex');
const json=value=>JSON.stringify(value,null,2)+'\n',same=(a,b)=>JSON.stringify(a)===JSON.stringify(b),fail=message=>{throw Error(message);};
const load=(root,name)=>JSON.parse(fs.readFileSync(path.join(root,name),'utf8'));
const read=(root,name)=>fs.readFileSync(path.join(root,name));
const close=({t,c})=>({t,c});
const normalizePrice=value=>{if(!/^\d+(?:\.\d+)?$/.test(value))fail('Malformed source price.');const n=Number(value);if(!Number.isFinite(n)||n<=0||n>=1e9||!Number.isInteger(n*4))fail('Invalid source price.');return n;};

export function parseTradeStationSubset(csv){
 const lines=csv.trimEnd().split(/\r?\n/),headers=lines.shift().split(','),expected=['Row','Symbol','SessionDate','SessionBar','SessionCountComplete','BarEndTime','Open','High','Low','Close','TotalVolumeOrTicks','UpVolumeOrTicks','DownVolumeOrTicks','BarType','BarInterval','BarStatus','ExportRun','RTHStartHHmm','RTHEndHHmm'];
 if(!same(headers,expected)||!lines.length)fail('Unexpected TradeStation CSV header.');
 const days=new Map();let previous='',previousRow=null;
 for(const line of lines){
  const values=line.split(',');if(values.length!==headers.length)fail('Malformed source CSV row.');const row=Object.fromEntries(headers.map((h,i)=>[h,values[i]]));
  const ordinal=Number(row.Row);if(!Number.isSafeInteger(ordinal)||ordinal<1||previousRow!==null&&ordinal!==previousRow+1)fail('Source row ordinal gap.');previousRow=ordinal;
  if(row.Symbol!=='@MES'||row.BarType!=='1'||row.BarInterval!=='5'||row.BarStatus!=='2'||row.RTHStartHHmm!=='830'||row.RTHEndHHmm!=='1515'||row.SessionCountComplete!=='1')fail('Unexpected source metadata.');
  if(!/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:00$/.test(row.BarEndTime)||row.BarEndTime<=previous||row.BarEndTime.slice(0,10)!==row.SessionDate)fail('Invalid or duplicate source timestamp.');
  const end=new Date(row.BarEndTime.replace(' ','T')+'Z');if(!Number.isFinite(end.getTime())||end.toISOString().slice(0,19).replace('T',' ')!==row.BarEndTime||end.getUTCMinutes()%5||[0,6].includes(end.getUTCDay()))fail('Invalid source date/grid.');previous=row.BarEndTime;
  const t=new Date(end.getTime()-300000).toISOString().slice(0,16).replace('T',' '),o=normalizePrice(row.Open),h=normalizePrice(row.High),l=normalizePrice(row.Low),c=normalizePrice(row.Close);
  if(l>Math.min(o,c)||h<Math.max(o,c)||l>h)fail('Impossible source OHLC.');
  const volume=[row.TotalVolumeOrTicks,row.UpVolumeOrTicks,row.DownVolumeOrTicks].map(Number);if(volume.some(v=>!Number.isSafeInteger(v)||v<0)||volume[0]!==volume[1]+volume[2])fail('Invalid source volume/tick values.');
  if(!days.has(row.SessionDate))days.set(row.SessionDate,[]);const bars=days.get(row.SessionDate);
  // The first copied context date can start part-way through a day; subsequent dates must start at bar1.
  const expectedBar=(Number(t.slice(11,13))*60+Number(t.slice(14))-510)/5+1;
  if(Number(row.SessionBar)!==expectedBar||bars.length&&t<=bars.at(-1).t)fail('Source session ordinal differs from timestamp.');
  bars.push({t,o,h,l,c});
 }
 return days;
}

export function verifyTradeStation2024(root){
 const p=load(root,'data/tradestation-2024-provenance.json'),b=load(root,'data/tradestation-2024-baseline.json'),coverage=load(root,'data/tradestation-2024-coverage.json');
 if(p.version!==1||p.batch!==BATCH||p.readiness!=='OBSERVED_ROWS_VALIDATED_WITH_DISCLOSED_GAP'||p.rawSourceSha256!==SOURCE_SHA256||p.selectedCount!==258||!Array.isArray(p.newCharts)||p.newCharts.length!==258||!Array.isArray(p.contexts)||p.contexts.length!==258)fail('Invalid 2024 provenance.');
 if(p.baselineManifestSha256!==BASELINE_SHA256||sha(read(root,'data/tradestation-2024-baseline.json'))!==BASELINE_SHA256||b.version!==1||b.existingCount!==460||b.existingCharts.length!==460)fail('Invalid frozen460 manifest.');
 const catalog=load(root,'public/charts/catalog.json'),references=load(root,'data/chart-references.json');
 if(catalog.version!==1||catalog.sessions.length!==718||references.length!==718||new Set(catalog.sessions.map(r=>r.id)).size!==718||new Set(catalog.sessions.map(r=>r.date)).size!==718||new Set(references.map(r=>r.id)).size!==718)fail('Duplicate or incomplete combined catalog.');
 const ids=new Set(b.existingCharts.map(r=>r.id)),baselineCatalog={...catalog,sessions:catalog.sessions.filter(r=>ids.has(r.id))},baselineReferences=references.filter(r=>ids.has(r.id));
 if(sha(json(baselineCatalog))!==b.catalogSha256||sha(JSON.stringify(baselineReferences)+'\n')!==b.referencesSha256)fail('Frozen460 catalog or references changed.');
 for(const r of b.existingCharts)if(sha(read(root,`public/charts/${r.id}.json`))!==r.sha256)fail('Frozen460 chart changed: '+r.id);
 if(p.observedCsv!=='data/tradestation-2024-observed.csv'||p.observedCsvSha256!==SUBSET_SHA256||sha(read(root,p.observedCsv))!==SUBSET_SHA256||p.coverageFile!=='data/tradestation-2024-coverage.json'||p.coverageSha256!==COVERAGE_SHA256||sha(read(root,p.coverageFile))!==COVERAGE_SHA256)fail('2024 source/coverage integrity mismatch.');
 const days=parseTradeStationSubset(read(root,p.observedCsv).toString('utf8')),dates=[...days.keys()].filter(d=>d.startsWith('2024-'));
 if(!same(dates,p.selectedDates)||dates.length!==258||[...days.values()].reduce((n,a)=>n+a.length,0)!==p.sourceSubsetRows)fail('Source date/count mismatch.');
 const absent=[];for(let d=new Date('2024-01-01T00:00Z');d.getUTCFullYear()===2024;d.setUTCDate(d.getUTCDate()+1)){const date=d.toISOString().slice(0,10);if(![0,6].includes(d.getUTCDay())&&!days.has(date))absent.push(date);}
 if(!same(absent,[...CLOSED_DATES,...MISSING_DATES].sort())||coverage.observedSessions!==258||coverage.observedBars!==20517||coverage.fullSessions!==248||!same(coverage.short42Dates,SHORT42)||!same(coverage.short45Dates,SHORT45)||!same(coverage.unexplainedMissingDates,MISSING_DATES)||!same(coverage.absentHolidayWeekdays,CLOSED_DATES)||coverage.internalMissingBars.length||coverage.duplicateTimestamps||coverage.badOhlcRows)fail('Coverage mismatch.');
 let history=[],previousDate=null,previousBars=null,currentRows=0;
 for(const [date,bars]of days){
  if(date.startsWith('2024-')){
   const count=SHORT42.includes(date)?42:SHORT45.includes(date)?45:81,id=`mes1-${date}-${count}`,index=dates.indexOf(date),record=p.newCharts[index],ref=catalog.sessions.find(r=>r.id===id),reference=references.find(r=>r.id===id);
   if(bars.length!==count||bars.some((bar,i)=>bar.t!==date+' '+String(Math.floor((510+i*5)/60)).padStart(2,'0')+':'+String((510+i*5)%60).padStart(2,'0')))fail('Incomplete 2024 session: '+date);
   const bytes=read(root,`public/charts/${id}.json`),digest=sha(bytes),chart=JSON.parse(bytes);
   if(!record||record.id!==id||record.date!==date||record.sha256!==digest||!ref||ref.sha256!==digest||ref.url!==`/charts/${id}.json`||!reference||reference.sha256!==digest||!same(reference.timestamps,bars.map(b=>b.t)))fail('2024 identity/hash mismatch: '+date);
   if(chart.version!==1||chart.id!==id||chart.date!==date||chart.title!==`TradeStation @MES · ${date} · ${count} bars`||ref.title!==chart.title||chart.instrument!=='MES'||chart.intervalMinutes!==5||chart.timezone!=='America/Chicago'||chart.source?.batch!==BATCH||chart.source.symbol!=='@MES'||chart.source.provider!=='TradeStation'||chart.source.sourceExportSha256!==SOURCE_SHA256||chart.source.backAdjustment!==null||chart.source.independentlyExchangeVerified!==false||!chart.source.emaPolicy?.includes('2000')||!chart.source.timezoneEvidence?.startsWith('Inferred'))fail('2024 source provenance mismatch: '+date);
   if(!same(chart.current,bars)||!same(chart.prior,previousBars.slice(-12))||!same(chart.warmup,history.slice(-2000).map(close)))fail('Source OHLC/context/warmup differs: '+date);
   const expectedPrevious={date:previousDate,barCount:previousBars.length,endTime:previousBars.at(-1).t.slice(11),bars:previousBars,source:'observed-export-session',sourceRowsSha256:sha(JSON.stringify(previousBars))};
   if(!same(chart.previousSession,expectedPrevious))fail('Previous observed session differs: '+date);
   const q=chart.source.dataQuality,missing=MISSING_DATES.filter(d=>d>previousDate&&d<date),warmupGaps=MISSING_DATES.filter(d=>d>chart.warmup[0].t.slice(0,10)&&d<date);
   if(!q||q.previousObservedDate!==previousDate||!same(q.missingPreviousSessionDates,missing)||!same(q.missingDatesInWarmup,warmupGaps)||q.timezoneInferred!==true||q.emaRecomputed!==true||missing.length&&!q.warnings?.some(w=>w.includes('July 17')&&w.includes('July 18')))fail('Missing context caveat: '+date);
   currentRows+=bars.length;
  }
  history.push(...bars);previousDate=date;previousBars=bars;
 }
 if(currentRows!==20517||catalog.sessions.filter(r=>!ids.has(r.id)).length!==258||fs.readdirSync(path.join(root,'public/charts')).length!==719)fail('Unexplained chart files or counts.');
 return{status:'PASS_WITH_DISCLOSED_GAP',addedSessions:258,currentRows,fullSessions:248,shortSessions:10,totalSessions:718,existingPreserved:460,missingDates:[...MISSING_DATES],baselineCatalog,baselineReferences};
}

/** Verify the additive source first, then run unchanged older gates on their exact frozen projection. */
export function withFrozen460(root,work){
 const verified=verifyTradeStation2024(root),temp=fs.mkdtempSync(path.join(os.tmpdir(),'ohlc-frozen460-'));
 try{
  fs.symlinkSync(path.resolve(root,'scripts'),path.join(temp,'scripts'));
  for(const directory of ['data','public/charts']){
   fs.mkdirSync(path.join(temp,directory),{recursive:true});
   for(const file of fs.readdirSync(path.join(root,directory))){
    if(directory==='data'&&(file==='chart-references.json'||file.startsWith('tradestation-2024-'))||directory==='public/charts'&&(file==='catalog.json'||/^mes1-2024-/.test(file)))continue;
    fs.symlinkSync(path.resolve(root,directory,file),path.join(temp,directory,file));
   }
  }
  fs.writeFileSync(path.join(temp,'public/charts/catalog.json'),json(verified.baselineCatalog));fs.writeFileSync(path.join(temp,'data/chart-references.json'),JSON.stringify(verified.baselineReferences)+'\n');
  return work(temp);
 }finally{fs.rmSync(temp,{recursive:true,force:true});}
}
