import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {fileURLToPath,pathToFileURL} from 'node:url';
import vm from 'node:vm';
import ts from 'typescript';
import {retainHistoryIndex,verifyHistoryRetention} from './history-candle-retention.mjs';

const root=new URL('../',import.meta.url),sha=bytes=>createHash('sha256').update(bytes).digest('hex');
export const HISTORY_IDENTITY='md-normalized-current-prior-ohlc-v1';

/** Execute only the five named, trusted repository normalization declarations, not the app.
 * This intentionally uses the actual MD normalizer, including its original prior-candle crop.
 * No browser, application startup, network, storage or arbitrary script from chart data runs. */
export function loadMDHistoryNormalizer(base=root){
 const source=readFileSync(new URL('public/modules/market-direction.html',base),'utf8');
 const names=['safeText','validCandle','timestampValue','normalizedCandles','normalizeHostedSession'];
 const declarations=names.map(name=>{
  const start=source.indexOf('function '+name+'(');if(start<0)throw Error('Missing MD normalization function: '+name);
  const parsed=ts.createSourceFile('normalizer.js',source.slice(start),ts.ScriptTarget.ESNext,true,ts.ScriptKind.JS),node=parsed.statements[0];
  if(!node||!ts.isFunctionDeclaration(node)||node.name?.text!==name)throw Error('Invalid MD normalization declaration.');
  return node.getText(parsed);
 });
 return vm.runInNewContext(`'use strict';const HOSTED_CATALOG='/charts/catalog.json';${declarations.join('\n')};normalizeHostedSession`,{}, {timeout:1000});
}

/** Deterministic, exact-key close projection of already authorized original chart files. */
export function buildHistoryCandleIndex(base=root){
 const normalize=loadMDHistoryNormalizer(base),catalogBytes=readFileSync(new URL('public/charts/catalog.json',base)),catalog=JSON.parse(catalogBytes);
 if(catalog.version!==1||!Array.isArray(catalog.sessions)||!catalog.sessions.length||catalog.sessions.length>1000)throw Error('Invalid history source catalog.');
 const seenIds=new Set(),seenKeys=new Set();
 const sessions=catalog.sessions.map(entry=>{
  if(!entry||typeof entry.id!=='string'||!/^[a-z0-9][a-z0-9_-]{0,63}$/.test(entry.id)||entry.url!==`/charts/${entry.id}.json`||seenIds.has(entry.id)||!/^[a-f0-9]{64}$/.test(entry.sha256||''))throw Error('Invalid or duplicate history source reference.');
  seenIds.add(entry.id);const bytes=readFileSync(new URL('public'+entry.url,base));if(sha(bytes)!==entry.sha256)throw Error('History original source hash mismatch: '+entry.id);
  const normalized=normalize(JSON.parse(bytes),entry),identity=JSON.stringify({current:normalized.current.map(b=>[b.t,b.o,b.h,b.l,b.c]),prior:normalized.prior.map(b=>[b.t,b.o,b.h,b.l,b.c])});
  const key='csv:'+sha(identity);if(seenKeys.has(key))throw Error('Duplicate MD history source identity.');seenKeys.add(key);
  return {key,id:entry.id,sourceSha256:entry.sha256,closes:normalized.current.map(b=>b.c),candles:normalized.current.map(({o,h,l,c})=>({o,h,l,c}))};
 }).sort((a,b)=>a.id<b.id?-1:a.id>b.id?1:0);
 return JSON.stringify({version:1,identity:HISTORY_IDENTITY,sourceCatalogSha256:sha(catalogBytes),sessions})+'\n';
}

if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){
 const text=buildHistoryCandleIndex(),asset=new URL('public/modules/history-candle-index.json',root),loader=new URL('public/modules/history-candle-data.js',root),digest=sha(text),source=readFileSync(loader,'utf8');
 if(!/HISTORY_INDEX_SHA256='[a-f0-9]{64}'/.test(source))throw Error('Missing history candle index pin.');
 if(process.argv.includes('--check')){
  verifyHistoryRetention(root,{currentBytes:text});
  if(readFileSync(asset,'utf8')!==text||!source.includes(`HISTORY_INDEX_SHA256='${digest}'`))throw Error('History candle index or pinned digest is stale.');
 }else{
  retainHistoryIndex(root,text);
  writeFileSync(asset,text);writeFileSync(loader,source.replace(/HISTORY_INDEX_SHA256='[a-f0-9]{64}'/,`HISTORY_INDEX_SHA256='${digest}'`));
 }
 console.log(JSON.stringify({asset:fileURLToPath(asset),bytes:Buffer.byteLength(text),sha256:digest,sessions:JSON.parse(text).sessions.length,check:process.argv.includes('--check')}));
}
