import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import Model from '../lib/portal/lesson-model.cjs';
import {historicalPrefix,historicalGap,matchSessionDate,observedPreviousSession} from '../lib/chart-match.mjs';
const root=new URL('../',import.meta.url),sha=bytes=>createHash('sha256').update(bytes).digest('hex');
/** Deterministic projection of the existing, hash-verified source assets. No downloads/new candles. */
export function buildChartMatchIndex(base=root){
 const catalogBytes=readFileSync(new URL('public/charts/catalog.json',base)),catalog=JSON.parse(catalogBytes),seen=new Set();
 if(catalog.version!==1||!Array.isArray(catalog.sessions)||!catalog.sessions.length)throw Error('Invalid source catalog.');
 const originals=catalog.sessions.map(reference=>{
  const date=matchSessionDate(reference.id);
  if(reference.date!==date||reference.url!==`/charts/${reference.id}.json`||seen.has(date)||!/^[a-f0-9]{64}$/.test(reference.sha256))throw Error('Invalid source reference.');seen.add(date);
  const bytes=readFileSync(new URL('public'+reference.url,base));if(sha(bytes)!==reference.sha256)throw Error('Original chart source hash mismatch.');
  const chart=JSON.parse(bytes);if(chart.id!==reference.id||chart.date!==date||chart.instrument!=='MES'||chart.intervalMinutes!==5||!Array.isArray(chart.warmup)||!chart.warmup.length)throw Error('Unexpected source chart.');
  historicalPrefix(chart,chart.current.length,{useEma:true});historicalGap(chart);
  return {reference};
 }).sort((a,b)=>a.reference.date.localeCompare(b.reference.date));
 const byDate=new Map(originals.map(row=>[row.reference.date,row.reference]));
 let crossCheckedPriorSessions=0;
 const sessions=originals.map(({reference})=>{
  const chart=JSON.parse(readFileSync(new URL('public'+reference.url,base),'utf8'));
  const gap=historicalGap(chart),prior=chart.prior.at(-1),final=chart.warmup.at(-1),previousReference=byDate.get(gap.priorSessionDate),candidatePrevious=previousReference?JSON.parse(readFileSync(new URL('public'+previousReference.url,base),'utf8')):null,sourceFamily=value=>value?.source?.provider==='TradeStation'?'tradestation':'legacy',previous=candidatePrevious&&sourceFamily(candidatePrevious)===sourceFamily(chart)?candidatePrevious:null;
  // A sparse catalog is not a trading calendar. Cross-check the actual supplied
  // prior date when present; do not substitute the latest selectable catalog day.
  const observed=chart.previousSession===undefined?null:observedPreviousSession(chart);
  if(observed&&sha(JSON.stringify(observed.bars))!==observed.sourceRowsSha256)throw Error('Observed previous-session source rows hash mismatch.');
  if(previous){const actual=previous.current.at(-1);if(!actual||actual.t!==final.t||actual.c!==final.c)throw Error('Prior exported-session final close differs from the previous real session final candle.');if(observed&&JSON.stringify(previous.current)!==JSON.stringify(observed.bars))throw Error('Observed previous-session OHLC differs from its selectable source.');crossCheckedPriorSessions++;}
  const current=chart.current.map(({t,o,h,l,c})=>({t,o,h,l,c}));
  const projected={...(chart.source?.provider==='TradeStation'?{source:chart.source}:{}),id:chart.id,title:chart.title,date:chart.date,instrument:'MES',intervalMinutes:5,current,previousSessionFinal:{t:final.t,c:final.c,source:'original-warmup-final',sourceChartSha256:reference.sha256,crossCheckedSessionId:previous?.id??null},prior:[{t:prior.t,o:prior.o,h:prior.h,l:prior.l,c:prior.c}],warmup:{value:Model.emaSequence(chart.warmup).at(-1)}};
  if(observed){
   const values=Model.emaSequence(chart.warmup),lookup=new Map(chart.warmup.map((b,i)=>[b.t,values[i]]));
   const bars=observed.bars.map(b=>({...b,ema:lookup.get(b.t)}));if(bars.some(b=>!Number.isFinite(b.ema)))throw Error('Observed previous-session EMA is missing.');
   projected.previousSession={...observed,bars};projected.previousSessionFinal.sessionBarCount=observed.barCount;projected.previousSessionFinal.sessionEndTime=observed.endTime;projected.prior=bars.slice(-12);
   historicalGap(projected);
  }
  // Exact all-prefix equivalence follows from identical bars and identical causal pre-open EMA seed.
  const actual=Model.chartIndicators(chart,chart.current.length-1).ema,derived=Model.chartIndicators(projected,projected.current.length-1).ema;
  if(actual.some((v,i)=>v!==derived[i]))throw Error('Derived EMA differs from source.');
  return {reference:{id:reference.id,title:reference.title,date:reference.date,url:reference.url,sha256:reference.sha256},chart:projected};
 });
 return JSON.stringify({version:1,sourceCatalogSha256:sha(catalogBytes),derivation:'Exact original OHLC; actual previous observed source-session final close from chronological warmup, cross-checked against its dated selectable source when available. Observed context preserves complete81/45/42-bar sessions and their final12 candles; different source families are never cross-checked or substituted. Source caveats identify missing prior dates. EMA20 pre-open seed and prior EMA from original warmup. No invented OHLC or inferred market data.',crossCheckedPriorSessions,sessions})+'\n';
}
if(process.argv[1]&&fileURLToPath(import.meta.url)===fileURLToPath(new URL('file://'+process.argv[1]))){
 const text=buildChartMatchIndex(),asset=new URL('public/modules/chart-match-index.json',root),loader=new URL('components/chart-match-data.mjs',root),digest=sha(text);
 if(process.argv.includes('--check')){
  if(readFileSync(asset,'utf8')!==text||!readFileSync(loader,'utf8').includes(`MATCH_INDEX_SHA256='${digest}'`))throw Error('Matching index or pinned hash is stale.');
 }else{
  writeFileSync(asset,text);const source=readFileSync(loader,'utf8');if(!/MATCH_INDEX_SHA256='[a-f0-9]{64}'/.test(source))throw Error('Missing index hash pin.');writeFileSync(loader,source.replace(/MATCH_INDEX_SHA256='[a-f0-9]{64}'/,`MATCH_INDEX_SHA256='${digest}'`));
 }
 console.log(JSON.stringify({asset:'public/modules/chart-match-index.json',bytes:Buffer.byteLength(text),sha256:digest,sessions:JSON.parse(text).sessions.length,check:process.argv.includes('--check')}));
}
