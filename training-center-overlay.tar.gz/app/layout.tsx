import type { Metadata } from "next";
import GuestVisitTracker from "../components/guest-visit-tracker";
import "./globals.css";
import "../public/loading-indicator.css";
export const metadata: Metadata = {
  title: "Price Action Center",
  description: "Practice price action with the Market Orders Simulator and Limit Orders Simulator.",
  robots: { index: false, follow: false },
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body><GuestVisitTracker/>{children}</body></html>;
}
