import {learnerConfiguration} from '../../lib/learner/google-config.mjs';
import AccountMarketDirection from '../../components/account-market-direction';
export const dynamic='force-dynamic';
export const metadata = { title: 'PATC Market' };
export default function MarketDirectionPage():Promise<React.JSX.Element>;
export default function MarketDirectionPage(props:{searchParams?:Promise<{history?:string|string[];replay?:string|string[]}>}):Promise<React.JSX.Element>;
export default async function MarketDirectionPage({searchParams}:{searchParams?:Promise<{history?:string|string[];replay?:string|string[]}>}={}) {
  const params=await searchParams;
  const source=params?.history==='1'?'/modules/market-direction.html?history=1':'/modules/market-direction.html';
  const onlineParams=new URLSearchParams();if(params?.history==='1')onlineParams.set('history','1');if(typeof params?.replay==='string'&&/^[a-f0-9]{8}-[a-f0-9]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[a-f0-9]{12}$/.test(params.replay))onlineParams.set('replay',params.replay);const onlineSource='/modules/market-direction.html'+(onlineParams.size?'?'+onlineParams.toString():'');
  return <main className="training-module-shell market-direction-shell">
    <h1 className="sr-only">Market Orders Simulator</h1>
    {learnerConfiguration()?<AccountMarketDirection source={onlineSource}/>:<iframe className="market-direction-frame" src={source} title="Market Orders Simulator practice" allow="fullscreen" /> }
    {!learnerConfiguration()&&<footer className="module-footer"><details><summary>Saved progress</summary><p>Practice progress stays in this browser. Progress from the previous site remains there; it is not automatically transferred between website addresses.</p></details></footer>}
  </main>;
}
