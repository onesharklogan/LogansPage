import '../trade-simulator/simulator.css';
import {learnerConfiguration} from '../../lib/learner/google-config.mjs';
import CombinedSimulator from '../../components/combined-simulator';
export const dynamic='force-dynamic';
export const metadata={title:'PATC Simulator',description:'Market and limit order practice with one combined history.'};
export default async function SimulatorPage({searchParams}:{searchParams?:Promise<{mode?:string;history?:string;replay?:string}>}){
 const params=await searchParams,query=new URLSearchParams();if(params?.history==='1')query.set('history','1');
 if(typeof params?.replay==='string'&&/^[a-f0-9]{8}-[a-f0-9]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[a-f0-9]{12}$/.test(params.replay)&&params?.mode!=='limit')query.set('replay',params.replay);
 return <CombinedSimulator accountsEnabled={!!learnerConfiguration()} initialMode={params?.mode==='limit'?'limit':'market'} initialHistory={params?.history==='1'} marketSource={'/modules/market-direction.html'+(query.size?'?'+query.toString():'')}/>;
}
