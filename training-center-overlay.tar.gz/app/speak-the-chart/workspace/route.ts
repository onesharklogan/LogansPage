import {readFile} from 'node:fs/promises';
import path from 'node:path';
import {speakChartAccess} from '../../../lib/speak-chart/access.mjs';
import {handleRenderRequest} from '../../../lib/portal/render-runtime.mjs';
export const runtime='nodejs';
export const dynamic='force-dynamic';
export async function GET(request:Request){
 const access=await speakChartAccess(request,handleRenderRequest);
 const headers={'Cache-Control':'private, no-store','Vary':'Cookie','Content-Type':'text/html; charset=utf-8','X-Content-Type-Options':'nosniff','X-Frame-Options':'SAMEORIGIN'};
 if(!access.allowed)return new Response('Administrator sign-in required.',{status:access.unavailable?503:403,headers});
 const [html,commands]=await Promise.all([readFile(path.join(process.cwd(),'lib/speak-chart/workspace.html'),'utf8'),readFile(path.join(process.cwd(),'lib/speak-chart/commands.cjs'),'utf8')]);
 return new Response(html.replace('/* SPEAK_CHART_COMMANDS */',commands),{headers});
}
