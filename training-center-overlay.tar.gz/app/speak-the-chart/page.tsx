import SpeakChartWorkspace from '../../components/speak-chart-workspace';
export const dynamic='force-dynamic';
export const metadata={title:'PATC Speak the Chart',description:'Administrator chart markup with typed commands and keyboard dictation.'};
// The server proxy requires a verified administrator before this page is rendered.
export default function SpeakChartPage(){return <SpeakChartWorkspace/>;}
