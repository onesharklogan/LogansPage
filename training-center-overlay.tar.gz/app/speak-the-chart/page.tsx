import SpeakChartWorkspace from '../../components/speak-chart-workspace';
export const dynamic='force-dynamic';
export const metadata={title:'Speak the Chart · Price Action Center',description:'Administrator chart markup with typed commands and keyboard dictation.'};
// The server proxy requires a verified administrator before this page is rendered.
export default function SpeakChartPage(){return <SpeakChartWorkspace/>;}
