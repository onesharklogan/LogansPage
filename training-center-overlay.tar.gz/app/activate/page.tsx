import type { Metadata } from 'next';
import ActivateAccount from '@/components/activate';
export const metadata: Metadata = { title: 'PATC Set Password', robots: { index: false, follow: false } };
export default function ActivatePage() { return <ActivateAccount />; }
