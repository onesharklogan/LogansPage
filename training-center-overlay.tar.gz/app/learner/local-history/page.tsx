import LearnerLocalHistory from '../../../components/learner-local-history';
export const metadata={title:'PATC Local History'};
export default function LocalHistoryPage(){return <LearnerLocalHistory/>;}
