import Studio from "@/components/studio";
export const metadata = { title: "PATC Studio" };
export const dynamic = "force-dynamic";
export default function StudioPage() { return <Studio />; }
