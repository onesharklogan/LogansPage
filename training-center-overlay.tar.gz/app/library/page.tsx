import type { Metadata } from "next";
import {learnerConfiguration} from '../../lib/learner/google-config.mjs';
import LessonAccessBoundary from '@/components/lesson-access-boundary';
import PublicLibrary from "@/components/public-library";
export const metadata: Metadata = { title: "PATC Lessons", description: "Browse slides organized in shared modules." };
export const dynamic = "force-dynamic";
export default function Home() { return <LessonAccessBoundary><PublicLibrary accountsEnabled={!!learnerConfiguration()} /></LessonAccessBoundary>; }
