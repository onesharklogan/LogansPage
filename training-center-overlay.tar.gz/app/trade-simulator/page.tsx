import './simulator.css';
import ProfiledTradeSimulator from '../../components/profiled-trade-simulator';
import {learnerConfiguration} from '../../lib/learner/google-config.mjs';
export const dynamic='force-dynamic';
export const metadata = { title: 'PATC Limit', description: 'Practice setting limit orders at specific prices' };
export default function TradeSimulatorPage() { return <ProfiledTradeSimulator accountsEnabled={!!learnerConfiguration()}/>; }
