import './simulator.css';
import CombinedSimulator from '../../components/combined-simulator';
import {learnerConfiguration} from '../../lib/learner/google-config.mjs';
export const dynamic='force-dynamic';
export const metadata={title:'PATC Simulator',description:'Market and limit order practice with one combined history.'};
/** Existing saved links retain their limit-mode replay semantics. */
export default async function TradeSimulatorPage({searchParams}:{searchParams?:Promise<{history?:string}>}){const params=await searchParams;return <CombinedSimulator accountsEnabled={!!learnerConfiguration()} initialMode="limit" initialHistory={params?.history==='1'}/>;}
