import AdminOwnerActivate from '@/components/admin-owner-activate';
export const metadata={title:'PATC Admin Activation',referrer:'no-referrer',robots:{index:false,follow:false}};
export default function AdminOwnerActivationPage(){return <AdminOwnerActivate/>;}
