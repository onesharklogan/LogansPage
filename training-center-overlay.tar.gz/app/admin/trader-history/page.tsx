import AdminTraderHistory from '@/components/admin-trader-history';
export const dynamic='force-dynamic';
export const metadata={title:'PATC Trader History'};
export default function Page(){return <AdminTraderHistory/>;}
