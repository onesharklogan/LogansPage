import {learnerConfiguration} from '../../lib/learner/google-config.mjs';
export const dynamic='force-dynamic';
import ChartMatch from '../../components/chart-match-automatic';
export const metadata={title:'Chart Match · Price Action Center',description:'Experimental browser-local screenshot recognition and historical opening-shape comparison. Similarity is not a forecast.'};
export default function ChartMatchPage():Promise<React.JSX.Element>;
export default function ChartMatchPage(props:{searchParams?:Promise<{embedded?:string|string[]}>}):Promise<React.JSX.Element>;
export default async function ChartMatchPage({searchParams}:{searchParams?:Promise<{embedded?:string|string[]}>}={}){const params=await searchParams;return <ChartMatch learnerAccounts={!!learnerConfiguration()} embedded={params?.embedded==='1'}/>;}
