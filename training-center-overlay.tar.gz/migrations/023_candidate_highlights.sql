-- PREPARED ONLY. Additive account settings; no identities, grants, or existing data changed.
-- NULL is ineligible. Enrollment of the exact verified account is a separate private operation.
BEGIN;
ALTER TABLE learner_app.accounts ADD COLUMN candidate_highlights jsonb DEFAULT NULL
 CONSTRAINT learner_candidate_highlights_check CHECK (
 candidate_highlights IS NULL OR (
 jsonb_typeof(candidate_highlights) = 'object' AND
 candidate_highlights ?& ARRAY['enabled','bullColor','bearColor'] AND
 candidate_highlights - ARRAY['enabled','bullColor','bearColor'] = '{}'::jsonb AND
 jsonb_typeof(candidate_highlights->'enabled') = 'boolean' AND
 jsonb_typeof(candidate_highlights->'bullColor') = 'string' AND
 jsonb_typeof(candidate_highlights->'bearColor') = 'string' AND
 (candidate_highlights->>'bullColor') ~ '^#[0-9A-Fa-f]{6}$' AND
 (candidate_highlights->>'bearColor') ~ '^#[0-9A-Fa-f]{6}$'));
INSERT INTO learner_app.schema_migrations(version,description) VALUES(6,'Opt-in account-specific candidate highlight preferences');
COMMIT;
