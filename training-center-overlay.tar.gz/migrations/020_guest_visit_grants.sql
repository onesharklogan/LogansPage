-- PREPARED ONLY. Requires approval for these exact narrow permissions.
-- Does not create a role or credential or grant access to any other table.
BEGIN;
GRANT SELECT,INSERT,UPDATE ON learner_app.guest_visit_days TO learner_runtime;
GRANT SELECT,INSERT,DELETE ON learner_app.guest_visit_receipts TO learner_runtime;
COMMIT;
