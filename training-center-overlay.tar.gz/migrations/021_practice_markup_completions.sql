-- PREPARED ONLY: separately approve schema-owner execution. No historical backfill.
BEGIN;
CREATE TABLE learner_app.markup_completions (
 account_id uuid NOT NULL REFERENCES learner_app.accounts(id) ON DELETE CASCADE,
 generation integer NOT NULL CHECK(generation >= 1),
 completion_id uuid NOT NULL,
 completed_at bigint NOT NULL CHECK(completed_at >= 1577836800000),
 saved_at bigint NOT NULL CHECK(saved_at >= 0),
 PRIMARY KEY(account_id,generation,completion_id)
);
REVOKE ALL ON learner_app.markup_completions FROM PUBLIC;
INSERT INTO learner_app.schema_migrations(version,description) VALUES(5,'Count-only signed-in markup action completion dates');
COMMIT;
