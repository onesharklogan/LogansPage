-- PREPARED ONLY: approve these exact runtime grants separately. No new credentials.
BEGIN;
GRANT SELECT,INSERT,DELETE ON learner_app.markup_completions TO learner_runtime;
-- Markup UPDATE is intentionally not granted: completion records are immutable.
COMMIT;
