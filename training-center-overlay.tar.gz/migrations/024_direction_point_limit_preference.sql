-- Additive owner-only Market Orders preference. Existing settings and history are untouched.
-- The API separately enforces existing server enrollment; this column does not enroll accounts.
-- Apply only to the verified learner database through the approved migration process.
BEGIN;
SET LOCAL lock_timeout = '5s';
ALTER TABLE learner_app.accounts ADD COLUMN use_point_limit boolean NOT NULL DEFAULT false;
INSERT INTO learner_app.schema_migrations(version,description) VALUES(7,'Owner-only Market Orders point-limit preference');
COMMIT;
