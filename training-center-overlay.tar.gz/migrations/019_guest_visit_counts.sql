-- PREPARED ONLY. Requires separately approved schema-owner installation.
-- Additive, empty guest counting tables. No account, history, Auth or teacher rows change.
-- No grants here. Review and apply 020_guest_visit_grants.sql separately.
-- Existing table/ledger conflicts deliberately fail closed; inspect the catalog first.
BEGIN;
CREATE TABLE learner_app.guest_visit_days (
 day date PRIMARY KEY,
 visits bigint NOT NULL CHECK (visits >= 0 AND visits <= 9007199254740991)
);
CREATE TABLE learner_app.guest_visit_receipts (
 token_hash text PRIMARY KEY CHECK (token_hash ~ '^[a-f0-9]{64}$'),
 expires_at bigint NOT NULL CHECK (expires_at >= 0)
);
CREATE INDEX guest_visit_receipts_expiry ON learner_app.guest_visit_receipts(expires_at);
REVOKE ALL ON learner_app.guest_visit_days,learner_app.guest_visit_receipts FROM PUBLIC;
INSERT INTO learner_app.schema_migrations(version,description) VALUES(4,'Anonymous guest entry counts and short-lived dedup receipts');
COMMIT;
