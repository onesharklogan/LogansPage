# Account-specific candidate highlights (unpublished candidate)

Market Orders Simulator → Indicators contains **Highlight candidates**, **Bull color**, and **Bear color** for an enrolled, server-verified learner account only. Default: disabled, bull `#c6e84b` (yellowish green), bear `#df3b82` (reddish magenta). Enabled state and each color are saved to the account and survive sign-out, reload and different devices. They are independent of practice history resets.

Candles use close versus open. Each current-session bull or bear run highlights its first two candles, immediately as revealed, with no lookahead. One-candle runs still qualify. Third/later candles keep normal colors. A doji is not highlighted and breaks a run. Session boundaries restart the count; prior-session context is unchanged. Panning/zooming and practice First Bar do not restart the count. Wick and body use the chosen color. Existing trading decisions, scoring, backgrounds, markers, EMA/pivots, historical charts and trade history are unchanged. Other tools and completed-chart review are unchanged.

## Data and eligibility

`023_candidate_highlights.sql` adds one nullable JSON column to `learner_app.accounts` with strict shape/color constraints, plus migration ledger version 6. NULL (the default for every existing/new account) means ineligible. The exact verified owner's row must be enrolled separately by an authorized operator, using private identity verification. Neither an account ID, an email, a display-name allowlist, nor a secret is shipped in client assets or this migration. No new roles, grants, authentication privileges, tables, history edits or data deletion are involved.

The API derives the account from the existing live verified session, checks context and CSRF, locks that account, and rejects preference writes unless the database row is already enrolled. Requests cannot enroll an account. Client code exposes controls only when the server supplied these preferences. Account change, logout or unresolved verification hides/disables the controls and clears candidate colors. Pending writes guard the captured account and disable overlapping preferences. Failed writes keep the last confirmed state and report a retryable error; settings are never guessed from browser storage or a profile name.

## Rollout (not executed)

1. Obtain publication, deployment and additive migration/one-account enrollment approval.
2. Apply the migration to the verified target database as the approved schema owner. All rows remain NULL/ineligible until the separate exact-account activation.
3. Activate only the previously verified owner by exact UUID and provider identity, checking that exactly one row is affected. Use defaults above, never a name-only match. Private activation SQL stays out of the public repository/archive.
4. Deploy and verify eligible sign-in, reload, picker changes, sign-out, unrelated account and Guest. No real-account preference changes are authorized as part of preparation.

The code is compatible with the previous schema: missing column omits the feature and rejects candidate preference writes. Rollback may revert the application without dropping the additive column. To withdraw enrollment, an authorized operator may set that one row to NULL, which discards its three settings; no history is touched. This document is not permission to execute any rollout/rollback.
