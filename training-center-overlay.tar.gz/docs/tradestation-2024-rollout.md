# TradeStation 2024 sessions

Adds 258 observed source sessions (20,517 five-minute bars) to the immutable 460-chart catalog, for 718 total. Existing charts, references, source hashes and saved-history identities are preserved. No prices are shifted or resampled.

## Coverage and limitations

- 248 full 81-bar dates; seven 42-bar futures-holiday dates; three 45-bar early-close dates.
- Full-day gap: July 18,2024. It remains unavailable in the calendar. July 19 uses the actual previous available July 17 context and visibly warns that the displayed change spans a missing session.
- January 1, March 29 and December 25 are the other absent 2024 weekdays, consistent with the published holiday calendar.
- Source is owner-supplied TradeStation @MES, not the existing non-back-adjusted TradingView feed. The overlap has an additive back-adjustment signature; the export does not record its exact adjustment/roll settings. No license-cleared or exchange-verified claim is made.
- Chicago is inferred from session clocks and prior DST-spanning overlap, not explicitly recorded by the CSV. The source BarEndTime is shifted exactly five minutes to the app's bar-open convention.
- EMA20 is recomputed from available RTH closes using alpha 2/21, initialized on the first of the last 2000 prior observed closes. Independent audit found exact floating-point agreement with the full available export stream on all 2024 bars. This does not recover missing July 18 bars or certify the broker's indicator settings.
- No overnight bars, bid/ask, tick path or exact fill-sequencing information is supplied.

## Safety and compatibility

The legacy mes1 asset-ID namespace remains stable; titles and source metadata explicitly identify TradeStation @MES. New suffixes42/45 describe actual short-session lengths. Runtime consumers enforce the ID's actual bar count. Sources from different provider families never substitute for each other in matcher prior-close cross-checks. In particular TradeStation December 31, 2024 does not replace the original TradingView context for January 2, 2025.

Catalog limits increase from 500 to 1000, catalog fetches from 256KiB to 512KiB, and the matcher projection's bounded response limit from 8MiB to 12MiB (actual 9,310,576 bytes). The history projection has 718 rows/3,211,953 bytes and retains the existing 4MiB bound. All prior content-addressed history assets remain present.

The new source verifier pins the raw export identity, required source subset, calendar coverage and frozen460 manifest. Every new current/prior/warmup candle is reconstructed from the subset. Older acquisition verifiers run unchanged on their exact 460-chart projection. The matcher builder processes source charts one at a time rather than retaining every large warmup array.

## Reproduce

Run `python scripts/generate-tradestation-2024.py --source ORIGINAL_EXPORT.csv --baseline FROZEN460_ROOT --out TARGET_ROOT` only in a prepared copy. The original full export must have SHA256 bc9e5f7714df4974b6bfc109ee52df2486895e6f7744d3b79fd12e0482829820. Do not run it against a mixed or already-expanded baseline.

Then regenerate both index assets with their existing build scripts. Run `npm run typecheck`, the focused `tradestation-*.test.mjs` tests, and `npm run check:release`. Memory-constrained environments should run checks serially with a 512MiB Node heap. Local dependency symlinks require `npm run build -- --webpack`; the deployment archive has ordinary installed dependencies.

No database migration or existing learner-data mutation is needed. This isolated candidate does not incorporate concurrently prepared pattern-encyclopedia, recap-color or charts-per-day changes; combine their narrow patches and rerun checks before publication.
