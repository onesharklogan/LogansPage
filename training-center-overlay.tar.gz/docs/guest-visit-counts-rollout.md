# Anonymous guest session counts

## What is counted

When a visible, top-level public app page opens, the browser makes a best-effort anonymous session-count request. Direct simulator links and dismissal of the home sign-in prompt are included. Public routes are allowlisted in `components/guest-visit-tracker.tsx`; admin, teacher editor, sign-in callback and embedded module routes do not trigger counting. Server checks reject cross-origin writes and verify absence of an authenticated learner or teacher/admin session. A failed identity check skips the count, never guest practice.

One anonymous session means one randomly generated tab token, shared across route changes and refresh in that tab for 24 hours. Tabs normally have separate tokens, but a browser's Duplicate Tab/session restore can copy sessionStorage and will conservatively share a count. Clearing browser storage, a fresh tab or expiry can start another count. This is **not unique people, verified logins, accounts, or page views**. A later login does not delete a genuine earlier guest visit. Login/logout within an already counted tab does not increment it again. Older visits cannot be reconstructed.

The admin card shows all recorded sessions, today's UTC count, the inclusive latest seven UTC calendar days, and daily counts for the latest thirty calendar days. `since` means the first day with a recorded session, not the feature's activation date. Empty enabled tables return zero with no first date. Disabled or failing storage is shown as unavailable, never as a misleading zero.

## Data and limitations

The request accepts exactly `visitId` (random UUID) and `startedAt` (dedup window start). No name, email, IP address, user agent, referrer, chart, screenshot, trade, score, account ID or guest trading history is sent in its body or saved by this feature. Normal service infrastructure may maintain its existing operational logs; this change does not configure logging. No guest account or learner history row is created.

The database retains only UTC daily aggregate totals plus a one-way hash of the random tab token and its expiry for retry deduplication. The raw token stays in tab sessionStorage, not localStorage or a browser profile. Receipts expire after the token's 24-hour window (a maximum one-minute client clock-ahead tolerance is accepted); expired hashes are pruned transactionally on the next successful guest count. In a dormant deployment, expired hashes can remain until the next counting request. There is no association with learner or teacher records and no per-guest history or drilldown.

Counts are best effort: blocked sessionStorage, an offline/blocked request, an unresolved sign-in, a clock more than one minute ahead, an expired delayed request, or load limiting can omit a session. A lost response retries the same token on a later page lifecycle event, so a successful server count is not doubled. The record transaction atomically inserts a unique receipt and increments one day, rolling both back on failure. Duplicate requests return only an acknowledgement, never totals. The public endpoint cannot certify a human visit and scripted traffic can inflate counts; the process-local limiter bounds load without identifying visitors. Do not use the number as a security/audit or unique-user metric.

## Prepared rollout, not applied

1. Obtain approval to publish to the exact public repository/branch and deploy the reviewed application. This source includes the separately pending v97 mobile matcher changes; do not discard them during integration.
2. Separately review/approve applying `migrations/019_guest_visit_counts.sql` to the verified learner database as its existing schema owner. It adds two empty tables, one expiry index and learner migration ledger version 4. It does not alter existing account/history/teacher/Auth rows or existing table definitions. Table/version collisions fail closed and require inspection, not forced retry.
3. Separately review/approve the precise permissions in `migrations/020_guest_visit_grants.sql`: SELECT/INSERT/UPDATE on the new daily table and SELECT/INSERT/DELETE on the new receipt table to existing `learner_runtime`. It creates no role or credential and grants access to no existing table. No new secret is required.
4. Deploy the code with `GUEST_VISITS_ENABLED` absent or false. Existing app and guest practice remain functional before the migration. The guest card reports unavailable while disabled.
5. After migration/grant verification, explicitly set `GUEST_VISITS_ENABLED=true` and restart the service. Existing learner readiness configuration must remain valid. No startup migration is run; `npm run db:migrate` intentionally does not include these files.
6. Use a synthetic anonymous session with a clean tab, repeat/refresh/navigate, then verify exactly one increment through an existing approved admin session. Verify signed-in learner and password/Google teacher/admin sessions do not increment; verify guests/authors cannot read `/api/author/guest-visits` and missing storage yields unavailable. Do not reset real counters to hide the synthetic smoke test; note its one test session if testing production.

Rollback: unset the feature flag and restart. No existing app data needs restoring; the new tables can remain intact. Do not drop or purge them without separate deletion approval. This preparation and its isolated local tests did not change production schema, grants, roles, credentials, flags, data, repository, or deployment.
