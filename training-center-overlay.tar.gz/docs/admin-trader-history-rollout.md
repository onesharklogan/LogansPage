# Administrator trader history

Prepared read-only Teacher Studio module at `/admin/trader-history`, linked from Teacher Area and Teacher Studio for verified administrators. `/api/author/trader-history` lists saved accounts; `/api/author/trader-history/:accountId` returns current-generation simulator summary pages. Both use existing server-verified teacher sessions and require the active admin role before reads and again before returning data. Authors, unapproved learners and guests are denied. Cross-origin reads are rejected and responses use private/no-store.

The module shows account display names (with an eight-character reference for same-name disambiguation), saved attempt counts, chart identities, completion/save timestamps, and allowlisted numeric educational simulator results. It does not expose provider identities, emails, authentication/session data, reset tokens, learner preferences, Lesson completion marks, raw practice decisions or account exports. Browser-local and guest practice are excluded. Pagination uses at most 50 results plus one lookahead and account/generation-bound cursors; reset invalidates a stale history cursor. No history write or deletion routes are provided.

## Activation boundary

`ADMIN_TRADER_HISTORY_ENABLED=true` enables the server feature only when the existing learner configuration is valid. It defaults off. Before activating, confirm that approved administrators may review saved simulator account summaries across traders and that this matches the site's privacy policy. The feature updates learner-facing and admin-grant copy to disclose this access. Deployment/activation is a separate decision, not performed by this candidate.

The implementation reuses the application's existing learner connection with SELECT-only statements. No credentials, database grants, schemas, data, or roles are changed. The existing teacher database role remains isolated. No new migration is required. Missing configuration returns an unavailable state rather than falling back to local history or teacher-owned storage.

Disable by removing the flag or setting it to false. No rollback or data cleanup is required because the feature writes no history. Existing learner-owned history APIs, simulator scoring, and saved attempts are unchanged.

## Optional practice insights extension

The prepared `/api/author/trader-history/:accountId/practice` extension returns the existing verified simulator stats plus count-only markup action history. Existing list/detail routes remain unchanged. It uses a consistent read-only snapshot and the same admin check/recheck gates. Markup availability is separately gated by `LEARNER_PRACTICE_MARKUPS_ENABLED`, default false, with prepared migrations 021/022 and explicit schema/grant/activation approvals. See `practice-insights-rollout.md` for the count-only scope, first-recorded-date semantics, bounds, export/reset behavior and rollback retention limitation. No deployment or activation was performed by this candidate.
