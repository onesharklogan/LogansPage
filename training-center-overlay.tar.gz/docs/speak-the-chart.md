# Speak the Chart (administrator preview)

The new `/speak-the-chart` tool is a private copy of Chart Marker. Open **Admin → Speak the Chart** while signed in as an administrator. Ordinary authors and guests are rejected by the server before the page loads. The private iframe route verifies the administrator again and never serves cacheable HTML. There is no public HTML copy. The original Chart Marker and all stored charts, simulator attempts, teacher content and data remain unchanged.

## Use

1. Choose **Load predefined chart** and a historical session.
2. Tap the command field and type, or use the microphone on the iPhone keyboard. Desktop system dictation can also supply text.
3. Review the recognized command and the endpoint description, then choose **Apply command**.
4. Try `bar 44 through 47, line on lows`, then another command such as `bar 42 through 49, line on highs` for the other boundary. `undo` and `redo` also work. The existing toolbar Undo and Redo work as before.

Number words such as `forty four` are supported. Bar numbers refer to the selected current session's bars 1–81, not the unnumbered prior-session context. Commands join the actual wick low/high of the specified first and last bars. They do not fit all candles in between, extend a ray, infer pivots, identify a trading pattern, or claim one line is a full wedge. A wedge needs two separately specified boundaries and human interpretation.

Typed/dictated text does not draw until Apply. Unsupported, ambiguous, reversed, missing and out-of-range commands leave drawings unchanged. Repeated clicks cannot create duplicates. Each successful line is one reversible drawing operation. An image is installed with its verified coordinates only after successful decoding. Failed/canceled/stale loads preserve the previous chart and its coordinates. Loading a different local image clears coordinates rather than reusing them on unrelated pixels.

Exact bar commands are supported only for predefined sessions, whose PNG and anchors come from the same actual historical candle renderer. Uploaded/pasted images do not carry verified OHLC or bar geometry, so they retain manual Marker tools and reject numeric anchoring instead of guessing. This version does not perform image interpretation or paid transcription.

## Privacy and persistence

The site records no audio and does not request microphone permission. The existing `microphone=()` Permissions Policy remains unchanged. Dictation is supplied by the user's keyboard/operating system; its availability, processing and privacy behavior depend on that device. No paid speech service is configured. Images, commands and drawings stay in the current open workspace; use **Save PNG** to keep the annotated result. No new server write endpoint, database migration or storage permission is introduced.

## Validation and remaining device checks

Run `node --test tests/speak-chart.test.mjs`, `npm run typecheck`, `npm run build -- --webpack`, and `npm run check:release`.

Automated tests cover every supplied historical session's endpoint wick coordinates, current-session numbering despite prior context, text/IME behavior, duplicate prevention, Undo/Redo, malformed/stale/untrusted bridge messages, image decode/geometry mismatch, pasted image refusal, server admin gates, pending/canceled loads, and normalized rendering at desktop/mobile/landscape stage sizes. These deterministic DOM/state tests are not a browser/device rendering test.

Native iPhone keyboard dictation, Safari rendering, actual touch/virtual-keyboard layout, PNG export appearance and mobile fullscreen still require browser/device validation. Local Chromium could not launch in the current environment because socket creation was disallowed, including with the available escalation path. Do not claim these device checks passed.
