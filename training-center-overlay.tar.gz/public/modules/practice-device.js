/** Coarse client-reported device class, captured once at attempt start.
 * Phones/tablets count as mobile, including desktop-UA iPadOS. Window size is
 * ignored. No raw user-agent/device identifier is stored. Not an auth signal. */
export function practiceIsMobile(navigator=globalThis.navigator){
 const ua=typeof navigator?.userAgent==='string'?navigator.userAgent:'';
 if(/Android|iPhone|iPad|iPod|Mobile|Tablet|Silk|Kindle/i.test(ua))return true;
 if((navigator?.platform==='MacIntel'||/Macintosh/i.test(ua))&&navigator?.maxTouchPoints>1)return true;
 if(typeof navigator?.userAgentData?.mobile==='boolean')return navigator.userAgentData.mobile;
 return false;
}
