/** One-shot chart-only handoff. New tabs consume a bounded temporary sessionStorage payload. No network or full-session data. */
export const HANDOFF_PREFIX='chart-match-image-v1:';
const TTL=90000,MAX_BYTES=20*1024*1024;
const receiving=new WeakMap();
/** Strip the source down to observed, currently visible opening bars. Reject panned-away openings. */
export function visibleOpeningSnapshot(view,{showEma=true}={}){
  if(!view||![view.width,view.height,view.left,view.right,view.top,view.bottom,view.lo,view.hi,view.start,view.step,view.priorCount].every(Number.isFinite)||view.hi<=view.lo||view.step<=0)throw Error('Open a chart before opening Chart Matcher.');
  const visible=view.visible||[],prior=visible.find(c=>c.prior&&c.slot===view.priorCount-1),opening=visible.find(c=>!c.prior&&c.index===0);
  if(!prior||!opening)throw Error('Bring the last prior-context candle and today’s opening candle into view, then try Open Chart Matcher again. Zoom out the time axis or pan back to the opening; hidden candles are never captured.');
  const priorTime=typeof prior.t==='string'?prior.t.slice(-5):'';
  if(!/^(?:0[89]|1[0-5]):[0-5][05]$/.test(priorTime)||priorTime>'15:10'||!/^\d{4}-\d{2}-\d{2} /.test(prior.t)||!/^\d{4}-\d{2}-\d{2} 08:30$/.test(opening.t)||prior.t.slice(0,10)>=opening.t.slice(0,10))throw Error('The visible prior candle time could not be verified. Choose a historical chart and try again.');
  const selected=visible.filter(c=>c===prior||!c.prior),slots=new Set(selected.map(c=>c.slot));
  if(selected.length<8)throw Error('Reveal at least seven opening candles, then try Open Chart Matcher again.');
  if(selected.some((c,i)=>!['o','h','l','c'].every(k=>Number.isFinite(c[k]))||c.slot!==prior.slot+i))throw Error('The visible opening sequence is incomplete. Fit the chart and try again.');
  // No original references or unrecognized fields survive this boundary.
  return {width:view.width,height:view.height,left:view.left,right:view.right,top:view.top,bottom:view.bottom,lo:view.lo,hi:view.hi,start:view.start,step:view.step,
    candles:selected.map(c=>({o:c.o,h:c.h,l:c.l,c:c.c,slot:c.slot,prior:!!c.prior})),
    ema:showEma?(view.visibleEma||[]).filter(p=>slots.has(p.slot)&&Number.isFinite(p.value)).map(p=>({slot:p.slot,value:p.value})):[],
    priorTime};
}
/** A clean chart-only export of the same visible prices/viewport, without trade/account overlays.
 * Earlier prior context is cropped to the one prior-final candle required by opening matching.
 * Rasterizing at 2x improves small wick/axis readability without changing any candle values. */
export function renderVisibleChart(snapshot,doc=document){
  const s=snapshot,firstX=s.left+(s.candles[0].slot-s.start)*s.step,plotRight=s.width-s.right;
  const cropLeft=Math.max(s.left,firstX),plotWidth=plotRight-cropLeft,axis=100,width=Math.max(240,Math.ceil(plotWidth+axis+16)),height=Math.max(160,Math.ceil(s.height));
  if(plotWidth<12||s.height-s.top-s.bottom<20||width>4000||height>1500||width*height*4>12000000)throw Error('Resize the chart to a readable size, then try again.');
  const canvas=doc.createElement('canvas');canvas.width=width*2;canvas.height=height*2;
  const ctx=canvas.getContext('2d');if(!ctx)throw Error('Chart export is unavailable in this browser.');
  ctx.scale(2,2);ctx.fillStyle='#101a27';ctx.fillRect(0,0,width,height);
  const left=12,right=12+plotWidth,top=s.top,bottom=s.height-s.bottom,x=slot=>left+s.left+(slot-s.start+.5)*s.step-cropLeft,y=value=>bottom-(value-s.lo)/(s.hi-s.lo)*(bottom-top);
  ctx.font='16px monospace';ctx.textAlign='left';
  const minTick=Math.ceil(s.lo*4)/4,maxTick=Math.floor(s.hi*4)/4;if(maxTick-minTick<1||bottom-top<80)throw Error('Zoom out the price scale or enlarge the chart so five price labels fit, then try again.');
  for(let i=0;i<=4;i++){const price=Math.round((maxTick-(maxTick-minTick)*i/4)*4)/4,yy=y(price);ctx.strokeStyle='#29384a';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(left,yy);ctx.lineTo(right,yy);ctx.stroke();ctx.fillStyle='#c8d8e8';ctx.fillText(price.toFixed(2),right+8,yy+4);}
  ctx.save();ctx.beginPath();ctx.rect(left,top,plotWidth,bottom-top);ctx.clip();
  for(const c of s.candles){ctx.strokeStyle=ctx.fillStyle=c.c>=c.o?'#67dfb3':'#f18da6';ctx.lineWidth=Math.min(1.4,Math.max(.6,s.step*.3));ctx.beginPath();ctx.moveTo(x(c.slot),y(c.h));ctx.lineTo(x(c.slot),y(c.l));ctx.stroke();const w=Math.max(.7,s.step*.56);ctx.fillRect(x(c.slot)-w/2,Math.min(y(c.o),y(c.c)),w,Math.max(1,Math.abs(y(c.o)-y(c.c))));}
  if(s.ema.length){ctx.strokeStyle='#f6c760';ctx.lineWidth=2;ctx.beginPath();s.ema.forEach((p,i)=>{if(i===0)ctx.moveTo(x(p.slot),y(p.value));else ctx.lineTo(x(p.slot),y(p.value));});ctx.stroke();}
  ctx.restore();ctx.fillStyle='#c8d8e8';ctx.font='12px monospace';
  // Ordered layout is explicit: exactly one prior-final candle, then today's opening prefix.
  ctx.font='16px monospace';ctx.fillText(s.priorTime,left,Math.max(16,top-12));
  ctx.fillText('08:30',Math.max(left,x(s.candles[1].slot)-20),bottom+30);
  return canvas;
}
export const LOCAL_HANDOFF_PREFIX='chart-match-local-v1:';
const MAX_LOCAL_BYTES=2*1024*1024;
const localReceiving=new WeakMap();
/** Encode and deposit before navigation: a foreground matcher must not depend on a
 * simulator tab that iOS may suspend. Only the new tab stores the bounded payload.
 * sessionStorage is temporary, not guaranteed memory-only; expired payloads are rejected. */
export function openChartMatchImage(canvas,{onStatus=(_message)=>{},onError=(_message)=>{},onDone=()=>{},priorTime='',excludeSha256='',container=/** @type {HTMLElement|null} */(null),returnFocus=/** @type {HTMLElement|null} */(null)}={},win=window){
  if(container)return openInlineChartMatchImage(canvas,{container,returnFocus,priorTime,excludeSha256,onStatus,onError,onDone},win);
  let popup=null,key='',ended=false;
  const done=()=>{if(!ended){ended=true;onDone();}};
  const fail=message=>{try{if(key)popup?.sessionStorage.removeItem(key);}catch{}try{popup?.close();}catch{}done();onError(message);};
  if(!win.crypto?.getRandomValues){fail('Secure chart transfer is unavailable in this browser. Save/paste a chart screenshot manually.');return()=>{};}
  if(!/^[a-f0-9]{64}$/.test(excludeSha256)||!/^(?:0[89]|1[0-5]):[0-5][05]$/.test(priorTime)||priorTime>'15:10'){fail('The visible chart reference could not be verified. Reopen the session and try again.');return()=>{};}
  // Reserve the tab immediately within the trusted click, before PNG encoding.
  try{popup=win.open('about:blank','_blank');}catch{}
  if(!popup){fail('The new tab was blocked. Allow pop-ups for this site, then click Open Chart Matcher again.');return()=>{};}
  let image;
  try{
    image=canvas.toDataURL('image/png');
    if(!/^data:image\/png;base64,[A-Za-z0-9+/]+={0,2}$/.test(image)||image.length>Math.ceil(MAX_LOCAL_BYTES/3)*4+22)throw Error();
  }catch{fail('The chart image could not be prepared at this size. Resize the chart and try again.');return()=>{};}
  key=LOCAL_HANDOFF_PREFIX+Array.from(win.crypto.getRandomValues(new Uint8Array(24)),n=>n.toString(16).padStart(2,'0')).join('');
  try{
    // Only a newly opened blank tab is cleared, before it ever loads the app.
    popup.opener=null;popup.sessionStorage.clear();
    popup.sessionStorage.setItem(key,JSON.stringify({image,priorTime,excludeSha256,expires:Date.now()+TTL}));
  }catch{fail('This browser could not temporarily store this chart in the new tab. Check this site’s storage permissions or try a smaller chart screenshot.');return()=>{};}
  try{popup.location.replace('/chart-match#'+key);}catch{fail('Chart Matcher could not open. Return to the simulator and try again.');return()=>{};}
  image=null;done();onStatus('Chart opened in a new tab. Your simulator stays paused here.');
  // Navigation has completed the source-side handoff. Unmount must not erase it.
  return()=>{};
}
/** Consume before validation so corrupt or expired data cannot survive retries. */
function receiveLocalChartMatchHandoff({onImage,onStatus,onError},win){
  const match=new RegExp('^#'+LOCAL_HANDOFF_PREFIX+'([a-f0-9]{48})$').exec(win.location.hash);
  const retained=localReceiving.get(win);
  if(!match&&!retained)return null;
  if(retained)return dispatchLocal(retained,{onImage,onStatus},win);
  const key=LOCAL_HANDOFF_PREFIX+match[1];
  win.history.replaceState(win.history.state,'',win.location.pathname+win.location.search);
  let raw,storageFailed=false;
  try{raw=win.sessionStorage.getItem(key);}catch{storageFailed=true;}
  try{win.sessionStorage.removeItem(key);}catch{storageFailed=true;}
  if(storageFailed){onError('Chart transfer storage is unavailable. Close this matcher tab, then return to the simulator and try again, or paste a screenshot.');return()=>{};}
  try{
    if(!raw||raw.length>Math.ceil(MAX_LOCAL_BYTES/3)*4+1024)throw Error();
    const data=JSON.parse(raw);
    if(!Number.isFinite(data.expires)||data.expires<Date.now()||data.expires>Date.now()+TTL||!/^[a-f0-9]{64}$/.test(data.excludeSha256)||!/^(?:0[89]|1[0-5]):[0-5][05]$/.test(data.priorTime)||data.priorTime>'15:10'||typeof data.image!=='string'||!/^data:image\/png;base64,[A-Za-z0-9+/]+={0,2}$/.test(data.image))throw Error();
    const bytes=Uint8Array.from(atob(data.image.slice(22)),c=>c.charCodeAt(0));
    if(bytes.length<8||bytes.length>MAX_LOCAL_BYTES||![137,80,78,71,13,10,26,10].every((b,i)=>bytes[i]===b))throw Error();
    const pending={file:new File([bytes],'visible-simulator-chart.png',{type:'image/png'}),priorTime:data.priorTime,excludeSha256:data.excludeSha256};
    localReceiving.set(win,pending);
    return dispatchLocal(pending,{onImage,onStatus},win);
  }catch{onError('This chart transfer expired or could not be accepted. Return to the simulator and click Open Chart Matcher again.');}
  return()=>{};
}
function dispatchLocal(pending,{onImage,onStatus},win){
  let active=true;const subscription=Symbol();pending.active=subscription;
  queueMicrotask(()=>{if(!active||localReceiving.get(win)!==pending)return;localReceiving.delete(win);onStatus('Receiving the visible simulator chart…');onImage(pending.file,pending.priorTime,pending.excludeSha256);});
  return(discard=false)=>{active=false;if(discard){localReceiving.delete(win);return;}queueMicrotask(()=>{if(localReceiving.get(win)===pending&&pending.active===subscription)localReceiving.delete(win);});};
}
/** Inline transfer stays in this page's frame tree and memory, never popup/storage. */
const inlinePanels=new WeakMap();
export function openInlineChartMatchImage(canvas,{container,returnFocus=null,priorTime='',excludeSha256='',onStatus=(_message)=>{},onError=(_message)=>{},onDone=()=>{}}={},win=window){
  let ended=false,finished=false,blob=null,ready=false,sent=false,timer=null;
  const done=()=>{if(!finished){finished=true;onDone();}};
  if(!container||!container.isConnected||!/^[a-f0-9]{64}$/.test(excludeSha256)||!/^(?:0[89]|1[0-5]):[0-5][05]$/.test(priorTime)||priorTime>'15:10'){done();onError('The visible chart reference could not be verified. Reopen the session and try again.');return()=>{};}
  inlinePanels.get(container)?.();
  const doc=container.ownerDocument,section=doc.createElement('section'),header=doc.createElement('div'),title=doc.createElement('h2'),note=doc.createElement('p'),close=doc.createElement('button'),frame=doc.createElement('iframe');
  section.setAttribute('aria-label','Matching charts');section.dataset.inlineChartMatcher='true';section.style.cssText='width:100%;min-width:0;margin:18px 0;border:1px solid #45617b;border-radius:12px;background:#0b111a;overflow:hidden;scroll-margin-top:72px;color:#e2effb';
  header.style.cssText='display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:8px;padding:12px 16px';
  title.textContent='Matching charts';title.tabIndex=-1;title.style.cssText='margin:0;font:700 20px system-ui';
  close.type='button';close.textContent='Close · back to simulator';close.style.cssText='min-height:44px;padding:8px 12px;border:1px solid #58758e;border-radius:8px;background:#183146;color:#e2effb;font:inherit;cursor:pointer';
  note.textContent='Your simulator is paused above. This comparison uses only the visible chart.';note.style.cssText='margin:0;padding:0 16px 12px;font:13px/1.5 system-ui;color:#adc1d4';
  frame.title='Matching historical charts';frame.style.cssText='display:block;width:100%;height:420px;border:0;background:#0b111a';frame.setAttribute('scrolling','no');
  header.append(title,close);section.append(header,note,frame);
  const cleanup=()=>{if(ended)return;ended=true;blob=null;win.clearTimeout(timer);win.removeEventListener('message',message);section.remove();returnFocus?.setAttribute('aria-expanded','false');if(inlinePanels.get(container)===cleanup)inlinePanels.delete(container);done();};
  const dismiss=()=>{cleanup();onStatus('Chart Matcher closed. Your simulator stays paused.');returnFocus?.focus({preventScroll:true});returnFocus?.scrollIntoView({block:'center',behavior:'auto'});};
  const fail=message=>{cleanup();onError(message);};
  const send=()=>{if(ended||!ready||!blob||sent)return;sent=true;frame.contentWindow?.postMessage({type:'chart-match-inline-image',blob,priorTime,excludeSha256},win.location.origin);};
  function message(event){
    if(ended||event.origin!==win.location.origin||event.source!==frame.contentWindow)return;
    if(event.data?.type==='chart-match-inline-ready'){ready=true;send();}
    if(event.data?.type==='chart-match-inline-received'){blob=null;win.clearTimeout(timer);done();onStatus('Matching charts are open below. Your simulator stays paused.');}
    if(event.data?.type==='chart-match-inline-height'&&Number.isFinite(event.data.height)){const height=Math.max(240,Math.min(30000,Math.ceil(event.data.height)));if(frame.style.height!==height+'px')frame.style.height=height+'px';}
    if(event.data?.type==='chart-match-inline-close')dismiss();
  }
  close.onclick=dismiss;inlinePanels.set(container,cleanup);win.addEventListener('message',message);
  frame.src='/chart-match?embedded=1';container.append(section);returnFocus?.setAttribute('aria-expanded','true');
  onStatus('Opening matching charts below…');
  win.requestAnimationFrame(()=>{if(ended)return;win.requestAnimationFrame(()=>{if(ended)return;section.scrollIntoView({block:'start',behavior:'auto'});title.focus({preventScroll:true});});});
  timer=win.setTimeout(()=>fail('Chart Matcher did not finish loading. Your simulator is unchanged. Tap Open Chart Matcher to retry.'),90000);
  try{canvas.toBlob(value=>{if(ended)return;if(!value||value.type!=='image/png'||value.size<8||value.size>MAX_BYTES){fail('The chart image could not be prepared at this size. Resize the chart and try again.');return;}blob=value;send();},'image/png');}catch{fail('The chart image could not be prepared. Resize the chart and try again.');}
  return cleanup;
}
/** The dedicated embedded receiver accepts one chart only from its same-origin parent. */
export function receiveInlineChartMatchHandoff({onImage,onStatus=(_message)=>{},onError=(_message)=>{}},win=window){
  let active=true,received=false;
  const message=event=>{
    if(!active||received||event.source!==win.parent||event.origin!==win.location.origin||event.data?.type!=='chart-match-inline-image')return;
    const data=event.data;
    if(!(data.blob instanceof Blob)||data.blob.type!=='image/png'||data.blob.size<8||data.blob.size>MAX_BYTES||!/^[a-f0-9]{64}$/.test(data.excludeSha256)||!/^(?:0[89]|1[0-5]):[0-5][05]$/.test(data.priorTime)||data.priorTime>'15:10'){onError('This chart image could not be accepted. Close Chart Matcher and try again.');return;}
    received=true;win.parent.postMessage({type:'chart-match-inline-received'},win.location.origin);
    onStatus('Reading your visible simulator chart…');onImage(new File([data.blob],'visible-simulator-chart.png',{type:'image/png'}),data.priorTime,data.excludeSha256);
  };
  win.addEventListener('message',message);win.parent.postMessage({type:'chart-match-inline-ready'},win.location.origin);
  return()=>{active=false;win.removeEventListener('message',message);};
}
/** Receives a bounded one-shot PNG; also accepts legacy in-flight BroadcastChannel transfers. */
export function receiveChartMatchHandoff({onImage,onStatus=(_message)=>{},onError=(_message)=>{}},win=window){
  if(win.parent&&win.parent!==win&&new URLSearchParams(win.location.search).get('embedded')==='1')return receiveInlineChartMatchHandoff({onImage,onStatus,onError},win);
  const local=receiveLocalChartMatchHandoff({onImage,onStatus,onError},win);if(local)return local;
  const match=new RegExp('^#'+HANDOFF_PREFIX+'([a-f0-9]{48})$').exec(win.location.hash);
  if(match)receiving.set(win,{token:match[1],expires:Date.now()+TTL});
  const pending=receiving.get(win);if(!pending||pending.expires<=Date.now()){receiving.delete(win);return()=>{};}
  win.clearTimeout(pending.releaseTimer);const subscription=Symbol();pending.active=subscription;
  // Keep reload/back history free of even the ephemeral transfer token.
  win.history.replaceState(win.history.state,'',win.location.pathname+win.location.search);
  if(typeof win.BroadcastChannel!=='function'){onError('Chart transfer is unavailable in this browser. Paste a chart screenshot instead.');return()=>{};}
  const channel=new win.BroadcastChannel(HANDOFF_PREFIX+pending.token);let done=false;
  const cleanup=(discard=false)=>{if(done)return;done=true;win.clearTimeout(timer);if(discard)channel.postMessage({type:'cancelled'});channel.close();if(discard){receiving.delete(win);return;}if(receiving.get(win)===pending)pending.releaseTimer=win.setTimeout(()=>{if(receiving.get(win)===pending&&pending.active===subscription)receiving.delete(win);},0);};
  const timer=win.setTimeout(()=>{receiving.delete(win);cleanup();onError('No chart arrived. Keep the simulator tab open and click Open Chart Matcher there again.');},Math.max(1,pending.expires-Date.now()));
  channel.onmessage=event=>{if(done)return;const data=event.data;if(data?.type==='error'){receiving.delete(win);cleanup();onError('The chart transfer failed. Return to the simulator and click Open Chart Matcher again.');return;}if(data?.type!=='image')return;
    if(!/^[a-f0-9]{64}$/.test(data.excludeSha256)||!/^(?:0[89]|1[0-5]):[0-5][05]$/.test(data.priorTime)||data.priorTime>'15:10'||!(data.blob instanceof Blob)||data.blob.type!=='image/png'||data.blob.size<1||data.blob.size>MAX_BYTES){receiving.delete(win);cleanup();onError('This chart image could not be accepted. Try opening it again from the simulator.');return;}
    channel.postMessage({type:'received'});receiving.delete(win);cleanup();onImage(new File([data.blob],'visible-simulator-chart.png',{type:'image/png'}),data.priorTime,data.excludeSha256);
  };
  onStatus('Receiving the visible simulator chart…');channel.postMessage({type:'ready'});return cleanup;
}
