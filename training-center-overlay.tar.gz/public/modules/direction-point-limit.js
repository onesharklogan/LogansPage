/** Optional account-saved session stop for the existing server-enrolled owner.
 * This control never closes a position or scores candles. The simulator calls
 * reached only when an actual position closes, using the confirmed preference.
 */
export const SESSION_POINT_LIMIT = 20;
export function createPointLimitUI({bridge,container,pause,canEdit=()=>true,documentObject=document}) {
 const read=()=>bridge?.enabled===true&&bridge.mode==='account'?bridge.readPointLimitPreference?.()??null:null;
 if(!read())return null;
 const root=documentObject.createElement('div');root.id='pointLimitControls';root.className='direction-bracket-controls';root.style.maxWidth='100%';const previousWrap=container.style.flexWrap;container.style.flexWrap='wrap';
 const label=documentObject.createElement('label'),check=documentObject.createElement('input');check.type='checkbox';check.id='usePointLimit';label.append(check,'Point limit: ±20');
 const help=documentObject.createElement('details'),summary=documentObject.createElement('summary'),note=documentObject.createElement('p');
 summary.textContent='Point limit rules';note.id='pointLimitHelp';note.textContent='After a position closes, finish the session if net closed-position points are +20 or more, or −20 or less. Open positions are never closed by this option. A reversal that reaches the limit finishes Neutral without opening the other side. Your choice is saved to your profile and restored when you sign in on another device. Off until you choose it.';
 const status=documentObject.createElement('span');status.id='pointLimitStatus';status.setAttribute('role','status');status.setAttribute('aria-live','polite');status.style.cssText='flex-basis:100%;font-size:11px;color:#b1c2d3;overflow-wrap:anywhere';
 check.setAttribute('aria-describedby',note.id+' '+status.id);help.append(summary,note);root.append(label,help,status);container.append(root);
 let enabled=false,pending=false,disposed=false;
 function update(){if(disposed)return;const value=read();if(value)enabled=value.usePointLimit===true;else if(bridge.ownerValid?.()===false||bridge.guard())enabled=false;root.hidden=!value;root.style.display=value?'flex':'none';check.checked=enabled;check.disabled=!value||pending||!bridge.canMutate()||!canEdit();if(!value)status.textContent='';}
 async function save(next){if(disposed||pending||!read()||!bridge.canMutate()||!canEdit()){update();return;}pause();pending=true;status.textContent='Saving point limit…';update();try{await bridge.savePointLimitPreference(next);if(!disposed&&bridge.guard())status.textContent='Point limit saved to your profile.';}catch(error){if(!disposed&&bridge.guard())status.textContent=error?.message||'Could not confirm the point limit setting. Retry.';}finally{pending=false;update();}}
 check.onchange=()=>save(check.checked===true);
 const unsubscribe=bridge.subscribe(update);update();
 return Object.freeze({update,reached(total){const value=read();return !disposed&&value?.usePointLimit===true&&Number.isFinite(total)&&(total>=SESSION_POINT_LIMIT||total<=-SESSION_POINT_LIMIT);},dispose(){disposed=true;enabled=false;unsubscribe();root.remove();container.style.flexWrap=previousWrap;}});
}
