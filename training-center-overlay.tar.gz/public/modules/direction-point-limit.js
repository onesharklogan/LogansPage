/** Optional, page-private session stop for the existing server-enrolled owner.
 * This control never closes a position, scores candles, or persists a preference.
 * The simulator calls reached only when an actual position closes.
 */
export const SESSION_POINT_LIMIT = 20;
export function createPointLimitUI({bridge,container,pause,canEdit=()=>true,documentObject=document}) {
 const eligible=()=>bridge?.enabled===true&&bridge.mode==='account'&&!!bridge.readCandidatePreferences?.();
 if(!eligible())return null;
 const root=documentObject.createElement('div');root.id='pointLimitControls';root.className='direction-bracket-controls';root.style.maxWidth='100%';const previousWrap=container.style.flexWrap;container.style.flexWrap='wrap';
 const label=documentObject.createElement('label'),check=documentObject.createElement('input');check.type='checkbox';check.id='usePointLimit';
 label.append(check,'Point limit: ±20');
 const help=documentObject.createElement('details'),summary=documentObject.createElement('summary'),note=documentObject.createElement('p');
 summary.textContent='Point limit rules';note.id='pointLimitHelp';note.textContent='After a position closes, finish the session if net closed-position points are +20 or more, or −20 or less. Open positions are never closed by this option. A reversal that reaches the limit finishes Neutral without opening the other side. Off by default; applies only while this simulator page stays open.';
 check.setAttribute('aria-describedby',note.id);help.append(summary,note);root.append(label,help);container.append(root);
 let enabled=false,disposed=false;
 function update(){if(disposed)return;const allowed=eligible();if(bridge.ownerValid?.()===false||bridge.guard()&&!allowed)enabled=false;root.hidden=!allowed;root.style.display=allowed?'flex':'none';check.checked=enabled;check.disabled=!allowed||!bridge.canMutate()||!canEdit();}
 check.onchange=()=>{if(disposed||!eligible()||!bridge.canMutate()||!canEdit()){update();return;}pause();enabled=check.checked===true;update();};
 const unsubscribe=bridge.subscribe(update);update();
 return Object.freeze({update,reached(total){return !disposed&&enabled&&eligible()&&Number.isFinite(total)&&(total>=SESSION_POINT_LIMIT||total<=-SESSION_POINT_LIMIT);},dispose(){disposed=true;enabled=false;unsubscribe();root.remove();container.style.flexWrap=previousWrap;}});
}
