/** Public, immutable close projection. Never reads learner storage or changes a replay. */
export const HISTORY_INDEX_SHA256='fd1057116a27bddfe10335dd41dda09233ddd7b36fcd6e38d7363a0e02d6c414';
// Content-addressed bytes are retained across releases for already-open clients.
export const HISTORY_INDEX_URL='/modules/history-candle-index/'+HISTORY_INDEX_SHA256+'.json';
export const HISTORY_INDEX_MAX_BYTES=4*1024*1024;
export const HISTORY_INDEX_MAX_ROWS=1000;
const identity='md-normalized-current-prior-ohlc-v1',hex=/^[a-f0-9]{64}$/;
const abortError=()=>new DOMException('History source loading was canceled.','AbortError');
const checkAbort=signal=>{if(signal?.aborted)throw abortError();};
const shape=(value,keys)=>!!value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).sort().join('|')===[...keys].sort().join('|');

/** Schema validation returns detached, deeply frozen rows and a read-only exact-key lookup.
 * Hash verification of the fetched bytes is additionally mandatory before this is used by load. */
export function validateHistoryCandleIndex(raw){
 if(!shape(raw,['version','identity','sourceCatalogSha256','sessions'])||raw.version!==1||raw.identity!==identity||typeof raw.sourceCatalogSha256!=='string'||!hex.test(raw.sourceCatalogSha256)||!Array.isArray(raw.sessions)||!raw.sessions.length||raw.sessions.length>HISTORY_INDEX_MAX_ROWS)throw Error('Invalid history candle index.');
 const byKey=new Map(),ids=new Set(),sessions=Array.from(raw.sessions).map(row=>{
  if(!(shape(row,['key','id','sourceSha256','closes'])||shape(row,['key','id','sourceSha256','closes','candles']))||typeof row.key!=='string'||!/^csv:[a-f0-9]{64}$/.test(row.key)||typeof row.id!=='string'||!/^[a-z0-9][a-z0-9_-]{0,63}$/.test(row.id)||typeof row.sourceSha256!=='string'||!hex.test(row.sourceSha256)||byKey.has(row.key)||ids.has(row.id)||!Array.isArray(row.closes)||![42,45,78,81].includes(row.closes.length)||Array.from(row.closes).some(value=>!Number.isFinite(value)||value<=0||value>=1e6||Math.abs(value*4-Math.round(value*4))>=1e-7))throw Error('Invalid or duplicate history candle source.');
  if(row.candles!==undefined&&(!Array.isArray(row.candles)||row.candles.length!==row.closes.length||row.candles.some((b,i)=>!shape(b,['o','h','l','c'])||!['o','h','l','c'].every(k=>Number.isFinite(b[k])&&b[k]>0&&b[k]<1e6&&Number.isInteger(b[k]*4))||b.c!==row.closes[i]||b.l>Math.min(b.o,b.c)||b.h<Math.max(b.o,b.c))))throw Error('Invalid history OHLC.');
  const copy=Object.freeze({key:row.key,id:row.id,sourceSha256:row.sourceSha256,closes:Object.freeze([...row.closes]),...(row.candles?{candles:Object.freeze(row.candles.map(b=>Object.freeze({...b})))}:{})});byKey.set(copy.key,copy);ids.add(copy.id);return copy;
 });
 return Object.freeze({version:1,identity,sourceCatalogSha256:raw.sourceCatalogSha256,sessions:Object.freeze(sessions),get:key=>typeof key==='string'?byKey.get(key)||null:null});
}
function abortable(promise,signal){
 checkAbort(signal);return new Promise((resolve,reject)=>{const abort=()=>{signal.removeEventListener('abort',abort);reject(abortError());};signal.addEventListener('abort',abort,{once:true});Promise.resolve(promise).then(value=>{signal.removeEventListener('abort',abort);if(signal.aborted)reject(abortError());else resolve(value);},error=>{signal.removeEventListener('abort',abort);reject(error);});});
}
async function readIndex(fetcher,cryptoProvider,signal,progress){
 checkAbort(signal);const response=await abortable(fetcher(HISTORY_INDEX_URL,{signal,credentials:'omit',redirect:'error',cache:'no-store',referrerPolicy:'no-referrer'}),signal);checkAbort(signal);
 if(!response.ok||response.redirected)throw Error('History candle sources could not be loaded.');
 if(response.url&&typeof location!=='undefined'&&new URL(response.url).href!==new URL(HISTORY_INDEX_URL,location.href).href)throw Error('Unexpected history candle source URL.');
 const type=response.headers?.get('content-type');if(type&&!/^application\/json(?:\s*;|$)/i.test(type))throw Error('History candle source is not JSON.');
 const header=response.headers?.get('content-length'),total=header&&/^\d+$/.test(header)?Number(header):null;
 if(total!==null&&(!Number.isSafeInteger(total)||total>HISTORY_INDEX_MAX_BYTES))throw Error('History candle source exceeds its size limit.');
 progress({loaded:0,total});checkAbort(signal);const reader=response.body?.getReader();let bytes;
 try{
  if(reader){let chunks=[],size=0;while(true){const {done,value}=await abortable(reader.read(),signal);checkAbort(signal);if(done)break;if(!(value instanceof Uint8Array))throw Error('Invalid history source bytes.');size+=value.byteLength;if(size>HISTORY_INDEX_MAX_BYTES)throw Error('History candle source exceeds its size limit.');chunks.push(value);progress({loaded:size,total});checkAbort(signal);}bytes=new Uint8Array(size);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}}
  else{bytes=new Uint8Array(await abortable(response.arrayBuffer(),signal));if(bytes.byteLength>HISTORY_INDEX_MAX_BYTES)throw Error('History candle source exceeds its size limit.');progress({loaded:bytes.byteLength,total});}
 }catch(error){if(reader)Promise.resolve(reader.cancel()).catch(()=>{});throw error;}finally{try{reader?.releaseLock();}catch{}}
 checkAbort(signal);if(!cryptoProvider?.subtle?.digest)throw Error('History integrity verification is unavailable.');
 const digest=[...new Uint8Array(await abortable(cryptoProvider.subtle.digest('SHA-256',bytes),signal))].map(value=>value.toString(16).padStart(2,'0')).join('');checkAbort(signal);
 if(digest!==HISTORY_INDEX_SHA256)throw Error('History candle source integrity check failed.');
 const data=validateHistoryCandleIndex(JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes)));checkAbort(signal);return {data,bytes:bytes.length};
}

/** Factory permits isolated tests; production uses the singleton below. No URL or digest override.
 * Concurrent readers share one bounded request. Canceling one reader does not cancel another;
 * canceling the last reader aborts the request. Only fully verified results enter memory cache. */
export function createHistoryCandleLoader({fetcher=(...args)=>globalThis.fetch(...args),cryptoProvider=globalThis.crypto,timeoutMs=12000}={}){
 if(typeof fetcher!=='function'||!Number.isFinite(timeoutMs)||timeoutMs<1||timeoutMs>30000)throw Error('Invalid history loader options.');
 let cached=null,pending=null;
 return function load({signal,onProgress}={}){
  try{checkAbort(signal);}catch(error){return Promise.reject(error);}
  if(cached){try{onProgress?.({loaded:cached.bytes,total:cached.bytes});checkAbort(signal);return Promise.resolve(cached.data);}catch(error){return Promise.reject(error);}}
  if(!pending||pending.controller.signal.aborted){
   const job={controller:new AbortController(),readers:new Set(),promise:null};pending=job;
   const timer=setTimeout(()=>job.controller.abort(),timeoutMs);
   job.promise=Promise.resolve().then(()=>readIndex(fetcher,cryptoProvider,job.controller.signal,progress=>{for(const reader of [...job.readers]){try{reader.progress?.({...progress});}catch(error){reader.finish(error);}}})).then(result=>{checkAbort(job.controller.signal);if(pending===job)cached=result;for(const reader of [...job.readers])reader.finish(null,result.data);},error=>{for(const reader of [...job.readers])reader.finish(error);}).finally(()=>{clearTimeout(timer);if(pending===job)pending=null;});
  }
  const job=pending;
  return new Promise((resolve,reject)=>{
   let done=false;const abort=()=>reader.finish(abortError());
   const reader={progress:onProgress,finish(error,data){if(done)return;done=true;signal?.removeEventListener('abort',abort);job.readers.delete(reader);if(error)reject(error);else resolve(data);if(!job.readers.size&&!cached)job.controller.abort();}};
   job.readers.add(reader);signal?.addEventListener('abort',abort,{once:true});if(signal?.aborted)abort();
  });
 };
}
export const loadHistoryCandleIndex=createHistoryCandleLoader();
export async function resolveHistoryCloses(key,options){if(typeof key!=='string'||!/^csv:[a-f0-9]{64}$/.test(key))return null;const index=await loadHistoryCandleIndex(options);return index.get(key);}
