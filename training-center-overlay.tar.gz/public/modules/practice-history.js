/** Count-only markup DTOs. No chart content, filenames, identities or persistence. */
export const PRACTICE_BYTES=2*1024*1024;
export const MARKUP_LIMIT=10000;
const uuid=v=>typeof v==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(v);
const exact=(v,keys)=>!!v&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).length===keys.length&&keys.every(k=>Object.hasOwn(v,k));
export const practiceISO=v=>typeof v==='string'&&/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(v)&&Number.isFinite(Date.parse(v))&&new Date(v).toISOString()===v;
export function validMarkupCompletion(value){return exact(value,['id','completedAt'])&&uuid(value.id)&&practiceISO(value.completedAt);}
export function decodePracticeHistory(value){
 if(!exact(value,['version','context','asOf','markupTracking','markups'])||value.version!==1||!exact(value.context,['accountId','generation','sessionTag'])||!uuid(value.context.accountId)||!Number.isSafeInteger(value.context.generation)||value.context.generation<1||value.context.generation>2147483646||typeof value.context.sessionTag!=='string'||!/^[a-f0-9]{64}$/.test(value.context.sessionTag)||!practiceISO(value.asOf)||!exact(value.markupTracking,['enabled','since'])||typeof value.markupTracking.enabled!=='boolean'||!(value.markupTracking.since===null||practiceISO(value.markupTracking.since))||!Array.isArray(value.markups)||value.markups.length>MARKUP_LIMIT||!value.markups.every(validMarkupCompletion))throw Error('Markup history could not be verified.');
 const seen=new Set();let earliest=null;for(const completion of value.markups){if(seen.has(completion.id)||Date.parse(completion.completedAt)>Date.parse(value.asOf)+300000)throw Error('Markup completion dates could not be verified.');seen.add(completion.id);if(earliest===null||completion.completedAt<earliest)earliest=completion.completedAt;}
 if(!value.markupTracking.enabled&&(value.markups.length||value.markupTracking.since!==null)||value.markupTracking.enabled&&value.markupTracking.since!==earliest)throw Error('Markup tracking coverage could not be verified.');
 return value;
}
