// Anonymous public app sessions only. No account, chart, or practice data.
const KEY = 'price-action-guest-visit-v1';
const MAX_AGE = 24 * 60 * 60 * 1000;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
let inFlight = false;

/** Best effort only: never delay guest practice, retry only on a later public-page lifecycle event. */
export async function recordGuestVisit() {
  if (inFlight || typeof window === 'undefined') return;
  let storage, visit;
  try {
    storage = window.sessionStorage;
    const raw = storage.getItem(KEY);
    try { visit = raw ? JSON.parse(raw) : null; } catch { visit = null; }
    const now = Date.now();
    if (!visit || !UUID.test(visit.visitId) || !Number.isSafeInteger(visit.startedAt) || visit.startedAt > now || now - visit.startedAt >= MAX_AGE) {
      visit = { visitId: window.crypto.randomUUID(), startedAt: now, recorded: false };
    }
    if (visit.recorded === true) return;
    // Persist before sending so refresh/lost responses reuse the same dedup key.
    storage.setItem(KEY, JSON.stringify(visit));
  } catch { return; } // Denied storage: skip telemetry, not practice.
  inFlight = true;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8000);
  try {
    const response = await fetch('/api/learner/guest-visit', {
      method: 'POST', credentials: 'same-origin', cache: 'no-store', redirect: 'error',
      headers: { 'Content-Type': 'application/json' }, signal: controller.signal,
      body: JSON.stringify({ visitId: visit.visitId, startedAt: visit.startedAt }),
    });
    if (response.ok && (await response.json()).recorded === true) {
      // Do not overwrite a newer tab token after an interrupted request.
      const current = JSON.parse(storage.getItem(KEY) || 'null');
      if (current?.visitId === visit.visitId && current?.startedAt === visit.startedAt) {
        storage.setItem(KEY, JSON.stringify({ ...visit, recorded: true }));
      }
    }
  } catch { /* Best effort. A later public-page lifecycle event can retry this token. */ }
  finally { clearTimeout(timer); inFlight = false; }
}
