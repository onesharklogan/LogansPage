/** Market Direction only. This view never scores candles or changes playback. */
export function createExitBracketUI({canvas,container,controls,getState,onEnabled,onDistance,onDragStart=()=>{},canInteract=()=>true}) {
 const doc=canvas.ownerDocument, win=doc.defaultView;
 const panel=doc.createElement('div');panel.className='direction-bracket-controls';
 const label=doc.createElement('label'),check=doc.createElement('input');check.type='checkbox';check.id='useExitBracket';
 label.append(check,doc.createTextNode('Use exit bracket'));
 const value=doc.createElement('span');value.className='direction-bracket-distance';
 const help=doc.createElement('details'),summary=doc.createElement('summary'),note=doc.createElement('p');
 summary.textContent='Bracket rules';note.id='directionBracketHelp';const rules='Drag either handle to move both exits equally from entry. Arrow keys adjust one tick. Editing pauses playback; changes apply to future bars only. When a 5-minute bar opens inside the bracket and touches both exits, the stop wins. Stop gaps fill at the open; targets fill at their set price. An exit returns to Neutral.';
 help.append(summary,note);panel.append(label,value,help);controls.append(panel);
 const overlay=doc.createElement('div');overlay.className='direction-bracket-overlay';container.append(overlay);
 const handles=[1,-1].map(side=>{const line=doc.createElement('div');line.className='direction-bracket-line';const handle=doc.createElement('button');handle.type='button';handle.className='direction-bracket-handle';handle.setAttribute('role','slider');handle.setAttribute('aria-describedby',note.id);line.append(handle);overlay.append(line);return {side,line,handle};});
 let drag=null,destroyed=false;
 const normalize=(distance,tick,maxDistance)=>Number((Math.min(maxDistance,Math.max(tick,Math.round(distance/tick)*tick))).toFixed(8));
 const state=()=>{const s=getState()||{},tick=Number.isFinite(s.tick)&&s.tick>0?s.tick:.25,maxDistance=Number.isFinite(s.maxDistance)&&s.maxDistance>=tick?Math.floor(s.maxDistance/tick)*tick:100000;return {...s,tick,maxDistance,distance:normalize(Number.isFinite(s.distance)&&s.distance>0?s.distance:5,tick,s.preserveDistance?100000:maxDistance)};};
 const permitted=s=>!s.disabled&&canInteract();
 const same=(s,d)=>s.identity===d.identity&&s.entry===d.entry&&s.direction===d.direction&&s.maxDistance===d.maxDistance&&s.enabled&&s.active&&permitted(s);
 function release(){const old=drag;drag=null;if(old?.handle.hasPointerCapture?.(old.id))old.handle.releasePointerCapture(old.id);}
 function cancel(){release();if(!destroyed)update();}
 function update(){
  if(destroyed)return;let s=state();if(drag&&!same(s,drag))release();
  const distance=drag?drag.distance:s.distance;check.checked=s.enabled===true;check.disabled=!permitted(s);value.textContent='±'+distance.toFixed(2)+' pts'+(s.maxDistance===20?(distance>20?' · existing; new max 20':' · 20 max'):'');value.hidden=!s.enabled;note.textContent=(s.maxDistance===20?'Maximum 20 points from entry on each side. ':'')+(s.preserveDistance&&s.distance>s.maxDistance?'This existing bracket is unchanged. A new adjustment must bring both exits within 20 points. ':'')+rules;
  const g=s.geometry,valid=s.enabled&&s.active&&Number.isFinite(s.entry)&&[1,-1].includes(s.direction)&&g&&g.hi>g.lo&&g.right>g.left&&g.bottom>g.top;
  overlay.hidden=!valid;if(!valid)return;
  const r=canvas.getBoundingClientRect(),c=container.getBoundingClientRect();
  overlay.style.left=(r.left-c.left+container.scrollLeft-container.clientLeft)+'px';overlay.style.top=(r.top-c.top+container.scrollTop-container.clientTop)+'px';overlay.style.width=r.width+'px';overlay.style.height=r.height+'px';
  for(const {side,line,handle} of handles){
   const price=s.entry+side*distance,target=side===s.direction,y=g.bottom-(price-g.lo)/(g.hi-g.lo)*(g.bottom-g.top),clamped=Math.max(g.top+18,Math.min(g.bottom-18,y));
   line.style.left=g.left+'px';line.style.width=(g.right-g.left)+'px';line.style.top=Math.max(g.top,Math.min(g.bottom,y))+'px';handle.style.transform='translateY('+(clamped-Math.max(g.top,Math.min(g.bottom,y)))+'px)';line.dataset.kind=target?'target':'stop';line.dataset.offscale=String(y<g.top||y>g.bottom);
   handle.style.right=side===1?'4px':'120px';handle.disabled=!permitted(s);handle.textContent=(y<g.top?'↑ ':y>g.bottom?'↓ ':'')+(target?'Target ':'Stop ')+distance.toFixed(2)+' pts';
   handle.setAttribute('aria-label',(target?'Target':'Stop')+' bracket distance; both exits move equally');handle.setAttribute('aria-valuemin',String(s.tick));handle.setAttribute('aria-valuemax',String(Math.max(s.maxDistance,distance)));handle.setAttribute('aria-valuenow',String(distance));handle.setAttribute('aria-valuetext',distance.toFixed(2)+' points from entry; '+(target?'target':'stop')+' price '+price.toFixed(2));
  }
 }
 check.addEventListener('change',()=>{const s=state();if(permitted(s)){release();onEnabled(check.checked);}update();});
 for(const {side,handle} of handles){
  handle.addEventListener('pointerdown',event=>{event.stopPropagation();if(event.button!==0||drag)return;const s=state();if(!permitted(s)||!s.active||!s.enabled)return;event.preventDefault();const g=s.geometry;if(!g||g.hi<=g.lo||g.bottom<=g.top)return;onDragStart();drag={id:event.pointerId,handle,identity:s.identity,entry:s.entry,direction:s.direction,distance:s.distance,tick:s.tick,maxDistance:s.maxDistance,side,startY:event.clientY,startDistance:s.distance,pointsPerPixel:(g.hi-g.lo)/(g.bottom-g.top)};handle.focus({preventScroll:true});handle.setPointerCapture(event.pointerId);});
  handle.addEventListener('pointermove',event=>{if(!drag||drag.id!==event.pointerId||drag.handle!==handle)return;event.preventDefault();event.stopPropagation();if(!same(state(),drag)){cancel();return;}drag.distance=normalize(drag.startDistance-(event.clientY-drag.startY)*drag.pointsPerPixel*side,drag.tick,drag.maxDistance);update();});
  handle.addEventListener('pointerup',event=>{if(!drag||drag.id!==event.pointerId||drag.handle!==handle)return;event.preventDefault();event.stopPropagation();const current=state(),distance=drag.distance,valid=same(current,drag);release();if(valid&&distance!==current.distance)onDistance(distance);update();});
  for(const event of ['pointercancel','lostpointercapture'])handle.addEventListener(event,()=>{if(drag?.handle===handle)cancel();});
  handle.addEventListener('keydown',event=>{if(!['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Escape'].includes(event.key)||event.altKey||event.metaKey||event.ctrlKey)return;event.preventDefault();event.stopPropagation();if(event.key==='Escape'){cancel();return;}const s=state();if(!permitted(s)||!s.active||!s.enabled)return;release();const distance=normalize(s.distance+(['ArrowUp','ArrowRight'].includes(event.key)?1:-1)*s.tick,s.tick,s.maxDistance);if(distance!==s.distance)onDistance(distance);update();});
 }
 const onVisibility=()=>{if(doc.hidden)cancel();};win.addEventListener('blur',cancel);win.addEventListener('resize',update);doc.addEventListener('visibilitychange',onVisibility);
 update();
 return Object.freeze({update,cancel,destroy(){release();destroyed=true;win.removeEventListener('blur',cancel);win.removeEventListener('resize',update);doc.removeEventListener('visibilitychange',onVisibility);panel.remove();overlay.remove();}});
}
