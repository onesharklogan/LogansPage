/** Pure daily analytics. Dates mean completion actions, never historical chart dates. */
export function practiceDay(instant,timeZone='UTC'){
 const parts=new Intl.DateTimeFormat('en-US',{timeZone,year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date(instant));
 return ['year','month','day'].map(k=>parts.find(p=>p.type===k).value).join('-');
}
const shift=(day,n)=>new Date(Date.parse(day+'T12:00:00Z')+n*86400000).toISOString().slice(0,10);
const empty=()=>({sessions:0,verified:0,outcomes:0,grossProfit:0,grossLoss:0});
function add(a,b){for(const key of Object.keys(a))a[key]+=b[key];return a;}
function metrics(v){const complete=v.sessions===v.verified;return {...v,complete,netPoints:complete?v.grossProfit-v.grossLoss:null,profitFactor:!complete||!v.outcomes?'unavailable':v.grossLoss?(Number.isFinite(v.grossProfit/v.grossLoss)?v.grossProfit/v.grossLoss:'unavailable'):v.grossProfit?'no-losses':'flat-only'};}
export function derivePracticeInsights(stats,practice,{days=30,timeZone='UTC',module='market-direction',now=stats.asOf,accountStats=stats}={}){
 if(![7,30,90].includes(days))throw Error('Unsupported practice window.');
 if(!['market-direction','trade-simulator','combined'].includes(module))throw Error('Unsupported simulator.');
 // The rate starts with the account, not the currently selected simulator/device.
 // A separately supplied complete snapshot must belong to this exact account view.
 if(accountStats!==stats&&(['accountId','generation','sessionTag'].some(key=>!stats.context||!accountStats.context||accountStats.context[key]!==stats.context[key])||accountStats.snapshot!==stats.snapshot||accountStats.asOf!==stats.asOf))throw Error('Practice account snapshot mismatch.');
 const nowMs=Date.parse(now),end=practiceDay(now,timeZone),start=shift(end,1-days),dates=Array.from({length:days},(_,i)=>shift(start,i));
 let firstChartDay=null;
 for(const r of accountStats.attempts){const completed=Date.parse(r.completedAt);if(!Number.isFinite(completed)||completed>nowMs)continue;const day=practiceDay(r.completedAt,timeZone);if(firstChartDay===null||day<firstChartDay)firstChartDay=day;}
 const chartStart=firstChartDay===null?null:firstChartDay>start?firstChartDay:start;
 const chartDays=chartStart===null?0:dates.filter(day=>day>=chartStart).length;
 const buckets=new Map(dates.map(date=>[date,{date,...empty(),markups:null,observedMarkups:0,partial:false}]));
 // Include six preceding days to make each trailing seven-day value a full calendar window.
 const history=new Map();let excludedFuture=0;
 for(const r of stats.attempts){if(module!=='combined'&&r.module!==module)continue;if(Date.parse(r.completedAt)>Date.parse(now)){excludedFuture++;continue;}const day=practiceDay(r.completedAt,timeZone);if(day>end)continue;const v=history.get(day)||empty();v.sessions++;if(r.outcomes!==null){v.verified++;v.outcomes+=r.outcomes.wins+r.outcomes.losses+r.outcomes.flats;v.grossProfit+=r.outcomes.grossProfit;v.grossLoss+=r.outcomes.grossLoss;}history.set(day,v);}
 const tracking=practice?.markupTracking,trackingDay=tracking?.enabled&&tracking.since?practiceDay(tracking.since,timeZone):null;
 // Tracking begins with the first recorded completion. The first day is explicitly partial.
 const fullSince=trackingDay;
 for(const date of dates){const b=buckets.get(date);Object.assign(b,history.get(date)||empty());if(fullSince&&date>=fullSince)b.markups=0;b.partial=date===trackingDay;}
 let partialMarkups=0;
 if(tracking?.enabled)for(const m of practice.markups||[]){if(Date.parse(m.completedAt)>Date.parse(now))continue;const date=practiceDay(m.completedAt,timeZone),b=buckets.get(date);if(b){b.observedMarkups++;if(b.markups!==null)b.markups++;if(b.partial)partialMarkups++;}}
 const cumulative=empty();for(const [date,v]of history)if(date<start)add(cumulative,v);
 const daily=dates.map(date=>{const b=buckets.get(date);add(cumulative,history.get(date)||empty());const rolling=empty();for(let i=0;i<7;i++)add(rolling,history.get(shift(date,-i))||empty());return {...b,...metrics(b.sessions?{sessions:b.sessions,verified:b.verified,outcomes:b.outcomes,grossProfit:b.grossProfit,grossLoss:b.grossLoss}:empty()),cumulative:metrics({...cumulative}),rolling:metrics(rolling)};});
 const totals=empty();for(const b of daily)add(totals,{sessions:b.sessions,verified:b.verified,outcomes:b.outcomes,grossProfit:b.grossProfit,grossLoss:b.grossLoss});
 const trackedDays=daily.filter(b=>b.markups!==null),markups=trackedDays.reduce((a,b)=>a+b.markups,0);
 return {days,timeZone,module,start,end,daily,...metrics(totals),firstChartDay,chartStart,chartDays,averageSessions:chartDays?totals.sessions/chartDays:null,averageMarkups:trackedDays.length?markups/trackedDays.length:null,markups:trackedDays.length?markups:null,trackedDays:trackedDays.length,partialMarkups,trackingDay,excludedFuture,capacity:{attempts:stats.attempts.length,limit:1000,byteLimit:8388608}};
}

/** Finite PF values only, with separate SVG segments around unavailable/no-loss/flat days. */
export function practicePFTrend(daily,width=600,height=120){
 const values=daily.map(d=>typeof d.rolling.profitFactor==='number'&&Number.isFinite(d.rolling.profitFactor)?d.rolling.profitFactor:null),max=Math.max(1,...values.filter(v=>v!==null));
 const points=values.map((value,i)=>value===null?null:{x:10+i*(width-20)/Math.max(1,values.length-1),y:10+(height-20)*(1-value/max),value});
 const segments=[];let current=[];for(const p of points){if(p)current.push(p);else if(current.length){segments.push(current);current=[];}}if(current.length)segments.push(current);
 return {max,points:points.filter(Boolean),paths:segments.map(segment=>segment.map((p,i)=>`${i?'L':'M'}${p.x},${p.y}`).join(' '))};

}

/** Direct daily PF, not the trailing average. Status markers are kept off the numeric axis. */
export function practiceDailyPFTrend(daily,width=600,height=160){
 const values=daily.map(d=>typeof d.profitFactor==='number'&&Number.isFinite(d.profitFactor)?d.profitFactor:null),max=Math.max(1,...values.filter(v=>v!==null));
 const points=values.map((value,i)=>value===null?null:{index:i,date:daily[i].date,x:44+i*(width-60)/Math.max(1,values.length-1),y:12+(height-40)*(1-value/max),value});
 const segments=[];let current=[];for(const p of points){if(p)current.push(p);else if(current.length){segments.push(current);current=[];}}if(current.length)segments.push(current);
 return {max,points:points.filter(Boolean),paths:segments.map(segment=>segment.map((p,i)=>`${i?'L':'M'}${p.x},${p.y}`).join(' ')),statuses:daily.map(d=>({date:d.date,state:d.profitFactor==='no-losses'?'no-losses':d.profitFactor==='flat-only'?'flat-only':typeof d.profitFactor==='number'?'finite':d.sessions?'unavailable':'no-data'}))};
}
