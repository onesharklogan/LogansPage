/** Causal body-direction runs. Session input only; no future bars or prior-session context. */
export const CANDIDATE_DEFAULTS=Object.freeze({enabled:false,bullColor:'#c6e84b',bearColor:'#df3b82'});
export function validCandidatePreferences(value){return !!value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===3&&typeof value.enabled==='boolean'&&['bullColor','bearColor'].every(key=>typeof value[key]==='string'&&/^#[0-9a-f]{6}$/i.test(value[key]));}
export function candidateColors(bars,revealed,preferences){
 if(!validCandidatePreferences(preferences)||!preferences.enabled||!Number.isSafeInteger(revealed)||revealed<0)return [];
 const colors=[];let previous=0,length=0;
 for(let i=0;i<Math.min(revealed,bars.length);i++){
  const bar=bars[i],direction=Number.isFinite(bar?.o)&&Number.isFinite(bar?.c)?Math.sign(bar.c-bar.o):0;
  length=direction===0?0:direction===previous?length+1:1;previous=direction;
  colors.push(direction!==0&&length<=2?(direction===1?preferences.bullColor:preferences.bearColor):null);
 }
 return colors;
}
