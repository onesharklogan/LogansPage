// Presentation only: immutable executed fills and observed candles. No scoring or storage writes.
const NS = 'http://www.w3.org/2000/svg';
const number = value => Number(value).toFixed(2);
const signed = value => `${value >= 0 ? '+' : ''}${number(value)}`;

export function reviewWindow(candles, trade) {
  const {entryIndex, exitIndex, entryPrice, exitPrice, points, side} = trade;
  if (!Array.isArray(candles) || !Number.isInteger(entryIndex) || !Number.isInteger(exitIndex) || entryIndex < 0 || exitIndex < entryIndex || exitIndex >= candles.length || ![entryPrice, exitPrice, points].every(Number.isFinite) || !['long', 'short'].includes(side)) throw new Error('Invalid completed trade.');
  const start = 0, end = candles.length;
  const bars = candles.slice(start, end).map((bar, index) => {
    if (!['o', 'h', 'l', 'c'].every(key => Number.isFinite(bar[key]))) throw new Error('Trade candles are unavailable.');
    return {...bar, index: start + index};
  });
  const low = Math.min(entryPrice, exitPrice, ...bars.map(bar => bar.l)), high = Math.max(entryPrice, exitPrice, ...bars.map(bar => bar.h)), pad = Math.max(.5, (high-low)*.15);
  return {bars, start, end, low:low-pad, high:high+pad};
}

export function renderTradeChart(document, candles, trade) {
  const model = reviewWindow(candles, trade), width = 960, height = 370, left = 58, right = 940, top = 30, bottom = 319;
  const svg = document.createElementNS(NS, 'svg');
  svg.setAttribute('viewBox', `0 0 ${width} ${height}`);svg.setAttribute('role', 'img');svg.setAttribute('aria-label', `Full session, bars 1 to ${candles.length}. Only this ${trade.side === 'long' ? 'long' : 'short'} trade: entry at bar ${trade.entryIndex+1}, exit at bar ${trade.exitIndex+1}. ${signed(trade.points)} points.`);
  const add = (tag, attrs, text) => {const node = document.createElementNS(NS,tag);for(const [key,value] of Object.entries(attrs))node.setAttribute(key,String(value));if(text!==undefined)node.textContent=text;svg.append(node);return node;};
  svg.setAttribute('data-review-bars', String(model.bars.length));
  const labelEvery = Math.max(1, Math.ceil(model.bars.length/10));
  const x = index => left+(index-model.start+.5)*(right-left)/model.bars.length, y = value => bottom-(value-model.low)/(model.high-model.low)*(bottom-top);
  add('rect',{width,height,fill:'#09121d',rx:10});
  for(let i=0;i<=4;i++){const value=model.low+(model.high-model.low)*i/4;add('line',{x1:left,x2:right,y1:y(value),y2:y(value),stroke:'#243344'});add('text',{x:left-6,y:y(value)+4,fill:'#a9bacb','text-anchor':'end','font-size':10},number(value));}
  add('rect',{x:x(trade.entryIndex)-(right-left)/model.bars.length*.42,y:top,width:Math.max((right-left)/model.bars.length*.84,x(trade.exitIndex)-x(trade.entryIndex)+(right-left)/model.bars.length*.84),height:bottom-top,fill:trade.points<0?'#e3769118':'#66d6af18'});
  for(const bar of model.bars){const color=bar.c>=bar.o?'#6ce1ae':'#f28cab',body=Math.max(.5,Math.min(16,(right-left)/model.bars.length*.65));add('line',{x1:x(bar.index),x2:x(bar.index),y1:y(bar.h),y2:y(bar.l),stroke:color,'stroke-width':1.5});add('rect',{x:x(bar.index)-body/2,y:Math.min(y(bar.o),y(bar.c)),width:body,height:Math.max(1.5,Math.abs(y(bar.o)-y(bar.c))),fill:color});if(bar.index===0||(bar.index+1)%labelEvery===0||bar.index===model.end-1)add('text',{x:x(bar.index),y:bottom+19,fill:'#a9bacb','font-size':11,'text-anchor':'middle'},String(bar.index+1));}
  add('line',{x1:x(trade.entryIndex),x2:x(trade.exitIndex),y1:y(trade.entryPrice),y2:y(trade.exitPrice),stroke:'#f5cf7b','stroke-width':2,'stroke-dasharray':'5 3'});
  for(const [index,price,label,color,labelY] of [[trade.entryIndex,trade.entryPrice,'ENTRY','#9bd1ff',18],[trade.exitIndex,trade.exitPrice,'EXIT','#f5cf7b',height-12]]){add('line',{x1:x(index),x2:x(index),y1:top,y2:bottom,stroke:color,'stroke-opacity':.65,'stroke-dasharray':'3 4'});add('circle',{cx:x(index),cy:y(price),r:5,fill:color,stroke:'#07101b','stroke-width':2,'data-trade-mark':label.toLowerCase()});add('text',{x:x(index),y:labelY,fill:color,'font-size':12,'font-weight':700,'text-anchor':index>model.end-5?'end':index<4?'start':'middle'},`${label} ${index+1}`);}
  return svg;
}

export function createCompletedTradeReview({document, isValid = () => true, onDone = () => {}}) {
  let state = null, dialog = null, returnFocus = null, advanceAfter = 0, priorOverflow = null, verificationNotice = null, reviewVisible = true;
  function dismiss(restore = false) {
    const previous=returnFocus;state=null;returnFocus=null;verificationNotice=null;reviewVisible=true;if(priorOverflow!==null){document.body.style.overflow=priorOverflow;priorOverflow=null;}
    if(dialog){dialog.close();dialog.remove();dialog=null;}
    if(restore&&previous?.isConnected)previous.focus({preventScroll:true});
  }
  function paint() {
    if(!state||!dialog)return;
    const trade=state.trades[state.index];verificationNotice=null;dialog.replaceChildren();
    const title=document.createElement('h2');title.id='completed-trade-review-title';title.textContent=trade?`Loss ${state.index+1} of ${state.trades.length}`:'No losing trades';
    const heading=document.createElement('p');heading.className='trade-review-heading';heading.textContent=trade?`${trade.side==='long'?'Long':'Short'} · ${signed(trade.points)} points`:'All executed trades were winning or breakeven.';heading.style.color=trade?'#f5a4b6':'#8ee4bf';
    const description=document.createElement('p');description.id='completed-trade-review-description';description.textContent=trade?'Full session · only this loss is marked. Review it, then tap OK.':'There are no losses to review. Tap OK to return to the completed chart.';
    const chart=document.createElement('div');chart.className='trade-review-chart';if(trade)chart.append(renderTradeChart(document,state.candles,trade));
    const facts=document.createElement('dl');facts.className='trade-review-facts';
    if(trade)for(const [label,value] of [['Entry',`Bar ${trade.entryIndex+1} · ${number(trade.entryPrice)}`],['Exit',`Bar ${trade.exitIndex+1} · ${number(trade.exitPrice)}`],['Result',`${signed(trade.points)} points`]]){const group=document.createElement('div'),term=document.createElement('dt'),detail=document.createElement('dd');term.textContent=label;detail.textContent=value;group.append(term,detail);facts.append(group);}
    const reason=document.createElement('p');reason.className='trade-review-note';reason.textContent=trade?(trade.reason||'Recorded entry and exit fills. Full-session candles are for review only.'):'';
    const action=document.createElement('button');action.type='button';action.textContent='OK';action.dataset.tradeReviewOk='true';action.setAttribute('aria-label',trade?`OK, acknowledge loss ${state.index+1} of ${state.trades.length}`:'OK, finish review');
    const expected=state.index;action.onclick=event=>{if(event.detail>1||Date.now()<advanceAfter||!state||!reviewVisible||state.index!==expected)return;if(!isValid()){description.textContent='Your profile must be verified before continuing. Try OK again when verification finishes.';return;}if(state.index+1>=state.trades.length){dismiss(true);onDone();return;}state.index++;advanceAfter=Date.now()+300;paint();};
    action.onkeydown=event=>{if(event.repeat&&(event.key==='Enter'||event.key===' ')){event.preventDefault();event.stopPropagation();}};
    const footer=document.createElement('footer');const note=document.createElement('span');note.textContent=state.index+1>=state.trades.length?'Finish review':'Next loss after OK';footer.append(note,action);dialog.append(title,heading,description,chart,facts,reason,footer);setVisible(reviewVisible);if(reviewVisible)action.focus({preventScroll:true});dialog.scrollTop=0;
  }

  function open({candles,trades}) {
    if(state||!trades.length)return false;
    const copy=trades.filter(trade=>Number.isFinite(trade.points)&&trade.points<0).map(trade=>({...trade}));copy.forEach(trade=>reviewWindow(candles,trade));
    if(!document.getElementById('completed-trade-review-style')){const style=document.createElement('style');style.id='completed-trade-review-style';style.textContent=`dialog.completed-trade-review{box-sizing:border-box;width:min(1100px,calc(100vw - 24px));max-height:calc(100dvh - 24px);margin:auto;padding:14px 16px;border:1px solid #44617b;border-radius:16px;background:#101d2b;color:#e8eff7;font:14px/1.45 system-ui;overflow:auto;overscroll-behavior:contain}.completed-trade-review [hidden]{display:none!important}dialog.completed-trade-review::backdrop{background:#030915d9}dialog.completed-trade-review h2{margin:0;font-size:20px}.completed-trade-review .trade-review-heading{margin:5px 0;font-size:18px;font-weight:700}.completed-trade-review p{margin:5px 0;color:#c6d2df}.completed-trade-review .trade-review-chart{width:100%;min-width:0}.completed-trade-review svg{width:100%;height:auto;display:block;max-height:56dvh}.completed-trade-review .trade-review-facts{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin:8px 0}.completed-trade-review dt{color:#9fb3c7;font-size:12px}.completed-trade-review dd{margin:4px 0;overflow-wrap:anywhere}.completed-trade-review footer{display:flex;justify-content:space-between;align-items:center;gap:16px;padding-top:6px;position:sticky;bottom:0;background:#101d2b}.completed-trade-review footer span{font-size:12px;color:#adbed0}.completed-trade-review button{min-height:48px;min-width:112px;padding:10px 24px;background:#92c9ff;color:#071421;border:0;border-radius:8px;font:bold 16px system-ui;cursor:pointer}.completed-trade-review button:focus-visible{outline:3px solid white;outline-offset:3px}@media(max-width:480px){dialog.completed-trade-review{padding:10px;width:calc(100vw - 16px);max-height:calc(100dvh - 16px)}.completed-trade-review .trade-review-facts{gap:8px;font-size:12px}.completed-trade-review .trade-review-note{font-size:12px}.completed-trade-review h2{font-size:18px}.completed-trade-review .trade-review-heading{font-size:16px}}`;document.head.append(style);}
    returnFocus=document.activeElement;state={candles:candles.map(bar=>({...bar})),trades:copy,index:0};advanceAfter=0;
    dialog=document.createElement('dialog');dialog.className='completed-trade-review';dialog.setAttribute('aria-labelledby','completed-trade-review-title');dialog.setAttribute('aria-describedby','completed-trade-review-description');dialog.setAttribute('aria-modal','true');
    dialog.addEventListener('cancel',event=>{event.preventDefault();event.stopPropagation();});
    dialog.addEventListener('keydown',event=>{if(event.key==='Escape'){event.preventDefault();event.stopPropagation();}if(event.key==='Tab'){event.preventDefault();dialog.querySelector('button')?.focus({preventScroll:true});}});
    document.body.append(dialog);priorOverflow=document.body.style.overflow;document.body.style.overflow='hidden';dialog.showModal();paint();return true;
  }
  function setVisible(visible){
    reviewVisible=visible;
    if(!state||!dialog)return;
    // Keep the modal/focus owner stable during a temporary sign-in check.
    // Closing and reopening a parent-document dialog refocuses the parent,
    // which can start the same account check again before a save dispatches.
    if(!visible&&!verificationNotice){verificationNotice=document.createElement('p');verificationNotice.setAttribute('role','status');verificationNotice.setAttribute('aria-live','polite');verificationNotice.textContent='Verifying your learner account…';dialog.append(verificationNotice);}
    for(const child of dialog.children)if(child!==verificationNotice)child.hidden=!visible;
    if(verificationNotice)verificationNotice.hidden=visible;
    const action=dialog.querySelector('button');if(action)action.disabled=!visible;
  }
  return {open,setVisible,active:()=>!!state,progress:()=>state?{index:state.index,total:state.trades.length}:null,dismiss};
}
