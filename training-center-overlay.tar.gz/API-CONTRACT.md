# API contract

The interface calls shared collections **Modules** and saved records **Slides**. Existing `folders`/`lessons` routes, JSON field names and `price-action-lessons` format remain unchanged for compatibility; these are internal names, not UI labels.

Author mutations require active approved membership, an eight-hour HttpOnly Secure SameSite=Strict session, exact same origin and `X-CSRF-Token`. Membership/session is rechecked inside serialized mutation transactions. Public data endpoints are read-only.

- `GET /api/status`: readiness plus current caller's role/email.
- `GET /api/auth/csrf`: short-lived, single-use preauth cookie and CSRF token.
- `POST /api/auth/login` `{email,password}`: generic failures; scrypt verified server-side. No claim-by-email.
- `POST /api/auth/enroll` `{token,password}`: one-use, expiring capability bound to an existing active member; atomically sets/reset credential, consumes token and revokes older sessions. No raw token or password is retained/logged.
- `POST /api/auth/logout`: revoke session.
- `GET /api/author/members`: admins only.
- `POST /api/author/members` `{email,role}`: explicit grant/reactivation; default Author, no invitation.
- `PATCH /api/author/members/:encodedEmail` `{role}`.
- `POST /api/author/members/:encodedEmail/remove` `{}`: revoke sessions, enrollment tokens and password; protect last admin.
- `POST /api/author/members/:encodedEmail/enrollment` `{}`: admin-confirmed setup/reset capability; `{enrollmentUrl,expiresAt}` returned once, private/no-store. One-hour expiry, 10 issuances per admin per hour; invalidates prior unused links.
- `/api/author/folders`: GET active modules, POST `{name}`. `?trashed=true` selects Module Trash. Author summaries include `trashed`, `slideCount`, `activeSlideCount`, `trashedSlideCount`, and `versionCount`; public summaries omit these private trash counts.
- `PATCH /api/author/folders/:id` `{name,expectedRevision}`.
- `POST /api/author/folders/:id/{trash|restore}` `{expectedRevision}`: recoverable parent archive, not cascade deletion. Parent revisions include child writes/moves/trash changes; stale confirmations return 409. Archived modules reject child mutation and disappear from every public list/manifest/version pack. Author immutable version access remains; restore preserves individual Slide Trash flags. Requires additive migration 005 before deployment.
- `POST /api/author/lessons` `{folderId,requestId,pack,lessonId?,expectedRevision?}`: exact pack JSON text, no images. Update requires ID+expected revision.
- `GET /api/author/save-status?requestId=...`: recover uncertain saves; reuse exact ID/text only for the same save.
- `GET /api/{public|author}/lessons`, `/folders`, `/lessons/:id/manifest`, `/lessons/:id/versions/:versionId/pack`.
- `GET /api/author/lessons/:id/versions`: immutable history.
- `POST /api/author/lessons/:id/restore` `{expectedRevision}` remains available for existing legacy Slide Trash. New `/trash` calls return `409 slide_confirmation_required`; they never become destructive implicitly.

`/library` fetches only public endpoints. `/studio`, `/admin/modules`, and raw `/editor/*` documents require the existing server-verified author/admin session, including HEAD and Next prefetch/RSC requests. The discreet Admin entry is public; teacher controls are not. These page checks supplement, not replace, the API authorization and CSRF boundary.

Conflicts return 409, not overwrite. Version text, revision and request result commit atomically. Limits: 100 modules, 1,000 slides, 200 versions per slide, 3MiB per pack, 100MiB retained JSON. Chart references must match bundled catalog. No Google, public setup, shared-password, or image-upload endpoint exists.

## Additive Slide JSON fields (pack version 1)

- Optional `coverArtwork` is one allowlisted preset ID: `ema-touch`, `trend`, `breakout`, `waves`, `fin`, or `sailboat`. Missing legacy values remain absent in stored/exported JSON and display the `ema-touch` cover. Unknown or non-string values are rejected on save/import; summary rendering safely falls back to `ema-touch`. Public/author summaries derive this one ID from the current immutable version, while history uses each version’s own value. These fixed bundled SVG illustrations are decorative card covers, not previews of saved price data, user SVG, or uploaded images. No database migration or backfill is required.
- Optional `indicators: {ema20, pivotDiamonds}` contains exactly two boolean settings. Missing settings remain absent but resolve to EMA20 on/pivots off. Explicit false values stay off; new author drafts explicitly default to EMA20 on/pivots off. Learner EMA20 hide/show state is transient, does not alter these settings or slide bytes, and does not affect teacher PNG exports. No migration or backfill is performed. Values are derived from the existing verified chart, never saved as extra chart data. EMA20 uses alpha 2/21 with historical warmup once; pivots use current-session candles only, with confirmation and five-bar strength bounded by the saved range end (no future candles after it). Settings affect content/dedup identity but require no migration.
- `prompt` is the initial question/action; existing `notes` is final-only explanation.
- Optional `range: {startBar, endBar}` uses global zero-based inclusive candle indices (UI 8–20 means 7–19, 13 candles). Missing range remains absent and means the original full session. Bounds must be ordered integers within the chosen chart; a single-bar range is valid. All original mark anchors/timestamps remain global and unchanged. Final saves require every correct Candle Picker bar and each entire Clickable Areas target extent inside the range. Incomplete local drafts may retain incompatible answers with an actionable warning; saved packs may not.
- Lines optionally carry `color` (`#rrggbb`) and `style` (`solid` or `dotted`); text annotations optionally carry `color` and `size` (14, 18, 22 or 26).
- `arrows` contains up to 80 `{id,at,direction,study,crossed}` point marks. Direction is `up` or `down`; `at` is a normal chart point.
- `exercise` is `{type:"reveal-drawings"}`, `{type:"candle-picker",correctBars:[...]}`, or `{type:"clickable-areas",targets:[{id,a,b},...]}`. Candle indices are zero-based in JSON and one-based in the UI. Rectangular targets use the same bar/time/price points as line endpoints.

Missing optional keys remain absent when normalizing legacy slides. Missing exercise means Reveal Drawings. Candle Picker and Clickable Areas require a nonempty prompt and a nonempty valid answer set on final save. Answer indices, point timestamps, unique mark IDs and nondegenerate/unique target rectangles are validated against the selected immutable chart. Overlapping targets are allowed. Incomplete answers may exist only in local author drafts, never in saved packs.

Candle Picker **Reveal Answer** is a transient study state: it displays the correct candle numbers and explanation without recording a correct check or enabling Next. Replay clears it; only the exact chosen set passes Check Answer. This changes no saved exercise keys or server state. Visible bar labels retain original 1-based current-session indices after crops and adapt spacing to available width.

The server stores exact pack text and immutable prior versions; no data migration or student-state endpoint is introduced. The client conceals teacher marks/explanation in the initial rendered UI, but public JSON is not an assessment-security boundary.

## Confirmed permanent Slide deletion

`POST /api/author/workspace/operations` accepts `{version:1,requestId,op:"delete-slide",slideKey,expectedRevision,expectedLessonRevision,confirmedTitle,confirmedVersionId}`. The UI obtains confirmation for that named Slide immediately before sending. Missing confirmation fields return 400; changed identity/title/content version/Slide revision/parent revision or existing Slide Trash returns 409. A committed deletion returns `{version:1,requestId,op:"delete-slide",deleted:{key,title,revision,versionId,permanent:true},lesson?}`; the deleted revision is the confirmed pre-delete revision, and the optional current parent revision increases by one. No new Slide Trash entry is created.

The existing author/admin, CSRF, origin, read-only, cancellation, and serialized transaction guards apply. `/api/status.workspace.permanentDeleteEnabled` is strictly true only with the separate explicit runtime opt-in and exact reviewed scoped function. An unavailable capability returns `423 slide_delete_unavailable`; ordinary writes and restore remain independently available.

`GET /api/author/workspace/operations/:requestId` is actor-bound. Committed requests replay without executing deletion again. A known absent ID returns `404 {state:"unknown",code:"workspace_operation_unknown"}`; another 404 or an inconclusive response must not authorize retry. The UI permits only one exact retry after that check and a fresh confirmation. Earlier save receipts for an erased Slide return `410 slide_permanently_deleted`; retired legacy creation request IDs cannot recreate it, including concurrent stale retries.

Selective erasure includes the Slide's own versions and its entries across historical shared sequence packs and composition snapshots. Other Slides/parents/shared media are not erased. Historical sequence packs that become empty are no longer served as playable packs/manifests/previews; their empty Lesson is preserved in the workspace. Ordinary saves still preserve immutable historical bytes; only this explicitly confirmed deletion redacts the selected member. This does not erase external backups or copies already downloaded.

## Count-only markup completion history (prepared, default off)

Authenticated same-origin GET `/api/learner/practice` returns version 1, the current account context, asOf, `markupTracking:{enabled,since}`, and `markups:[{id,completedAt}]`. `since` is the earliest recorded completion date, or null. No chart, image, drawing, filename or real trade content appears. GET performs no DML. Disabled tracking returns unavailable metadata and an empty list, not evidence of zero past practice.

Authenticated same-origin/CSRF POST `/api/learner/practice-markups` accepts exactly `{context,completion:{id,completedAt}}`. Account identity comes from the verified server principal. Immutable `(account_id,generation,completion_id)` deduplicates retries, including concurrent requests. The response returns the same completion plus server savedAt and a duplicate boolean. A new completion beyond the 10,000-per-generation cap fails without pruning. Client-reported actual completion timestamps are canonical UTC ISO, no earlier than 2020 and no more than five minutes in the future; they are not server-proven activity evidence. For NEW completion IDs only, the lower bound is `max(account.created_at, session.created_at, serverNow - 24 hours) - 5 minutes`. Existing identical receipts are checked first and remain retryable regardless of their age or a newer valid session. A timestamp conflict still fails; an out-of-window new ID is rejected without insertion or silent retimestamping.

Administrator GET `/api/author/trader-history/:accountId/practice` returns `{trader,stats,practice}` with existing verified outcome projections. The admin role is checked before and after retrieval, and database reads share a read-only repeatable snapshot. A fixed non-authenticating context tag replaces any real learner session identifier. Export/reset include markup records only when the feature is enabled; simulator records and existing reset safeguards are preserved. See the rollout document for disabled-mode retention limitations.

## Read-only bar-group outcome totals

Stats version 1 optionally adds `bucketOutcomes` per attempt: null when closed-outcome allocation is unverifiable, otherwise four exact outcome-total objects with wins, losses, flats, grossProfit, grossLoss, biggestWin and biggestLoss. Groups are whole closed legs/trades exiting at bars 1–20, 21–40, 41–60 and 61–end. Gross totals, counts and extrema reconcile to the row's outcomes. Existing `buckets` stay unchanged (Market per-transition net, Limit exit net). Legacy snapshots without the optional property remain accepted but cannot provide precise bar-group PF. The same read-only stats projection serves authorized learner and admin reports; no new endpoint, persistence or permission is introduced. See docs/trader-history-graphs.md.
