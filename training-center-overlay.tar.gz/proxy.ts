import {NextResponse,type NextRequest} from 'next/server';
import {speakChartAccess} from './lib/speak-chart/access.mjs';
import {handleRenderRequest} from './lib/portal/render-runtime.mjs';
import {teacherRouteAccess,lessonRouteAccess} from './lib/portal/teacher-route-guard.mjs';

export async function proxy(request:NextRequest) {
  const guard=request.nextUrl.pathname==='/speak-the-chart'||request.nextUrl.pathname.startsWith('/speak-the-chart/')?speakChartAccess:request.nextUrl.pathname==='/library'||request.nextUrl.pathname.startsWith('/library/')?lessonRouteAccess:teacherRouteAccess;
  const result=await guard(request,handleRenderRequest);
  if(result.allowed){const response=NextResponse.next();response.headers.set('Cache-Control','private, no-store');return response;}
  // The sign-in page is deliberately outside this matcher; no redirect loop or open return URL.
  const response=NextResponse.redirect(new URL('/admin',request.url),303);
  response.headers.set('Cache-Control','private, no-store');return response;
}
export const config={matcher:['/speak-the-chart/:path*','/admin/lesson-preview/:path*','/library/:path*','/studio/:path*','/admin/modules/:path*','/editor/:path*']};
