import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {classifyOpen,filterOpenSessions} from '../lib/pattern-open-type.mjs';
import {randomPatternSession} from '../lib/pattern-selection.mjs';
function chart(closes,open=101){return {id:'mes1-2025-05-22-81',date:'2025-05-22',warmup:{value:100,ema10Value:100},prior:[],previousSessionFinal:{t:'2025-05-21 15:10',c:100,source:'original-warmup-final'},current:closes.map((c,i)=>({t:`2025-05-22 ${String(Math.floor((510+i*5)/60)).padStart(2,'0')}:${String((510+i*5)%60).padStart(2,'0')}`,o:open,h:Math.max(c,open)+1,l:Math.min(c,open)-1,c}))};}
test('opening classification uses real gap sign, first six closes and warmed EMA20',()=>{
 assert.deepEqual(classifyOpen(chart([110,110,110,110,110,110])),{gap:'up',ema:'above'});
 assert.deepEqual(classifyOpen(chart([90,90,90,90,90,90],99)),{gap:'down',ema:'below'});
 assert.deepEqual(classifyOpen(chart([100,100,100,100,100,100],100)),{gap:'',ema:''});
 assert.equal(classifyOpen(chart([110,110,110,90,90,90])).ema,'');
 assert.equal(classifyOpen(chart([110,110,110,110,90,90])).ema,'above');
 const c=chart([110,110,110,110,110,110,0,0]);assert.deepEqual(classifyOpen(c),classifyOpen({...c,current:c.current.slice(0,6)}));
});
test('missing EMA or gap cannot qualify that filter, but independent filters still work',()=>{
 const c=chart([110,110,110,110,110]);assert.deepEqual(classifyOpen(c),{gap:'up',ema:''});
 const noGap={...chart([110,110,110,110,110,110]),previousSessionFinal:null};assert.deepEqual(classifyOpen(noGap),{gap:'',ema:'above'});
});
test('filters intersect, empty selections preserve pool, no matches never fall back; current excluded only when possible',()=>{
 const rows=[{reference:{id:'a'},chart:chart([110,110,110,110,110,110])},{reference:{id:'b'},chart:chart([90,90,90,90,90,90],99)}];
 const before=JSON.stringify(rows);assert.equal(filterOpenSessions(rows,{}),rows);
 assert.equal(filterOpenSessions(rows,{gap:'up',ema:'above'})[0],rows[0]);
 assert.deepEqual(filterOpenSessions(rows,{gap:'up',ema:'below'}),[]);
 assert.equal(randomPatternSession(filterOpenSessions(rows,{ema:'above'}),'a',()=>0),rows[0]);
 assert.equal(randomPatternSession(rows,'a',()=>0),rows[1]);
 assert.equal(randomPatternSession(filterOpenSessions(rows,{gap:'up',ema:'below'}),'a'),null);
 assert.deepEqual(filterOpenSessions(rows,{gap:'invalid'}),[]);assert.equal(JSON.stringify(rows),before);
});
test('all real catalog selections satisfy both requested opening filters',()=>{
 const rows=JSON.parse(fs.readFileSync(new URL('../public/modules/chart-match-index.json',import.meta.url))).sessions;
 for(const gap of ['up','down'])for(const ema of ['above','below']){
 const pool=filterOpenSessions(rows,{gap,ema});assert.ok(pool.length);
 for(const fraction of [0,.25,.5,.999])assert.deepEqual(classifyOpen(randomPatternSession(pool,'',()=>fraction).chart),{gap,ema});
 }
});
