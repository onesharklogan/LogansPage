'use client';
import {useId} from 'react';

export const TRADING_STYLES = ['Buy Closes','Buy Pullbacks','Buy Previous Lows','Sell Closes','Sell Pullbacks','Sell Previous Highs','Stay Out'] as const;
type Props = {value:string;onChange:(value:string)=>void;disabled?:boolean;id?:string};

/** Existing custom styles remain selected until an explicit replacement or clear. */
export default function TradingStyleSelect({value,onChange,disabled=false,id}:Props){
 const generatedId=useId(),selectId=id??generatedId;
 const legacy=!!value&&!TRADING_STYLES.some(style=>style===value);
 return <label htmlFor={selectId}>Trading Style
  <select id={selectId} value={value} disabled={disabled} aria-describedby={legacy?`${selectId}-legacy`:undefined} onChange={event=>onChange(event.target.value)}>
   <option value="">None (optional)</option>
   {legacy&&<option value={value} disabled>Keep saved custom style</option>}
   {TRADING_STYLES.map(style=><option key={style} value={style}>{style}</option>)}
  </select>
  {legacy&&<span id={`${selectId}-legacy`}>Saved custom style: {value}. Kept unless you choose a style or None.</span>}
 </label>;
}
