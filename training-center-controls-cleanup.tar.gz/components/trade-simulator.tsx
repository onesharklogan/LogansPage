'use client';
import {readPreviewPreference} from '../public/modules/preview-trading-preference.js';
import MobileSessionOverview from './mobile-session-overview';
import '../public/modules/session-overview.css';
import {chartSourceNotice} from '../lib/session-source.mjs';

import {patternFinderUrl,openPatternFinderTab} from '../public/modules/pattern-finder-link.js';
import {visibleOpeningSnapshot,renderVisibleChart,openChartMatchImage} from '../public/modules/chart-match-handoff.js';
import LoadingIndicator from './loading-indicator';
import LimitTradeReview from './limit-trade-review';
import { useEffect, useLayoutEffect, useMemo, useRef, useState, type PointerEvent, type KeyboardEvent, type MouseEvent } from 'react';
import { initialState, placeBracket, editBracket, cancelPending, closeOpenPosition, advanceCandle, finishSession, statistics, bracketStats, snapPrice, type Bracket, type SimState } from '../lib/trade-simulator.mjs';
import { replayViewport, replayPoint, placementPoint, tradeReviewMarks, priceFromClient, orderHandle, orderTag, entryCloseHandle, entryMinimizeHandle, priceAxisHandle, advanceView, focusLatest, hiddenRevealed, focusHidden, initialView, dragView, zoomTime, panTime, resetViewAxis, type ViewNavigation, EXIT_LABELS } from '../lib/trade-simulator-view.mjs';
import {newAttempt as localNewAttempt, load as localLoadHistory, checkpoint as localCheckpoint, restore as localRestore, summarize, type Attempt} from '../lib/trade-simulator-history.mjs';
import Model from '../lib/portal/lesson-model.cjs';
import AppHeader from './app-navigation';
import TradeSessionCalendar from './trade-session-calendar';
import TradeHistoryChart from './trade-history-chart';
import TradeHistoryBuckets from './trade-history-buckets';
import {buildCalendar} from '../lib/session-calendar.mjs';
import type {SimulatorProfileAccess} from './simulator-profile-gate';
import { loadSimulatorCatalog, loadSimulatorChart } from './trade-simulator-data.mjs';
import {readTradePreferences as localReadPreferences,saveEqualTpSl as localSavePreference,PREFERENCE_PREFIX} from '../lib/trade-simulator-preferences.mjs';

import {validatePracticeBracket,defaultPracticeBracket as defaultBracket,practiceExitPrice,linkedPracticeExitEdit as linkedExitEdit,equalPracticeTargetFromStop as equalTargetFromStop} from '../lib/trade-simulator-practice-limits.mjs';

type Candle = {t:string;o:number;h:number;l:number;c:number};
type Chart = {id:string;title:string;current:Candle[];prior?:Candle[]};
type Reference = {id:string;title:string;url:string;sha256:string;date?:string};
type CalendarRequest = {token:number;generation:number;initialId:string};
type CalendarFocusReturn = {token:number;generation:number;owner:Attempt|null;profile:SimulatorProfileAccess|undefined;target:HTMLElement;from:Element|null;cancel:()=>void};
type Key = 'entry'|'stop'|'target';
type OrderControl = 'close'|'minimize'|'expand';
type Draft = {side:'buy'|'sell';entry:string;stop:string;target:string};
type View = ReturnType<typeof replayViewport>;
type QuickOrder = {token:number;generation:number;index:number;price:number;left:number;top:number};
const KEYS:Key[]=['entry','stop','target'];
const COLORS={entry:'var(--appearance-ink-8ac7ff, #8ac7ff)',stop:'var(--appearance-ink-ff9aa9, #ff9aa9)',target:'var(--appearance-ink-9ee5bc, #9ee5bc)'};
const WARNING_STYLE={background:'var(--appearance-ink-332a17, #332a17)',border:'1px solid #b58a3b',color:'var(--appearance-ink-ffe0a3, #ffe0a3)',borderRadius:10,padding:'12px 14px'};
const LABELS={entry:'Entry',stop:'Stop',target:'Target'};
const format=(value:number)=>Number.isFinite(value)?value.toFixed(2):'—';
const distanceText=(value:number)=>{if(!Number.isFinite(value))return '—';const exact=Number(value.toFixed(2)).toString();if(exact.length<=7)return exact;const units:[[number,string],[number,string],[number,string]]=[[1e9,'b'],[1e6,'m'],[1e3,'k']];const unit=units.find(([size])=>value>=size);return unit?`≈${Number((value/unit[0]).toFixed(1))}${unit[1]}`:`≈${value.toExponential(1)}`;};
const signed=(value:number)=>`${value>0?'+':''}${format(value)}`;
const draftOf=(b:Bracket):Draft=>({side:b.side,entry:String(b.entry),stop:String(b.stop),target:String(b.target)});
const directionKey=(key:string)=>({w:'ArrowUp',a:'ArrowLeft',s:'ArrowDown',d:'ArrowRight'}[key.toLowerCase()]||key);
const keyBlocked=(event:KeyboardEvent,allowShiftArrow=false,allowShiftPlus=false)=>event.defaultPrevented||(event as KeyboardEvent&{isComposing?:boolean}).isComposing||event.nativeEvent?.isComposing||event.nativeEvent?.keyCode===229||event.keyCode===229||event.ctrlKey||event.metaKey||event.altKey||(event.shiftKey&&!(allowShiftArrow&&event.key.startsWith('Arrow')||allowShiftPlus&&event.key==='+'));
const isTyping=(target:EventTarget|null)=>{const node=target as HTMLElement|null;return !!(node?.isContentEditable||node?.closest?.('input,textarea,select,[role="textbox"],[contenteditable]:not([contenteditable="false"])'));};
const bracketOf=(d:Draft):Bracket=>({side:d.side,entry:d.entry.trim()?Number(d.entry):NaN,stop:d.stop.trim()?Number(d.stop):NaN,target:d.target.trim()?Number(d.target):NaN});

const profileInitials=(name:string)=>{const words=name.trim().split(/\s+/u).filter(Boolean);return Array.from(((Array.from(words[0]||'')[0]||'')+(words.length>1?(Array.from(words.at(-1)||'')[0]||''):'')).toUpperCase()).slice(0,2).join('')||'L';};

export default function TradeSimulator({profileAccess}:{profileAccess?:SimulatorProfileAccess}={}) {
  const newAttempt=profileAccess?.store?.newAttempt??localNewAttempt,loadHistory=profileAccess?.store?.load??localLoadHistory,checkpoint=profileAccess?.store?.checkpoint??localCheckpoint,restore=profileAccess?.store?.restore??localRestore;
  const readTradePreferences=profileAccess?.store?.readTradePreferences??localReadPreferences,saveEqualTpSl=profileAccess?.store?.saveEqualTpSl??localSavePreference;
  const online=profileAccess?.mode==='account'||profileAccess?.mode==='guest',guest=profileAccess?.mode==='guest';
  const [failedHeaderAvatar,setFailedHeaderAvatar]=useState<{key:string|null}|null>(null),headerAvatar=useRef<{key:string|null}>({key:null});
  const accountHeader=profileAccess?.mode==='account'?profileAccess.accountHeader:null,headerVerified=!!accountHeader?.ready&&accountHeader.isCurrent(),headerAvatarKey=headerVerified?JSON.stringify([profileAccess!.profile.learnerId,profileAccess!.profile.name,accountHeader!.avatarUrl]):null;
  if(headerAvatar.current.key!==headerAvatarKey)headerAvatar.current={key:headerAvatarKey};const displayedHeaderAvatar=headerAvatar.current;
  const [matcherStatus,setMatcherStatus]=useState(''),[matcherError,setMatcherError]=useState(''),[matcherBusy,setMatcherBusy]=useState(false),matcherTransfer=useRef<null|(()=>void)>(null),matcherActive=useRef(false),matcherContainer=useRef<HTMLDivElement>(null),matcherButton=useRef<HTMLButtonElement>(null);
  useEffect(()=>()=>{matcherTransfer.current?.();},[]);
  const [catalog,setCatalog]=useState<Reference[]>([]),[choice,setChoice]=useState(''),[sessionId,setSessionId]=useState('');
  const entryPickerPending=useRef(false),entryPickerConsumed=useRef(false);
  const [chart,setChart]=useState<Chart|null>(null),[loading,setLoading]=useState(true),[error,setError]=useState(''),[retry,setRetry]=useState(0);
  const [tradeReview,setTradeReview]=useState<SimState|null>(null),reviewPending=useRef<SimState|null>(null),reviewFocusNeeded=useRef(false),reviewOwner=useRef(profileAccess?.profile.learnerId||'standalone');
  const [state,setState]=useState<SimState>(()=>initialState()),[draft,setDraft]=useState<Draft>({side:'buy',entry:'',stop:'',target:''}),[edited,setEdited]=useState(false);
  const [equalTpSl,setEqualTpSl]=useState(false),equalMode=useRef(false),preferenceBusy=useRef(false),preferenceRequest=useRef(0),pendingPreference=useRef<boolean|null>(null);
  const [preferenceSaving,setPreferenceSaving]=useState(false),[preferenceError,setPreferenceError]=useState('');
  const [playing,setPlaying]=useState(false),[speed,setSpeed]=useState(1000),[notice,setNoticeText]=useState(''),[width,setWidth]=useState(900);
  const [noticeWarning,setNoticeWarning]=useState(false),[sessionWarning,setSessionWarning]=useState(false),[historyReplayWarning,setHistoryReplayWarning]=useState(false);
  const [history,setHistory]=useState<Attempt[]>([]),[historyOpen,setHistoryOpen]=useState(false),[saving,setSaving]=useState(false),[saveError,setSaveError]=useState('');
  const attempt=useRef<Attempt|null>(null),restoreAttempt=useRef<Attempt|null>(null),saveBusy=useRef(false),unsavedCheckpoint=useRef(false),saveFailure=useRef(''),saveFailureKind=useRef<'save'|'read'>('save'),alive=useRef(true),historyPanel=useRef<HTMLElement>(null),deferredLoad=useRef(false);
  const [confirm,setConfirm]=useState<{kind:'reset'|'session'|'history'|'calendar';id?:string;title?:string;reference?:Reference;generation:number}|null>(null);
  const historyReplayLoad=useRef<AbortController|null>(null),installedHistoryChart=useRef<Chart|null>(null),historyReplayFocus=useRef<string|null>(null),replayedChartFocus=useRef(false);
  const [historyReplayMessage,setHistoryReplayText]=useState('');
  const [quickMenu,setQuickMenu]=useState<QuickOrder|null>(null),quickOrder=useRef<QuickOrder|null>(null),quickSequence=useRef(0),quickMenuElement=useRef<HTMLDivElement>(null);
  const [preview,setPreview]=useState<ReturnType<typeof placementPoint>>(null),picker=useRef<HTMLButtonElement>(null),dialogOpen=useRef(false);
  const [calendar,setCalendar]=useState<CalendarRequest|null>(null),calendarRequest=useRef<CalendarRequest|null>(null),calendarSequence=useRef(0),calendarFocus=useRef<HTMLElement|null>(null),calendarFocusReturn=useRef<CalendarFocusReturn|null>(null);
  const sessionLoad=useRef<AbortController|null>(null),[sessionLoading,setSessionLoading]=useState(false),[sessionMessage,setSessionText]=useState('');
  const host=useRef<HTMLDivElement>(null),svg=useRef<SVGSVGElement>(null),current=useRef(state),loadedChart=useRef<Chart|null>(null);
  const drag=useRef<{key:Key;pointerId:number;view:View;before:Draft;beforeEdited:boolean;candidate:Bracket;orderId:number;offset:number;equal:boolean;basis:number;adjusted:boolean}|null>(null);
  const [dragging,setDragging]=useState(false),[showEma,setShowEma]=useState(true),[priceDragging,setPriceDragging]=useState(false);
  const [mode,setMode]=useState<'idle'|'armed'|'draft'>('idle'),[navigation,setNavigation]=useState<ViewNavigation>(initialView),[height,setHeight]=useState(440);
  const placement=useRef<'idle'|'armed'|'draft'>('idle'),paused=useRef(true),timerRef=useRef<ReturnType<typeof setTimeout>|null>(null);
  const gesture=useRef<{pointerId:number;x:number;y:number;view:View;nav:ViewNavigation;scaleX:number;scaleY:number;mode:'plot'|'price'|'time'|'place';moved:boolean}|null>(null);
  const [minimized,setMinimized]=useState(false),compact=useRef(false),focusOrder=useRef(false);
  const closePress=useRef<{action:OrderControl;moved:boolean;pointerId:number;orderId:number;generation:number;x:number;y:number;left:number;right:number;top:number;bottom:number}|null>(null);
  const recoveryPress=useRef<{pointerId:number;generation:number;index:number;x:number;y:number;left:number;right:number;top:number;bottom:number;moved:boolean}|null>(null);
  const [,setInteractionEpoch]=useState(0);
  const runGeneration=useRef(0),playEpoch=useRef(0),bodyKeyHandler=useRef<(event:globalThis.KeyboardEvent)=>void>(()=>{});
  // Scoring mode is captured once at session creation, never from a live checkbox.
  const previewTrading=attempt.current?.previewTrading===true;
  const active=state.position||state.pending,renderGeneration=runGeneration.current;
  const showOrders=!!active;
  const parsed=bracketOf(draft),validation=validatePracticeBracket(parsed,state.tick,state.position?.entryPrice??parsed.entry),metrics=bracketStats(parsed);
  const displayMetrics=metrics||(active?bracketStats(active):null);
  const distanceBasis=state.position?.entryPrice??parsed.entry;
  const oversizedSavedBracket=active&&!validatePracticeBracket(active,state.tick,state.position?.entryPrice??active.entry).valid;
  const distanceOf=(key:Key)=>key==='entry'?null:Math.abs(parsed[key]-distanceBasis);
  const distanceDetail=(key:Key)=>key==='entry'?'':`, ${format(distanceOf(key)!)} points from ${state.position?'actual fill':'planned entry'}`;
  const blocked=loading||!!error||!!confirm||!!calendar||!chart||state.ended||saving||!!saveError||preferenceSaving;
  const totals=statistics(state),pointStats=summarize(state.trades),historyStats=summarize(history);
  const displayIndex=state.ended&&chart?chart.current.length-1:state.index;
  const indicators=useMemo(()=>chart?Model.chartIndicators(chart,displayIndex):{ema:[],priorEma:[]},[chart,displayIndex]);
  const overviewIndicators=useMemo(()=>chart&&showEma?Model.chartIndicators(chart,previewTrading?chart.current.length-1:state.index):{ema:[],ema10:[]},[chart,showEma,previewTrading,state.index]);
  const levels=showOrders?KEYS.map(k=>parsed[k]).filter(Number.isFinite):[];
  const viewport=useMemo(()=>chart?replayViewport(chart,displayIndex,levels,width,height,navigation,indicators):null,[chart,displayIndex,width,height,parsed.entry,parsed.stop,parsed.target,showOrders,navigation,indicators]);
  const displayedView=drag.current?.view||viewport;
  const orderYs=displayedView?Object.fromEntries(KEYS.map(key=>[key,replayPoint(0,parsed[key],displayedView).y])):null;
  const reviewMarks=state.ended&&displayedView?tradeReviewMarks(state.trades,displayedView):[];
  const hiddenCandles=chart&&displayedView?hiddenRevealed(chart,displayIndex,displayedView):null;
  const unrealized=state.position&&chart?(chart.current[state.index].c-state.position.entryPrice)*(state.position.side==='buy'?1:-1):0;

  useLayoutEffect(()=>{if(!tradeReview&&reviewFocusNeeded.current){reviewFocusNeeded.current=false;svg.current?.focus({preventScroll:true});}},[tradeReview]);
  bodyKeyHandler.current=event=>replayKeys(event as unknown as KeyboardEvent);
  useEffect(()=>{const listener=(event:globalThis.KeyboardEvent)=>{if(event.target===document.body||event.target===document.documentElement)bodyKeyHandler.current(event);};document.addEventListener('keydown',listener);return()=>document.removeEventListener('keydown',listener);},[]);
  function openPatternFinder(){
    if(reviewPending.current||loading||!chart||chart!==loadedChart.current||!!confirm||!!calendar||!profileReady())return;
    pause();setMatcherError('');
    try{
      const url=patternFinderUrl({id:chart.id,sha256:catalog.find(row=>row.id===chart.id)?.sha256,revealed:current.current.index+1,total:chart.current.length,finished:current.current.ended,preview:previewTrading});
      openPatternFinderTab(url);
      setMatcherStatus('Pattern Finder opened in a new tab. Keep this simulator tab open to resume.');
    }catch(error){setMatcherError(error instanceof Error?error.message:'Pattern Finder could not open.');}
  }
  function openMatcher(){
    if(reviewPending.current||matcherActive.current||matcherBusy||renderGeneration!==runGeneration.current||loading||!chart||chart!==loadedChart.current||!displayedView||displayedView.end!==current.current.index||!!confirm||!!calendar||dragging||!profileReady())return;
    pause();setMatcherError('');setMatcherStatus('');
    try{
      const excludeSha256=catalog.find(row=>row.id===sessionId)?.sha256;if(!excludeSha256)throw Error('The source chart could not be verified for safe comparison. Reload the session catalog and try again.');
      const snapshot=visibleOpeningSnapshot(displayedView,{showEma});
      const image=renderVisibleChart(snapshot);matcherActive.current=true;setMatcherBusy(true);
      matcherTransfer.current=openChartMatchImage(image,{container:matcherContainer.current,returnFocus:matcherButton.current,priorTime:snapshot.priorTime,excludeSha256,onStatus:(message:string)=>{if(alive.current)setMatcherStatus(message);},onError:(message:string)=>{if(alive.current)setMatcherError(message);},onDone:()=>{matcherActive.current=false;if(alive.current)setMatcherBusy(false);}});
    }catch(error){setMatcherError(error instanceof Error?error.message:'The chart could not be captured. Try again.');}
  }
  function setNotice(message:string,warning=false) {setNoticeText(message);setNoticeWarning(warning);}
  function setSessionMessage(message:string,warning=false) {setSessionText(message);setSessionWarning(warning);}
  function setHistoryReplayMessage(message:string,warning=false) {setHistoryReplayText(message);setHistoryReplayWarning(warning);}
  function combinedHost(){return typeof window==='undefined'?null:(window as any).PriceActionCombined;}
  function profileReady() {return (!combinedHost()||combinedHost().isActive('limit'))&&(!profileAccess||profileAccess.guard());}
  function mutationReady(allowDialog=false) {return !reviewPending.current&&profileReady()&&!preferenceBusy.current&&!saveBusy.current&&!saveFailure.current&&!historyReplayLoad.current&&!sessionLoad.current&&!calendarRequest.current&&(allowDialog||!dialogOpen.current);}
  useLayoutEffect(()=>{
    const pending=calendarFocusReturn.current;if(!pending)return;
    pending.cancel();
    if(!alive.current||calendar||confirm||loading||pending.token!==calendarSequence.current||pending.generation!==runGeneration.current||pending.owner!==attempt.current||pending.profile!==profileAccess||!mutationReady())return;
    const focused=document.activeElement;
    if(focused!==pending.from&&focused!==document.body&&focused!==document.documentElement)return;
    if(pending.target.isConnected===false||pending.target.matches?.(':disabled')||pending.target.closest?.('[inert]'))return;
    pending.target.focus({preventScroll:true});
  });
  useEffect(()=>{alive.current=true;return()=>{alive.current=false;calendarFocusReturn.current?.cancel();historyReplayLoad.current?.abort();historyReplayLoad.current=null;sessionLoad.current?.abort();sessionLoad.current=null;calendarRequest.current=null;};},[]);
  useEffect(()=>{if(typeof window==='undefined')return;const leaving=(event:BeforeUnloadEvent)=>{if(saveBusy.current||saveFailure.current){event.preventDefault();event.returnValue='';}};window.addEventListener('beforeunload',leaving);return()=>window.removeEventListener('beforeunload',leaving);},[]);
  useEffect(()=>{if(historyOpen)historyPanel.current?.scrollIntoView?.({block:'start',behavior:'smooth'});},[historyOpen]);
  useEffect(()=>{if(!loading&&replayedChartFocus.current){replayedChartFocus.current=false;host.current?.scrollIntoView?.({block:'start'});svg.current?.focus?.({preventScroll:true});}if(!confirm&&historyOpen&&historyReplayFocus.current){const id=historyReplayFocus.current;historyReplayFocus.current=null;historyPanel.current?.querySelector<HTMLButtonElement>(`[data-history-replay="${id}"]`)?.focus();}},[loading,chart,confirm,historyOpen]);
  function suspendForProfile() {
    calendarFocusReturn.current?.cancel();calendarRequest.current=null;setCalendar(null);
    if(sessionLoad.current){sessionLoad.current.abort();sessionLoad.current=null;setLoading(false);setSessionLoading(false);setSessionMessage(loadedChart.current?'Session loading canceled. Your current attempt was kept.':'Session loading canceled. No attempt was started.');}
    if(historyReplayLoad.current){historyReplayLoad.current.abort();historyReplayLoad.current=null;setLoading(false);setHistoryReplayMessage('Replay loading canceled. Your current attempt was kept.');}
    pause();clearQuickOrder();setPreview(null);runGeneration.current+=1;setInteractionEpoch(value=>value+1);recoveryPress.current=null;dialogOpen.current=false;setConfirm(null);historyReplayFocus.current=null;replayedChartFocus.current=false;
    const pointerId=drag.current?.pointerId??gesture.current?.pointerId??closePress.current?.pointerId;closePress.current=null;
    const moving=drag.current;if(moving){setDraft(moving.before);setEdited(moving.beforeEdited);}
    const movingView=gesture.current;if(movingView&&movingView.mode!=='place')setNavigation(movingView.nav);
    drag.current=null;gesture.current=null;setDragging(false);setPriceDragging(false);
    if(pointerId!==undefined&&svg.current?.hasPointerCapture(pointerId))svg.current.releasePointerCapture(pointerId);
  }
  useEffect(()=>{profileAccess?.registerSuspend(suspendForProfile);if(deferredLoad.current&&profileReady()){deferredLoad.current=false;setRetry(value=>value+1);}return()=>profileAccess?.registerSuspend(null);},[profileAccess]);
  const combinedController=useRef<any>(null),combinedUnregister=useRef<null|(()=>void)>(null);
  useEffect(()=>()=>{combinedUnregister.current?.();},[]);
  if(!combinedController.current)combinedController.current={};
  useEffect(()=>{
    const bridge=combinedHost();if(!bridge)return;
    Object.assign(combinedController.current,{
      status:()=>({ready:!reviewPending.current&&!loading&&!error&&!dialogOpen.current&&!calendarRequest.current&&!sessionLoad.current&&!historyReplayLoad.current&&!matcherActive.current&&(!profileAccess||profileAccess.guard()),canLeave:!reviewPending.current&&!saveBusy.current&&!unsavedCheckpoint.current&&!saveFailure.current&&pendingPreference.current===null,pending:saveBusy.current||pendingPreference.current!==null,identity:profileAccess?.profile.learnerId||'standalone',exposure:current.current.position?'open limit position':current.current.pending?'pending limit order':null,session:loadedChart.current?{id:loadedChart.current.id,sha256:catalog.find(row=>row.id===loadedChart.current?.id)?.sha256,index:current.current.index,seedIndex:current.current.ended?0:current.current.index}:null}),
      suspend:suspendForProfile,
      resume:()=>{pause();if(deferredLoad.current){deferredLoad.current=false;setRetry(value=>value+1);}setInteractionEpoch(value=>value+1);},
      replay:(target:any)=>{if(profileReady()&&target.attemptId)requestHistoryReplay(target.attemptId,runGeneration.current);}
    });
    combinedUnregister.current=bridge.register('limit',combinedController.current);
  });
  function refreshTradePreferences() {
    if(!profileAccess||!profileReady()||preferenceBusy.current||pendingPreference.current!==null)return;
    const result=readTradePreferences(profileAccess.profile,{guard:profileAccess.guard});
    equalMode.current=result.ok&&result.equalTpSl;setEqualTpSl(equalMode.current);setPreferenceError(result.ok?'':result.error||'Trade preferences are unavailable.');
  }
  useEffect(()=>{
    refreshTradePreferences();
    if(typeof window==='undefined')return;
    const refresh=()=>refreshTradePreferences(),changed=(event:StorageEvent)=>{if(profileAccess&&(event.key===null||event.key===PREFERENCE_PREFIX+profileAccess.profile.learnerId)){suspendForProfile();refreshTradePreferences();}};
    window.addEventListener('focus',refresh);window.addEventListener('storage',changed);
    return()=>{window.removeEventListener('focus',refresh);window.removeEventListener('storage',changed);};
  },[profileAccess]);
  async function changeEqualTpSl(value:boolean,generation:number) {
    if(!profileAccess||generation!==runGeneration.current||!mutationReady()||loading||!!error||dialogOpen.current||drag.current||gesture.current||closePress.current)return;
    pause();clearQuickOrder();const before=current.current,beforeMode=placement.current,existing=before.position||before.pending;
    const candidate=existing||beforeMode!=='idle'?existing||bracketOf(draft):null,basis=before.position?.entryPrice??candidate?.entry;
    const linked=value&&candidate?equalTargetFromStop(candidate,basis,before.tick):null;
    if(value&&candidate&&!linked){setNotice('Equal TP/SL could not be enabled without changing the current stop. Keep a valid stop within 20 points of entry and retry. The bracket and saved preference are unchanged.',true);return;}
    const request=++preferenceRequest.current,owner=profileAccess.profile.learnerId;
    const valid=()=>alive.current&&request===preferenceRequest.current&&generation===runGeneration.current&&current.current===before&&placement.current===beforeMode&&profileAccess.guard();
    if(profileAccess.mode==='account')pendingPreference.current=value;
    preferenceBusy.current=true;setPreferenceSaving(true);setPreferenceError('');
    try {const result=await saveEqualTpSl(profileAccess.profile,value,{guard:valid});
      if(!valid()||profileAccess.profile.learnerId!==owner){if(alive.current&&profileAccess.mode==='account')setPreferenceError('The account preference save was not confirmed for this bracket. After verification, retry to apply the same setting safely.');return;}
      if(result.ok){
        pendingPreference.current=null;
        equalMode.current=result.equalTpSl;setEqualTpSl(result.equalTpSl);setPreferenceError('');
        if(result.equalTpSl&&linked&&candidate){
          if(existing&&!before.ended&&linked.bracket.target!==existing.target){commit(editBracket(before,linked.bracket));setDraft(draftOf(linked.bracket));setEdited(false);}
          else if(!existing&&beforeMode!=='idle'){setDraft(draftOf(linked.bracket));}
          setNotice('Equal TP/SL is on. Target now matches the current stop distance from '+(before.position?'actual fill':'entry')+'. The stop is unchanged; active changes apply from the next candle.');
        }else setNotice(result.equalTpSl?'Equal TP/SL is on. New brackets start with equal stop and target distances.':'Equal TP/SL is off. Stop and target can be adjusted separately.');
      }else setPreferenceError(result.error||'The preference could not be saved. Retry to read the saved setting.');
    }finally {if(request===preferenceRequest.current){preferenceBusy.current=false;if(alive.current)setPreferenceSaving(false);}}
  }
  function storageFailure(message:string,kind:'save'|'read'='save') {if(kind==='read'||saveFailureKind.current!=='read')saveFailureKind.current=kind;saveFailure.current=message;setSaveError(message);pause();clearQuickOrder();}
  async function saveCheckpoint(next:SimState) {
    if(!profileAccess||!attempt.current)return;
    if(saveBusy.current||!profileReady())return;
    const record=attempt.current;saveFailureKind.current='save';saveBusy.current=true;setSaving(true);saveFailure.current='';setSaveError('');
    try {
      const result=await checkpoint(profileAccess.profile,record,next,{guard:()=>alive.current&&profileAccess.guard(),chart:loadedChart.current||undefined,sessionHash:record.sessionHash||undefined});
      if(!alive.current||attempt.current?.id!==record.id)return;
      if(!profileAccess.guard()){if(result.ok&&result.record){attempt.current=result.record;unsavedCheckpoint.current=false;}else if(!result.ok){saveFailure.current=profileAccess.mode==='account'?'The account save was not confirmed while sign-in was being checked. Keep this page open and retry after verification.':'The local save was interrupted while profiles changed. Return to this profile and retry.';setSaveError(saveFailure.current);}return;}
      if(!result.ok||!result.record){storageFailure(result.error||(profileAccess.mode==='account'?'This account save was not confirmed. Your current result is still on this page.':'This attempt could not be saved locally. Your current result is still on this page.'));return;}
      attempt.current=result.record;unsavedCheckpoint.current=false;
      if(result.record.state.ended&&!guest&&result.record.previewTrading!==true)setHistory(rows=>[result.record!,...rows.filter(row=>row.id!==result.record!.id)]);
    }catch{if(alive.current)storageFailure(profileAccess.mode==='account'?'This account save was not confirmed. Keep this page open and retry.':'This attempt could not be saved locally. Keep this page open and retry.');}
    finally {saveBusy.current=false;if(alive.current)setSaving(false);}
  }
  function commit(next:SimState) {if(profileAccess?.store&&attempt.current){const check=profileAccess.store.canCommit(attempt.current,next);if(!check.ok){setNotice(check.error||'This account action is unavailable.',true);return false;}}const completed=!current.current.ended&&next.ended;
    if(completed){
      // Reveal the finished historical chart without advancing the scored state or moving the viewport.
      if(viewport)setNavigation(nav=>({...nav,follow:false,offset:viewport.start,priceCenter:(viewport.lo+viewport.hi)/2,priceSpan:viewport.hi-viewport.lo}));
      reviewPending.current=next;setTradeReview(next);pause();clearQuickOrder();
    }else if(!next.ended){reviewPending.current=null;setTradeReview(null);}
    unsavedCheckpoint.current=!!profileAccess;current.current=next;setState(next);void saveCheckpoint(next);return true;}
  function retrySave() {if(!profileReady()||saveBusy.current)return;if(saveFailureKind.current==='read'&&profileAccess){const saved=loadHistory(profileAccess.profile,{guard:profileAccess.guard});if(!saved.ok){storageFailure(saved.error||'Saved history is still unavailable. Existing data was kept.','read');return;}setHistory(saved.completed);}if(attempt.current)void saveCheckpoint(current.current);else{saveFailure.current='';setSaveError('');setRetry(v=>v+1);}}
  useEffect(()=>{profileAccess?.registerHistory?.(openHistory);profileAccess?.registerNavigationGuard?.(()=>!reviewPending.current&&!saveBusy.current&&!unsavedCheckpoint.current&&pendingPreference.current===null);return()=>{profileAccess?.registerHistory?.(null);profileAccess?.registerNavigationGuard?.(null);};},[profileAccess]);
  const requestedHistory=useRef(false);
  useEffect(()=>{if(!combinedHost()&&!requestedHistory.current&&(chart||catalog.length>0)&&!loading&&!error&&!saving&&!saveError&&profileReady()&&typeof window!=='undefined'&&new URLSearchParams(window.location?.search||'').get('history')==='1'){requestedHistory.current=true;openHistory();}},[chart,catalog,loading,error,saving,saveError,profileAccess]);
  function openHistory() {if(reviewPending.current||!profileReady())return;if(combinedHost()){combinedHost().history();return;}suspendForProfile();if(profileAccess){const saved=loadHistory(profileAccess.profile,{guard:profileAccess.guard});if(saved.ok)setHistory(saved.completed);else storageFailure(saved.error||'Saved history could not be read safely. Existing data was kept.','read');}setHistoryOpen(true);}
  function closeHistory() {if(historyReplayLoad.current)suspendForProfile();setHistoryOpen(false);picker.current?.focus();}

  function historyReplayRecord(id:string) {
    if(!profileReady())return null;
    if(profileAccess){const saved=loadHistory(profileAccess.profile,{guard:profileAccess.guard});if(!saved.ok){storageFailure(saved.error||'Saved history could not be read safely. Existing data was kept.','read');return null;}return saved.completed.find((row:Attempt)=>row.id===id)||null;}
    return history.find(row=>row.id===id)||null;
  }
  function requestHistoryReplay(id:string,generation:number) {
    if(!mutationReady()||generation!==runGeneration.current||loading||dialogOpen.current)return;
    setHistoryReplayMessage('');suspendForProfile();
    const record=historyReplayRecord(id);if(!record)return;
    const reference=catalog.find(row=>row.id===record.sessionId&&row.sha256===record.sessionHash);
    if(!reference){setHistoryReplayMessage('This saved session’s exact chart is unavailable. Its original result and your current attempt were kept.',true);return;}
    if(chart&&!current.current.ended){dialogOpen.current=true;setConfirm({kind:'history',id:record.id,title:record.sessionTitle,generation:runGeneration.current});return;}
    void replayHistoryRecord(record.id,runGeneration.current);
  }
  async function replayHistoryRecord(id:string,generation:number) {
    if(!mutationReady()||generation!==runGeneration.current)return;
    const record=historyReplayRecord(id),reference=record&&catalog.find(row=>row.id===record.sessionId&&row.sha256===record.sessionHash);
    if(!record||!reference){setHistoryReplayMessage('This saved session’s exact chart is unavailable. Its original result and your current attempt were kept.',true);return;}
    const controller=new AbortController(),before=current.current,owner=attempt.current;
    historyReplayLoad.current=controller;pause();setLoading(true);setHistoryReplayMessage('Loading the saved session for a new attempt…');
    const valid=()=>alive.current&&!controller.signal.aborted&&historyReplayLoad.current===controller&&generation===runGeneration.current&&current.current===before&&attempt.current===owner&&profileReady();
    try {
      const source=await loadSimulatorChart(reference,{signal:controller.signal});if(!valid())return;
      const saved=historyReplayRecord(id);if(!saved||saved.sessionId!==record.sessionId||saved.sessionHash!==record.sessionHash||saved.revision!==record.revision)throw Error('The saved session changed while loading.');
      restore(saved,source,{sessionHash:reference.sha256});
      const fresh=profileAccess?newAttempt(profileAccess.profile,source,initialState(0,source.current[0]),{sessionHash:reference.sha256,previewTrading:readPreviewPreference(profileAccess.profile.learnerId)}):undefined;
      if(!valid())return;
      historyReplayLoad.current=null;restoreAttempt.current=null;loadedChart.current=source;
      if(source.id!==sessionId)installedHistoryChart.current=source;
      setChart(source);setSessionId(source.id);setChoice(source.id);setError('');setHistoryOpen(false);resetRun(source,fresh);setLoading(false);
      replayedChartFocus.current=true;setNotice('New replay started paused. The original completed result stays in history.');
    }catch{if(valid())setHistoryReplayMessage('The saved session could not be replayed safely. Its original result and your current attempt were kept.',true);}
    finally {if(historyReplayLoad.current===controller){historyReplayLoad.current=null;if(alive.current)setLoading(false);}}
  }

  function restoreCalendarFocusAfterCommit() {
    calendarFocusReturn.current?.cancel();
    const target=calendarFocus.current;if(!target)return;
    // A newer interaction owns focus, even if it happens before this close commits.
    const cancel=()=>{if(calendarFocusReturn.current===request)calendarFocusReturn.current=null;document.removeEventListener('pointerdown',cancel,true);document.removeEventListener('keydown',cancel,true);document.removeEventListener('focusin',cancel,true);};
    const request:CalendarFocusReturn={target,from:document.activeElement,token:calendarSequence.current,generation:runGeneration.current,owner:attempt.current,profile:profileAccess,cancel};
    calendarFocusReturn.current=request;
    document.addEventListener('pointerdown',cancel,true);document.addEventListener('keydown',cancel,true);document.addEventListener('focusin',cancel,true);
  }
  function openSessionPicker(generation:number,trigger?:HTMLElement) {
    if(!mutationReady()||generation!==runGeneration.current||loading||dialogOpen.current||!catalog.length)return;
    try {buildCalendar(catalog);}catch{pause();setSessionMessage('Session dates are unavailable or ambiguous. Your current attempt was kept.',true);return;}
    calendarFocus.current=trigger||picker.current;
    suspendForProfile();setSessionMessage('');
    const request={token:++calendarSequence.current,generation:runGeneration.current,initialId:sessionId};
    calendarRequest.current=request;dialogOpen.current=true;setCalendar(request);
  }
  function closeSessionPicker(token:number,restoreFocus=true) {
    if(calendarRequest.current?.token!==token)return;
    calendarRequest.current=null;dialogOpen.current=false;setCalendar(null);pause();
    if(restoreFocus)restoreCalendarFocusAfterCommit();
  }
  function selectCalendarSession(id:string,token:number) {
    const request=calendarRequest.current;
    if(!request||request.token!==token||request.generation!==runGeneration.current||!profileReady()||saveBusy.current||saveFailure.current||sessionLoad.current||historyReplayLoad.current)return;
    let reference:Reference|undefined;
    try {const model=buildCalendar(catalog);reference=catalog.find(row=>row.id===id);if(!reference||!model.entries.some((row:Reference)=>row.id===id))return;}catch{return;}
    closeSessionPicker(token,false);setChoice(id);
    if(chart&&!current.current.ended){dialogOpen.current=true;setConfirm({kind:'calendar',reference,id,title:reference.title,generation:runGeneration.current});return;}
    void loadCalendarSession(reference,runGeneration.current);
  }
  function cancelSessionConfirmation(generation:number) {
    if(!profileReady()||!dialogOpen.current||generation!==runGeneration.current)return;
    dialogOpen.current=false;setConfirm(null);restoreCalendarFocusAfterCommit();
  }
  function cancelSessionLoad(generation:number) {
    if(generation!==runGeneration.current||!sessionLoad.current)return;
    suspendForProfile();restoreCalendarFocusAfterCommit();
  }
  async function loadCalendarSession(reference:Reference,generation:number) {
    if(!mutationReady()||generation!==runGeneration.current)return;
    if(!catalog.some(row=>row.id===reference.id&&row.sha256===reference.sha256&&row.url===reference.url))return;
    const controller=new AbortController(),before=current.current,owner=attempt.current;
    sessionLoad.current=controller;pause();setLoading(true);setSessionLoading(true);setSessionMessage(chart?'Loading the selected session. Your current attempt is kept until it is ready…':'Loading the selected session…');
    const valid=()=>alive.current&&!controller.signal.aborted&&sessionLoad.current===controller&&generation===runGeneration.current&&current.current===before&&attempt.current===owner&&profileReady();
    try {
      const source=await loadSimulatorChart(reference,{signal:controller.signal});if(!valid())return;
      if(source.id!==reference.id||!Array.isArray(source.current)||source.current.length<2)throw Error('Chart identity mismatch');
      const fresh=profileAccess?newAttempt(profileAccess.profile,source,initialState(0,source.current[0]),{sessionHash:reference.sha256,previewTrading:readPreviewPreference(profileAccess.profile.learnerId)}):undefined;
      if(!valid())return;
      sessionLoad.current=null;restoreAttempt.current=null;loadedChart.current=source;
      if(source.id!==sessionId)installedHistoryChart.current=source;
      setChart(source);setSessionId(source.id);setChoice(source.id);setError('');setHistoryOpen(false);resetRun(source,fresh);setLoading(false);setSessionLoading(false);setSessionMessage('');replayedChartFocus.current=true;
      setNotice('New session started paused. Your completed results stay in history.');
    }catch{if(valid())setSessionMessage(chart?'The selected session could not be loaded safely. Your current attempt and saved history were kept. Pick a session to retry.':'The selected session could not be loaded safely. No attempt was started. Pick a session to retry.',true);}
    finally {if(sessionLoad.current===controller){sessionLoad.current=null;if(alive.current){setLoading(false);setSessionLoading(false);}}}
  }

  function cancelHistoryConfirmation(id:string,generation:number) {if(!profileReady()||!dialogOpen.current||generation!==runGeneration.current)return;dialogOpen.current=false;historyReplayFocus.current=id;setConfirm(null);}

  function pause() { playEpoch.current+=1;paused.current=true; if(timerRef.current!==null)clearTimeout(timerRef.current);timerRef.current=null;setPlaying(false); }
  function placeMode(value:'idle'|'armed'|'draft') {setPreview(null);placement.current=value;setMode(value);}
  function setCompact(value:boolean) {compact.current=value;setMinimized(value);}
  function clearDraft() {setCompact(false);placeMode('idle');setDraft({side:'buy',entry:'',stop:'',target:''});setEdited(false);}
  function resetRun(source:Chart,prepared?:Attempt) {
    const seed=!attempt.current?combinedHost()?.initialSession('limit'):null,index=seed?.id===source.id&&seed?.sha256===catalog.find(row=>row.id===source.id)?.sha256?Math.min(source.current.length-1,seed.index):0;const next=initialState(index,source.current[index]);let fresh=prepared;
    if(profileAccess&&!fresh){try {fresh=newAttempt(profileAccess.profile,source,next,{sessionHash:catalog.find(row=>row.id===source.id)?.sha256,previewTrading:readPreviewPreference(profileAccess.profile.learnerId)});}catch{storageFailure('A private local attempt ID could not be created. Enable secure browser storage and retry.');return;}}
    pause();clearQuickOrder();dialogOpen.current=false;runGeneration.current+=1;recoveryPress.current=null;
    if(fresh)attempt.current=fresh;
    commit(next);clearDraft();setNavigation(initialView());setNotice('Choose Buy or Sell, then tap the chart to set your entry.');drag.current=null;gesture.current=null;closePress.current=null;setDragging(false);setPriceDragging(false);
  }
  useEffect(()=>{
    const controller=new AbortController();setLoading(true);setError('');
    let saved:Attempt|null=null;
    if(profileAccess){const local=loadHistory(profileAccess.profile,{guard:profileAccess.guard});if(!local.ok){storageFailure(local.error||'Saved Trade history is unavailable. Existing data has not been changed.','read');setLoading(false);return()=>controller.abort();}saved=attempt.current?null:local.latest;setHistory(local.completed);}
    restoreAttempt.current=saved;
    loadSimulatorCatalog({signal:controller.signal}).then((items:Reference[])=>{if(controller.signal.aborted)return;if(!profileReady()){deferredLoad.current=true;return;}const requested=profileAccess?.store?.initialSession?.()||combinedHost()?.initialSession('limit');const selected=saved?items.find(row=>row.id===saved.sessionId&&(!saved.sessionHash||row.sha256===saved.sessionHash)):requested?items.find(row=>row.id===requested.id&&row.sha256===requested.sha256):attempt.current?items.find(row=>row.id===sessionId):null;if(!selected&&(saved||requested||attempt.current)){storageFailure('The saved attempt’s exact chart is unavailable. Its history and checkpoint were kept unchanged.','read');setLoading(false);return;}setCatalog(items);if(selected){entryPickerPending.current=false;entryPickerConsumed.current=true;setChoice(selected.id);setSessionId(selected.id);return;}setChoice('');setSessionId('');entryPickerPending.current=!entryPickerConsumed.current;setLoading(false);if(!items.length)setError('No historical sessions are available. Retry to check the catalog again.');}).catch(e=>{if(!controller.signal.aborted){setError(e.message);setLoading(false);}});
    return()=>controller.abort();
  },[retry]);
  useEffect(()=>{
    if(combinedHost()?.hasPendingReplay?.('limit')||!entryPickerPending.current||entryPickerConsumed.current||chart||attempt.current||loading||error||saveError||!catalog.length||!mutationReady())return;
    entryPickerPending.current=false;entryPickerConsumed.current=true;
    if(typeof window!=='undefined'&&new URLSearchParams(window.location?.search||'').get('history')==='1')return;
    openSessionPicker(runGeneration.current,picker.current||undefined);
  },[catalog,loading,error,saveError,chart,profileAccess,preferenceSaving,saving]);
  useEffect(()=>{
    const reference=catalog.find(s=>s.id===sessionId);if(!reference)return;
    if(installedHistoryChart.current?.id===reference.id&&loadedChart.current===installedHistoryChart.current){installedHistoryChart.current=null;return;}
    const controller=new AbortController();pause();setLoading(true);setError('');
    loadSimulatorChart(reference,{signal:controller.signal}).then(source=>{if(controller.signal.aborted)return;if(!profileReady()){deferredLoad.current=true;return;}const saved=restoreAttempt.current;loadedChart.current=source;setChart(source);if(saved){try{const restored=restore(saved,source,{sessionHash:reference.sha256});attempt.current=saved;unsavedCheckpoint.current=false;restoreAttempt.current=null;current.current=restored;setState(restored);clearDraft();const bracket=restored.position||restored.pending;if(bracket)setDraft(draftOf(bracket));setNavigation(initialView());setNotice(restored.ended?'Saved session restored. Slide the chart to review your points.':'Your saved attempt is paused. Press Play or Next candle to continue.');}catch{storageFailure('The saved attempt could not be restored safely. Its stored data has not been changed.','read');}}else resetRun(source);setLoading(false);}).catch(e=>{if(!controller.signal.aborted){setError(e.message);setLoading(false);}});
    return()=>controller.abort();
  },[sessionId,catalog]);
  useEffect(()=>{
    const element=host.current;if(!element)return;
    const resize=new ResizeObserver(entries=>{setWidth(Math.max(280,Math.round(entries[0].contentRect.width)));setHeight(Math.max(220,Math.round(entries[0].contentRect.height)));});resize.observe(element);return()=>resize.disconnect();
  },[]);
  useEffect(()=>{
    if(typeof window==='undefined'||!host.current)return;
    const fit=()=>{const element=host.current,panel=element?.closest('.simulator-chart-panel');if(!element||!panel)return;const box=element.getBoundingClientRect(),outer=panel.getBoundingClientRect(),tail=Math.max(0,outer.bottom-box.bottom),available=Math.max(260,Math.min(850,window.innerHeight-(box.top+window.scrollY)-tail-10));if(Math.abs(box.height-available)>1)element.style.height=`${Math.round(available)}px`;};
    const frame=window.requestAnimationFrame(fit);window.addEventListener('resize',fit);return()=>{window.cancelAnimationFrame(frame);window.removeEventListener('resize',fit);};
  },[width,loading,mode,state.ended,!!state.position]);
  useEffect(()=>{setPreview(null);clearQuickOrder();},[width,height,navigation]);
  useEffect(()=>{if(quickMenu)quickMenuElement.current?.querySelector<HTMLButtonElement>('button')?.focus({preventScroll:true});},[quickMenu]);
  useEffect(()=>{if(typeof window==='undefined')return;const clear=()=>{setPreview(null);clearQuickOrder();};window.addEventListener('scroll',clear,true);window.addEventListener('blur',clear);return()=>{window.removeEventListener('scroll',clear,true);window.removeEventListener('blur',clear);};},[]);
  useEffect(()=>{const onVisibility=()=>{if(document.hidden){pause();setPreview(null);clearQuickOrder();}};document.addEventListener('visibilitychange',onVisibility);return()=>{pause();document.removeEventListener('visibilitychange',onVisibility);};},[]);
  useEffect(()=>{if(!focusOrder.current)return;focusOrder.current=false;const target=svg.current?.querySelector?.<SVGGElement>(minimized?'.sim-compact-line':'.sim-order-handle:not(.locked)');if(target)target.focus();else svg.current?.focus?.();},[minimized]);
  useEffect(()=>{
    if(!playing||blocked||edited||dragging||mode!=='idle')return;
    const generation=runGeneration.current,epoch=playEpoch.current;
    const timer=setTimeout(()=>{if(timerRef.current!==timer||generation!==runGeneration.current||epoch!==playEpoch.current)return;timerRef.current=null;nextCandle(true);},speed);timerRef.current=timer;
    return()=>{if(timerRef.current===timer){clearTimeout(timer);timerRef.current=null;}};
  },[playing,speed,state.index,blocked,edited,dragging,mode]);
  function togglePlay() {if(!profileReady())return;if(!paused.current){pause();return;}if(!mutationReady()||quickOrder.current||blocked||edited||placement.current!=='idle'||drag.current||gesture.current||closePress.current)return;paused.current=false;setPlaying(true);}

  function nextCandle(automatic=false) {if(!mutationReady())return;
    if(automatic&&paused.current||quickOrder.current||current.current.ended||dialogOpen.current||blocked||edited||placement.current!=='idle'||drag.current||gesture.current||closePress.current||!chart)return;
    const before=current.current,index=before.index+1;if(index>=chart.current.length)return;
    let next=advanceCandle(before,chart.current[index],index);
    if(index===chart.current.length-1)next=finishSession(next,chart.current[index]);
    if(viewport&&!next.ended)setNavigation(nav=>advanceView(nav,viewport,chart,index));
    commit(next);
    if(next.ended||next.trades.length!==before.trades.length||(!before.position&&next.position)){pause();if(!next.pending&&!next.position)clearDraft();setNotice(next.ended?(previewTrading?'Preview complete. Review your entries and exits below.':'Session complete. Your points breakdown is below.'):next.trades.length!==before.trades.length?'Position closed. Review the result or place another bracket.':'Limit filled. Stop and target are now active.');}
  }
  function changeSide(side:'buy'|'sell') {if(!mutationReady())return;
    if(blocked||current.current.pending||current.current.position||drag.current||gesture.current||closePress.current||!chart)return;pause();clearQuickOrder();placeMode('armed');setEdited(false);const base=defaultBracket(chart.current[state.index],side) as Bracket,linked=equalMode.current?equalTargetFromStop(base,base.entry,current.current.tick):null;setDraft(draftOf(linked?.bracket||base));setNotice('Tap the chart to place your entry, stop and target. Then slide any line.');
  }
  function commitBracket(proposal:Bracket,expectedId:number|null) {if(!mutationReady())return false;
    pause();const existing=current.current.position||current.current.pending;
    if(blocked||expectedId!==null&&existing?.id!==expectedId||expectedId===null&&existing)return false;
    if(!existing&&equalMode.current){const linked=equalTargetFromStop(proposal,proposal.entry,current.current.tick);if(!linked){setNotice('An equal bracket could not be placed with this stop. Choose a valid entry and stop; no order was created.',true);return false;}proposal=linked.bracket;}
    const check=validatePracticeBracket(proposal,current.current.tick,current.current.position?.entryPrice??proposal.entry);
    if(!check.valid||!check.bracket){setNotice(`${check.error} The previous bracket is unchanged.`,true);return false;}
    if(existing&&existing.side===check.bracket.side&&KEYS.every(key=>existing[key]===check.bracket![key])){setDraft(draftOf(check.bracket));setEdited(false);return true;}
    try {const next=existing?editBracket(current.current,check.bracket):placeBracket(current.current,check.bracket);if(!commit(next))return false;setDraft(draftOf(check.bracket));setEdited(false);placeMode('idle');setNotice(`Bracket ${existing?'updated':'placed'}. Eligible from candle ${next.index+2}. Press Play or Next candle to continue.`);return true;}
    catch(error){setNotice(error instanceof Error?error.message:'The bracket could not be updated.',true);return false;}
  }
  function cancelPlacement() {if(!mutationReady())return;pause();clearQuickOrder();const pointerId=gesture.current?.pointerId;gesture.current=null;if(pointerId!==undefined&&svg.current?.hasPointerCapture(pointerId))svg.current.releasePointerCapture(pointerId);clearDraft();setNotice('Placement canceled. No order was created.');}
  function closeEntry(orderId:number,generation:number,positionOnly=false) {if(!mutationReady())return;
    pause();const existing=current.current.position||current.current.pending;
    if(generation!==runGeneration.current||blocked||(!positionOnly&&compact.current)||(positionOnly&&!current.current.position)||!existing||existing.id!==orderId||current.current.ended||drag.current||gesture.current||closePress.current)return;
    const open=!!current.current.position;
    try {if(!commit(open?closeOpenPosition(current.current):cancelPending(current.current)))return;clearDraft();setNotice(open?'Position closed at the latest revealed close. Both exits were removed.':'Unfilled bracket canceled. Both linked exits were removed.');}
    catch(error){setNotice(error instanceof Error?error.message:'The position could not be closed.',true);}
  }
  function orderDisplay(action:'minimize'|'expand',orderId:number,generation:number) {if(!profileReady())return;
    const existing=current.current.position||current.current.pending;
    if(generation!==runGeneration.current||blocked||!existing||existing.id!==orderId||current.current.ended||drag.current||gesture.current||closePress.current||compact.current!==(action==='expand'))return;
    pause();focusOrder.current=true;setCompact(action==='minimize');
    setNotice(action==='minimize'?'Bracket minimized. Tap any order line to edit. Press Play to resume.':'Order controls reopened. Slide a line to update it; press Play to resume.');
  }
  function orderControl(action:OrderControl,orderId:number,generation:number) {if(action==='close')closeEntry(orderId,generation);else orderDisplay(action,orderId,generation);}
  function controlDown(event:PointerEvent<SVGElement>,action:OrderControl,orderId:number,generation:number,key:Key='entry') {if(!profileReady())return;
    event.preventDefault();event.stopPropagation();
    if(event.button!==0)return;
    const existing=current.current.position||current.current.pending;
    if(generation!==runGeneration.current||blocked||!existing||existing.id!==orderId||compact.current!==(action==='expand')||drag.current||gesture.current||closePress.current||!displayedView||!svg.current)return;
    pause();
    const y=replayPoint(0,parsed[key],displayedView).y,rect=action==='expand'?{x:displayedView.left,y:y-22,width:displayedView.width-displayedView.left-displayedView.right,height:44}:action==='minimize'?entryMinimizeHandle(y,displayedView,orderYs):entryCloseHandle(y,displayedView,orderYs),box=svg.current.getBoundingClientRect();
    closePress.current={action,moved:false,pointerId:event.pointerId,orderId,generation,x:event.clientX,y:event.clientY,left:box.left+rect.x*box.width/displayedView.width,right:box.left+(rect.x+rect.width)*box.width/displayedView.width,top:box.top+rect.y*box.height/displayedView.height,bottom:box.top+(rect.y+rect.height)*box.height/displayedView.height};
    svg.current.setPointerCapture(event.pointerId);
  }
  function clearQuickOrder(restoreFocus=false) {quickOrder.current=null;setQuickMenu(null);if(restoreFocus)svg.current?.focus?.({preventScroll:true});}
  function openQuickOrder(event:MouseEvent<SVGSVGElement>) {
    if(event.defaultPrevented||event.ctrlKey||event.metaKey||event.altKey||event.shiftKey||!mutationReady()||blocked||current.current.ended||dialogOpen.current||current.current.pending||current.current.position||drag.current||gesture.current||closePress.current||!viewport||!svg.current)return;
    const box=svg.current.getBoundingClientRect(),candidate=placementPoint(event.clientX,event.clientY,box,viewport);if(!candidate)return;
    event.preventDefault();event.stopPropagation();pause();clearDraft();
    const menu:QuickOrder={token:++quickSequence.current,generation:runGeneration.current,index:current.current.index,price:candidate.price,left:Math.max(4,Math.min(event.clientX-box.left+10,box.width-180)),top:Math.max(4,Math.min(event.clientY-box.top+10,box.height-88))};
    quickOrder.current=menu;setQuickMenu(menu);
  }
  function chooseQuickOrder(side:'buy'|'sell',token:number) {
    const menu=quickOrder.current;if(!menu||menu.token!==token||menu.generation!==runGeneration.current||menu.index!==current.current.index||!mutationReady()||blocked||dialogOpen.current||current.current.ended||current.current.pending||current.current.position||drag.current||gesture.current||closePress.current||!chart)return;
    clearQuickOrder();pause();const base=defaultBracket(chart.current[current.current.index],side) as Bracket,delta=menu.price-base.entry;
    commitBracket({...base,entry:menu.price,stop:snapPrice(base.stop+delta),target:snapPrice(base.target+delta)},null);svg.current?.focus?.({preventScroll:true});
  }
  function quickMenuKeys(event:KeyboardEvent<HTMLDivElement>) {
    event.stopPropagation();if(keyBlocked(event)||isTyping(event.target))return;
    if(event.key==='Escape'){event.preventDefault();clearQuickOrder(true);return;}
    if(event.key==='Tab'){clearQuickOrder();return;}
    if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Home','End'].includes(directionKey(event.key))){event.preventDefault();const buttons=quickMenuElement.current?.querySelectorAll<HTMLButtonElement>('button');if(buttons?.length){const index=Array.from(buttons).indexOf(event.target as HTMLButtonElement),key=directionKey(event.key),next=key==='Home'?0:key==='End'?buttons.length-1:(index+(key==='ArrowLeft'||key==='ArrowUp'?-1:1)+buttons.length)%buttons.length;buttons[next].focus();}}
  }
  function finishNow(generation:number) {if(!mutationReady()||generation!==runGeneration.current||blocked||dialogOpen.current||current.current.ended||!chart)return;
    suspendForProfile();clearDraft();commit(finishSession(current.current));setNotice('Session finished at the last visible close. No hidden candle was used.');
  }
  function requestAction(kind:'reset'|'session',id?:string) {if(!mutationReady())return;pause();clearQuickOrder();setPreview(null);dialogOpen.current=true;runGeneration.current+=1;closePress.current=null;setConfirm({kind,id,generation:runGeneration.current});}
  function confirmAction() {if(!mutationReady(true))return;
    if(!confirm||!chart||!dialogOpen.current||confirm.generation!==runGeneration.current)return;
    if(confirm.kind==='calendar'){dialogOpen.current=false;setConfirm(null);if(confirm.reference)void loadCalendarSession(confirm.reference,confirm.generation);return;}
    if(confirm.kind==='history'){if(confirm.generation!==runGeneration.current)return;dialogOpen.current=false;setConfirm(null);void replayHistoryRecord(confirm.id!,confirm.generation);return;}
    if(confirm.kind==='session'){setSessionId(confirm.id!);setLoading(true);}
    else resetRun(chart);
    dialogOpen.current=false;setConfirm(null);
  }
  function startDrag(event:PointerEvent<SVGElement>,key:Key) {if(!mutationReady())return;
    if(blocked||compact.current||!showOrders||gesture.current||drag.current||closePress.current||event.button!==0||!displayedView||key==='entry'&&!!state.position)return;
    event.preventDefault();event.stopPropagation();pause();setNotice('');
    const existing=current.current.position||current.current.pending;if(!existing)return;
    const price=svg.current?priceFromClient(event.clientY,svg.current.getBoundingClientRect(),displayedView):null;
    drag.current={key,pointerId:event.pointerId,view:displayedView,before:draft,beforeEdited:edited,candidate:bracketOf(draft),orderId:existing.id,offset:Number.isFinite(price)?Number(price)-parsed[key]:0,equal:equalMode.current,basis:current.current.position?.entryPrice??existing.entry,adjusted:false};setDragging(true);
    svg.current?.setPointerCapture(event.pointerId);
  }
  function moveDrag(event:PointerEvent<SVGSVGElement>) {if(!profileReady())return;
    const move=drag.current;if(!move||move.pointerId!==event.pointerId||!svg.current||!Number.isFinite(event.clientY))return;
    const price=priceFromClient(event.clientY,svg.current.getBoundingClientRect(),move.view);
    if(price!==null){const wanted=snapPrice(Math.max(.25,price-move.offset));if(move.equal&&move.key!=='entry'){const linked=linkedExitEdit(move.candidate,move.key,wanted,move.basis,current.current.tick);if(!linked)return;move.candidate=linked.bracket;move.adjusted=linked.adjusted;}else move.candidate={...move.candidate,[move.key]:move.key==='entry'?wanted:practiceExitPrice(move.candidate.side,move.key,wanted,move.basis,current.current.tick)};setEdited(true);setDraft(draftOf(move.candidate));}
  }
  function endDrag(event:PointerEvent<SVGSVGElement>,cancel=false) {if(!profileReady())return;
    const move=drag.current;if(!move||event.pointerId!==move.pointerId)return;
    if(!cancel)moveDrag(event); // The release position wins, even without a final pointermove/render.
    drag.current=null;setDragging(false);
    const before=bracketOf(move.before),changed=KEYS.some(key=>move.candidate[key]!==before[key]);
    if(cancel||!changed){setDraft(move.before);setEdited(move.beforeEdited);if(cancel)setNotice('Line move canceled. The bracket is unchanged.');}
    else if(!commitBracket(move.candidate,move.orderId)){setDraft(move.before);setEdited(move.beforeEdited);}else if(move.equal&&move.adjusted)setNotice('Equal TP/SL updated. Distance was adjusted to the nearest valid quarter-tick so both exits stay beyond the planned entry. Press Play or Next candle to continue.');
    if(svg.current?.hasPointerCapture(event.pointerId))svg.current.releasePointerCapture(event.pointerId);
  }
  function keyMove(event:KeyboardEvent<SVGGElement>,key:Key) {if(!mutationReady())return;
    if(keyBlocked(event,true)||isTyping(event.target))return;
    const direction=directionKey(event.key);if(!['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(direction))return;
    event.preventDefault();event.stopPropagation();
    if(blocked||dialogOpen.current||compact.current||drag.current||gesture.current||closePress.current||key==='entry'&&!!current.current.position||!['ArrowUp','ArrowDown'].includes(direction))return;
    pause();const existing=current.current.position||current.current.pending;if(!existing)return;
    const wanted=snapPrice(existing[key]+(direction==='ArrowUp'?1:-1)*(event.shiftKey?1:.25));
    if(equalMode.current&&key!=='entry'){const linked=linkedExitEdit(existing,key,wanted,current.current.position?.entryPrice??existing.entry,current.current.tick);if(linked&&commitBracket(linked.bracket,existing.id)&&linked.adjusted)setNotice('Equal TP/SL updated. Distance was adjusted to the nearest valid quarter-tick so both exits stay beyond the planned entry. Press Play or Next candle to continue.');}
    else commitBracket({...existing,[key]:key==='entry'?wanted:practiceExitPrice(existing.side,key,wanted,current.current.position?.entryPrice??existing.entry,current.current.tick)},existing.id);
  }
  function replayKeys(event:KeyboardEvent) {if((event.target as Element)?.closest?.('[data-inline-chart-matcher]')||!profileReady()||quickOrder.current)return;
    if(keyBlocked(event)||isTyping(event.target)||host.current?.closest?.('main')?.querySelector?.('.app-nav-menu[open]'))return;
    const node=event.target as HTMLElement|null;if(node?.closest?.('a,nav,summary,form,[role="slider"],[role="button"],[role="dialog"],[data-trade-history]'))return;
    if(node?.closest?.('button')&&!node?.closest?.('.simulator-chart-panel'))return;
    if(directionKey(event.key)!=='ArrowRight')return;
    event.preventDefault();event.stopPropagation();if(event.repeat)return;
    pause();nextCandle();
  }
  function completedAction(action:'replay'|'random'|'choose',generation:number,trigger?:HTMLElement) {if(!mutationReady())return;
    if(generation!==runGeneration.current||!current.current.ended||loading||dialogOpen.current||drag.current||gesture.current||closePress.current||!chart)return;
    pause();setPreview(null);
    if(action==='choose'){openSessionPicker(generation,trigger);return;}
    if(action==='replay'){resetRun(chart);return;}
    const choices=catalog.filter(item=>item.id!==sessionId),next=choices[Math.floor(Math.random()*choices.length)];
    if(!next){resetRun(chart);return;}
    suspendForProfile();void loadCalendarSession(next,runGeneration.current);
  }
  function previewAt(event:PointerEvent<SVGElement>,view=viewport) {if(!profileReady())return;
    if(event.isPrimary===false)return;
    if(placement.current!=='armed'||blocked||!view||!svg.current){setPreview(null);return;}
    setPreview(placementPoint(event.clientX,event.clientY,svg.current.getBoundingClientRect(),view));
  }

  function navigate(action:'left'|'right'|'in'|'out'|'fit'|'follow'|'priceIn'|'priceOut') {if(reviewPending.current||!profileReady())return;
    if(!viewport||loading||error||confirm||dialogOpen.current||drag.current||gesture.current||closePress.current)return;pause();clearQuickOrder();setPreview(null);
    setNavigation(nav=>action==='follow'&&chart?focusLatest(nav,viewport,chart,displayIndex):action==='left'||action==='right'?panTime(nav,action,viewport):action==='in'||action==='out'?zoomTime(nav,action==='in'?1.3:1/1.3,viewport):action==='priceIn'||action==='priceOut'?dragView(nav,'price',0,action==='priceIn'?-35:35,viewport):resetViewAxis(nav,action));
  }
  function chartDown(event:PointerEvent<SVGElement>) {if(!profileReady())return;
    if(event.button===2){if(!event.ctrlKey&&!event.metaKey&&!event.altKey&&!event.shiftKey&&event.isPrimary!==false&&mutationReady()&&!blocked&&!current.current.ended&&!dialogOpen.current&&!current.current.pending&&!current.current.position&&!drag.current&&!gesture.current&&!closePress.current&&viewport&&svg.current&&placementPoint(event.clientX,event.clientY,svg.current.getBoundingClientRect(),viewport))pause();return;}
    if(loading||!!error||!!confirm||dialogOpen.current||!chart||drag.current||gesture.current||closePress.current||event.button!==0||event.isPrimary===false||!viewport||!svg.current||![event.clientX,event.clientY].every(Number.isFinite))return;
    clearQuickOrder();const r=svg.current.getBoundingClientRect();if(![r.left,r.top,r.width,r.height].every(Number.isFinite)||r.width<=0||r.height<=0)return;const x=(event.clientX-r.left)*viewport.width/r.width,y=(event.clientY-r.top)*viewport.height/r.height;
    if(x<viewport.left||x>viewport.width||y<0||y>viewport.height)return;
    const area=x>=viewport.width-viewport.right?'price':y>=viewport.height-viewport.bottom?'time':'plot';
    if(y<viewport.top&&area==='plot')return;pause();svg.current.focus?.({preventScroll:true});setPriceDragging(area==='price');
    gesture.current={pointerId:event.pointerId,x:event.clientX,y:event.clientY,view:viewport,nav:navigation,scaleX:viewport.width/r.width,scaleY:viewport.height/r.height,mode:placement.current==='armed'&&area==='plot'?'place':area,moved:false};
    if(gesture.current.mode==='place')previewAt(event);else setPreview(null);
    event.preventDefault();svg.current.setPointerCapture(event.pointerId);
  }
  function chartMove(event:PointerEvent<SVGSVGElement>) {if(!profileReady()||![event.clientX,event.clientY].every(Number.isFinite))return;
    if(closePress.current){const press=closePress.current;if(press.pointerId===event.pointerId&&Math.hypot(event.clientX-press.x,event.clientY-press.y)>=8)press.moved=true;return;}
    if(drag.current){moveDrag(event);return;}
    const g=gesture.current;if(!g){if(event.pointerType!=='touch')previewAt(event);return;}if(g.pointerId!==event.pointerId)return;
    if(g.mode==='place')previewAt(event,g.view);
    const dx=event.clientX-g.x,dy=event.clientY-g.y;if(!g.moved&&Math.hypot(dx,dy)<4)return;g.moved=true;setPreview(null);
    if(g.mode!=='place')setNavigation(dragView(g.nav,g.mode,dx*g.scaleX,dy*g.scaleY,g.view));
  }
  function chartUp(event:PointerEvent<SVGSVGElement>,cancel=false) {if(!profileReady())return;
    if(cancel&&(!gesture.current||gesture.current.pointerId===event.pointerId))setPreview(null);
    const close=closePress.current;
    if(close){event.preventDefault();event.stopPropagation();if(close.pointerId!==event.pointerId)return;closePress.current=null;const inside=event.clientX>=close.left&&event.clientX<=close.right&&event.clientY>=close.top&&event.clientY<=close.bottom;if(!cancel&&!close.moved&&inside&&Math.hypot(event.clientX-close.x,event.clientY-close.y)<8)orderControl(close.action,close.orderId,close.generation);if(svg.current?.hasPointerCapture(event.pointerId))svg.current.releasePointerCapture(event.pointerId);return;}
    if(drag.current){endDrag(event,cancel);return;}
    const g=gesture.current;if(!g||g.pointerId!==event.pointerId)return;
    setPreview(null);
    const moved=g.moved||Math.hypot(event.clientX-g.x,event.clientY-g.y)>=4;
    gesture.current=null;
    setPriceDragging(false);
    if(cancel||![event.clientX,event.clientY].every(Number.isFinite))setNavigation(g.nav);
    else if(g.mode!=='place'&&moved&&[event.clientX,event.clientY].every(Number.isFinite))setNavigation(dragView(g.nav,g.mode,(event.clientX-g.x)*g.scaleX,(event.clientY-g.y)*g.scaleY,g.view));
    else if(g.mode==='place'&&!moved&&svg.current&&chart){
      const candidate=placementPoint(event.clientX,event.clientY,svg.current.getBoundingClientRect(),g.view);
      if(candidate){const base=defaultBracket(chart.current[current.current.index],draft.side) as Bracket,entry=candidate.price,delta=entry-base.entry;commitBracket({...base,entry,stop:snapPrice(base.stop+delta),target:snapPrice(base.target+delta)},null);}

    }
    if(svg.current?.hasPointerCapture(event.pointerId))svg.current.releasePointerCapture(event.pointerId);
  }
  function recoverHidden(generation:number,index:number) {
    if(!profileReady()||generation!==runGeneration.current||index!==current.current.index||loading||error||confirm||dialogOpen.current||!chart||!viewport||drag.current||gesture.current||closePress.current)return;
    const target=hiddenRevealed(chart,displayIndex,viewport);if(!target)return;
    pause();clearQuickOrder();setPreview(null);setNavigation(nav=>focusHidden(nav,viewport,target,chart,displayIndex));svg.current?.focus?.({preventScroll:true});
  }
  function resetPriceAxis() {if(!profileReady()||loading||error||confirm||dialogOpen.current||!viewport||drag.current||gesture.current||closePress.current)return;pause();clearQuickOrder();setPreview(null);setNavigation(nav=>resetViewAxis(nav,'price'));}
  function axisDown(event:PointerEvent<SVGGElement>) {event.stopPropagation();chartDown(event);if(gesture.current?.pointerId===event.pointerId&&gesture.current.mode==='price')event.currentTarget.focus?.({preventScroll:true});}
  function axisKeys(event:KeyboardEvent<SVGGElement>) {
    if(keyBlocked(event,true)||isTyping(event.target))return;
    const key=directionKey(event.key);if(!['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Home','Enter',' '].includes(key))return;
    event.preventDefault();event.stopPropagation();if(event.repeat&&['Home','Enter',' '].includes(key))return;
    if(key==='ArrowUp'||key==='ArrowDown')navigate(key==='ArrowUp'?'priceIn':'priceOut');
    else if(['Home','Enter',' '].includes(key))resetPriceAxis();
  }
  function chartKeys(event:KeyboardEvent<SVGSVGElement>) {if(!profileReady())return;
    if(event.target!==event.currentTarget||keyBlocked(event,false,true)||isTyping(event.target))return;
    const key=directionKey(event.key);if(key==='ArrowRight'){if(current.current.ended){event.preventDefault();event.stopPropagation();navigate('right');}else replayKeys(event);return;}
    const action=key==='ArrowLeft'?'left':event.key==='+'||event.key==='='?'in':event.key==='-'?'out':event.key==='Home'?'fit':null;
    if(action){event.preventDefault();event.stopPropagation();navigate(action);}
  }

  return <><main inert={!!calendar||!!tradeReview} className="simulator-shell" onKeyDown={replayKeys} onPointerDownCapture={event=>{if(quickOrder.current&&!(event.target as Element)?.closest?.('[data-quick-order-menu]'))clearQuickOrder();}}>
    <AppHeader section="TRADE SIMULATOR · LIMIT ORDERS" current="/market-direction">{profileAccess&&<button className={`quiet-button${headerVerified?' simulator-account-profile':''}`} data-learner-profile-control="true" disabled={saving} aria-haspopup="dialog" onClick={()=>{if(!reviewPending.current&&!saveBusy.current)profileAccess.choose();}} title={accountHeader&&!headerVerified?'Checking learner account':`View learner profile: ${profileAccess.profile.name}`}>{headerVerified?<><span className="simulator-profile-avatar" aria-hidden="true" data-initials={profileInitials(profileAccess.profile.name)}>{accountHeader!.avatarUrl&&failedHeaderAvatar!==displayedHeaderAvatar?<img key={headerAvatarKey} src={accountHeader!.avatarUrl} width={28} height={28} alt="" referrerPolicy="no-referrer" decoding="async" onError={()=>{if(alive.current&&headerAvatar.current===displayedHeaderAvatar&&accountHeader!.isCurrent())setFailedHeaderAvatar(displayedHeaderAvatar);}}/>:null}</span><span className="simulator-profile-name">{profileAccess.profile.name}</span></>:accountHeader?<LoadingIndicator label="Checking…" size="small" />:profileAccess.profile.name}</button>}</AppHeader><h1 className="visually-hidden">Trade Simulator: limit orders</h1>
    <div className="simulator-session"><button ref={picker} type="button" className="quiet-button" data-session-picker="true" aria-haspopup="dialog" disabled={loading||!!confirm||!!calendar||saving||!!saveError||!catalog.length} onClick={event=>openSessionPicker(renderGeneration,event?.currentTarget)}>Pick a session</button><span className="simulator-selected-session">{chart?.title||'Historical chart sessions'}</span>{profileAccess&&<span className="simulator-save-status" role="status">{previewTrading?'Preview · not scored or saved':saving?<LoadingIndicator label="Saving…" size="small" />:saveError?'Not saved':guest?'Guest · not saved':online?'Account · completed attempts saved':'Local autosave'}</span>}<p>{previewTrading?'Full-session preview is on. This attempt is not kept. Changing preview mode applies to your next new session.':guest?'Guests will not be able to track their history + skill progress':online?'Completed attempts sync to your account. An unfinished attempt stays only on this page.':'Completed results and your latest paused attempt stay in this browser under your learner profile.'}</p></div>
    {sessionMessage&&<div className={sessionWarning?"notice warning":"notice"} style={sessionWarning?WARNING_STYLE:undefined} data-session-load-status="true" data-warning={sessionWarning||undefined} role={sessionWarning?"alert":"status"}>{sessionLoading?<LoadingIndicator label={sessionMessage} />:sessionMessage}{sessionLoading&&<button className="quiet-button" onClick={()=>cancelSessionLoad(renderGeneration)}>Cancel loading</button>}</div>}
    {saveError&&<div className="notice warning" style={WARNING_STYLE} role="alert" data-trade-save-error="true">{saveError} The current attempt is not confirmed saved. Retry before leaving; reloading restores only saved data. <button className="quiet-button" disabled={saving} onClick={retrySave}>Retry save</button></div>}
    {error&&<div className="notice warning" style={WARNING_STYLE} role="alert">{error} <button className="quiet-button" onClick={()=>{if(profileReady())setRetry(v=>v+1);}}>Try again</button></div>}
    {confirm&&<section className="simulator-confirm" aria-label="Confirm session action" onKeyDown={event=>{if((confirm.kind==='history'||confirm.kind==='calendar')&&event.key==='Escape'){event.preventDefault();event.stopPropagation();if(confirm.kind==='history')cancelHistoryConfirmation(confirm.id!,confirm.generation!);else cancelSessionConfirmation(confirm.generation);}}}><h2>Clear this attempt?</h2><p>{state.ended?(confirm.kind==='history'?`Replay ${confirm.title} as a new attempt? Its original completed result stays saved.`:confirm.kind==='calendar'?`Start ${confirm.title} as a new attempt? Completed history stays saved.`:'Start a new attempt? Completed history stays saved.'):'If you leave this session it will not be recorded in your history.'}</p><button className="primary-button" onClick={confirmAction}>OK</button><button className="quiet-button" autoFocus onClick={()=>{if(!profileReady()||confirm.generation!==runGeneration.current)return;if(confirm.kind==='history'){cancelHistoryConfirmation(confirm.id!,confirm.generation!);return;}if(confirm.kind==='calendar'){cancelSessionConfirmation(confirm.generation);return;}if(!profileReady())return;dialogOpen.current=false;setConfirm(null);}}>Cancel</button></section>}
    <div className="simulator-workspace">
      <section className="simulator-chart-panel" aria-label="Replay chart">
        <div className="simulator-chart-heading"><div><span className={`sim-status ${state.position?'is-open':''}`}>{loading?<LoadingIndicator label="Loading chart…" size="small" />:state.ended?'SESSION COMPLETE':state.position?`${state.position.side==='buy'?'LONG':'SHORT'} OPEN`:state.pending?'BRACKET WAITING':'NO ACTIVE ORDER'}</span><p>{chart?.title||'Historical chart sessions'}</p>{chartSourceNotice(chart)&&<p data-session-source>{chartSourceNotice(chart)}</p>}</div><div className="simulator-candle-count">Candle <strong>{chart?state.index+1:'—'}</strong> / {chart?.current.length||'—'}<small>{previewTrading?'Preview · results not scored':'Only revealed candles are scored'}</small></div></div>
        <div className="simulator-trade-bar"><button className="sim-buy" aria-pressed={mode!=='idle'&&draft.side==='buy'} disabled={blocked||!!active} onClick={()=>changeSide('buy')}>Buy limit</button><button className="sim-sell" aria-pressed={mode!=='idle'&&draft.side==='sell'} disabled={blocked||!!active} onClick={()=>changeSide('sell')}>Sell limit</button><span role="status">{state.ended?'Session complete · Review your trades, then choose your next practice':mode==='armed'?'Tap the chart to set your entry':active?minimized?'Tap any order line to edit':'Slide to update · ✓ minimizes · × closes':'Choose Buy or Sell, then tap the chart'}</span>{mode==='armed'&&<button className="quiet-button" onClick={cancelPlacement}>Cancel placement</button>}</div>
        {active&&displayMetrics&&<p className="simulator-profitable simulator-bracket-threshold" role="status">Your risk/reward requires {displayMetrics.requiredWinRate.toFixed(1)}% win rate</p>}
        <div className={`simulator-chart ${mode==='armed'?'is-placing':''} ${preview?'has-placement-preview':''} ${priceDragging?'is-price-dragging':''}`} ref={host}>
          {chart&&!loading&&!error&&<MobileSessionOverview key={chart.id} candles={chart.current} revealed={state.index+1} preview={previewTrading} ema20={overviewIndicators.ema} ema10={overviewIndicators.ema10}/>} 
          {!chart&&!loading&&!error&&<div className="simulator-empty-session"><p>Pick a session to begin.</p><button type="button" className="quiet-button" disabled={!!confirm||!!calendar||saving||!!saveError||!catalog.length} onClick={event=>openSessionPicker(renderGeneration,event.currentTarget)}>Pick a session</button></div>}
          {chart&&displayedView&&<svg ref={svg} preserveAspectRatio="none" viewBox={`0 0 ${displayedView.width} ${displayedView.height}`} role="group" aria-label="Candle chart with draggable entry, stop and target lines" tabIndex={0} onKeyDown={chartKeys} onContextMenu={openQuickOrder} onPointerDown={chartDown} onPointerMove={chartMove} onPointerLeave={()=>setPreview(null)} onPointerUp={e=>chartUp(e)} onPointerCancel={e=>chartUp(e,true)} onLostPointerCapture={e=>chartUp(e,true)}>

            <defs><clipPath id="simulator-plot"><rect x={displayedView.left} y={displayedView.top} width={displayedView.width-displayedView.left-displayedView.right} height={displayedView.height-displayedView.top-displayedView.bottom}/></clipPath></defs>
            {Array.from({length:6},(_,i)=>{const price=displayedView.lo+(displayedView.hi-displayedView.lo)*i/5,y=replayPoint(0,price,displayedView).y;return <g key={i}><line x1={displayedView.left} x2={displayedView.width-displayedView.right} y1={y} y2={y} stroke="var(--appearance-line-203248, #203248)"/><text x={displayedView.width-7} y={y+4} textAnchor="end" fill="var(--appearance-ink-8ea8be, #8ea8be)" fontSize="11">{format(price)}</text></g>;})}
            <g clipPath="url(#simulator-plot)" data-layer="visible-candles">{displayedView.visible.map(c=>{const o=replayPoint(c.slot,c.o,displayedView),h=replayPoint(c.slot,c.h,displayedView),l=replayPoint(c.slot,c.l,displayedView),close=replayPoint(c.slot,c.c,displayedView),color=c.c>=c.o?'var(--appearance-ink-67dfb3, #67dfb3)':'var(--appearance-ink-f18da6, #f18da6)',w=Math.max(.7,displayedView.step*.56);return <g key={c.slot} opacity={c.prior ? .78 : 1} data-prior={c.prior}><rect x={o.x-displayedView.step/2} y={displayedView.top} width={displayedView.step} height={displayedView.height-displayedView.top-displayedView.bottom} fill={c.prior?'var(--appearance-surface-23304066, #23304066)':'transparent'}/><line x1={h.x} x2={h.x} y1={h.y} y2={l.y} stroke={color} strokeWidth={Math.min(1.4,Math.max(.6,displayedView.step*.3))}/><rect x={o.x-w/2} y={Math.min(o.y,close.y)} width={w} height={Math.max(1,Math.abs(o.y-close.y))} fill={color}/><title>{`${c.prior?'Prior context':'Candle '+(c.index+1)} · ${c.t} · O ${c.o} H ${c.h} L ${c.l} C ${c.c}`}</title>{!c.prior&&<text x={o.x} y={Math.max(displayedView.top+10,h.y-7)} textAnchor="middle" fontSize={Math.max(7,Math.min(10,displayedView.step/1.35))} fill="var(--appearance-ink-a2b0c1, #a2b0c1)">{c.index+1}</text>}</g>;})}
              {showEma&&displayedView.visibleEma10.length>0&&<path data-indicator="ema10" d={displayedView.visibleEma10.map((point,index,all)=>{const p=replayPoint(point.slot,point.value,displayedView);return `${index&&all[index-1].slot===point.slot-1?'L':'M'} ${p.x} ${p.y}`;}).join(' ')} fill="none" stroke="var(--appearance-ink-f6c760, #f6c760)" strokeWidth=".7" opacity=".3" vectorEffect="non-scaling-stroke" pointerEvents="none"/>}
              {showEma&&displayedView.visibleEma.length>1&&<path data-indicator="ema20" d={displayedView.visibleEma.map((point,index)=>{const p=replayPoint(point.slot,point.value,displayedView);return `${index?'L':'M'} ${p.x} ${p.y}`;}).join(' ')} fill="none" stroke="var(--appearance-ink-f6c760, #f6c760)" strokeWidth="2" pointerEvents="none"/>}
              {showEma&&displayedView.visibleEma.length===1&&<circle data-indicator="ema20" cx={replayPoint(displayedView.visibleEma[0].slot,displayedView.visibleEma[0].value,displayedView).x} cy={replayPoint(displayedView.visibleEma[0].slot,displayedView.visibleEma[0].value,displayedView).y} r="3" fill="var(--appearance-ink-f6c760, #f6c760)"/>}
              {displayedView.priorClose!==null&&<g pointerEvents="none"><line x1={displayedView.left} x2={displayedView.width-displayedView.right} y1={replayPoint(0,displayedView.priorClose,displayedView).y} y2={replayPoint(0,displayedView.priorClose,displayedView).y} stroke="var(--appearance-ink-e4cc95, #e4cc95)" strokeWidth="1.25" strokeDasharray="5 5"/><text x={displayedView.left+4} y={Math.max(displayedView.top+12,replayPoint(0,displayedView.priorClose,displayedView).y-5)} fill="var(--appearance-ink-e4cc95, #e4cc95)" fontSize="10">Prior close {format(displayedView.priorClose)}</text></g>}
              {!state.ended&&state.trades.flatMap(t=>[{key:`${t.id}-in`,index:t.entryIndex,price:t.entryPrice,color:'var(--appearance-ink-8ac7ff, #8ac7ff)',text:'Entry'},{key:`${t.id}-out`,index:t.exitIndex,price:t.exitPrice,color:t.points>=0?'var(--appearance-ink-9ee5bc, #9ee5bc)':'var(--appearance-ink-ff9aa9, #ff9aa9)',text:'Exit'}]).map(p=>{const point=replayPoint(displayedView.priorCount+p.index,p.price,displayedView);return <circle key={p.key} cx={point.x} cy={point.y} r="4" fill={p.color} stroke="var(--appearance-line-0b1421, #0b1421)"><title>{`${p.text} · ${format(p.price)}`}</title></circle>;})}
              {reviewMarks.map(mark=><g key={`review-${mark.id}`} data-trade-points={mark.id} data-trade-id={mark.id} data-entry-index={mark.entryIndex} data-exit-index={mark.exitIndex} data-entry-price={mark.entryPrice} data-exit-price={mark.exitPrice} data-points={previewTrading?undefined:mark.points} pointerEvents="none" aria-hidden="true"><line x1={mark.entry.x} y1={mark.entry.y} x2={mark.exit.x} y2={mark.exit.y} stroke={mark.points<0?'var(--appearance-ink-ff9aa9, #ff9aa9)':'var(--appearance-ink-9ee5bc, #9ee5bc)'} strokeWidth="1.5" strokeDasharray="4 3" opacity=".75"/><circle cx={mark.entry.x} cy={mark.entry.y} r="4" fill="var(--appearance-ink-8ac7ff, #8ac7ff)" stroke="var(--appearance-line-0b1421, #0b1421)"/><circle cx={mark.exit.x} cy={mark.exit.y} r="4" fill={mark.points<0?'var(--appearance-ink-ff9aa9, #ff9aa9)':'var(--appearance-ink-9ee5bc, #9ee5bc)'} stroke="var(--appearance-line-0b1421, #0b1421)"/><line x1={mark.exit.x} y1={mark.exit.y} x2={mark.label.x+mark.label.width/2} y2={mark.label.y+mark.label.height} stroke={mark.points<0?'var(--appearance-ink-ff9aa9, #ff9aa9)':'var(--appearance-ink-9ee5bc, #9ee5bc)'} opacity=".6"/><rect {...mark.label} rx="4" fill={mark.points<0?'var(--appearance-ink-432733, #432733)':'var(--appearance-surface-1b3d32, #1b3d32)'} stroke={mark.points<0?'var(--appearance-ink-d78191, #d78191)':'var(--appearance-ink-75b49a, #75b49a)'}/><text x={mark.label.x+mark.label.width/2} y={mark.label.y+15} fill={mark.points<0?'var(--appearance-ink-ffc3cf, #ffc3cf)':'var(--appearance-ink-bcf6d8, #bcf6d8)'} textAnchor="middle" fontSize={Math.min(11,(mark.label.width-8)/(mark.text.length*.61))} fontWeight="700">{previewTrading?'Entry → Exit':mark.text}</text></g>)}
            </g>
            {(()=>{const x=displayedView.left+(displayedView.priorCount-displayedView.start)*displayedView.step;return x>=displayedView.left&&x<displayedView.width-displayedView.right?<g pointerEvents="none"><line x1={x} x2={x} y1={displayedView.top} y2={displayedView.height-displayedView.bottom} stroke="var(--appearance-ink-b6c8e0, #b6c8e0)" strokeDasharray="4 4"/><text x={x+5} y={displayedView.top-9} fill="var(--appearance-ink-c5d8f0, #c5d8f0)" fontSize="11">Day open · 08:30</text>{x-displayedView.left>70&&<text x={displayedView.left} y={displayedView.top-9} fill="var(--appearance-ink-91a0b3, #91a0b3)" fontSize="11">Prior RTH</text>}</g>:null;})()}
            {displayedView.visible.filter((c,i)=>i===0||!c.prior&&c.index%Math.max(6,Math.ceil(48/displayedView.step/6)*6)===0).map(c=><text key={c.slot} x={replayPoint(c.slot,0,displayedView).x} y={displayedView.height-17} fill={c.prior?'var(--appearance-ink-758496, #758496)':'var(--appearance-ink-90a2b9, #90a2b9)'} fontSize="10" textAnchor="middle">{c.t?.slice(-5)}</text>)}
            {displayedView.count-displayedView.visible.length>(displayedView.rightPadding||0)&&<text x={Math.min(displayedView.width-displayedView.right-75,displayedView.left+displayedView.visible.length*displayedView.step+10)} y={displayedView.top+24} fill="var(--appearance-ink-7b8fa7, #7b8fa7)" fontSize="11">{state.ended?'Session end':'Unrevealed'}</text>}
            {mode==='armed'&&preview&&<g data-placement-preview="true" pointerEvents="none" aria-hidden="true"><line x1={preview.x} x2={preview.right} y1={preview.y} y2={preview.y} stroke="var(--appearance-ink-aab2bc, #aab2bc)" strokeWidth="1" opacity=".55"/><path d={`M ${preview.x} ${preview.y} l 10 -8 v 4 h 13 v 8 h -13 v 4 Z`} fill="var(--appearance-ink-d5dce5, #d5dce5)" stroke="var(--appearance-line-091321, #091321)" strokeWidth="1"/><rect {...preview.label} rx="4" fill="var(--appearance-surface-26323f, #26323f)" stroke="var(--appearance-ink-778391, #778391)"/><text x={preview.label.x+preview.label.width/2} y={preview.label.y+15} textAnchor="middle" fill="var(--appearance-ink-edf2f7, #edf2f7)" fontSize={Math.min(11,(preview.label.width-10)/(format(preview.price).length*.61))}>{format(preview.price)}</text></g>}
            {!state.ended&&active&&minimized&&KEYS.filter(k=>Number.isFinite(parsed[k])).map(key=>{const y=replayPoint(0,parsed[key],displayedView).y,id=active.id,generation=runGeneration.current,label=`Edit ${LABELS[key].toLowerCase()} line at ${format(parsed[key])}${distanceDetail(key)}`;return <g key={key} className="sim-compact-line" role="button" tabIndex={blocked?-1:0} aria-label={label} aria-disabled={blocked} clipPath="url(#simulator-plot)" onPointerDown={event=>controlDown(event,'expand',id,generation,key)} onClick={event=>{event.preventDefault();event.stopPropagation();if(event.detail===0)orderDisplay('expand',id,generation);}} onKeyDown={event=>{event.stopPropagation();if(event.key==='Enter'||event.key===' '){event.preventDefault();orderDisplay('expand',id,generation);}}}><line className="sim-order-visible" x1={displayedView.left} x2={displayedView.width-displayedView.right} y1={y} y2={y} stroke={COLORS[key]} opacity=".8" pointerEvents="none"/><line x1={displayedView.left} x2={displayedView.width-displayedView.right} y1={y} y2={y} stroke="transparent" strokeWidth="44"/><title>{label}</title></g>;})}
            {!state.ended&&showOrders&&!minimized&&KEYS.filter(k=>Number.isFinite(parsed[k])).map(key=>{const y=replayPoint(0,parsed[key],displayedView).y;return <g key={key}><line x1={displayedView.left} x2={displayedView.width-displayedView.right} y1={y} y2={y} stroke={COLORS[key]} strokeDasharray={!active||edited?'5 5':undefined} opacity=".8" pointerEvents="none"/><line className="sim-order-line-hit" x1={displayedView.left} x2={displayedView.width-displayedView.right} y1={y} y2={y} stroke="transparent" strokeWidth="18" onPointerDown={e=>startDrag(e,key)} /></g>;})}
            {!state.ended&&showOrders&&!minimized&&KEYS.filter(k=>Number.isFinite(parsed[k])).map(key=>{const y=replayPoint(0,parsed[key],displayedView).y,handle=orderHandle(key,y,displayedView,orderYs),tag=orderTag(key,y,displayedView,orderYs),locked=key==='entry'&&!!state.position,labelValue=key==='entry'?format(parsed[key]):`${distanceText(distanceOf(key)!)} pts`;return <g key={key} className={`sim-order-handle ${locked?'locked':''}`} data-order-distance={distanceOf(key)??undefined} data-distance-basis={key==='entry'?undefined:state.position?'actual':'planned'} role="slider" tabIndex={blocked||locked?-1:0} aria-label={`${LABELS[key]} price${locked?' (locked after fill)':''}`} aria-valuemin={.25} aria-valuemax={1e9} aria-valuenow={parsed[key]} aria-valuetext={`${format(parsed[key])}${distanceDetail(key)}${locked?', locked':''}`} aria-disabled={blocked||locked} onPointerDown={e=>startDrag(e,key)} onKeyDown={e=>keyMove(e,key)}><title>{`${LABELS[key]} ${format(parsed[key])}${distanceDetail(key)}`}</title><line x1={key==='entry'?tag.x+tag.width:tag.x} x2={key==='entry'?tag.x+tag.width:tag.x} y1={y} y2={tag.y+tag.height/2} stroke={COLORS[key]} opacity=".55" pointerEvents="none"/><rect {...handle} className="sim-order-touch-target" fill="transparent"/><rect {...tag} className="sim-order-tag" rx="5" fill="var(--appearance-surface-122439, #122439)" stroke={COLORS[key]} pointerEvents="none"/><text x={tag.x+4} y={tag.y+11} fill={COLORS[key]} fontSize={key==='entry'?(tag.width<60?7:8):9} fontWeight="700" pointerEvents="none">{key!=='entry'?LABELS[key]:locked?'LOCKED':'ENTRY ↕'}</text><text x={tag.x+4} y={tag.y+25} fill="var(--appearance-ink-f1f6fc, #f1f6fc)" fontSize={Math.min(11,(tag.width-8)/(labelValue.length*.61))} fontWeight={key==='entry'?undefined:700} pointerEvents="none">{labelValue}</text></g>;})}
            {!state.ended&&active&&!minimized&&Number.isFinite(parsed.entry)&&(['minimize','close'] as const).map(action=>{const y=replayPoint(0,parsed.entry,displayedView).y,box=action==='minimize'?entryMinimizeHandle(y,displayedView,orderYs):entryCloseHandle(y,displayedView,orderYs),label=action==='minimize'?'Minimize order controls':state.position?'Close simulated position at latest revealed close':'Cancel pending bracket',id=active.id,generation=runGeneration.current;return <g key={action} className={action==='minimize'?'sim-entry-minimize':'sim-entry-close'} role="button" tabIndex={blocked?-1:0} aria-label={label} aria-disabled={blocked} onPointerDown={event=>controlDown(event,action,id,generation)} onClick={event=>{event.preventDefault();event.stopPropagation();if(event.detail===0)orderControl(action,id,generation);}} onKeyDown={event=>{event.stopPropagation();if(event.key==='Enter'||event.key===' '){event.preventDefault();orderControl(action,id,generation);}}}><rect {...box} rx="7" fill="var(--appearance-surface-14283c, #14283c)" stroke={action==='minimize'?'var(--appearance-ink-9ee5bc, #9ee5bc)':'var(--appearance-ink-8ac7ff, #8ac7ff)'}/><text x={box.x+22} y={box.y+29} textAnchor="middle" fill="var(--appearance-ink-eaf5ff, #eaf5ff)" fontSize={action==='minimize'?22:27} pointerEvents="none">{action==='minimize'?'✓':'×'}</text><title>{label}</title></g>;})}

            <g className="sim-price-axis" data-price-axis="true" role="slider" aria-label="Vertical price scale" aria-orientation="vertical" aria-valuemin={.25} aria-valuemax={8} aria-valuenow={navigation.yZoom} aria-valuetext={`${Math.round(navigation.yZoom*100)}% scale; visible prices ${format(displayedView.lo)} to ${format(displayedView.hi)}`} aria-disabled={loading||!!error||!!confirm} tabIndex={loading||!!error||!!confirm?-1:0} onPointerDown={axisDown} onKeyDown={axisKeys} onDoubleClick={event=>{event.preventDefault();event.stopPropagation();resetPriceAxis();}}>
              <rect {...priceAxisHandle(displayedView)} className="sim-price-axis-hit" fill="var(--appearance-surface-24415c, #24415c)" fillOpacity=".28" pointerEvents="all"/>
              <line x1={displayedView.width-displayedView.right} x2={displayedView.width-displayedView.right} y1="0" y2={displayedView.height} stroke="var(--appearance-ink-44627d, #44627d)" strokeOpacity=".7" pointerEvents="none"/>
              <text x={displayedView.width-displayedView.right/2} y="18" textAnchor="middle" fill="var(--appearance-ink-d1e6f8, #d1e6f8)" fontSize="10" fontWeight="700" pointerEvents="none" aria-hidden="true">↕ DRAG</text><path d={`M ${displayedView.width-displayedView.right+6} ${displayedView.height/2-16} v 32 m -3 -27 l 3 -5 3 5 m -6 22 l 3 5 3 -5`} fill="none" stroke="var(--appearance-ink-a5c8e4, #a5c8e4)" strokeWidth="1.5" pointerEvents="none" aria-hidden="true"/>
              <title>Drag the price axis up or down to resize candles. Up/W and Down/S also resize; double-click or Home resets this scale.</title>
            </g>
          </svg>}
          {quickMenu&&<div ref={quickMenuElement} className="sim-quick-order-menu" data-quick-order-menu="true" data-quick-order-price={quickMenu.price} role="menu" aria-label={`Place limit bracket at ${format(quickMenu.price)}`} style={{left:quickMenu.left,top:quickMenu.top}} onKeyDown={quickMenuKeys} onPointerDown={event=>{event.stopPropagation();pause();}} onPointerUp={event=>event.stopPropagation()} onClick={event=>event.stopPropagation()} onContextMenu={event=>{event.preventDefault();event.stopPropagation();}}><p>{format(quickMenu.price)}</p><div><button type="button" role="menuitem" data-quick-order-side="buy" onClick={()=>chooseQuickOrder('buy',quickMenu.token)}>Buy</button><button type="button" role="menuitem" data-quick-order-side="sell" onClick={()=>chooseQuickOrder('sell',quickMenu.token)}>Sell</button></div></div>}
          {chart&&displayedView&&hiddenCandles&&<button type="button" role="button" className="sim-hidden-candles" data-hidden-candle="true" data-hidden-direction={hiddenCandles.direction} data-hidden-target={hiddenCandles.targetSlot} data-hidden-target-index={hiddenCandles.targetIndex} data-hidden-prior={hiddenCandles.prior} data-hidden-latest={hiddenCandles.latest} aria-label={hiddenCandles.label} title={hiddenCandles.label} disabled={loading||!!error||!!confirm} style={{right:`${(displayedView.right+4)/displayedView.width*100}%`}} onPointerDown={event=>{event.stopPropagation();recoveryPress.current=null;if(!profileReady()||event.button!==0||event.isPrimary===false||drag.current||gesture.current||closePress.current)return;pause();setPreview(null);const box=event.currentTarget.getBoundingClientRect();if(![box.left,box.right,box.top,box.bottom,event.clientX,event.clientY].every(Number.isFinite)||box.right<=box.left||box.bottom<=box.top)return;recoveryPress.current={pointerId:event.pointerId,generation:renderGeneration,index:state.index,x:event.clientX,y:event.clientY,left:box.left,right:box.right,top:box.top,bottom:box.bottom,moved:false};}} onPointerMove={event=>{event.stopPropagation();const press=recoveryPress.current;if(press?.pointerId===event.pointerId&&Math.hypot(event.clientX-press.x,event.clientY-press.y)>=8)press.moved=true;}} onPointerUp={event=>{event.stopPropagation();const press=recoveryPress.current;if(press?.pointerId!==event.pointerId)recoveryPress.current=null;else if(![event.clientX,event.clientY].every(Number.isFinite)||event.clientX<press.left||event.clientX>press.right||event.clientY<press.top||event.clientY>press.bottom||Math.hypot(event.clientX-press.x,event.clientY-press.y)>=8)press.moved=true;}} onPointerCancel={event=>{event.stopPropagation();recoveryPress.current=null;}} onPointerLeave={()=>{recoveryPress.current=null;}} onClick={event=>{event.stopPropagation();const press=recoveryPress.current;recoveryPress.current=null;if(event.detail!==0&&(!press||press.moved||press.generation!==renderGeneration||press.index!==state.index))return;recoverHidden(renderGeneration,state.index);}} onDoubleClick={event=>event.stopPropagation()}><span aria-hidden="true">{({left:'←',right:'→',up:'↑',down:'↓','up-left':'↖','up-right':'↗','down-left':'↙','down-right':'↘'} as Record<string,string>)[hiddenCandles.direction]||'→'}</span></button>}

        </div>
        <label className="simulator-ema"><input type="checkbox" checked={showEma} onChange={e=>{if(profileReady())setShowEma(e.target.checked);}} /> EMA20</label><label className="simulator-ema" style={{minHeight:44}} title="Private to this profile. Turning on keeps the current stop and immediately matches the target distance from entry, or actual fill after entry. New brackets start equal."><input type="checkbox" data-equal-tp-sl="true" checked={equalTpSl} disabled={!profileAccess||preferenceSaving||!!preferenceError||loading||!!confirm||!!calendar||saving||!!saveError||dragging} onChange={event=>void changeEqualTpSl(event.target.checked,renderGeneration)}/> Equal TP/SL (1:1)</label>{preferenceSaving&&<p role="status"><LoadingIndicator label="Saving profile preference…" size="small" /></p>}{preferenceError&&<p className="notice warning" style={WARNING_STYLE} role="alert" data-preference-error="true">{preferenceError} <button type="button" className="quiet-button" disabled={preferenceSaving} onClick={()=>pendingPreference.current===null?refreshTradePreferences():void changeEqualTpSl(pendingPreference.current,runGeneration.current)}>Retry preference</button></p>}<p className="simulator-chart-hint">Drag the chart to pan. Drag the ↕ price axis up/down to resize candles; double-click resets its scale. Drag the bottom axis to zoom time. Release a valid line move to update it. ✓ minimizes; tap a line to edit. Right/D: next candle; focused lines ↑/W or ↓/S.</p>
        {state.ended?<section className="simulator-finished" aria-label="Session finished"><div><h2>Session complete</h2><p>{previewTrading?'Preview complete · entries and exits are for practice only.':'Slide the chart to review your filled trades and points.'} Focus the chart and use ←/A or →/D to pan.</p>{!previewTrading&&<p>Net points <strong>{signed(totals.netPoints)}</strong> · {totals.trades} closed {totals.trades===1?'position':'positions'}</p>}</div><div>{(saving||saveError||sessionLoading)&&<div className="simulator-finished-save" data-finished-save-status="true" role="status">{saving?<><LoadingIndicator label={online?'Saving this result to your account…':'Saving this result locally…'} />{' Replay and session choices unlock when the save finishes.'}</>:saveError?'This result is not safely saved yet. Retry the save to enable Replay and session choices.':<LoadingIndicator label="Loading your next session…" />}{saveError&&<button className="quiet-button" disabled={saving} onClick={retrySave}>Retry save</button>}</div>}<button className="primary-button" disabled={loading||!!confirm||saving||!!saveError} onClick={()=>completedAction('replay',renderGeneration)}>Replay</button><button className="quiet-button" disabled={loading||!!confirm||saving||!!saveError} onClick={()=>completedAction('random',renderGeneration)}>Next Random</button><button className="quiet-button" disabled={loading||!!confirm||saving||!!saveError} onClick={event=>completedAction('choose',renderGeneration,event?.currentTarget)}>Choose a Session</button></div></section>:<div className="simulator-replay"><button className="primary-button" disabled={!playing&&(blocked||edited||dragging||mode!=='idle')} onClick={togglePlay}>{playing?'Pause':'▶ Play'}</button><button className="quiet-button" disabled={blocked||edited||playing||dragging||mode!=='idle'} onClick={()=>nextCandle()} aria-keyshortcuts="ArrowRight d" title="Next candle (Right Arrow or D)">Next candle →</button><label>Speed<select value={speed} disabled={!!confirm} onChange={e=>{if(profileReady())setSpeed(Number(e.target.value));}}><option value={1800}>Slow</option><option value={1000}>Normal</option><option value={450}>Fast</option></select></label><button className="quiet-button" disabled={loading||!chart||!!confirm||saving||!!saveError} onClick={()=>requestAction('reset')}>Replay</button>{state.position&&<button type="button" className="quiet-button" data-close-position="true" style={{minHeight:44}} disabled={blocked||dragging||priceDragging} title="Close this simulated position at the latest revealed close and remove both exits" onClick={()=>closeEntry(state.position!.id,renderGeneration,true)}>Close Position</button>}<button className="quiet-button" disabled={blocked} onClick={()=>finishNow(renderGeneration)}>{previewTrading?'Finish preview':'Finish & score now'}</button></div>}
        <div className="simulator-view-controls" aria-label="Chart view controls"><button type="button" disabled={loading||!chart||!!error||!!confirm||!!calendar||state.index<1} onClick={openPatternFinder}>Open in Pattern Finder ↗</button><button onClick={()=>navigate('fit')}>Fit</button><button onClick={()=>navigate('follow')}>Latest</button><button ref={matcherButton} className="simulator-chart-matcher" type="button" aria-expanded="false" title="Open this visible chart in Chart Matcher" disabled={matcherBusy||loading||!chart||!!error||!!confirm||!!calendar||dragging} onClick={openMatcher}><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false"><path d="M3 3v14h7M6 12l3-4 3 2 3-5"/><circle cx="16" cy="16" r="4"/><path d="m19 19 3 3"/></svg><span>Open Chart Matcher</span></button>{!previewTrading&&<output className="simulator-closed-points" data-sign={totals.netPoints>0?'positive':totals.netPoints<0?'negative':'zero'} hidden={!chart||loading||!!error} role="status" aria-live="polite" aria-atomic="true" aria-label={`Closed trades: ${totals.netPoints===0?'0':signed(totals.netPoints)} Points`}>{totals.netPoints===0?'0':signed(totals.netPoints)} Points</output>}</div>
        {matcherStatus&&<p role="status" aria-live="polite">{matcherStatus}</p>}{matcherError&&<p role="alert">{matcherError}</p>}
        <p className="simulator-replay-note">Auto-play pauses on an entry or exit. Replay starts a new attempt; completed history stays saved.</p>
      </section>
      {active&&!minimized&&<aside className="simulator-ticket simulator-lines-only" aria-label="Bracket summary"><p className="eyebrow">ONE BRACKET AT A TIME</p><h2>{state.position?'Open position':'Working bracket'}</h2>
        {oversizedSavedBracket&&<p className="notice warning" style={WARNING_STYLE} role="status">This existing bracket exceeds 20 points and has not been changed. New edits must put each exit within 20 points of entry. You can still cancel an unfilled bracket or close an open position yourself.</p>}<div className="simulator-risk"><p className="eyebrow">PLANNED BRACKET</p>{metrics?<><div><span>Risk <strong>{format(metrics.risk)} pts</strong></span><span>Reward <strong>{format(metrics.reward)} pts</strong></span></div></>:<p className="simulator-validation warning" style={WARNING_STYLE} role="status">{validation.error}</p>}<small>Maximum 20 points each for stop and target. Prices snap to 0.25. Distances use planned entry until filled, then actual fill.</small></div>
        {state.position&&<p className="simulator-fill">Actual entry <strong>{format(state.position.entryPrice)}</strong>{!previewTrading&&<><br/>Open points <strong className={unrealized<0?'negative':'positive'}>{signed(unrealized)}</strong></>}</p>}
        <p className="simulator-ticket-help">{state.pending?`Waiting for a touch from candle ${state.pending.eligibleIndex+1}. Slide a line to change it; × cancels the bracket.`:'Entry is fixed. Slide the stop or target to update it; × closes at the latest revealed close.'} Valid releases apply immediately for the next candle. Replay stays paused.{equalTpSl?' Equal TP/SL is enabled. Stop/target edits stay equidistant around '+(state.position?'actual fill':'planned entry')+'. Minimum distance may expand by ticks to keep both exits valid.':''}</p>
      </aside>}
      {!previewTrading&&state.position&&minimized&&<aside className="simulator-compact-summary" aria-label="Open position summary"><span>Open points <strong className={unrealized<0?'negative':'positive'}>{signed(unrealized)}</strong></span></aside>}
      <p className={noticeWarning?"simulator-notice simulator-order-notice warning":"simulator-notice simulator-order-notice"} style={noticeWarning?WARNING_STYLE:undefined} role={noticeWarning?"alert":"status"} aria-live={noticeWarning?"assertive":"polite"}>{notice}</p>
    </div>
    <div ref={matcherContainer} data-chart-matcher-container="true"/>
    <section className="simulator-results" aria-labelledby="sim-results"><div className="simulator-results-heading"><h2 id="sim-results">{previewTrading?'Preview entries and exits':state.ended?'Your points breakdown':'Points so far'}</h2><span>{previewTrading?'NOT SCORED OR SAVED':state.ended?'FINAL':'CLOSED POSITIONS ONLY'}</span></div>{!previewTrading&&<div className="simulator-stats"><div><span>Net points</span><strong className={totals.netPoints<0?'negative':'positive'}>{signed(totals.netPoints)}</strong></div><div><span>Wins / losses / flat</span><strong>{totals.wins} / {totals.losses} / {totals.flats}</strong></div><div><span>Win rate</span><strong>{totals.trades?`${totals.winRate.toFixed(1)}%`:'—'}</strong></div><div><span>Won / lost points</span><strong>{format(totals.grossProfit)} / {format(totals.grossLoss)}</strong></div><div data-profit-factor="current"><span>Profit factor · points</span><strong>{pointStats.profitFactorLabel}</strong>{pointStats.profitFactor===Infinity&&<small>No losing trades</small>}{pointStats.profitFactor===null&&<small>No non-flat closed trades</small>}</div></div>}
      <div className="simulator-ledger" tabIndex={0} aria-label="Scrollable trade ledger"><table><thead><tr><th>Trade</th><th>Entry</th><th>Exit</th><th>Reason</th>{!previewTrading&&<><th>Result</th><th>Points</th></>}</tr></thead><tbody>{state.trades.map((t,index)=><tr key={t.id}><td>{index+1} · {t.side==='buy'?'Long':'Short'}</td><td>{format(t.entryPrice)}<small>Candle {t.entryIndex+1} · {t.entryTime.slice(-5)}</small></td><td>{format(t.exitPrice)}<small>Candle {t.exitIndex+1} · {t.exitTime.slice(-5)}</small></td><td>{EXIT_LABELS[t.reason as keyof typeof EXIT_LABELS]||t.reason}{t.ambiguous&&<small>Both levels touched · stop first</small>}</td>{!previewTrading&&<><td>{t.outcome==='win'?'Win':t.outcome==='loss'?'Loss':'Flat'}</td><td className={t.points<0?'negative':'positive'}>{signed(t.points)}</td></>}</tr>)}</tbody></table>{!state.trades.length&&<p>No closed positions yet. Your entries and exits will appear here.</p>}</div>
      {!previewTrading&&state.position&&<p>One position is still open; {signed(unrealized)} open points are not included in the closed total.</p>}{state.ended&&<p>Open positions were marked at the last revealed close; unfilled orders were canceled. {!previewTrading&&'Win rate includes flat results in the total.'}</p>}
    </section>
    {historyOpen&&<section className="simulator-history" data-trade-history="true" ref={historyPanel} aria-labelledby="sim-history-title" onKeyDown={event=>{event.stopPropagation();if(event.key==='Escape'){event.preventDefault();closeHistory();}}}>
      <div className="simulator-results-heading"><h2 id="sim-history-title">{profileAccess?.profile.name||'Your'} · Trade history</h2><button className="quiet-button" onClick={closeHistory}>Close history</button></div>
      <p>{online?'Saved to your account.':'Saved in this browser only.'} Completed attempts count below; unfinished checkpoints do not. Replay creates a new attempt.</p>
      <div className="simulator-stats"><div><span>Completed attempts</span><strong>{history.length}</strong></div><div><span>Net points</span><strong className={historyStats.netPoints<0?'negative':'positive'}>{signed(historyStats.netPoints)}</strong></div><div><span>Wins / losses / flat</span><strong>{historyStats.wins} / {historyStats.losses} / {historyStats.flats}</strong></div><div data-profit-factor="history"><span>Profit factor · pooled points</span><strong>{historyStats.profitFactorLabel}</strong>{historyStats.profitFactor===Infinity&&<small>No losing trades</small>}{historyStats.profitFactor===null&&<small>No non-flat closed trades</small>}</div></div>
      <p>Profit factor = total winning points ÷ total losing points. These are points, not cash; the total is pooled, not an average of session factors.</p>
      <TradeHistoryChart records={history} learnerId={profileAccess?.profile.learnerId}/>
      <TradeHistoryBuckets records={history} learnerId={profileAccess?.profile.learnerId}/>
      {historyReplayMessage&&<p data-history-replay-status="true" className={historyReplayWarning?"notice warning":undefined} style={historyReplayWarning?WARNING_STYLE:undefined} role={historyReplayWarning?"alert":"status"}>{historyReplayMessage}</p>}
      {!history.length&&<p>No completed sessions saved yet. Finish an attempt to add its actual fills and results here.</p>}
      {history.map(record=>{const stats=summarize([record]);return <details key={record.id} className="simulator-history-attempt" data-history-attempt={record.id}><summary><span>{record.sessionTitle}<small>{record.completedAt?.slice(0,16).replace('T',' ')} UTC · through candle {record.state.index+1} / {record.barCount}</small></span><strong className={stats.netPoints<0?'negative':'positive'}>{signed(stats.netPoints)} points</strong><span>PF {stats.profitFactorLabel}{stats.profitFactor===Infinity?' · No losing trades':''}</span><button type="button" className="quiet-button sim-history-replay" data-history-replay={record.id} aria-label={`Replay ${record.sessionTitle}`} disabled={loading||saving||!!saveError||!!confirm} onClick={event=>{event.preventDefault();event.stopPropagation();requestHistoryReplay(record.id,renderGeneration);}}>Replay</button></summary><p>{stats.wins} wins · {stats.losses} losses · {stats.flats} flat · {stats.trades} closed trades. Winning points {format(stats.grossProfit)} / losing points {format(stats.grossLoss)}.</p><div className="simulator-ledger" tabIndex={0} aria-label={`Trade details for ${record.sessionTitle}`}><table><thead><tr><th>Trade</th><th>Entry</th><th>Exit</th><th>Reason</th><th>Points</th></tr></thead><tbody>{record.state.trades.map((trade,index)=><tr key={trade.id}><td>{index+1} · {trade.side==='buy'?'Long':'Short'}</td><td>{format(trade.entryPrice)}<small>Candle {trade.entryIndex+1} · {trade.entryTime.slice(-5)}</small></td><td>{format(trade.exitPrice)}<small>Candle {trade.exitIndex+1} · {trade.exitTime.slice(-5)}</small></td><td>{EXIT_LABELS[trade.reason as keyof typeof EXIT_LABELS]||trade.reason}</td><td className={trade.points<0?'negative':'positive'}>{signed(trade.points)}</td></tr>)}</tbody></table>{!record.state.trades.length&&<p>No filled trades in this completed attempt.</p>}</div></details>;})}
    </section>}
    <details className="simulator-rules"><summary>How candle fills and points work</summary><ul><li>This is a simplified historical points simulation—not live trading or an execution guarantee. One bracket or position is allowed at a time. New stop and target distances are each limited to 20 points from entry. Previously saved open brackets are not moved automatically; cancel or close them yourself, or make a valid adjustment. Opening gaps can still produce fills beyond 20 points.</li><li>Choose Buy or Sell, then left-click or tap the chart to place the entry, stop and target together. Or right-click the chart and choose Buy or Sell at that price. A valid line release updates the complete bracket immediately. New or changed orders are eligible on the next candle. Previously visible candles never fill it. An unfilled bracket remains active until filled, moved, canceled or the session ends.</li><li>Buy limits fill when the next eligible candle opens at or below the limit, or its low touches it. Sell limits are the reverse. A favorable opening gap uses the opening price; otherwise entry is at the limit.</li><li>The stop and target activate only after entry. A gap past an active stop exits at the opening price. A gap past an active target exits at the opening price too. If an entry gaps past its own stop, entry and stop both fill at that open, for zero points.</li><li>Candles reveal open, high, low and close—not the exact path between them. When both exits are reachable after an opening between them, the stop wins. An already-triggered opening exit happens before later wicks.</li><li>On an intrabar entry candle, a target wick alone is not credited: it could have happened before entry. A target is credited that candle only if the close proves a crossing after entry, and the stop was not reached. A fill at the open can use that candle’s target touch.</li><li>Right Arrow or D reveals one next candle and pauses playback. Focused chart Left/A pans; focused order-line Up/W and Down/S adjust the price, with Shift+Arrow retaining larger steps. Typing fields, modified letter shortcuts and dialogs are protected. Arming, tapping, dragging, keyboard line adjustments and chart navigation pause replay immediately. Valid line releases apply without a confirmation. Invalid or canceled moves restore the last valid bracket. Press Play explicitly to resume. The ✓ beside × minimizes the order controls to lines without changing the bracket or its eligibility. Tap any minimized line (or press Enter/Space when focused) to reopen the controls; the opening gesture does not move prices. Both actions pause replay and never resume it automatically. An open entry cannot be moved. Each completed exit cancels its paired order. The × beside the entry cancels an unfilled bracket or closes an open simulated position at the latest revealed close—not a panned historical candle—and removes both exits. Close Position below the chart closes an open position the same way, including while the order controls are minimized.</li><li>The planned percentage uses risk ÷ (risk + reward). Actual points use the entry and exit fill prices. A long earns exit minus entry; a short earns entry minus exit. Finish scores immediately, without a confirmation. Final open positions close at the last revealed close, explicitly labeled Session end; pending orders are canceled.</li><li>Each next candle brings its full wick back into view while keeping the chosen candle size when possible. You can pan into blank space after the newest revealed candle; blank space contains no future data. The in-chart arrow points toward hidden revealed candles (newest first); tap it to bring that area into view. The opening view matches Market Orders Simulator: prior-session context, a day-open divider and the revealed current-day candles. Empty slots are unrevealed, not future prices. Drag the right-hand price axis up to enlarge candles or down to compress them. Double-click the axis (or focus it and press Home) to reset only the price scale. Up/W and Down/S on the focused axis also resize it. Pan/zoom only changes the view, never the replay or score.</li><li>{online?'A signed-in learner can save completed attempts across devices. Guest practice and unfinished account attempts stay only on this page. No broker is connected.':'A local learner profile is required; no broker is connected. Completed attempts and the latest paused checkpoint stay in this browser, not in cloud storage. Clearing browser data removes them.'} Profit factor is gross winning points divided by gross losing points; pooled history uses those totals, not an average of session factors. It is points-based, not cash profit factor. No losing trades with wins shows ∞; no non-flat trades shows N/A.</li></ul></details>
  </main>{tradeReview&&chart&&<LimitTradeReview key={`${sessionId}:${profileAccess?.profile.learnerId||'standalone'}`} previewTrading={previewTrading} trades={tradeReview.trades} candles={chart.current} ema10={Model.chartEma10(chart).ema10} title={chart.title} active={profileReady()&&reviewOwner.current===(profileAccess?.profile.learnerId||'standalone')} canAcknowledge={()=>alive.current&&profileReady()&&reviewOwner.current===(profileAccess?.profile.learnerId||'standalone')&&reviewPending.current===tradeReview&&current.current===tradeReview} onComplete={()=>{if(!alive.current||!profileReady()||reviewOwner.current!==(profileAccess?.profile.learnerId||'standalone')||reviewPending.current!==tradeReview||current.current!==tradeReview)return;reviewPending.current=null;reviewFocusNeeded.current=true;setTradeReview(null);}}/>}{calendar&&<TradeSessionCalendar key={calendar.token} entries={catalog} initialId={calendar.initialId} allowRandom onChoose={id=>selectCalendarSession(id,calendar.token)} onClose={()=>closeSessionPicker(calendar.token)}/>}</>;
}
