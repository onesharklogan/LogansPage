import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createRequire} from 'node:module';
import ts from 'typescript';
import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
const source=fs.readFileSync(new URL('../components/trading-style-select.tsx',import.meta.url),'utf8');
const compiled=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,jsx:ts.JsxEmit.ReactJSX}}).outputText;
const loaded={exports:{}};new Function('require','module','exports',compiled)(createRequire(import.meta.url),loaded,loaded.exports);
const {default:Select,TRADING_STYLES}=loaded.exports;
const expected=['Buy Closes','Buy Pullbacks','Buy Previous Lows','Sell Closes','Sell Pullbacks','Sell Previous Highs','Stay Out','BLSH Scalp'];
const render=(value='',disabled=false)=>renderToStaticMarkup(React.createElement(Select,{id:'style',value,disabled,onChange(){throw Error('Rendering must not rewrite a saved style');}}));
test('creation offers exactly eight named choices plus optional None',()=>{
 assert.deepEqual(TRADING_STYLES,expected);
 const html=render();assert.equal((html.match(/<option /g)||[]).length,9);
 for(const name of expected)assert.ok(html.includes(`value="${name}">${name}</option>`));
 assert.match(html,/<option value="" selected="">None \(optional\)<\/option>/);
});
test('all eight saved selections round-trip into the selected dropdown option',()=>{
 for(const name of expected)assert.ok(render(name).includes(`value="${name}" selected="">${name}</option>`));
});
test('legacy free text stays selected, visible and escaped without becoming a new selectable style',()=>{
 const html=render('Wait <patiently> & confirm');
 assert.match(html,/<option value="Wait &lt;patiently&gt; &amp; confirm" disabled="" selected="">Keep saved custom style/);
 assert.match(html,/Saved custom style: Wait &lt;patiently&gt; &amp; confirm/);
 assert.match(html,/aria-describedby="style-legacy"/);
 assert.equal((html.match(/<option /g)||[]).length,10);
 assert.doesNotMatch(render('Stay Out'),/Keep saved custom style/);
 assert.doesNotMatch(render(''),/Keep saved custom style/);
});
test('pending saves disable the select and label remains associated',()=>{
 assert.match(render('Buy Closes',true),/<label for="style">/);
 assert.match(render('Buy Closes',true),/<select id="style" disabled="">/);
});
