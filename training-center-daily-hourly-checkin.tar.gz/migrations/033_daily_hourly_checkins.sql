BEGIN;
CREATE TABLE IF NOT EXISTS learner_app.daily_hourly_checkins (
 account_id uuid NOT NULL REFERENCES learner_app.accounts(id),
 day_key text NOT NULL CHECK(day_key ~ '^\d{4}-\d{2}-\d{2}$'),
 hour smallint NOT NULL CHECK(hour BETWEEN 8 AND 20),
 completed boolean NOT NULL,
 updated_at bigint NOT NULL,
 PRIMARY KEY(account_id,day_key,hour)
);
REVOKE ALL ON learner_app.daily_hourly_checkins FROM PUBLIC;
GRANT SELECT, INSERT ON learner_app.daily_hourly_checkins TO learner_runtime;
GRANT UPDATE(completed,updated_at) ON learner_app.daily_hourly_checkins TO learner_runtime;
COMMIT;
