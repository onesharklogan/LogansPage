import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {PGlite} from '@electric-sql/pglite';
import {LearnerRepository} from '../lib/learner/repository.mjs';
import {createLearnerService} from '../lib/learner/server.mjs';
import {createChartResolver} from '../lib/learner/charts.mjs';
import {HOURLY_HOURS,hourlyClock} from '../lib/learner/daily-hourly.mjs';

test('Chicago clock has thirteen slots and preserves summer and winter boundaries',()=>{
 assert.deepEqual(HOURLY_HOURS,[8,9,10,11,12,13,14,15,16,17,18,19,20]);
 for(const [utc,day,hour] of [
  ['2026-11-19T13:59:59.999Z','2026-11-19',7],['2026-11-19T14:00:00Z','2026-11-19',8],
  ['2026-11-20T02:59:59.999Z','2026-11-19',20],['2026-11-20T03:00:00Z','2026-11-19',21],
  ['2026-07-19T13:00:00Z','2026-07-19',8],['2026-07-20T01:00:00Z','2026-07-19',20],
  ['2026-07-20T05:00:00Z','2026-07-20',0]
 ]) assert.deepEqual(hourlyClock(Date.parse(utc)),{day,hour});
});

test('daily API enforces hourly windows, account and CSRF and persists without affecting other tracking',async()=>{
 const db=new PGlite();
 try {
  const read=name=>fs.readFileSync(new URL('../migrations/'+name+'.sql',import.meta.url),'utf8');
  await db.exec('CREATE ROLE learner_runtime');
  for(const migration of ['006_learner_accounts','027_learner_appearance','028_daily_dashboard','030_daily_dashboard_points','032_daily_categories_order','033_daily_hourly_checkins'])await db.exec(read(migration));
  const issuer='https://hourly.test',origin='https://learner.test';
  let now,subject='Synthetic owner';
  const setTime=iso=>{now=Date.parse(iso);};
  const repository=new LearnerRepository({transaction:fn=>db.transaction(tx=>fn({query:(sql,args)=>tx.query(sql,args)}))});
  const service=createLearnerService({origin,repository,identityProvider:{issuer,resolve:async()=>({issuer,subject,name:subject,sessionId:'synthetic-session-'+subject+'-abcdefghijklmnop',expiresAt:Date.parse('2026-11-22T00:00:00Z'),emailVerified:true})},csrfSecret:'synthetic-only-no-production-secret-123456789',charts:createChartResolver(),now:()=>now});
  const request=async(path,init={})=>{const r=await service(new Request(origin+'/api/learner/'+path,{...init,headers:{host:'learner.test',origin,'sec-fetch-site':'same-origin',...init.headers}}));return {status:r.status,body:await r.json()};};
  const date='2026-11-19';
  setTime('2026-11-19T13:59:59.999Z');
  const session=(await request('session')).body;
  const write=(hour,extra={},sendToken=true,auth=session)=>request('daily',{method:'POST',headers:{'content-type':'application/json',...(sendToken?{'x-csrf-token':auth.csrfToken}:{})},body:JSON.stringify({context:auth.context,action:'hourly',date,hour,completed:true,...extra})});
  assert.equal((await write(8)).status,409);
  setTime('2026-11-19T14:00:00Z');
  const baseline=(await request('daily')).body;
  assert.equal((await write(9)).status,409);
  assert.equal((await write(7)).status,400);
  assert.equal((await write(8,{serverNow:now})).status,400);
  assert.equal((await write(8,{date:'2026-11-18'})).status,409);
  assert.equal((await write(8,{},false)).status,403);
  assert.deepEqual((await write(8)).body.hourly,{completedHours:[8],serverNow:now});
  assert.deepEqual((await write(8,{completed:false})).body.hourly.completedHours,[]);
  setTime('2026-11-19T14:59:59.999Z');
  assert.deepEqual((await write(8)).body.hourly.completedHours,[8]);
  setTime('2026-11-19T15:00:00Z');
  assert.equal((await write(8,{completed:false})).status,409);
  assert.equal((await write(9)).status,200);
  setTime('2026-11-20T02:59:59.999Z');
  assert.equal((await write(20)).status,200);
  setTime('2026-11-20T03:00:00Z');
  assert.equal((await write(20,{completed:false})).status,409);
  const reload=(await request('daily')).body;
  assert.deepEqual(reload.hourly.completedHours,[8,9,20]);
  for(const field of ['percentage','tasks','items','trading','history']) assert.deepEqual(reload[field],baseline[field]);
  setTime('2026-11-20T14:00:00Z');
  assert.deepEqual((await request('daily')).body.hourly.completedHours,[]);
  assert.deepEqual((await request('daily?date='+date)).body.hourly.completedHours,[8,9,20]);
  subject='Different synthetic account';
  const other=(await request('session')).body;
  assert.deepEqual((await request('daily?date='+date)).body.hourly.completedHours,[]);
  assert.equal((await write(8,{date:'2026-11-20',context:session.context},true,other)).status,409);
 } finally {await db.close();}
});
