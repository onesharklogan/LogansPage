import {useMemo} from 'react';
import {patternOutcomes} from '../lib/pattern-outcomes.mjs';
type Match={id:string;date:string;startBar:number;endBar:number;distance:number};
type Session={reference:{id:string};chart:{current:{c:number;t:string}[]}};
export default function PatternOutcomes({matches,sessions,ready}:{matches:Match[];sessions:Session[];ready:boolean}){
 const model=useMemo(()=>patternOutcomes(matches,sessions),[matches,sessions]);
 let low=0,high=0;for(const line of model.lines)for(const value of line.points){low=Math.min(low,value);high=Math.max(high,value);}
 const pad=Math.max(.02,(high-low)*.08),lo=low-pad,hi=high+pad;
 const longest=Math.max(1,...model.lines.map(line=>line.points.length-1));
 const x=(i:number)=>58+i/longest*870,y=(v:number)=>300-(v-lo)/(hi-lo)*260;
 return <section aria-labelledby="pattern-outcomes-title" style={{marginTop:20,minWidth:0}}><h3 id="pattern-outcomes-title">Historical outcomes · 25 closest patterns</h3>
 <p>Up to 25 closest windows from the same ranking as the 10 previews. No similarity cutoff or guarantee of a good match. Up to two nonoverlapping windows per session can appear; these are not independent days. Observed closes, not simulated paths or forecasts. All lines start at 0% at the matched pattern’s final close.</p>
 {!ready?<p>Find matches to compare the rest of each session.</p>:<><p role="status">{model.lines.length} plotted windows of {model.total} selected windows · {model.noContinuation} without later closes · {model.unavailable} unavailable · {model.truncated} stopped at missing data{model.duplicates?` · ${model.duplicates} duplicate references omitted`:''}. Windows without later closes are counted but not replaced. Re-checking keeps checked previews and replaces unchecked windows in both previews and this chart; checkboxes alone control saving.</p>
 {model.lines.length?<svg viewBox="0 0 960 350" role="img" aria-label={`${model.lines.length} historical continuation lines. Percent change from matched final close versus five-minute bars after pattern end.`} style={{width:'100%',height:'auto',minHeight:220,background:'var(--appearance-surface-08131f, #08131f)',borderRadius:8}}>
 {[0,.25,.5,.75,1].map(f=>{const v=lo+(hi-lo)*f;return <g key={f}><line x1="58" x2="928" y1={y(v)} y2={y(v)} stroke="var(--appearance-line-1c3042, #1c3042)"/><text x="52" y={y(v)+4} textAnchor="end" fontSize="12" fill="var(--appearance-ink-8ba1b6, #8ba1b6)">{v.toFixed(2)}%</text></g>;})}
 <line x1="58" x2="928" y1={y(0)} y2={y(0)} stroke="var(--appearance-ink-8ba1b6, #8ba1b6)" strokeDasharray="4 4"/>
 {model.lines.map(line=><polyline key={line.key} data-outcome-session={line.id} points={line.points.map((v,i)=>`${x(i)},${y(v)}`).join(' ')} fill="none" stroke="var(--appearance-ink-8ac7ff, #8ac7ff)" strokeOpacity={.5} strokeWidth="1" vectorEffect="non-scaling-stroke"><title>{`${line.date} · pattern bars ${line.startBar}–${line.endBar} · ${line.points.length-1} later closes`}</title></polyline>)}
 <text x="58" y="327" fontSize="12" fill="var(--appearance-ink-8ba1b6, #8ba1b6)">Pattern end · 0</text><text x="928" y="327" textAnchor="end" fontSize="12" fill="var(--appearance-ink-8ba1b6, #8ba1b6)">{longest} bars later · 5 minutes/bar</text>
 </svg>:<p>No valid continuation data for these matches.</p>}
 <p>Lines stop at each session’s last available close; shorter sessions are not extended. Alignment is elapsed bars after the pattern, not clock time.</p></>}
 </section>;
}
