import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {patternOutcomes} from '../lib/pattern-outcomes.mjs';import {buildPatternWindow,rankPatternMatches} from '../lib/pattern-match.mjs';
const session=(id,closes)=>({reference:{id},chart:{current:closes.map((c,i)=>({c,t:`2025-01-02 08:${String(30+5*i).padStart(2,'0')}`}))}});
test('outcomes align at zero, normalize percentages and keep every close in chronological order',()=>{
 const sessions=[session('b',[100,110,99,121]),session('a',[200,220,198])],matches=[{id:'b',date:'2025-01-03',startBar:1,endBar:2},{id:'a',date:'2025-01-02',startBar:1,endBar:2}];const before=JSON.stringify({sessions,matches});
 const r=patternOutcomes(matches,sessions);assert.deepEqual(r.lines.map(l=>l.id),['a','b']);assert.deepEqual(r.lines[0].points,[0,-10]);assert.deepEqual(r.lines[1].points,[0,-10,10]);assert.equal(JSON.stringify({sessions,matches}),before);
});
test('duplicate references, endpoint-only and missing/partial sessions are counted and never padded',()=>{
 const a=session('a',[100,101,102,103]);a.chart.current[2].t='2025-01-02 08:50';
 const matches=[{id:'a',date:'2025-01-02',endBar:1},{id:'a',date:'2025-01-02',endBar:1},{id:'b',date:'2025-01-03',endBar:2},{id:'missing',date:'2025-01-04',endBar:1}];
 const r=patternOutcomes(matches,[a,session('b',[100,101])]);assert.equal(r.duplicates,1);assert.equal(r.noContinuation,1);assert.equal(r.unavailable,1);assert.equal(r.truncated,1);assert.deepEqual(r.lines[0].points,[0,1]);assert.deepEqual(patternOutcomes([],[]).lines,[]);
});
test('all-session refs exceed preview limit, deduplicate sessions and leave top matches exactly unchanged',async()=>{
 const rows=JSON.parse(fs.readFileSync(new URL('../public/modules/chart-match-index.json',import.meta.url))).sessions.slice(0,18);const q=buildPatternWindow(rows[0],1,15),opts={earlierOnly:false,limit:10,yieldControl:async()=>{}};
 const base=await rankPatternMatches(q,rows,opts),all=await rankPatternMatches(q,[...rows,rows[1]],{...opts,includeSessionMatches:true});
 assert.deepEqual(all.matches,base.matches);assert.equal(all.sessionMatches.length,17);assert.equal(new Set(all.sessionMatches.map(m=>m.id)).size,17);assert.ok(all.sessionMatches.every(m=>m.id!==q.id));
 const smaller=await rankPatternMatches(q,rows,{...opts,limit:1,includeSessionMatches:true});assert.deepEqual(smaller.sessionMatches,all.sessionMatches);
 const full=await rankPatternMatches(q,rows,{...opts,limit:48});for(const m of all.sessionMatches){const best=full.matches.find(x=>x.id===m.id);if(best)assert.equal(m.startBar,best.startBar);}
 const controller=new AbortController();controller.abort();await assert.rejects(rankPatternMatches(q,rows,{...opts,includeSessionMatches:true,signal:controller.signal}),e=>e.name==='AbortError');
});
import ts from 'typescript';import React from 'react';import {renderToStaticMarkup} from 'react-dom/server';import {createRequire} from 'node:module';
test('React renders all paths in one chart and a clear empty state without warnings',()=>{
 const src=fs.readFileSync(new URL('../components/pattern-outcomes.tsx',import.meta.url),'utf8'),js=ts.transpileModule(src,{compilerOptions:{module:ts.ModuleKind.CommonJS,jsx:ts.JsxEmit.ReactJSX}}).outputText,m={exports:{}};
 new Function('require','module','exports',js)(createRequire(new URL('../components/pattern-outcomes.tsx',import.meta.url)),m,m.exports);
 const sessions=['a','b'].map(id=>session(id,[100,101])),matches=sessions.map(s=>({id:s.reference.id,date:'2025-01-02',startBar:1,endBar:1,distance:0}));
 const html=renderToStaticMarkup(React.createElement(m.exports.default,{sessions,matches,ready:true}));assert.equal((html.match(/<svg/g)||[]).length,1);assert.equal((html.match(/<polyline/g)||[]).length,2);assert.match(html,/2 plotted windows/);
 assert.match(renderToStaticMarkup(React.createElement(m.exports.default,{sessions:[],matches:[],ready:true})),/No valid continuation data/);
});
