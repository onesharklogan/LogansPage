import type { Metadata } from "next";
import AppearanceProvider from "../components/appearance-provider";
import GuestVisitTracker from "../components/guest-visit-tracker";
import "./globals.css";
import "../public/appearance.css";
import "../public/loading-indicator.css";
export const metadata: Metadata = {
  title: "PATC Home",
  description: "Practice price action with the Market Orders Simulator and Limit Orders Simulator.",
  robots: { index: false, follow: false },
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body><AppearanceProvider/><GuestVisitTracker/>{children}</body></html>;
}
