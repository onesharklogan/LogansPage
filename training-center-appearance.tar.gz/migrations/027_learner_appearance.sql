-- Prepared only: apply separately through the approved learner migration process.
-- Existing accounts retain Dark; no history or identity data are rewritten.
BEGIN;
SET LOCAL lock_timeout = '5s';
ALTER TABLE learner_app.accounts ADD COLUMN appearance text NOT NULL DEFAULT 'dark' CHECK (appearance IN ('light','dark'));
INSERT INTO learner_app.schema_migrations(version,description) VALUES(9,'Account Light or Dark appearance');
COMMIT;
