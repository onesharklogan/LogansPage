import test from 'node:test';import assert from 'node:assert/strict';import {readFileSync,existsSync} from 'node:fs';import {createHash} from 'node:crypto';import {Worker} from 'node:worker_threads';import {spawnSync} from 'node:child_process';import {createRequire} from 'node:module';
import {recognizeChartText,inferPriceAxis,normalizeOcrWords,OCR_ASSETS,OCR_PRICE_SUPPORT} from '../lib/chart-match-ocr.mjs';
import {resolveDirectionsWithEma,recognizeChartScreenshot,inferSessionAnchors} from '../lib/chart-match-auto.mjs';
const require=createRequire(import.meta.url),root=new URL('../',import.meta.url).pathname;
const word=(text,x,y,confidence=95)=>({text,confidence,bbox:{x0:x,y0:y-7,x1:x+65,y1:y+7}});
const axisWords=()=>[word('7,800.00',920,100),word('7,750.00',920,300),word('7,700.00',920,500)];
const dimensions={width:1000,height:600};
test('independent price OCR anchors are redundant, signed linear and fail closed on misleading labels',()=>{
 const axis=inferPriceAxis(axisWords(),dimensions);assert.equal(axis.pointsPerPixel,.25);assert.equal(axis.upper.price,7800);assert.equal(axis.lower.price,7700);
 for(const words of [axisWords().slice(0,2),[word('7,700.00',920,100),word('7,750.00',920,300),word('7,800.00',920,500)],[word('7,800.00',920,100),word('7,749.00',920,300),word('7,700.00',920,500)],[word('780000',920,100),...axisWords().slice(1)],[word('7,800.OO',920,100),...axisWords().slice(1)],axisWords().map(w=>({...w,confidence:40})),[...axisWords(),word('7,751.00',920,300)]])assert.throws(()=>inferPriceAxis(words,dimensions));
 assert.equal(OCR_PRICE_SUPPORT.minimum,3100);assert.equal(OCR_PRICE_SUPPORT.maximum,15800);for(const factor of [.1,10])assert.throws(()=>inferPriceAxis(axisWords().map(w=>({...w,text:(Number(w.text.replaceAll(',',''))*factor).toFixed(2)})),dimensions));
 const both=[...axisWords(),word('8,800.00',10,100),word('8,750.00',10,300),word('8,700.00',10,500)];assert.throws(()=>inferPriceAxis(both,dimensions),e=>e.code==='price-axis-ambiguous');
 const raw={blocks:[{paragraphs:[{lines:[{words:[word('7,800.00',920,100),word('bad',-5,100),{...word('bad',920,100),confidence:Infinity}]}]}]}]};assert.equal(normalizeOcrWords(raw,1000,600).length,1);
});

function emaGeometry({count=30,body=24,constant=false}={}){
 const styles=[{id:'A'},{id:'B'}],candles=[];let ema=-180;
 for(let i=0;i<count;i++){const top=constant?120:95+(i%6)*5,bottom=top+body,styleId=Math.floor(i/5)%2?'B':'A',close=-(Math.floor(i/5)%2?bottom:top);ema=i?ema*19/21+close*2/21:ema;candles.push({styleId,ema,pixels:{bodyTop:top,bodyBottom:bottom}});}
 return {styles,candles};
}
test('independent forward EMA hypotheses select only a unique style mapping and never infer close from hue or prior close',()=>{
 const {styles,candles}=emaGeometry(),out=resolveDirectionsWithEma(candles,styles);assert.equal(out.valid,true);assert.deepEqual(out.mapping,{A:'bull',B:'bear'});
 const differentlyNamed=styles.map((s,i)=>({...s,color:i?[20,200,70]:[240,40,40]}));assert.deepEqual(resolveDirectionsWithEma(candles,differentlyNamed),out);
 const thin=emaGeometry({body:0,constant:true});assert.equal(resolveDirectionsWithEma(thin.candles,thin.styles).valid,false);assert.ok(resolveDirectionsWithEma(thin.candles,thin.styles).hypotheses.length>1);
 const corrupt=candles.map((c,i)=>({...c,ema:c.ema+(i===12?15:0)}));assert.equal(resolveDirectionsWithEma(corrupt,styles).valid,false);assert.equal(resolveDirectionsWithEma(corrupt,styles).hypotheses.length,0);
 assert.equal(resolveDirectionsWithEma(candles,[...styles,{id:'prior-only'}]).valid,false,'prior-only direction cannot be inferred from unobserved style');
 const tiny=emaGeometry({body:1,constant:true});assert.equal(resolveDirectionsWithEma(tiny.candles,tiny.styles).valid,false,'one-pixel bodies need ambiguity, not forced direction');
});

function fakeFactory({stall=false,bad=false}={}){const calls=[],state={terminated:0,worker:null};return {calls,state,factory(url){assert.equal(url,OCR_ASSETS.worker);const worker={onmessage:null,onerror:null,onmessageerror:null,terminate(){state.terminated++;},postMessage(packet){calls.push(packet);if(stall)return;queueMicrotask(()=>worker.onmessage?.({data:{...packet,status:bad?'reject':'resolve',data:packet.action==='recognize'?{text:'no fabricated labels',blocks:[]}:undefined}}));}};state.worker=worker;return worker;}};}
test('independent OCR worker lifecycle remains local and terminates on success/error/init abort/timeout',async()=>{
 const image={width:300,height:200,encoded:new Uint8Array([1,2,3])},good=fakeFactory();assert.deepEqual((await recognizeChartText(image,{workerFactory:good.factory})).words,[]);assert.equal(good.state.terminated,1);assert.deepEqual(good.calls.map(c=>c.action),['load','loadLanguage','initialize','setParameters','recognize']);assert.equal(good.calls[0].payload.options.corePath,'/chart-match/ocr');assert.equal(good.calls[1].payload.options.langPath,'/chart-match/ocr');assert.equal(good.calls[1].payload.options.cacheMethod,'none');
 const bad=fakeFactory({bad:true});await assert.rejects(recognizeChartText(image,{workerFactory:bad.factory}));assert.equal(bad.state.terminated,1);
 const pending=fakeFactory({stall:true}),controller=new AbortController(),promise=recognizeChartText(image,{workerFactory:pending.factory,signal:controller.signal});await new Promise(r=>setTimeout(r,0));controller.abort();await assert.rejects(promise,{name:'AbortError'});assert.equal(pending.state.terminated,1);assert.equal(pending.state.worker.onmessage,null);
 const slow=fakeFactory({stall:true});await assert.rejects(recognizeChartText(image,{workerFactory:slow.factory,timeoutMs:5}),e=>e.code==='ocr-timeout');assert.equal(slow.state.terminated,1);
});

function nativeFactory(url){assert.equal(url,OCR_ASSETS.worker);const raw=new Worker(require.resolve('tesseract.js/src/worker-script/node/index.js')),adapter={onmessage:null,onerror:null,onmessageerror:null,terminate:()=>raw.terminate(),postMessage(packet){if(packet.action==='loadLanguage')packet.payload.options.langPath=root+'public/chart-match/ocr';raw.postMessage(packet);}};raw.on('message',data=>adapter.onmessage?.({data}));raw.on('error',error=>adapter.onerror?.(error));return adapter;}
test('independent actual Tesseract OCR reads public PNG axis, while incomplete context never silently matches',async t=>{
 const bytes=readFileSync(new URL('../public/chart-match/example.png',import.meta.url)),width=bytes.readUInt32BE(16),height=bytes.readUInt32BE(20),ocr=await recognizeChartText({encoded:bytes,width,height},{workerFactory:nativeFactory});const axis=inferPriceAxis(ocr.words,{width,height});assert.ok(axis.labels.length>=3);assert.ok(axis.pointsPerPixel>0);t.diagnostic(`Real OCR ${ocr.words.length} words, ${axis.labels.length} price labels, ${axis.pointsPerPixel.toFixed(6)} points/pixel`);
 const blank={width,height,data:new Uint8ClampedArray(width*height*4).fill(255)};assert.equal(recognizeChartScreenshot(blank,{words:ocr.words,axis}).valid,false,'OCR text alone cannot manufacture candle pixels');
});

function decodeLocal(path){const p=spawnSync('python',['-c',"from PIL import Image\nimport struct,sys\nim=Image.open(sys.argv[1]).convert('RGBA');sys.stdout.buffer.write(struct.pack('<II',*im.size)+im.tobytes())",path],{maxBuffer:16e6});assert.equal(p.status,0,String(p.stderr));return {width:p.stdout.readUInt32LE(0),height:p.stdout.readUInt32LE(4),data:new Uint8ClampedArray(p.stdout.subarray(8))};}
test('independent real OCR plus actual public screenshot reaches image-only recognition without fixture metadata',async t=>{
 const path=new URL('../public/chart-match/example.png',import.meta.url).pathname,image=decodeLocal(path),bytes=readFileSync(path),ocr=await recognizeChartText({...image,encoded:bytes},{workerFactory:nativeFactory}),axis=inferPriceAxis(ocr.words,image),out=recognizeChartScreenshot(image,{words:ocr.words,axis});
 t.diagnostic(JSON.stringify({valid:out.valid,issues:out.issues,summary:out.summary,gapPoints:out.gapPoints}));assert.equal(out.valid,true,JSON.stringify(out.issues));assert.equal(out.summary.omittedLatest,true);assert.equal(out.candles.length,19);assert.ok(Math.abs(out.gapPoints-44.5)<.5);
});

test('independent time-boundary metadata, optional date warning, and newest-bar exclusion',async t=>{
 const path=new URL('../public/chart-match/example.png',import.meta.url).pathname,image=decodeLocal(path),ocr=await recognizeChartText({...image,encoded:readFileSync(path)},{workerFactory:nativeFactory}),axis=inferPriceAxis(ocr.words,image),baseline=recognizeChartScreenshot(image,{words:ocr.words,axis});assert.equal(baseline.valid,true);
 const mutateWords=fn=>ocr.words.map(w=>({...w,text:fn(w)}));
 const wrongPrior=mutateWords(w=>w.text==='15:10'?'15:05':w.text);assert.equal(recognizeChartScreenshot(image,{words:wrongPrior,axis}).valid,false);
 const noTimes=ocr.words.filter(w=>!/^\d{1,2}:\d{2}$/.test(w.text));const ordered=recognizeChartScreenshot(image,{words:noTimes,axis});assert.equal(ordered.valid,true,JSON.stringify(ordered.issues));assert.equal(ordered.summary.alignmentSource,'ordered-input');assert.equal(ordered.summary.assumedPriorFinal,true);assert.equal(ordered.summary.timezone,null);
 const noTimezone=mutateWords(w=>/Chicago/.test(w.text)?'UTC':w.text);const inferred=recognizeChartScreenshot(image,{words:noTimezone,axis});assert.equal(inferred.valid,true,JSON.stringify(inferred.issues));assert.equal(inferred.summary.alignmentSource,'time-anchors');assert.equal(inferred.summary.timezone,'America/Chicago');
 const noDate=ocr.words.filter(w=>!w.text.includes('2026')),dated=recognizeChartScreenshot(image,{words:noDate,axis});assert.equal(dated.valid,true,JSON.stringify(dated.issues));assert.equal(dated.queryDate,null);assert.ok(dated.issues.some(i=>i.code==='query-date'&&i.severity==='warning'));
 const badType=[...ocr.words,word('logarithmic',100,20)];assert.equal(recognizeChartScreenshot(image,{words:badType,axis}).valid,false);
 const changed={...image,data:new Uint8ClampedArray(image.data)},rect=(x,y,w,h,color)=>{for(let yy=y;yy<y+h;yy++)for(let xx=x;xx<x+w;xx++)changed.data.set([...color,255],(yy*image.width+xx)*4);};rect(853,160,20,80,[255,255,255]);rect(862,170,2,65,[38,166,154]);rect(855,190,15,30,[38,166,154]);
 const next=recognizeChartScreenshot(changed,{words:ocr.words,axis});assert.equal(next.valid,true,JSON.stringify(next.issues));assert.deepEqual(next.candles,baseline.candles);assert.equal(next.gapPoints,baseline.gapPoints);assert.equal(next.config.count,19);assert.ok(next.config.lastX<853);
});

test('independent prior full date cannot silently become the current query date',async()=>{
 const path=new URL('../public/chart-match/example.png',import.meta.url).pathname,image=decodeLocal(path),ocr=await recognizeChartText({...image,encoded:readFileSync(path)},{workerFactory:nativeFactory}),axis=inferPriceAxis(ocr.words,image);
 const words=[word('Prior',10,15),word('2026-10-16',100,15),...ocr.words],out=recognizeChartScreenshot(image,{words,axis});
 assert.notEqual(out.queryDate,'2026-10-16','Prior date was promoted to current date, silently changing earlier-session eligibility');
 if(out.valid&&out.queryDate===null)assert.ok(out.issues.some(i=>i.code==='query-date'&&i.severity==='warning'));
});

test('independent image complexity is rejected before a synchronous geometry stall',()=>{
 const moduleUrl=new URL('../lib/chart-match-auto.mjs',import.meta.url).href;
 const code=`import {recognizeChartScreenshot} from ${JSON.stringify(moduleUrl)};const width=1600,height=1000,data=new Uint8ClampedArray(width*height*4).fill(255);let s=1729;for(let i=0;i<data.length;i+=4){s=(Math.imul(s,1664525)+1013904223)>>>0;if(s&0x80000000)data[i]=data[i+1]=data[i+2]=40;}const words=[{text:'MES1! 5-minute EMA20 Close offset 0 Chicago',confidence:99,bbox:{x0:10,y0:10,x1:500,y1:30}}],axis={valid:true,side:'right',upper:{y:50,price:7900},lower:{y:950,price:7700},axisBounds:{x:1500,width:80}};const out=recognizeChartScreenshot({width,height,data},{words,axis});console.log(JSON.stringify({valid:out.valid,issues:out.issues.map(i=>i.code)}));`;
 const p=spawnSync(process.execPath,['--input-type=module','-e',code],{timeout:4000,encoding:'utf8'});assert.equal(p.status,0,`geometry exceeded bounded work budget: ${p.signal} ${p.error?.code??''}`);const out=JSON.parse(p.stdout);assert.equal(out.valid,false);assert.ok(out.issues.some(code=>/complex|noisy|overlay/.test(code)),JSON.stringify(out));
});

test('independent OCR assets match pinned local source bytes, with no downloaded image fixture',()=>{
 const manifest=JSON.parse(readFileSync(new URL('../public/chart-match/ocr/manifest.json',import.meta.url)));assert.equal(manifest.tesseract,'7.0.0');assert.equal(manifest.core,'7.0.0');assert.equal(manifest.englishData,'1.0.0');
 for(const item of manifest.files){assert.ok(!item.name.includes('..'));const local=readFileSync(new URL('../public/chart-match/ocr/'+item.name,import.meta.url));assert.equal(local.length,item.bytes);assert.equal(createHash('sha256').update(local).digest('hex'),item.sha256);if(item.source.startsWith('node_modules/'))assert.deepEqual(local,readFileSync(new URL('../'+item.source,import.meta.url)));}
});

test('independent Chicago/Eastern and dated UTC-offset alignment do not silently change opening identity',async()=>{
 const path=new URL('../public/chart-match/example.png',import.meta.url).pathname,image=decodeLocal(path),ocr=await recognizeChartText({...image,encoded:readFileSync(path)},{workerFactory:nativeFactory}),axis=inferPriceAxis(ocr.words,image);
 const offset=ocr.words.map(w=>({...w,text:w.text.replace('Chicago','UTC-5')}));const result=recognizeChartScreenshot(image,{words:offset,axis});assert.equal(result.valid,true,JSON.stringify(result.issues));assert.equal(result.summary.timezone,'America/Chicago');
 const missingYear=offset.filter(w=>!w.text.includes('2026')),undated=recognizeChartScreenshot(image,{words:missingYear,axis});assert.equal(undated.valid,true,JSON.stringify(undated.issues));assert.equal(undated.queryDate,null);assert.equal(undated.summary.timezone,'America/Chicago');assert.ok(undated.issues.some(i=>i.code==='query-date'&&i.severity==='warning'));
 const eastern=ocr.words.map(w=>{let text=w.text.replace('Chicago','Eastern');if(/^\d{2}:\d{2}$/.test(text)){const [h,m]=text.split(':');text=String(+h+1).padStart(2,'0')+':'+m;}return {...w,text};});const east=recognizeChartScreenshot(image,{words:eastern,axis});assert.equal(east.valid,true,JSON.stringify(east.issues));assert.equal(east.summary.timezone,'America/New_York');assert.equal(east.gapPoints,result.gapPoints);
});

test('independent unlabeled prior-final requires two coherent prior anchors and every intervening body',()=>{
 const bodies=Array.from({length:13},(_,i)=>({x:30+i*30,width:12})),labels=[{x:30,time:890},{x:90,time:900},{x:180,time:510},{x:330,time:535}],zones=['America/Chicago','America/New_York'];
 const out=inferSessionAnchors(bodies,labels,zones);assert.equal(out.valid,true);assert.equal(out.start,5);assert.equal(out.priorIndex,4);assert.equal(out.priorFinalDirect,false);assert.equal(out.timezone,'America/Chicago');
 assert.equal(inferSessionAnchors(bodies,labels.slice(1),zones).valid,false);assert.equal(inferSessionAnchors(bodies.filter((_,i)=>i!==3),labels,zones).valid,false);assert.equal(inferSessionAnchors(bodies.map((b,i)=>i===3?{...b,x:b.x+8}:b),labels,zones).valid,false);
 const wrong=labels.map((l,i)=>i===1?{...l,time:895}:l);assert.equal(inferSessionAnchors(bodies,wrong,zones).valid,false);
 const east=inferSessionAnchors(bodies,labels.map(l=>({...l,time:l.time+60})),zones);assert.equal(east.valid,true);assert.equal(east.timezone,'America/New_York');
});
