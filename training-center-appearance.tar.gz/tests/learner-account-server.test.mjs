import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {randomUUID} from 'node:crypto';
import {PGlite} from '@electric-sql/pglite';
import {LearnerRepository} from '../lib/learner/repository.mjs';
import {createLearnerService} from '../lib/learner/server.mjs';
import {createChartResolver} from '../lib/learner/charts.mjs';
import {handleLearnerRequest} from '../lib/learner/runtime.mjs';
const origin='https://learner.test',time=Date.parse('2026-10-30T12:00:00.000Z'),issuer='https://auth.learner.test',secret='test-only-csrf-secret-at-least-thirty-two-bytes';
const catalog=JSON.parse(await fs.readFile(new URL('../public/charts/catalog.json',import.meta.url))),reference=catalog.sessions[0];
const principal=(name='Ari',session='session-abcdefghijklmnop')=>({issuer,subject:name.toLowerCase(),name,sessionId:session,expiresAt:time+86400000,emailVerified:true});
const attempt=(extra={})=>({version:1,id:randomUUID(),module:'market-direction',chartId:reference.id,chartSha256:reference.sha256,startedAt:'2026-10-30T10:00:00.000Z',completedAt:'2026-10-30T10:01:00.000Z',practice:{run:{version:1,choices:[{bar:0,direction:1},{bar:1,direction:1},{bar:2,direction:1},{bar:3,direction:-1}],practiceCutoff:4},finalBar:4},...extra});
async function setup(options={}){
 const db=new PGlite();await db.exec(await fs.readFile(new URL('../migrations/006_learner_accounts.sql',import.meta.url),'utf8'));
 const repository=new LearnerRepository({transaction:fn=>db.transaction(tx=>fn({query:(sql,args)=>tx.query(sql,args)}))});
 let identity=principal(),now=time,resolves=0;
 const handler=createLearnerService({origin,repository,identityProvider:{issuer,resolve:async()=>{resolves++;return identity}},csrfSecret:secret,charts:options.charts||createChartResolver(),now:()=>now});
 async function request(path,method='GET',value,headers={}){const req=new Request(origin+'/api/learner/'+path,{method,headers:{host:'learner.test','sec-fetch-site':'same-origin',...(method==='POST'?{origin,'content-type':'application/json'}:{}),...headers},...(value===undefined?{}:{body:JSON.stringify(value)})});const response=await handler(req);return{status:response.status,body:await response.json(),headers:response.headers};}
 const login=()=>request('session');
 const post=(path,session,value={})=>request(path,'POST',{context:session.context,...value},{'x-csrf-token':session.csrfToken});
 return{db,repository,handler,request,login,post,setIdentity:v=>identity=v,setNow:v=>now=v,get resolves(){return resolves},close:()=>db.close()};
}

test('unconfigured runtime fails closed; verified guest does no account/session/history writes',async()=>{
 const response=await handleLearnerRequest(new Request(origin+'/api/learner/session'));assert.equal(response.status,503);assert.equal((await response.json()).authConfigured,false);
 const s=await setup();try{s.setIdentity(null);assert.deepEqual((await s.login()).body,{mode:'guest',authConfigured:true,profile:null});assert.equal((await s.request('attempts')).status,401);for(const table of ['accounts','sessions','attempts'])assert.equal((await s.db.query(`SELECT count(*)::int AS n FROM learner_app.${table}`)).rows[0].n,0);}finally{await s.close();}
});

test('verified provider identity maps one opaque account, independent sessions and no teacher identity acceptance',async()=>{
 const s=await setup();try{const a=(await s.login()).body;assert.equal(a.mode,'account');assert.notEqual(a.profile.id,'ari');assert.equal(a.profile.name,'Ari');assert.equal(a.context.accountId,a.profile.id);assert.match(a.csrfToken,/^[a-f0-9]{64}$/);const again=(await s.login()).body;assert.equal(a.profile.id,again.profile.id);assert.equal(s.resolves,2);
 s.setIdentity(principal('Ari','different-live-session-id'));const next=(await s.login()).body;assert.equal(next.profile.id,a.profile.id);assert.notEqual(next.context.sessionTag,a.context.sessionTag);assert.notEqual(next.csrfToken,a.csrfToken);
 for(const p of [{...principal(),issuer:'https://teacher.test'},{...principal(),emailVerified:false},{...principal(),expiresAt:time},{...principal(),sessionId:'short'}]){s.setIdentity(p);assert.equal((await s.login()).status,401);}
 assert.equal((await s.db.query('SELECT count(*)::int AS n FROM learner_app.accounts')).rows[0].n,1);}finally{await s.close();}
});

test('origin/host/CSRF/body owner checks reject cross-site and cross-user writes before mutation',async()=>{
 const s=await setup();try{const a=(await s.login()).body;for(const headers of [{origin:'https://evil.test'},{host:'evil.test'},{'sec-fetch-site':'cross-site'},{'x-csrf-token':'wrong'}]){const r=await s.request('attempts','POST',{context:a.context,attempt:attempt()},{'x-csrf-token':a.csrfToken,...headers});assert.equal(r.status,403);}
 s.setIdentity(principal('Bo'));const b=(await s.login()).body;assert.equal((await s.post('attempts',b,{context:a.context,attempt:attempt()})).status,409);assert.equal((await s.post('attempts',b,{attempt:attempt(),accountId:a.profile.id})).status,400);assert.equal((await s.db.query('SELECT count(*)::int AS n FROM learner_app.attempts')).rows[0].n,0);}finally{await s.close();}
});

test('completed decisions are recomputed against hash-pinned chart, immutable and idempotent',async()=>{
 const s=await setup();try{const session=(await s.login()).body,value=attempt();const first=await s.post('attempts',session,{attempt:value});assert.equal(first.status,201,JSON.stringify(first.body));assert.equal(first.body.duplicate,false);assert.equal(first.body.attempt.summary.scored,1);const retry=await s.post('attempts',session,{attempt:value});assert.equal(retry.body.duplicate,true);assert.deepEqual(retry.body.attempt,first.body.attempt);
 const other=structuredClone(value);other.practice.run.choices[0].direction=-1;assert.equal((await s.post('attempts',session,{attempt:other})).status,409);
 assert.equal((await s.post('attempts',session,{attempt:{...attempt(),summary:{accuracy:1}}})).status,400);assert.equal((await s.post('attempts',session,{attempt:attempt({chartSha256:'0'.repeat(64)})})).status,409);
 const progress=(await s.request('progress')).body.progress;assert.equal(progress.completedAttempts,1);assert.equal(progress.direction.practicedIntervals,3);assert.equal(progress.skillScore,null);assert.equal(progress.direction.netAlignedPoints,first.body.attempt.summary.netAlignedPoints);assert.equal('accuracy' in progress.direction,false);
 const detail=await s.request('attempts/'+value.id);assert.deepEqual(detail.body.attempt.practice,value.practice);assert.equal('candles'in detail.body.attempt,false);const exported=(await s.request('export')).body;assert.equal(exported.attempts.length,1);assert.equal(exported.profile.id,session.profile.id);}finally{await s.close();}
});

test('Trade user action replay computes points; rejects malformed/oversized/noncausal inputs',async()=>{
 const s=await setup();try{const session=(await s.login()).body,chart=await createChartResolver()(reference.id,reference.sha256),bars=chart.current.slice(0,3),entry=Math.ceil(Math.max(...bars.map(b=>b.h))*4)/4+.25,stop=Math.floor(Math.min(...bars.map(b=>b.l))*4)/4-10;
 const value=attempt({module:'trade-simulator',practice:{finalBar:2,actions:[{kind:'place',bar:0,bracket:{side:'buy',entry,stop,target:entry+100}},{kind:'close',bar:1}]}});const r=await s.post('attempts',session,{attempt:value});assert.equal(r.status,201,JSON.stringify(r.body));assert.equal(r.body.attempt.summary.trades,1);assert.equal(r.body.attempt.summary.netPoints,Number((bars[1].c-bars[1].o).toFixed(10)));
 for(const practice of [{finalBar:0,actions:[{kind:'close',bar:0}]},{finalBar:1,actions:[{kind:'place',bar:2,bracket:{side:'buy',entry,stop,target:entry+100}}]},{finalBar:2,actions:[],currentCandle:bars[0]},{finalBar:2,actions:Array(513).fill({kind:'cancel',bar:0})}])assert.equal((await s.post('attempts',session,{attempt:attempt({module:'trade-simulator',practice})})).status,400);
 assert.equal((await s.request('attempts','POST',{context:session.context,attempt:attempt(),padding:'x'.repeat(65536)},{'x-csrf-token':session.csrfToken})).status,413);}finally{await s.close();}
});

test('all history detail/list/progress/export reads stay with the current server owner',async()=>{
 const s=await setup();try{const a=(await s.login()).body,value=attempt();await s.post('attempts',a,{attempt:value});s.setIdentity(principal('Bo'));const b=(await s.login()).body;assert.notEqual(a.profile.id,b.profile.id);assert.equal((await s.request('attempts/'+value.id)).status,404);assert.deepEqual((await s.request('attempts')).body.attempts,[]);assert.equal((await s.request('progress')).body.progress.completedAttempts,0);assert.equal((await s.request('export')).body.attempts.length,0);assert.equal((await s.request('attempts?accountId='+a.profile.id)).status,400);}finally{await s.close();}
});

test('history pagination is bounded/stable and caps never prune existing attempts',async()=>{
 const s=await setup();try{const session=(await s.login()).body;for(let i=0;i<3;i++){s.setNow(time+i);await s.post('attempts',session,{attempt:attempt()});}const first=(await s.request('attempts?limit=2')).body;assert.equal(first.attempts.length,2);assert(first.nextCursor);const second=(await s.request('attempts?limit=2&cursor='+first.nextCursor)).body;assert.equal(second.attempts.length,1);assert.equal(second.nextCursor,null);assert(!first.attempts.some(x=>x.id===second.attempts[0].id));assert.equal((await s.request('attempts?limit=100')).status,400);assert.equal((await s.request('attempts?cursor=invalid')).status,400);
 await s.db.query('UPDATE learner_app.accounts SET attempt_count=1000 WHERE id=$1',[session.profile.id]);const failed=await s.post('attempts',session,{attempt:attempt()});assert.equal(failed.status,409);assert.equal(failed.body.code,'history_limit');assert.match(failed.body.error,/Nothing was pruned/);assert.equal((await s.request('export')).body.attempts.length,3);}finally{await s.close();}
});

test('reset is typed, owner/session/generation bound, atomic and retry-safe; old writes cannot resurrect history',async()=>{
 const s=await setup();try{const session=(await s.login()).body,value=attempt();await s.post('attempts',session,{attempt:value});const intent=(await s.post('reset-intent',session)).body,reset={token:intent.token,confirmation:'RESET MY HISTORY',requestId:randomUUID()};
 assert.equal((await s.post('reset',session,{...reset,confirmation:'reset'})).status,400);assert.equal((await s.request('progress')).body.progress.completedAttempts,1);
 const done=await s.post('reset',session,reset);assert.equal(done.status,200);assert.equal(done.body.context.generation,2);assert.equal(done.body.profile.id,session.profile.id);assert.equal((await s.request('progress')).body.progress.completedAttempts,0);
 const retry=await s.post('reset',session,reset);assert.deepEqual(retry.body,done.body);assert.equal((await s.post('attempts',session,{attempt:value})).status,409);assert.equal((await s.post('reset',session,{...reset,requestId:randomUUID()})).status,409);const current=(await s.login()).body;assert.equal(current.profile.generation,2);assert.equal((await s.request('export')).body.attempts.length,0);
 s.setIdentity(principal('Bo'));const bo=(await s.login()).body;assert.equal((await s.post('reset',bo,{...reset,context:session.context})).status,409);}finally{await s.close();}
});

test('expired reset tokens and stale sessions fail without deleting records; logout revokes old API access',async()=>{
 const s=await setup();try{const session=(await s.login()).body;await s.post('attempts',session,{attempt:attempt()});const intent=(await s.post('reset-intent',session)).body;s.setNow(time+6*60*1000);assert.equal((await s.post('reset',session,{token:intent.token,confirmation:'RESET MY HISTORY',requestId:randomUUID()})).status,409);assert.equal((await s.request('progress')).body.progress.completedAttempts,1);
 const out=await s.post('logout',session);assert.equal(out.body.signedOut,true);assert.equal((await s.login()).status,401);assert.equal((await s.request('export')).status,401);assert.equal((await s.post('attempts',session,{attempt:attempt()})).status,401);
 s.setIdentity(principal('Ari','new-provider-session-after-logout'));const newSession=(await s.login()).body;assert.equal(newSession.profile.id,session.profile.id);assert.equal((await s.request('progress')).body.progress.completedAttempts,1);}finally{await s.close();}
});

test('an in-flight validated save arriving after logout is rejected under the account/session lock',async()=>{
 let release;const real=createChartResolver(),wait=new Promise(r=>release=r),s=await setup({charts:async(...args)=>{await wait;return real(...args)}});try{const session=(await s.login()).body,pending=s.post('attempts',session,{attempt:attempt()});await new Promise(r=>setTimeout(r,0));assert.equal((await s.post('logout',session)).status,200);release();assert.equal((await pending).status,401);assert.equal((await s.db.query('SELECT count(*)::int AS n FROM learner_app.attempts')).rows[0].n,0);}finally{release();await s.close();}
});

test('an in-flight save arriving after reset rejects stale generation; other account records survive reset',async()=>{
 let slow=false,release;const real=createChartResolver(),wait=new Promise(r=>release=r),s=await setup({charts:async(...args)=>{if(slow)await wait;return real(...args)}});try{const ari=(await s.login()).body;await s.post('attempts',ari,{attempt:attempt()});s.setIdentity(principal('Bo'));const bo=(await s.login()).body;await s.post('attempts',bo,{attempt:attempt()});s.setIdentity(principal());slow=true;const pending=s.post('attempts',ari,{attempt:attempt()});await new Promise(r=>setTimeout(r,0));const intent=(await s.post('reset-intent',ari)).body;assert.equal((await s.post('reset',ari,{token:intent.token,confirmation:'RESET MY HISTORY',requestId:randomUUID()})).status,200);release();assert.equal((await pending).status,409);s.setIdentity(principal('Bo'));assert.equal((await s.request('progress')).body.progress.completedAttempts,1);}finally{release();await s.close();}
});

test('MD early Finish preserves configured-final points/closed legs while accuracy stops at practiced cutoff',async()=>{
 const s=await setup();try{const session=(await s.login()).body,chart=await createChartResolver()(reference.id,reference.sha256),value=attempt({practice:{run:{version:1,startBar:4,choices:[{bar:4,direction:1},{bar:5,direction:-1}],practiceCutoff:6},finalBar:10}});const r=await s.post('attempts',session,{attempt:value});assert.equal(r.status,201);const score=r.body.attempt.summary;assert.equal(score.scored,0);assert.equal(score.accuracy,null);assert.equal(score.practiceCutoff,6);assert.equal(score.finalBar,10);assert.equal(score.fullMoves,5);const expected=(chart.current[5].c-chart.current[4].c)-(chart.current[9].c-chart.current[5].c);assert.equal(score.netAlignedPoints,expected);assert.equal(score.legs.length,2);assert.equal(score.legs[0].entryIndex,4);assert.equal(score.legs[0].exitIndex,5);assert.equal(score.legs[1].exitIndex,9);assert.equal(score.legs.reduce((n,x)=>n+x.points,0),expected);
 }finally{await s.close();}
});

test('module-filtered history is parameterized, per-owner and bounded to 50',async()=>{
 const s=await setup();try{const session=(await s.login()).body;await s.post('attempts',session,{attempt:attempt()});assert.equal((await s.request('attempts?module=market-direction&limit=50')).body.attempts.length,1);assert.equal((await s.request('attempts?module=trade-simulator')).body.attempts.length,0);assert.equal((await s.request('attempts?module=admin')).status,400);assert.equal((await s.request('attempts?limit=51')).status,400);assert.equal((await s.request('attempts?module='+encodeURIComponent("';DROP TABLE learner_app.accounts;--"))).status,400);s.setIdentity(principal('Bo'));await s.login();assert.equal((await s.request('attempts?module=market-direction')).body.attempts.length,0);}finally{await s.close();}
});

 test('current PE v2 explicit Neutral closes signed legs, preserves Finish carry and never invents exposure',async()=>{
 const s=await setup();try{const session=(await s.login()).body,chart=await createChartResolver()(reference.id,reference.sha256);
 for(const last of [0,1,-1]){const run={version:2,startBar:4,choices:[{bar:4,direction:1},{bar:5,direction:0},{bar:6,direction:last}],practiceCutoff:7},value=attempt({practice:{run,finalBar:10}});const saved=await s.post('attempts',session,{attempt:value});assert.equal(saved.status,201,JSON.stringify(saved.body));const score=saved.body.attempt.summary;
 const expected=chart.current[5].c-chart.current[4].c+last*(chart.current[9].c-chart.current[6].c);assert.equal(score.netAlignedPoints,expected);assert.equal(score.practicedIntervals,2);assert.equal(score.practicedLongIntervals,1);assert.equal(score.practicedNeutralIntervals,1);assert.equal(score.practicedShortIntervals,0);assert.equal(score.legs.length,last===0?1:2);assert.equal(score.legs[0].exitIndex,5);if(last!==0){assert.equal(score.legs[1].entryIndex,6);assert.equal(score.legs[1].exitIndex,9);}assert.equal('accuracy' in score,false);assert.deepEqual(score.practiceEvidence,{...run,evaluatedThrough:7});assert.equal((await s.post('attempts',session,{attempt:value})).body.duplicate,true);}
 for(const run of [{version:1,startBar:0,choices:[{bar:0,direction:0}],practiceCutoff:1},{version:2,choices:[{bar:0,direction:0}],practiceCutoff:1},{version:2,startBar:0,choices:[{bar:0,direction:0},{bar:2,direction:1}],practiceCutoff:3}])assert.equal((await s.post('attempts',session,{attempt:attempt({practice:{run,finalBar:10}})})).status,400);
 const neutral={version:2,startBar:4,choices:[{bar:4,direction:0}],practiceCutoff:5},r=await s.post('attempts',session,{attempt:attempt({practice:{run:neutral,finalBar:81}})});assert.equal(r.body.attempt.summary.netAlignedPoints,0);assert.equal(r.body.attempt.summary.practicedIntervals,0);assert.equal(r.body.attempt.summary.legs.length,0);
 }finally{await s.close();}
});

test('Equal TP/SL is server-owned per account, cross-session persistent, guarded and retained by history reset',async()=>{
 const s=await setup();try{const ari=(await s.login()).body;assert.deepEqual(ari.preferences,{appearance:'dark',equalTpSl:false});assert.equal((await s.post('preferences',ari,{equalTpSl:true})).status,200);s.setIdentity(principal('Ari','second-device-session-abcdefghijklmnop'));const device=(await s.login()).body;assert.deepEqual(device.preferences,{appearance:'dark',equalTpSl:true});s.setIdentity(principal('Bo'));const bo=(await s.login()).body;assert.deepEqual(bo.preferences,{appearance:'dark',equalTpSl:false});assert.equal((await s.post('preferences',bo,{context:ari.context,equalTpSl:false})).status,409);assert.equal((await s.post('preferences',bo,{equalTpSl:'yes'})).status,400);
 s.setIdentity(principal());const intent=(await s.post('reset-intent',ari)).body;assert.equal((await s.post('reset',ari,{token:intent.token,confirmation:'RESET MY HISTORY',requestId:randomUUID()})).status,200);assert.equal((await s.post('preferences',ari,{equalTpSl:false})).status,409);const fresh=(await s.login()).body;assert.deepEqual(fresh.preferences,{appearance:'dark',equalTpSl:true});assert.equal((await s.post('preferences',fresh,{equalTpSl:false})).status,200);assert.deepEqual((await s.login()).body.preferences,{appearance:'dark',equalTpSl:false});
 }finally{await s.close();}
});

test('Market Direction progress uses first saved completion per chart; replay attempts stay distinct',async()=>{
 const s=await setup();try{const account=(await s.login()).body,first=attempt(),replay=attempt({practice:{run:{version:2,startBar:0,choices:[{bar:0,direction:0},{bar:1,direction:0}],practiceCutoff:2},finalBar:81}});const a=await s.post('attempts',account,{attempt:first});s.setNow(time+1);const b=await s.post('attempts',account,{attempt:replay});assert.equal(a.status,201);assert.equal(b.status,201);const p=(await s.request('progress')).body.progress;assert.equal(p.completedAttempts,2);assert.equal(p.byModule['market-direction'],2);assert.equal(p.direction.completedSessions,1);assert.equal(p.direction.netAlignedPoints,a.body.attempt.summary.netAlignedPoints);assert.equal((await s.request('export')).body.attempts.length,2);
 const bytes=(await s.db.query('SELECT storage_bytes FROM learner_app.accounts WHERE id=$1',[account.profile.id])).rows[0].storage_bytes;const rows=(await s.db.query('SELECT payload_bytes FROM learner_app.attempts WHERE account_id=$1',[account.profile.id])).rows;assert.equal(bytes,rows.reduce((sum,r)=>sum+r.payload_bytes,0));assert(bytes>JSON.stringify(first).length+JSON.stringify(replay).length,'quota includes recomputed summaries as well as payloads');
 }finally{await s.close();}
});
