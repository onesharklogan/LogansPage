import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {readLocalChartImage,imagePoint} from '../components/chart-match-input.mjs';

const file=(change={})=>({type:'image/png',size:1024,...change});
const deferred=()=>{let resolve,reject;const promise=new Promise((yes,no)=>{resolve=yes;reject=no;});return {promise,resolve,reject};};
function environment(options={}){
 const original=new Map(),savedUrl={create:URL.createObjectURL,revoke:URL.revokeObjectURL};
 const calls={created:[],revoked:[],decoded:[],closed:[],drawn:[],read:[],images:[],network:0,storage:0},pixels=new Uint8ClampedArray([38,166,154,255]);
 const put=(key,value)=>{original.set(key,Object.getOwnPropertyDescriptor(globalThis,key));Object.defineProperty(globalThis,key,{configurable:true,writable:true,value});};
 const bitmap=(width=1000,height=620)=>({width,height,close(){calls.closed.push(this);}});
 URL.createObjectURL=value=>{const url=`blob:local-${calls.created.length+1}`;calls.created.push({url,file:value});if(options.urlError)throw options.urlError;return url;};
 URL.revokeObjectURL=url=>calls.revoked.push(url);
 put('createImageBitmap',options.fallback?undefined:(value)=>{calls.decoded.push(value);return options.decode?options.decode(value):Promise.resolve(bitmap(options.width??1000,options.height??620));});
 put('Image',class {constructor(){calls.images.push(this);this.width=options.width??1000;this.height=options.height??620;}set src(value){this.source=value;if(options.autoImage==='success')queueMicrotask(()=>this.onload());else if(options.autoImage==='error')queueMicrotask(()=>this.onerror());}});
 const context={drawImage(...args){calls.drawn.push(args);if(options.drawError)throw options.drawError;},getImageData(...args){calls.read.push(args);options.onRead?.();if(options.readError)throw options.readError;return {data:pixels};}};
 put('document',{createElement(tag){assert.equal(tag,'canvas');if(options.canvasError)throw options.canvasError;return {width:0,height:0,getContext(kind,configuration){assert.equal(kind,'2d');assert.deepEqual(configuration,{willReadFrequently:true});return options.noContext?null:context;}};}});
 put('fetch',()=>{calls.network++;throw Error('Screenshot bytes must remain local.');});
 for(const key of ['localStorage','sessionStorage']){original.set(key,Object.getOwnPropertyDescriptor(globalThis,key));Object.defineProperty(globalThis,key,{configurable:true,get(){calls.storage++;throw Error('Image loading must not read/write browser storage.');}});}
 return {calls,pixels,bitmap,restore(){URL.createObjectURL=savedUrl.create;URL.revokeObjectURL=savedUrl.revoke;for(const [key,descriptor]of original){if(descriptor)Object.defineProperty(globalThis,key,descriptor);else delete globalThis[key];}}};
}
async function using(options,fn){const env=environment(options);try{return await fn(env);}finally{env.restore();}}

test('local input accepts PNG/JPEG/WebP and returns exact canvas pixels with idempotent URL ownership',async()=>{
 for(const type of ['image/png','image/jpeg','image/webp'])await using({},async({calls,pixels})=>{const input=file({type}),result=await readLocalChartImage(input);assert.equal(result.width,1000);assert.equal(result.height,620);assert.equal(result.data,pixels);assert.equal(result.url,'blob:local-1');assert.deepEqual(calls.decoded,[input]);assert.equal(calls.drawn.length,1);assert.deepEqual(calls.read,[[0,0,1000,620]]);assert.equal(calls.closed.length,1);assert.deepEqual(calls.revoked,[]);result.dispose();result.dispose();assert.deepEqual(calls.revoked,['blob:local-1']);assert.equal(calls.closed.length,1);assert.equal(calls.network,0);assert.equal(calls.storage,0);});
});

test('unsupported MIME and zero/nonfinite/oversize bytes are rejected before allocating an object URL',async()=>{
 await using({},async({calls})=>{for(const input of [null,undefined,file({type:'image/svg+xml'}),file({type:'image/gif'}),file({type:'text/html'}),file({type:'IMAGE/PNG'}),file({type:''}),file({size:0}),file({size:-1}),file({size:NaN}),file({size:Infinity}),file({size:'1024'}),file({size:20*1024*1024+1})])await assert.rejects(readLocalChartImage(input),/PNG, JPEG or WebP/);assert.deepEqual(calls.created,[]);assert.deepEqual(calls.decoded,[]);});
 await using({},async({calls})=>{for(const size of [1,20*1024*1024]){const r=await readLocalChartImage(file({size}));r.dispose();}assert.equal(calls.created.length,2);assert.equal(calls.revoked.length,2);});
});

test('bitmap dimension bounds fail closed and always close/revoke the decoded resource',async()=>{
 for(const [width,height]of [[239,160],[240,159],[0,620],[1000,0],[NaN,620],[1000,Infinity],[240.5,620],[1000,160.5],[8001,160],[240,8001],[4000,3001]])await using({width,height},async({calls})=>{await assert.rejects(readLocalChartImage(file()),/240 × 160/);assert.equal(calls.closed.length,1);assert.deepEqual(calls.revoked,['blob:local-1']);assert.deepEqual(calls.drawn,[]);});
 for(const [width,height]of [[240,160],[8000,160],[240,8000],[4000,3000]])await using({width,height},async({calls})=>{const result=await readLocalChartImage(file());assert.equal(result.width,width);assert.equal(result.height,height);result.dispose();assert.equal(calls.closed.length,1);assert.deepEqual(calls.revoked,['blob:local-1']);});
});

test('decode and canvas failure paths revoke URLs, and decoded bitmaps close once',async()=>{
 const decodeError=Error('bad image');await using({decode:()=>Promise.reject(decodeError)},async({calls})=>{await assert.rejects(readLocalChartImage(file()),error=>error===decodeError);assert.deepEqual(calls.closed,[]);assert.deepEqual(calls.revoked,['blob:local-1']);});
 for(const options of [{canvasError:Error('canvas denied')},{noContext:true},{drawError:Error('draw failed')},{readError:Error('pixels unavailable')}])await using(options,async({calls})=>{await assert.rejects(readLocalChartImage(file()));assert.equal(calls.closed.length,1);assert.deepEqual(calls.revoked,['blob:local-1']);});
 await using({urlError:Error('object URLs unavailable')},async({calls})=>{await assert.rejects(readLocalChartImage(file()),/object URLs unavailable/);assert.deepEqual(calls.decoded,[]);assert.deepEqual(calls.revoked,[]);});
});

test('abort before decode allocates nothing; abort during decode or pixel read closes and revokes',async()=>{
 const early=new AbortController();early.abort();await using({},async({calls})=>{await assert.rejects(readLocalChartImage(file(),{signal:early.signal}),{name:'AbortError'});assert.deepEqual(calls.created,[]);});
 const loading=new AbortController(),gate=deferred();await using({decode:()=>gate.promise},async({calls,bitmap})=>{const pending=readLocalChartImage(file(),{signal:loading.signal});loading.abort();gate.resolve(bitmap());await assert.rejects(pending,{name:'AbortError'});assert.equal(calls.closed.length,1);assert.deepEqual(calls.revoked,['blob:local-1']);assert.deepEqual(calls.drawn,[]);});
 const reading=new AbortController();await using({onRead:()=>reading.abort()},async({calls})=>{await assert.rejects(readLocalChartImage(file(),{signal:reading.signal}),{name:'AbortError'});assert.equal(calls.closed.length,1);assert.deepEqual(calls.revoked,['blob:local-1']);});
});

test('Image fallback decodes only the local blob URL and handles rejection, dimensions and abort',async()=>{
 await using({fallback:true,autoImage:'success'},async({calls,pixels})=>{const result=await readLocalChartImage(file());assert.equal(result.data,pixels);assert.equal(calls.images[0].source,'blob:local-1');assert.deepEqual(calls.decoded,[]);assert.deepEqual(calls.closed,[]);result.dispose();assert.deepEqual(calls.revoked,['blob:local-1']);assert.equal(calls.network,0);});
 await using({fallback:true,autoImage:'error'},async({calls})=>{await assert.rejects(readLocalChartImage(file()),/could not be decoded/);assert.deepEqual(calls.revoked,['blob:local-1']);});
 await using({fallback:true,autoImage:'success',width:100},async({calls})=>{await assert.rejects(readLocalChartImage(file()),/240 × 160/);assert.deepEqual(calls.revoked,['blob:local-1']);});
 const controller=new AbortController();await using({fallback:true},async({calls})=>{const pending=readLocalChartImage(file(),{signal:controller.signal});controller.abort();calls.images[0].onload();await assert.rejects(pending,{name:'AbortError'});assert.deepEqual(calls.revoked,['blob:local-1']);assert.deepEqual(calls.drawn,[]);});
});

test('replacing an in-flight image cannot revoke the newer image or transfer old pixel ownership',async()=>{
 const oldController=new AbortController(),first=deferred();let decodeCount=0;
 await using({decode:()=>++decodeCount===1?first.promise:Promise.resolve({width:800,height:400,close(){}})},async({calls,bitmap})=>{const old=readLocalChartImage(file(),{signal:oldController.signal});oldController.abort();const replacement=await readLocalChartImage(file({type:'image/jpeg'}));assert.equal(replacement.url,'blob:local-2');assert.equal(replacement.width,800);assert.deepEqual(calls.revoked,[]);first.resolve(bitmap());await assert.rejects(old,{name:'AbortError'});assert.deepEqual(calls.revoked,['blob:local-1']);replacement.dispose();assert.deepEqual(calls.revoked,['blob:local-1','blob:local-2']);});
 await using({},async({calls})=>{const a=await readLocalChartImage(file()),b=await readLocalChartImage(file());a.dispose();assert.deepEqual(calls.revoked,['blob:local-1']);b.dispose();assert.deepEqual(calls.revoked,['blob:local-1','blob:local-2']);});
});

test('CSS-scaled image points map exact bitmap coordinates across portrait/desktop scales',()=>{
 for(const [width,height]of [[240,160],[1000,620],[3840,2160]])for(const cssWidth of [240,320,375,430,1000,1920]){const rect={left:17.25,top:82.5,width:cssWidth,height:cssWidth*height/width};assert.deepEqual(imagePoint(rect.left,rect.top,rect,width,height),{x:0,y:0});assert.deepEqual(imagePoint(rect.left+rect.width*.5,rect.top+rect.height*.5,rect,width,height),{x:Math.round(width*.5),y:Math.round(height*.5)});assert.deepEqual(imagePoint(rect.left+rect.width-1e-7,rect.top+rect.height-1e-7,rect,width,height),{x:width-1,y:height-1});assert.equal(imagePoint(rect.left+rect.width,rect.top,rect,width,height),null);assert.equal(imagePoint(rect.left,rect.top+rect.height,rect,width,height),null);assert.equal(imagePoint(rect.left-.001,rect.top,rect,width,height),null);assert.equal(imagePoint(rect.left,rect.top-.001,rect,width,height),null);}
});

test('imagePoint rejects nonfinite or empty geometry rather than returning invalid preview coordinates',()=>{
 const rect={left:10,top:20,width:500,height:310};for(const v of [NaN,Infinity,-Infinity,undefined,null,'100']){assert.equal(imagePoint(v,20,rect,1000,620),null);assert.equal(imagePoint(10,v,rect,1000,620),null);for(const key of ['left','top','width','height'])assert.equal(imagePoint(10,20,{...rect,[key]:v},1000,620),null);assert.equal(imagePoint(10,20,rect,v,620),null);assert.equal(imagePoint(10,20,rect,1000,v),null);}assert.equal(imagePoint(10,20,null,1000,620),null);for(const value of [0,-1]){assert.equal(imagePoint(10,20,{...rect,width:value},1000,620),null);assert.equal(imagePoint(10,20,{...rect,height:value},1000,620),null);assert.equal(imagePoint(10,20,rect,value,620),null);assert.equal(imagePoint(10,20,rect,1000,value),null);}
});

test('input module contains no network/storage transport or source-image upload path',()=>{
 const source=readFileSync(new URL('../components/chart-match-input.mjs',import.meta.url),'utf8');assert.doesNotMatch(source,/\b(?:fetch|XMLHttpRequest|WebSocket|sendBeacon|localStorage|sessionStorage|indexedDB|FormData)\b/);assert.match(source,/URL\.createObjectURL\(file\)/);assert.match(source,/getImageData/);
});
