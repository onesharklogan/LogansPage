import test from 'node:test';
import assert from 'node:assert/strict';
import {placementPoint,replayPoint,replayViewport,initialView,tradeReviewMarks} from '../lib/trade-simulator-view.mjs';
const chart={prior:Array.from({length:12},()=>({o:100,h:102,l:98,c:100})),current:Array.from({length:81},(_,i)=>({o:100+i,h:104+i,l:96+i,c:100+i}))};
const near=(a,b)=>assert.ok(Math.abs(a-b)<1e-8,`${a} != ${b}`);
test('placement guide and entry share one quarter-tick candidate under screen scaling and price pan/zoom',()=>{
 let cases=0;for(const width of [280,390,900])for(const height of [220,440,850])for(const scale of [.5,1,2])for(const nav of [initialView(),{...initialView(),priceCenter:130,priceSpan:9,xZoom:2,follow:false,offset:3}]){
 const v=replayViewport(chart,25,[],width,height,nav),bounds={left:43,top:120,width:width*scale,height:height*scale},before=JSON.stringify(v);
 for(const xf of [0,.3,.8,1])for(const yf of [0,.01,.4,.999,1]){const x=v.left+xf*(width-v.left-v.right)-(xf===1?.000001:0),y=v.top+yf*(height-v.top-v.bottom),p=placementPoint(bounds.left+x*scale,bounds.top+y*scale,bounds,v);assert.ok(p);assert.equal(p.price%0.25,0);assert.ok(p.price>=v.lo&&p.price<=v.hi);near(p.x,x);near(p.y,replayPoint(0,p.price,v).y);assert.equal(p.right,width-v.right);assert.ok(p.label.x>=v.left&&p.label.x+p.label.width<=p.right);assert.ok(p.label.y>=v.top&&p.label.y+p.label.height<=height-v.bottom);assert.deepEqual(p,placementPoint(bounds.left+x*scale,bounds.top+y*scale,bounds,v));cases++;}
 assert.equal(JSON.stringify(v),before);
 }assert.equal(cases,1080);
});
test('placement does not clamp outside plot into accidental orders; malformed bounds and axis contacts rejected',()=>{
 const v=replayViewport(chart,5,[],390,440),bounds={left:0,top:0,width:390,height:440};for(const [x,y] of [[0,100],[389,100],[100,0],[100,439],[-1,-1],[NaN,100],[100,Infinity]])assert.equal(placementPoint(x,y,bounds,v),null);
 assert.equal(placementPoint(100,100,{...bounds,height:0},v),null);assert.equal(placementPoint(100,100,bounds,{...v,hi:v.lo}),null);
});
test('completed trade labels use actual fills, signed results and prior/current slot mapping, never future trades',()=>{
 const v=replayViewport(chart,15,[],900,440),trades=[{id:1,entryIndex:1,exitIndex:4,entryPrice:101,exitPrice:113,points:12,side:'buy'},{id:2,entryIndex:5,exitIndex:7,entryPrice:106,exitPrice:108.5,points:-2.5,side:'sell'},{id:3,entryIndex:8,exitIndex:9,entryPrice:109,exitPrice:109,points:0,side:'buy'}],before=JSON.stringify(trades),marks=tradeReviewMarks(trades,v);
 assert.deepEqual(marks.map(m=>m.text),['+12 points','-2.5 points','0 points']);for(let i=0;i<trades.length;i++){assert.deepEqual(marks[i].entry,replayPoint(12+trades[i].entryIndex,trades[i].entryPrice,v));assert.deepEqual(marks[i].exit,replayPoint(12+trades[i].exitIndex,trades[i].exitPrice,v));}
 assert.equal(JSON.stringify(trades),before);assert.equal(tradeReviewMarks([{...trades[0],exitIndex:16}],v).length,0);assert.equal(tradeReviewMarks([{...trades[0],points:NaN}],v).length,0);
});
test('dense review labels stay bounded while chart pan changes positions but never actual points',()=>{
 const trades=Array.from({length:10},(_,i)=>({id:i+1,entryIndex:i,exitIndex:i+1,entryPrice:101,exitPrice:103,points:i%2?-2:2,side:i%2?'sell':'buy'}));
 for(const width of [280,390,900]){const v=replayViewport(chart,20,[],width,440),marks=tradeReviewMarks(trades,v);for(const m of marks){assert.ok(m.label.x>=v.left&&m.label.x+m.label.width<=width-v.right);assert.ok(m.label.y>=v.top&&m.label.y+m.label.height<=440-v.bottom);assert.equal(m.points,trades.find(t=>t.id===m.id).points);}const moved=replayViewport(chart,20,[],width,440,{...initialView(),xZoom:2,follow:false,offset:3,priceCenter:110,priceSpan:30});for(const m of tradeReviewMarks(trades,moved))assert.equal(m.text,`${m.points>0?'+':''}${m.points} points`);}
});
