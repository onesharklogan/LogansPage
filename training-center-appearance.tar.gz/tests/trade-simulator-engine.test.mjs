import test from 'node:test';
import assert from 'node:assert/strict';
import {initialState,snapPrice,validateBracket,bracketStats,placeBracket,editBracket,cancelPending,advanceCandle,finishSession,closeOpenPosition,statistics} from '../lib/trade-simulator.mjs';

const buy={side:'buy',entry:100,stop:95,target:110};
const sell={side:'sell',entry:100,stop:105,target:90};
const bar=(o,h,l,c,t='09:35')=>({o,h,l,c,t});
const first=bar(102,103,101,102,'09:30');
const start=(bracket=buy)=>placeBracket(initialState(0,first),bracket);
const next=(state,candle)=>advanceCandle(state,candle,state.index+1);
function deepFreeze(value){if(value&&typeof value==='object'){Object.freeze(value);for(const child of Object.values(value))deepFreeze(child);}return value;}

test('snapping and bracket validation reject nonfinite, blank, zero, wrong direction, collapsed and invalid tick inputs',()=>{
 assert.equal(snapPrice(100.12),100);assert.equal(snapPrice(100.13),100.25);assert.equal(snapPrice(1.16,.1),1.2);
 for(const value of [undefined,null,'100','',NaN,Infinity])assert.ok(Number.isNaN(snapPrice(value)));
 assert.equal(validateBracket({...buy,entry:100.12}).bracket.entry,100);
 for(const side of ['BUY','long','',null])assert.equal(validateBracket({...buy,side}).valid,false);
 for(const field of ['entry','stop','target'])for(const value of [0,-1,NaN,Infinity,null,'100',1e10])assert.equal(validateBracket({...buy,[field]:value}).valid,false);
 for(const bracket of [{...buy,stop:100},{...buy,stop:101},{...buy,target:99},{...buy,target:100.1},{...sell,stop:99},{...sell,target:101}])assert.equal(validateBracket(bracket).valid,false);
 for(const tick of [0,-1,NaN,Infinity])assert.equal(validateBracket(buy,tick).valid,false);
 assert.equal(validateBracket({...buy,entry:.01,stop:.001,target:.2}).valid,false);
 assert.throws(()=>initialState(-1));assert.throws(()=>initialState(0,null,0));
});

test('planned bracket risk/reward and exact one-decimal profitability threshold are based on chosen prices',()=>{
 assert.deepEqual(bracketStats(buy),{risk:5,reward:10,rewardRisk:2,requiredWinRate:5/15*100});
 assert.equal(`Your risk/reward requires ${bracketStats(sell).requiredWinRate.toFixed(1)}% win rate`,'Your risk/reward requires 33.3% win rate');
 assert.equal(bracketStats({...buy,target:105}).requiredWinRate,50);
 assert.equal(bracketStats({...buy,stop:100}),null);
});

test('place is atomic, has all three prices and cannot fill the currently revealed or any historical candle',()=>{
 const visible=bar(100,120,90,100),original=initialState(0,visible),state=placeBracket(original,buy);
 assert.equal(state.pending.eligibleIndex,1);assert.equal(state.position,null);assert.equal(state.trades.length,0);
 assert.equal(advanceCandle(state,visible,0),state);assert.equal(original.pending,null);
 assert.throws(()=>placeBracket(state,buy),/one bracket/);
 assert.throws(()=>placeBracket(original,{side:'buy',entry:100,stop:95}));
});

test('an untouched pending buy persists across every later candle until a touch; exact low touch fills',()=>{
 let state=start();for(let i=0;i<4;i++)state=next(state,bar(103,106,100.25,104));
 assert.equal(state.pending.entry,100);assert.equal(state.position,null);
 state=next(state,bar(103,105,100,102));assert.equal(state.pending,null);assert.equal(state.position.entryPrice,100);assert.equal(state.position.entryIndex,5);
 assert.equal(state.events.filter(event=>event.kind==='entry').length,1);
});

test('sell limits trigger only on an equal-or-higher high and use the exact requested level on a touch',()=>{
 let state=start(sell);state=next(state,bar(98,99.75,96,98));assert.ok(state.pending);
 state=next(state,bar(98,100,96,99));assert.equal(state.position.entryPrice,100);assert.equal(state.position.side,'sell');
});

test('buy and sell favorable entry gaps fill at the opening print, retaining the planned bracket separately',()=>{
 for(const [bracket,candle,price] of [[buy,bar(98,103,97,102),98],[sell,bar(102,103,97,98),102]]){
  const state=next(start(bracket),candle);assert.equal(state.position.entry,100);assert.equal(state.position.entryPrice,price);assert.equal(state.position.openingFill,true);assert.equal(state.events.at(-1).reason,'limit-open');
  assert.equal(bracketStats(state.position).requiredWinRate,5/15*100);
 }
});

test('opening exactly on entry is an opening fill, with linked exits active only after it fills',()=>{
 const state=next(start(),bar(100,110,98,109));assert.equal(state.trades[0].reason,'target');assert.equal(state.trades[0].points,10);assert.equal(state.position,null);
 const untouched=next(start(),bar(112,114,111,113));assert.ok(untouched.pending);assert.equal(untouched.trades.length,0);
});

test('an entry gap through stop enters and exits at the same open without a fictitious stop-price gain',()=>{
 for(const [bracket,candle,price] of [[buy,bar(93,112,92,108),93],[sell,bar(107,108,88,92),107]]){
  const state=next(start(bracket),candle),trade=state.trades[0];assert.equal(trade.entryPrice,price);assert.equal(trade.exitPrice,price);assert.equal(trade.points,0);assert.equal(trade.outcome,'flat');assert.equal(trade.reason,'entry-gap-through-stop');assert.equal(state.position,null);assert.equal(state.pending,null);
 }
});

test('existing positions stop at adverse opening gaps; their actual fill determines points',()=>{
 for(const [bracket,entry,gap,exit,points] of [[buy,bar(98,103,97,102),bar(92,100,90,99),92,-6],[sell,bar(102,103,97,98),bar(109,112,100,102),109,-7]]){
  const state=next(next(start(bracket),entry),gap),trade=state.trades[0];assert.equal(trade.reason,'stop-gap');assert.equal(trade.exitPrice,exit);assert.equal(trade.points,points);
 }
});

test('existing target gaps improve to open, including when the later wick crosses stop',()=>{
 for(const [bracket,entry,gap,exit,points] of [[buy,bar(102,104,99,101),bar(112,114,94,96),112,12],[sell,bar(98,101,96,99),bar(88,106,86,104),88,12]]){
  const state=next(next(start(bracket),entry),gap),trade=state.trades[0];assert.equal(trade.reason,'target-gap');assert.equal(trade.exitPrice,exit);assert.equal(trade.points,points);assert.equal(trade.ambiguous,false);
 }
});

test('both extremes on an existing position choose stop conservatively, for buy and sell',()=>{
 for(const [bracket,entry,ambiguous] of [[buy,bar(102,104,99,101),bar(101,112,94,108)],[sell,bar(98,101,96,99),bar(99,106,88,92)]]){
  const state=next(next(start(bracket),entry),ambiguous),trade=state.trades[0];assert.equal(trade.reason,'stop');assert.equal(trade.points,-5);assert.equal(trade.ambiguous,true);
 }
});

test('same-candle intrabar entry and both exits choose stop even when close is beyond target',()=>{
 for(const [bracket,candle] of [[buy,bar(102,112,94,111)],[sell,bar(98,106,88,89)]]){
  const state=next(start(bracket),candle);assert.equal(state.trades[0].reason,'stop');assert.equal(state.trades[0].points,-5);assert.equal(state.trades[0].entryIndex,state.trades[0].exitIndex);assert.equal(state.trades[0].ambiguous,true);
 }
});

test('an ambiguous target-only wick before intrabar entry is never awarded retroactively',()=>{
 for(const [bracket,candle,follow] of [[buy,bar(102,112,99,104),bar(104,109,97,105)],[sell,bar(98,101,88,96),bar(96,103,91,95)]]){
  let state=next(start(bracket),candle);assert.ok(state.position);assert.equal(state.trades.length,0);assert.equal(state.events.at(-1).kind,'target-deferred');
  state=next(state,follow);assert.ok(state.position);assert.equal(state.trades.length,0);
 }
});

test('intrabar entry with a close at or beyond target proves a subsequent target crossing',()=>{
 for(const [bracket,candle] of [[buy,bar(102,112,99,110)],[sell,bar(98,101,88,90)]]){
  const state=next(start(bracket),candle);assert.equal(state.trades[0].reason,'target');assert.equal(state.trades[0].points,10);
 }
});

test('an opening fill credits a subsequent target wick without requiring close beyond target',()=>{
 for(const [bracket,candle,points] of [[buy,bar(98,111,97,102),12],[sell,bar(102,103,89,98),12]]){
  const state=next(start(bracket),candle);assert.equal(state.trades[0].reason,'target');assert.equal(state.trades[0].points,points);
 }
});

test('OCO exits clear both orders and cannot make a second exit or reenter on a later touch',()=>{
 const exited=next(start(),bar(100,111,98,109));assert.equal(exited.trades.length,1);assert.equal(exited.pending,null);assert.equal(exited.position,null);
 const later=next(exited,bar(100,112,90,100));assert.equal(later.trades.length,1);assert.equal(later.events.filter(event=>event.kind==='exit').length,1);
 assert.throws(()=>editBracket(later,buy),/no active/);
});

test('pending edits atomically replace all prices and cannot inspect the current candle',()=>{
 let state=next(start(),bar(102,108,101,104));const updated={side:'sell',entry:105,stop:110,target:95};
 state=editBracket(state,updated);assert.equal(state.pending.side,'sell');assert.equal(state.pending.eligibleIndex,2);assert.equal(state.position,null);
 assert.equal(advanceCandle(state,state.currentCandle,1),state);
 const result=next(state,bar(104,105,101,102));assert.equal(result.position.entryPrice,105);assert.equal(result.position.stop,110);assert.equal(result.position.target,95);
});

test('open-position edits lock entry and side, atomically change exits next candle and reject invalid edits without mutation',()=>{
 const original=next(start(),bar(102,108,99,103)),before=JSON.stringify(original);
 assert.throws(()=>editBracket(original,{...buy,entry:101}),/cannot be moved/);
 assert.throws(()=>editBracket(original,sell),/cannot be moved/);
 assert.throws(()=>editBracket(original,{...buy,stop:101}));assert.equal(JSON.stringify(original),before);
 const edited=editBracket(original,{...buy,stop:99.5,target:107});assert.equal(edited.position.eligibleIndex,2);assert.equal(edited.trades.length,0);
 const result=next(edited,bar(103,108,100,106));assert.equal(result.trades[0].exitPrice,107);assert.equal(result.trades[0].points,7);
});

test('cancel only affects a pending bracket and never flattens an open position',()=>{
 const pending=start(),canceled=cancelPending(pending);assert.equal(canceled.pending,null);assert.equal(cancelPending(canceled),canceled);
 assert.equal(next(canceled,bar(100,112,90,100)).trades.length,0);
 const open=next(start(),bar(102,104,99,101));assert.equal(cancelPending(open),open);assert.ok(open.position);
});

test('strict sequential replay blocks skips, ignores duplicate/stale calls and invalid candles do not advance',()=>{
 const state=start();assert.throws(()=>advanceCandle(state,bar(100,105,99,104),2),/without skipping/);
 for(const candle of [bar(100,99,98,99),bar(100,101,102,100),bar(NaN,105,99,103),bar(0,2,0,1)])assert.throws(()=>next(state,candle),/Invalid candle/);
 const entered=next(state,bar(102,105,99,104));assert.equal(advanceCandle(entered,bar(100,120,80,100),0),entered);assert.equal(advanceCandle(entered,bar(100,120,80,100),1),entered);assert.equal(state.index,0);
});

test('session end marks open positions at the latest revealed close, transparently records reason and prevents repeated scoring',()=>{
 const state=next(start(),bar(98,105,97,103)),finished=finishSession(state,state.currentCandle),trade=finished.trades[0];
 assert.equal(trade.entryPrice,98);assert.equal(trade.exitPrice,103);assert.equal(trade.points,5);assert.equal(trade.reason,'session-end');assert.equal(finished.ended,true);
 assert.equal(finishSession(finished),finished);assert.equal(next(finished,bar(100,112,90,100)),finished);
 assert.throws(()=>placeBracket(finished,buy),/session has ended/);assert.throws(()=>editBracket(finished,buy),/session has ended/);
 assert.throws(()=>finishSession(state,bar(98,120,97,119,'hidden')),/latest revealed/);
});

test('pending orders canceled at end, final-candle exits evaluated before flatten, replay starts empty',()=>{
 const pending=finishSession(start());assert.equal(pending.pending,null);assert.equal(pending.trades.length,0);assert.equal(pending.events.at(-2).reason,'session-end');
 const finalExit=finishSession(next(start(),bar(100,111,98,109)));assert.equal(finalExit.trades.length,1);assert.equal(finalExit.trades[0].reason,'target');
 const finalEntry=finishSession(next(start(),bar(102,105,99,104)));assert.equal(finalEntry.trades.length,1);assert.equal(finalEntry.trades[0].reason,'session-end');assert.equal(finalEntry.trades[0].entryIndex,finalEntry.trades[0].exitIndex);
 const replay=initialState(0,first);assert.equal(replay.ended,false);assert.equal(replay.pending,null);assert.equal(replay.position,null);assert.deepEqual(replay.events,[]);assert.deepEqual(replay.trades,[]);assert.equal(replay.nextId,1);
});

test('ledger statistics use closed actual fills, include flats in the denominator, and are decimal stable',()=>{
 const trades=[{points:1.1},{points:2.2},{points:-1.2},{points:0}];assert.deepEqual(statistics(trades),{trades:4,wins:2,losses:1,flats:1,winRate:50,netPoints:2.1,grossProfit:3.3,grossLoss:1.2});
 assert.deepEqual(statistics(initialState()),{trades:0,wins:0,losses:0,flats:0,winRate:0,netPoints:0,grossProfit:0,grossLoss:0});
 const open=next(start(),bar(102,108,99,107));assert.equal(statistics(open).trades,0);
});

test('no operation mutates input state, submitted bracket, existing ledger, or candle data',()=>{
 const bracket=deepFreeze({...buy}),candle=deepFreeze(bar(102,112,99,111)),initial=deepFreeze(initialState(0,first));
 const pending=deepFreeze(placeBracket(initial,bracket)),edited=deepFreeze(editBracket(pending,{...bracket,stop:94})),ended=deepFreeze(finishSession(next(edited,candle)));
 assert.equal(initial.pending,null);assert.equal(pending.pending.stop,95);assert.equal(edited.trades.length,0);assert.equal(ended.trades.length,1);assert.equal(candle.l,99);assert.equal(bracket.stop,95);
});


test('manual close uses actual buy/sell entry fills and current revealed close for signed points',()=>{
 for(const [bracket,candle,entry,exit,points] of [[buy,bar(98,104,97,103,'10:00'),98,103,5],[sell,bar(102,103,96,97,'10:00'),102,97,5],[buy,bar(98,100,96,96,'10:00'),98,96,-2],[sell,bar(102,104,100,104,'10:00'),102,104,-2]]){
  const state=next(start(bracket),candle),closed=closeOpenPosition(state),trade=closed.trades[0];
  assert.equal(trade.entryPrice,entry);assert.equal(trade.exitPrice,exit);assert.equal(trade.points,points);assert.equal(trade.reason,'manual-close');assert.equal(trade.exitIndex,1);assert.equal(trade.exitTime,'10:00');assert.equal(trade.ambiguous,false);assert.equal(closed.events.at(-1).reason,'manual-close');assert.equal(closed.ended,false);assert.equal(closed.position,null);assert.equal(closed.pending,null);
 }
});

test('manual close cannot select a previous/future price, does not advance replay, and ignores extra supplied arguments',()=>{
 const opened=next(start(),bar(98,104,97,103,'10:00')),latest=next(opened,bar(103,108,100,106,'10:05'));
 const closed=closeOpenPosition(latest,9999,bar(999,1000,998,999,'hidden'));
 assert.equal(closed.index,2);assert.equal(closed.currentCandle,latest.currentCandle);assert.equal(closed.trades[0].exitIndex,2);assert.equal(closed.trades[0].exitTime,'10:05');assert.equal(closed.trades[0].exitPrice,106);assert.equal(closed.trades[0].points,8);assert.notEqual(closed.trades[0].exitPrice,opened.currentCandle.c);assert.equal(closeOpenPosition.length,1);
});

test('manual close works immediately after an exit edit without waiting for the revised next-candle eligibility',()=>{
 const opened=next(start(),bar(98,104,97,103)),edited=editBracket(opened,{...buy,stop:96,target:109});assert.equal(edited.position.eligibleIndex,2);
 const closed=closeOpenPosition(edited);assert.equal(closed.index,1);assert.equal(closed.trades.length,1);assert.equal(closed.trades[0].reason,'manual-close');assert.equal(closed.trades[0].exitPrice,103);assert.equal(closed.trades[0].stop,96);assert.equal(closed.trades[0].target,109);assert.equal(closed.position,null);
});

test('manual close is idempotent, removes both old exits, permits a fresh bracket, and leaves pending-only or ended states unchanged',()=>{
 const initial=initialState(0,first),pending=start();assert.equal(closeOpenPosition(initial),initial);assert.equal(closeOpenPosition(pending),pending);
 const closed=closeOpenPosition(next(pending,bar(98,104,97,103)));assert.equal(closeOpenPosition(closed),closed);assert.equal(closed.events.filter(event=>event.kind==='exit').length,1);
 const advanced=next(closed,bar(100,112,90,100));assert.equal(advanced.trades.length,1);assert.equal(advanced.pending,null);assert.equal(advanced.position,null);
 const newOrder=placeBracket(advanced,buy);assert.equal(newOrder.pending.id,2);assert.equal(newOrder.pending.eligibleIndex,3);assert.equal(newOrder.trades.length,1);
 const ended=finishSession(newOrder);assert.equal(closeOpenPosition(ended),ended);
});

test('manual close validates a missing/invalid revealed candle safely and never mutates frozen input',()=>{
 const opened=next(start(),bar(98,104,97,103)),missing={...opened,currentCandle:null},beforeMissing=JSON.stringify(missing);
 assert.throws(()=>closeOpenPosition(missing),/latest revealed candle/);assert.equal(JSON.stringify(missing),beforeMissing);
 assert.throws(()=>closeOpenPosition({...opened,currentCandle:{...opened.currentCandle,c:NaN}}),/Invalid candle/);
 const frozen=deepFreeze(opened),before=JSON.stringify(frozen),closed=closeOpenPosition(frozen);assert.equal(JSON.stringify(frozen),before);assert.equal(frozen.trades.length,0);assert.equal(frozen.position.entryPrice,98);assert.equal(closed.trades.length,1);assert.notEqual(closed.events,frozen.events);assert.notEqual(closed.trades,frozen.trades);
});
