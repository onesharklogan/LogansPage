import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createLearnerClient} from '../lib/learner/client.mjs';
const A='11111111-1111-4111-8111-111111111111',B='22222222-2222-4222-8222-222222222222',ID='33333333-3333-4333-8333-333333333333',REQUEST='44444444-4444-4444-8444-444444444444';
const at='2026-10-30T12:00:00.000Z',now=Date.parse(at);
const context=(id=A,generation=0)=>({accountId:id,generation,sessionTag:'a'.repeat(64)});
const profile=(id=A,generation=0)=>({id,name:id===A?'Ari':'Bo',generation});
const account=(id=A,generation=0)=>({mode:'account',authConfigured:true,profile:profile(id,generation),context:context(id,generation),csrfToken:'c'.repeat(64)});
const guest=()=>({mode:'guest',authConfigured:true,profile:null});
const attempt=()=>({id:ID,module:'trade-simulator',chartId:'mes1-2026-01-06-81',chartSha256:'d'.repeat(64),startedAt:at,completedAt:at,savedAt:at,summary:{netPoints:3.5}});
const progress=()=>({completedAttempts:1,byModule:{'trade-simulator':1,'market-direction':0},trade:{trades:1,wins:1,losses:0,flats:0,netPoints:3.5,grossProfit:3.5,grossLoss:0},direction:{netAlignedPoints:0,favorablePoints:0,adversePoints:0,practicedIntervals:0,practicedLongIntervals:0,practicedShortIntervals:0,practicedNeutralIntervals:0},skillScore:null});
const json=(body,status=200)=>Response.json(body,{status});
const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b});return{promise,resolve,reject};};
function setup(handler){const calls=[],client=createLearnerClient({now:()=>now,randomUUID:()=>REQUEST,fetcher:async(url,init)=>{const call={url,...init,body:init.body?JSON.parse(init.body):undefined};calls.push(call);return handler(call,calls.length);}});return{client,calls};}

test('unconfigured account service leaves usable Guest without any storage or mutation writes',async()=>{
 const s=setup(()=>json({code:'auth_unavailable',authConfigured:false,error:'Not ready'},503));assert.equal(s.client.captureContext(),null);await s.client.refresh();assert.equal(s.client.getSnapshot().mode,'guest');assert.equal(s.client.getSnapshot().ready,true);assert.equal(s.client.getSnapshot().authConfigured,false);s.client.continueAsGuest();const capture=s.client.captureContext();assert(s.client.guard(capture));await s.client.loadDetails();await assert.rejects(s.client.prepareReset());await assert.rejects(s.client.saveAttempt(attempt(),capture));assert.equal(s.calls.length,1);assert(s.calls.every(c=>c.method==='GET'));const source=fs.readFileSync(new URL('../lib/learner/client.mjs',import.meta.url),'utf8');assert.doesNotMatch(source,/\b(localStorage|sessionStorage)\s*[.[]|document\.cookie|LearnerProfiles\./);
});

test('session and every saved-history response require exact owner/generation/session context',async()=>{
 for(const bad of [context(B),context(A,1),{...context(),sessionTag:'b'.repeat(64)}]){
  const s=setup(c=>c.url.endsWith('session')?json(account()):c.url.includes('attempts')?json({context:bad,attempts:[attempt()],nextCursor:null}):json({context:context(),progress:progress()}));await s.client.refresh();await s.client.loadDetails();assert.equal(s.client.getSnapshot().attempts.length,0);assert.match(s.client.getSnapshot().error,/different or changed/);
 }
});

test('verified summaries/progress hydrate without candle data or guessed skill score',async()=>{
 const s=setup(c=>c.url.endsWith('session')?json(account()):c.url.includes('attempts')?json({context:context(),attempts:[attempt()],nextCursor:null}):json({context:context(),progress:progress()}));await s.client.refresh();const capture=s.client.captureContext();await s.client.loadDetails();assert(s.client.guard(capture));assert.equal(s.client.getSnapshot().attempts[0].id,ID);assert.equal(s.client.getSnapshot().progress.skillScore,null);assert.equal(s.client.getSnapshot().progress.completedAttempts,1);assert(Object.isFrozen(s.client.getSnapshot().context));assert.equal(s.calls[0].credentials,'same-origin');assert.equal(s.calls[0].cache,'no-store');assert.equal(s.calls[0].redirect,'error');
});

test('bad summaries and fabricated skill score are not displayed',async()=>{
 for(const bad of ['attempt','score']){const s=setup(c=>c.url.endsWith('session')?json(account()):c.url.includes('attempts')?json({context:context(),attempts:[{...attempt(),...(bad==='attempt'?{module:'teacher'}:{})}],nextCursor:null}):json({context:context(),progress:{...progress(),...(bad==='score'?{skillScore:99}:{})}}));await s.client.refresh();await s.client.loadDetails();assert.equal(s.client.getSnapshot().attempts.length,0);assert.equal(s.client.getSnapshot().progress,null);assert(s.client.getSnapshot().error);}
});

test('stale session response cannot replace a newer identity or explicit Guest choice',async()=>{
 const d=deferred();let n=0;const s=setup(()=>++n===1?d.promise:json(account(B)));const first=s.client.refresh();await s.client.refresh();d.resolve(json(account(A)));await first;assert.equal(s.client.getSnapshot().profile.id,B);
 const g=setup(()=>json(guest()));await g.client.refresh();g.client.continueAsGuest();await g.client.refresh();assert.equal(g.calls.length,1);
});

test('benign panel cancellation aborts late details without invalidating same-account capture',async()=>{
 const d=deferred();const s=setup(c=>c.url.endsWith('session')?json(account()):d.promise);await s.client.refresh();const capture=s.client.captureContext(),loading=s.client.loadDetails();s.client.cancelPending();assert(s.client.guard(capture));d.resolve(json({context:context(),attempts:[attempt()],nextCursor:null,progress:progress()}));await loading;assert.equal(s.client.getSnapshot().attempts.length,0);assert.equal(s.client.getSnapshot().busy,null);
});

test('reset requires phrase, owner intent, CSRF and stable retry ID; success invalidates older captures',async()=>{
 let fail=true;const s=setup(c=>{if(c.url.endsWith('session'))return json(account());if(c.url.endsWith('reset-intent'))return json({context:context(),token:'e'.repeat(64),expiresAt:new Date(now+60000).toISOString()});if(c.url.endsWith('reset')){if(fail){fail=false;throw Error('connection lost');}return json({context:context(A,1),profile:profile(A,1),reset:true});}throw Error('unexpected')});await s.client.refresh();const capture=s.client.captureContext();await assert.rejects(s.client.reset('RESET MY HISTORY'));await s.client.prepareReset();await assert.rejects(s.client.reset('wrong'));await assert.rejects(s.client.reset('RESET MY HISTORY'));await s.client.reset('RESET MY HISTORY');const writes=s.calls.filter(c=>c.url.endsWith('/reset'));assert.equal(writes.length,2);assert.deepEqual(writes[0].body,writes[1].body);assert.equal(writes[0].body.requestId,REQUEST);assert.equal(writes[0].headers['X-CSRF-Token'],'c'.repeat(64));assert.deepEqual(writes[0].body.context,context());assert.equal(s.client.getSnapshot().profile.generation,1);assert.equal(s.client.guard(capture),false);assert.equal(s.client.getSnapshot().attempts.length,0);
});

test('reset errors and foreign identity never clear displayed history as success',async()=>{
 const s=setup(c=>c.url.endsWith('session')?json(account()):c.url.endsWith('reset-intent')?json({context:context(),token:'e'.repeat(64),expiresAt:new Date(now+60000).toISOString()}):json({context:context(B,1),profile:profile(B,1),reset:true}));await s.client.refresh();await s.client.prepareReset();await assert.rejects(s.client.reset('RESET MY HISTORY'));assert.equal(s.client.getSnapshot().profile.id,A);assert.equal(s.client.getSnapshot().profile.generation,0);
});

test('canceled sign-in remains unresolved until provider settles and server session is rechecked',async()=>{
 const d=deferred();let signed=false;const s=setup(()=>json(signed?account(B):guest()));await s.client.refresh();const login=s.client.authenticate({signIn:()=>d.promise},'signIn',{email:'synthetic@example.test',password:'not-a-real-password'}).catch(e=>e);await Promise.resolve();s.client.cancelPending();assert.equal(s.client.getSnapshot().ready,false);assert.equal(s.client.captureContext(),null);assert.throws(()=>s.client.continueAsGuest());signed=true;d.resolve({});const result=await login;await new Promise(r=>setTimeout(r,0));assert.equal(result.code,'stale_action');assert.equal(s.client.getSnapshot().profile.id,B);assert.equal(s.client.getSnapshot().ready,true);assert(s.calls.length>=2);
});

test('failed sign-in still verifies Guest session and allows explicit retry without storing passwords',async()=>{
 const s=setup(()=>json(guest()));await s.client.refresh();await assert.rejects(s.client.authenticate({signIn:async()=>{throw Error('provider failed')}},'signIn',{password:'secret'}));assert.equal(s.client.getSnapshot().ready,true);assert.equal(s.client.getSnapshot().mode,'guest');assert.equal(s.client.getSnapshot().busy,null);assert(!JSON.stringify(s.client.getSnapshot()).includes('secret'));assert.equal(s.calls.length,2);
});

test('logout confirms both app and provider and then verifies Guest session',async()=>{
 let providerDone=false;const s=setup(c=>c.url.endsWith('logout')?json({mode:'guest',signedOut:true,authConfigured:true}):json(providerDone?guest():account()));await s.client.refresh();const capture=s.client.captureContext();await s.client.logout({signOut:async()=>{providerDone=true}});assert.equal(s.client.getSnapshot().mode,'guest');assert.equal(s.client.getSnapshot().ready,true);assert.equal(s.client.guard(capture),false);const write=s.calls.find(c=>c.method==='POST');assert.deepEqual(write.body,{context:context()});assert.equal(write.headers['X-CSRF-Token'],'c'.repeat(64));
});

test('failed provider logout never masquerades as usable Guest',async()=>{
 const s=setup(c=>c.url.endsWith('logout')?json({mode:'guest',signedOut:true,authConfigured:true}):json(account()));await s.client.refresh();await assert.rejects(s.client.logout({signOut:async()=>{throw Error('offline')}}));assert.equal(s.client.getSnapshot().ready,false);assert.equal(s.client.getSnapshot().reconcileRequired,true);assert.equal(s.client.captureContext(),null);assert.throws(()=>s.client.continueAsGuest());assert.match(s.client.getSnapshot().error,/Provider sign-out could not be confirmed/);
});

test('attempt save/detail/list enforce capture, explicit owner context and returned ownership',async()=>{
 const s=setup(c=>{if(c.url.endsWith('session'))return json(account());if(c.method==='POST')return json({context:context(),attempt:attempt(),duplicate:true});if(c.url.endsWith(ID))return json({context:context(),attempt:{...attempt(),version:1,practice:{}}});return json({context:context(),attempts:[attempt()],nextCursor:null});});await s.client.refresh();const capture=s.client.captureContext();await s.client.saveAttempt(attempt(),capture);assert.deepEqual(s.calls.at(-1).body.context,context());assert.equal((await s.client.getAttempt(ID,capture)).id,ID);assert.equal((await s.client.listAttempts({module:'trade-simulator',limit:25},capture)).attempts.length,1);assert.match(s.calls.at(-1).url,/module=trade-simulator/);await assert.rejects(s.client.getAttempt('../other',capture));const before=s.calls.length;await assert.rejects(s.client.saveAttempt(attempt(),{...capture,epoch:-1}));assert.equal(s.calls.length,before);
});

test('read errors cannot expose cached practice as a freshly verified account',async()=>{
 let fail=false;const s=setup(()=>fail?json({error:'offline',code:'service_error'},503):json(account()));await s.client.refresh();const capture=s.client.captureContext();fail=true;await s.client.revalidate();assert.equal(s.client.getSnapshot().ready,false);assert.equal(s.client.guard(capture),false);
});

test('oversized/non-JSON exports fail closed and never produce download data',async()=>{
 for(const bad of [()=>new Response('private error'),()=>new Response('{}',{headers:{'Content-Type':'application/json','Content-Length':String(10*1024*1024+1)}})]){const s=setup(c=>c.url.endsWith('session')?json(account()):bad());await s.client.refresh();await assert.rejects(s.client.exportHistory());assert(s.client.getSnapshot().error);}
});

test('panel requests are in-memory only and validate requested view/module',async()=>{
 const s=setup(()=>json(guest()));await s.client.refresh();let seen;const unsubscribe=s.client.subscribe(v=>seen=v);assert.equal(s.client.requestPanel({view:'history',module:'trade-simulator'}),true);assert.equal(seen.panelRequest.view,'history');assert.equal(s.client.requestPanel({view:'admin'}),false);unsubscribe();assert.equal(s.calls.length,1);
});

test('provider reconciliation cannot be superseded by a focus check before its live-session response settles',async()=>{
 const d=deferred();let reads=0;const s=setup(()=>++reads===1?json(guest()):d.promise);await s.client.refresh();const login=s.client.authenticate({signIn:async()=>{}},'signIn',{});await new Promise(r=>setImmediate(r));assert.equal(reads,2);await s.client.revalidate();assert.equal(reads,2);assert.equal(s.client.captureContext(),null);d.resolve(json(account()));await login;assert.equal(s.client.getSnapshot().profile.id,A);assert(s.client.captureContext());
});

test('canceling while post-provider live-session verification is pending reconciles before restoring a usable identity',async()=>{
 const d=deferred();let reads=0;const s=setup(()=>++reads===1?json(guest()):reads===2?d.promise:json(account(B)));await s.client.refresh();const login=s.client.authenticate({signIn:async()=>{}},'signIn',{}).catch(e=>e);await new Promise(r=>setImmediate(r));s.client.cancelAuthentication();assert.equal(s.client.captureContext(),null);d.resolve(json(account()));assert.equal((await login).code,'stale_action');assert.equal(s.client.getSnapshot().profile.id,B);
});
