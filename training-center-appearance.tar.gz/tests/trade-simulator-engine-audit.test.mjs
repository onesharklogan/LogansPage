// Independent adversarial engine and OHLC canonical-path audit.
import test from 'node:test';
import assert from 'node:assert/strict';
import * as sim from '../lib/trade-simulator.mjs';
const B={side:'buy',entry:100,stop:95,target:110};
const bar=(o,h,l,c,t='t')=>({t,o,h,l,c});
const start=(bracket=B)=>sim.placeBracket(sim.initialState(0,bar(105,106,104,105,'0')),bracket);
const reflectBar=b=>({...b,o:200-b.o,h:200-b.l,l:200-b.h,c:200-b.c});
const reflectBracket=b=>({side:b.side==='buy'?'sell':'buy',entry:200-b.entry,stop:200-b.stop,target:200-b.target});

test('placement is next-candle only and repeated current index is an identical no-op',()=>{
 const s=start();assert.equal(s.position,null);assert.equal(s.pending.eligibleIndex,1);
 assert.equal(sim.advanceCandle(s,bar(100,120,80,110),0),s);
 assert.throws(()=>sim.advanceCandle(s,bar(100,120,80,110),2),/without skipping/);
 const n=sim.advanceCandle(s,bar(105,106,101,102),1);assert.ok(n.pending);assert.equal(n.trades.length,0);
});

test('next open improves resting entry, exact touch enters, favorable untouched side does not',()=>{
 let s=sim.advanceCandle(start(),bar(98,101,96,99),1);assert.equal(s.position.entryPrice,98);
 s=sim.advanceCandle(start(),bar(104,105,100,103),1);assert.equal(s.position.entryPrice,100);
 s=sim.advanceCandle(start(),bar(105,120,101,115),1);assert.ok(s.pending);assert.equal(s.position,null);
});

test('entry gap across stop is zero points, not fictional limit price loss',()=>{
 for(const b of [B,reflectBracket(B)]){
 const c=b.side==='buy'?bar(90,112,85,105):reflectBar(bar(90,112,85,105));
 const n=sim.advanceCandle(start(b),c,1);assert.equal(n.trades.length,1);assert.equal(n.trades[0].entryPrice,c.o);assert.equal(n.trades[0].exitPrice,c.o);assert.equal(n.trades[0].points,0);assert.equal(n.trades[0].reason,'entry-gap-through-stop');
 }
});

test('intrabar target wick deferred, later close proof credited, stop-first remains conservative',()=>{
 let s=sim.advanceCandle(start(),bar(105,112,99,104),1);assert.ok(s.position);assert.equal(s.trades.length,0);assert.equal(s.events.at(-1).kind,'target-deferred');
 s=sim.advanceCandle(start(),bar(105,112,99,111),1);assert.equal(s.trades[0].points,10);assert.equal(s.trades[0].reason,'target');
 s=sim.advanceCandle(start(),bar(105,112,94,111),1);assert.equal(s.trades[0].points,-5);assert.equal(s.trades[0].ambiguous,true);
});

test('existing position exits at known opening target or adverse stop before wick ambiguity',()=>{
 const s=sim.advanceCandle(start(),bar(100,104,98,102),1);
 let n=sim.advanceCandle(s,bar(112,115,90,94),2);assert.equal(n.trades[0].exitPrice,112);assert.equal(n.trades[0].reason,'target-gap');assert.equal(n.trades[0].ambiguous,false);
 n=sim.advanceCandle(s,bar(92,115,90,111),2);assert.equal(n.trades[0].exitPrice,92);assert.equal(n.trades[0].reason,'stop-gap');
});

test('pending move, cancel, invalid crossed bracket, filled entry lock and immutability',()=>{
 const s=start(),frozen=JSON.stringify(s);
 assert.throws(()=>sim.editBracket(s,{...B,stop:101}));assert.equal(JSON.stringify(s),frozen);
 const moved=sim.editBracket(s,{...B,entry:99});assert.equal(moved.pending.entry,99);assert.equal(moved.pending.eligibleIndex,1);assert.equal(s.pending.entry,100);
 const n=sim.advanceCandle(moved,bar(101,104,99.5,103),1);assert.ok(n.pending);
 assert.equal(sim.advanceCandle(sim.cancelPending(n),bar(99,112,90,100),2).trades.length,0);
 const p=sim.advanceCandle(start(),bar(100,104,98,102),1);
 assert.throws(()=>sim.editBracket(p,{...B,entry:99}),/cannot be moved/);
 assert.throws(()=>sim.editBracket(p,reflectBracket(B)),/cannot be moved/);
 const edited=sim.editBracket(p,{...B,stop:99,target:104});assert.equal(edited.position.eligibleIndex,2);assert.equal(edited.trades.length,0);
 assert.equal(sim.advanceCandle(edited,bar(102,105,99,100),1),edited);
});

test('OCO produces exactly one trade; session end cannot reuse future/stale price',()=>{
 const s=sim.advanceCandle(start(),bar(100,114,94,108),1);
 assert.equal(s.trades.length,1);assert.equal(s.pending,null);assert.equal(s.position,null);
 const n=sim.advanceCandle(s,bar(100,114,94,108),2);assert.equal(n.trades.length,1);
 assert.throws(()=>sim.finishSession(n,bar(100,114,94,109)),/latest revealed/);
 const end=sim.finishSession(n);assert.equal(end.trades.length,1);assert.equal(sim.finishSession(end),end);assert.equal(sim.advanceCandle(end,bar(100,114,94,108),3),end);
});

test('last-bar position closes once at observed close; unfilled order canceled at end',()=>{
 const p=sim.advanceCandle(start(),bar(100,104,98,103),1),end=sim.finishSession(p);
 assert.equal(end.trades[0].exitPrice,103);assert.equal(end.trades[0].points,3);assert.equal(end.trades[0].reason,'session-end');assert.equal(end.position,null);
 const pending=sim.finishSession(start());assert.equal(pending.pending,null);assert.equal(pending.trades.length,0);assert.equal(pending.events.at(-2).reason,'session-end');
});

test('planned threshold and ledger arithmetic remain separate from improved fill',()=>{
 const planned=sim.bracketStats(B);assert.equal(planned.risk,5);assert.equal(planned.reward,10);assert.equal(planned.rewardRisk,2);assert.ok(Math.abs(planned.requiredWinRate-100/3)<1e-12);
 const s=sim.advanceCandle(start(),bar(98,111,96,110),1);assert.equal(s.trades[0].points,12);assert.equal(s.trades[0].plannedEntry,100);
 const stats=sim.statistics([{points:12},{points:-5},{points:0},{points:-2.5}]);assert.deepEqual(stats,{trades:4,wins:1,losses:2,flats:1,winRate:25,netPoints:4.5,grossProfit:12,grossLoss:7.5});
});

test('tick rounding refuses blank, nonfinite, zero-distance or incorrectly ordered bracket',()=>{
 assert.equal(sim.snapPrice(100.12),100);assert.equal(sim.snapPrice(100.13),100.25);
 for(const bad of ['',NaN,Infinity,-Infinity,null,undefined,0,-1])assert.equal(sim.validateBracket({...B,entry:bad}).valid,false);
 assert.equal(sim.validateBracket({...B,stop:99.99}).valid,false);
 assert.equal(sim.validateBracket({...B,target:99}).valid,false);
 assert.equal(sim.validateBracket({...B,side:'long'}).valid,false);
});

test('buy/sell reflection symmetry across exhaustive valid one-bar OHLC combinations',()=>{
 let count=0;
 for(let o=90;o<=114;o+=2)for(let c=90;c<=114;c+=2)for(let l=90;l<=Math.min(o,c);l+=2)for(let h=Math.max(o,c);h<=114;h+=2){
  const b=bar(o,h,l,c),a=sim.advanceCandle(start(),b,1),z=sim.advanceCandle(start(reflectBracket(B)),reflectBar(b),1);
  assert.equal(a.trades.length,z.trades.length);assert.equal(Boolean(a.pending),Boolean(z.pending));assert.equal(Boolean(a.position),Boolean(z.position));
  if(a.trades.length){assert.equal(a.trades[0].points,z.trades[0].points);assert.equal(a.trades[0].reason,z.trades[0].reason);assert.equal(a.trades[0].ambiguous,z.trades[0].ambiguous);}count++;
 }
 console.log('Independent symmetry OHLC cases:',count);
});

test('conservative one-bar result matches the worse of both canonical continuous OHLC paths',()=>{
 function pathResult(points){let active=false,entry=null,exit=null;function visit(p){if(exit!==null)return;if(!active&&p<=B.entry){active=true;entry=p;}if(active){if(p<=B.stop)exit=p;else if(p>=B.target)exit=p;}}visit(points[0]);for(let k=1;k<points.length;k++){const a=points[k-1],b=points[k],step=b>=a?.25:-.25;for(let p=a+step;step>0?p<=b:p>=b;p+=step)visit(p);}return entry===null?0:(exit??points.at(-1))-entry;}
 let count=0;
 for(let o=90;o<=114;o+=2)for(let c=90;c<=114;c+=2)for(let l=90;l<=Math.min(o,c);l+=2)for(let h=Math.max(o,c);h<=114;h+=2){
  const b=bar(o,h,l,c),n=sim.finishSession(sim.advanceCandle(start(),b,1)),actual=sim.statistics(n).netPoints;
  const expected=Math.min(pathResult([o,h,l,c]),pathResult([o,l,h,c]));
  assert.equal(actual,expected,JSON.stringify(b));count++;
 }
 console.log('Independent canonical-path oracle cases:',count);
});

test('manual close uses only the current revealed close, cancels both exits and preserves an active session',()=>{
 const position=sim.advanceCandle(start(),bar(98,104,96,103,'current'),1),before=JSON.stringify(position);
 const closed=sim.closeOpenPosition(position,999999,bar(900,1200,800,1100,'future'));
 assert.equal(JSON.stringify(position),before);assert.equal(closed.ended,false);assert.equal(closed.index,1);assert.equal(closed.pending,null);assert.equal(closed.position,null);assert.equal(closed.trades.length,1);
 const trade=closed.trades[0];assert.equal(trade.entryPrice,98);assert.equal(trade.exitPrice,103);assert.equal(trade.points,5);assert.equal(trade.exitIndex,1);assert.equal(trade.exitTime,'current');assert.equal(trade.reason,'manual-close');assert.equal(trade.ambiguous,false);
 assert.equal(sim.closeOpenPosition(closed),closed);const next=sim.advanceCandle(closed,bar(102,120,90,115,'later'),2);assert.equal(next.trades.length,1);assert.equal(sim.statistics(next).netPoints,5);
});

test('manual close is buy/sell symmetric, immutable, and allows a later distinct bracket without double counting',()=>{
 for(const side of ['buy','sell'])for(const close of [97,98,100,103]){const buy=bar(98,104,96,close,'visible'),c=side==='buy'?buy:reflectBar(buy),b=side==='buy'?B:reflectBracket(B);const p=sim.advanceCandle(start(b),c,1),closed=sim.closeOpenPosition(p);assert.equal(closed.trades[0].points,close-98);assert.equal(closed.trades[0].outcome,close>98?'win':close<98?'loss':'flat');assert.equal(closed.trades[0].exitPrice,c.c);const again=sim.placeBracket(closed,b);assert.equal(again.pending.id,2);assert.equal(again.pending.eligibleIndex,2);assert.equal(again.trades.length,1);}
});

test('manual close cannot cancel an unfilled bracket, fabricate a missing quote or score an ended state again',()=>{
 const pending=start();assert.equal(sim.closeOpenPosition(pending),pending);assert.equal(sim.cancelPending(pending).trades.length,0);
 const p=sim.advanceCandle(start(),bar(100,104,98,103),1);for(const currentCandle of [null,{o:1,h:0,l:2,c:NaN}]){const bad={...p,currentCandle},snapshot=JSON.stringify(bad);assert.throws(()=>sim.closeOpenPosition(bad));assert.equal(JSON.stringify(bad),snapshot);}
 const edited=sim.editBracket(p,{...B,target:111});assert.equal(edited.position.eligibleIndex,2);const manual=sim.closeOpenPosition(edited);assert.equal(manual.trades[0].exitIndex,1);assert.equal(manual.trades[0].exitPrice,103);
 const ended=sim.finishSession(p);assert.equal(sim.closeOpenPosition(ended),ended);assert.equal(ended.trades.length,1);
});
