"use client";

import LoadingIndicator from './loading-indicator';
import { useEffect, useLayoutEffect, useMemo, useRef, useState, type PointerEvent, type KeyboardEvent, type ReactNode } from 'react';
import { loadLessonReview } from './lesson-review-data.mjs';
import { MAX_LEARNER_MARKS, createViewport, visibleViewportCandles, projectPoint, pointFromSvg, clientToSvg, distantEnough, validLearnerText, newAttempt, attemptReducer, exactCandleSelection, chartPositionFromSvg, hitTargetIds, allTargetsFound, textMarkLayout, hitLearnerMark, ERASER_CURSOR, barInViewport, clipLineToRange, savedIndicatorSettings, layoutSlideBarNumbers, learnerToolPolicy, learnerToolAllowed, learnerActionAllowed } from './lesson-attempt.mjs';
import type { Lesson } from './portal';
import {ShapeFill,type ShapeKind,type ShapeStyle} from './teacher-shape';

type Point = { bar: number; t: string; price: number };
type Line = { id: string; a: Point; b: Point; label?: string; color?: string; style?: 'solid' | 'dotted' };
type FilledShape={id:string;shape:ShapeKind;a:Point;b:Point;fill:string}&ShapeStyle;
type ConnectedLine = {id:string;points:Point[];color:string};
type TextMark = { id: string; at: Point; text: string; color?: string; size?: number; weight?: 400|700; box?: {width:number;height:number} };
type Target = {id:string;a:Point;b:Point};
type Arrow = { id: string; at: Point; direction: 'up' | 'down'; study: boolean; crossed: boolean };
type LearnerMark = (Line & { kind: 'line'; color: string }) | (TextMark & { kind: 'text'; color: string; size: number }) | (Arrow & { kind: 'arrow' });
export type Preview = {
  lesson: { learnerTools?: {version:1;allowed:('line'|'arrow'|'text'|'erase'|'select'|'undo'|'clear')[]}; title: string; purpose: string; prompt?: string; notes: string; indicators?: {ema20:boolean;pivotDiamonds:boolean}; range?: {startBar:number;endBar:number}; viewport?:{version:1;start:number;span:number;low:number;high:number}; session: { date: string }; lines: Line[]; connectedLines?: ConnectedLine[]; filledShapes?:FilledShape[]; annotations: TextMark[]; arrows?: Arrow[]; exercise?: { type: 'reveal-drawings' } | { type: 'candle-picker'; correctBars: number[] } | {type:'clickable-areas';targets:Target[]} };
  candles: { t: string; o: number; h: number; l: number; c: number }[];
  chart?: Record<string, unknown>;
  indicatorSeries?: {ema10?:number[];priorEma10?:(number|null)[];ema:number[];priorEma:number[];pivots:{index:number;bar:number;kind:'high'|'low';price:number;confirmedAt:number;heldFive:boolean}[]};
};
type Viewport = ReturnType<typeof createViewport>;
type Tool = 'line' | 'arrow' | 'text' | 'erase' | null;
type Attempt = { phase: string; marks: LearnerMark[]; history: LearnerMark[][]; selectedBars: number[]; foundIds:string[] };
const COLORS = ['var(--appearance-ink-ff8e11, #ff8e11)', 'var(--appearance-surface-0070c0, #0070c0)', 'var(--appearance-surface-009600, #009600)', 'var(--appearance-ink-ff0000, #ff0000)', 'var(--appearance-ink-ff00ff, #ff00ff)', 'var(--appearance-ink-d2691e, #d2691e)'];
const GRAY = 'var(--appearance-ink-74808c, #74808c)';

function Label({ mark, viewport, muted = false }: { mark: TextMark; viewport: Viewport; muted?: boolean }) {
  if (!barInViewport(mark.at.bar,viewport)) return null;
  const layout = textMarkLayout(mark, viewport),{x,y,size,lines,lineHeight}=layout;
  if(mark.box){const bounds=layout.bounds;return <g><foreignObject x={bounds.x} y={bounds.y} width={bounds.width} height={bounds.height} style={{overflow:'hidden'}}><div style={{fontFamily:'Arial, sans-serif',fontSize:size,fontWeight:mark.weight||400,lineHeight:1.3,color:muted?GRAY:mark.color||'var(--appearance-ink-b4ddff, #b4ddff)',whiteSpace:'pre-wrap',overflowWrap:'anywhere',width:'100%',height:'100%',overflow:'hidden'}}>{mark.text}</div></foreignObject><title>{mark.text}</title></g>}
  return <g><text x={x} y={y} fill={muted ? GRAY : mark.color || 'var(--appearance-ink-b4ddff, #b4ddff)'} fontSize={size} fontWeight={mark.weight} paintOrder="stroke" stroke="var(--appearance-line-091521, #091521)" strokeWidth="3" strokeLinejoin="round">{lines.map((line: string, index: number) => <tspan key={index} x={x} dy={index ? lineHeight : 0}>{line}</tspan>)}</text><title>{mark.text}</title></g>;
}
function ArrowMark({ mark, viewport, muted = false }: { mark: Arrow; viewport: Viewport; muted?: boolean }) {
  if (!barInViewport(mark.at.bar,viewport)) return null;
  const p = projectPoint(mark.at, viewport), up = mark.direction === 'up';
  const color = muted ? GRAY : mark.crossed ? 'var(--appearance-ink-a855f7, #a855f7)' : mark.study ? 'var(--appearance-ink-80d8ff, #80d8ff)' : up ? 'var(--appearance-surface-009e60, #009e60)' : 'var(--appearance-ink-dc143c, #dc143c)';
  return <g transform={`translate(${p.x - 10},${p.y - 17}) scale(1.4)`}>{mark.crossed ? <path d="M2 7 L12 17 M12 7 L2 17" fill="none" stroke={color} strokeWidth="3" strokeLinecap="round" /> : <path d={up ? 'M7 1 L14 8 H10 V23 H4 V8 H0 Z' : 'M4 1 H10 V16 H14 L7 23 L0 16 H4 Z'} fill={color} />}<title>{mark.crossed ? 'Crossed arrow' : `${mark.study ? 'Study ' : ''}${mark.direction} arrow`}</title></g>;
}
function FilledDrawing({mark,viewport}:{mark:FilledShape;viewport:Viewport}){const a=projectPoint(mark.a,viewport),b=projectPoint(mark.b,viewport);return <g data-filled-shape={mark.id}><ShapeFill shape={mark.shape} rect={{x:Math.min(a.x,b.x),y:Math.min(a.y,b.y),width:Math.abs(b.x-a.x),height:Math.abs(b.y-a.y)}} fill={mark.fill} style={mark}/></g>}
function ConnectedDrawing({mark,viewport}:{mark:ConnectedLine;viewport:Viewport}){return <g data-connected-line={mark.id}>{mark.points.slice(1).map((p,i)=>{const segment=clipLineToRange({a:mark.points[i],b:p},viewport);if(!segment)return null;const a=projectPoint(segment.a,viewport),b=projectPoint(segment.b,viewport);return <line key={i} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke={mark.color} strokeWidth="2.6" strokeLinecap="round"/>})}{mark.points.filter(p=>barInViewport(p.bar,viewport)).map((p,i)=>{const at=projectPoint(p,viewport);return <circle key={i} cx={at.x} cy={at.y} r="4" fill={mark.color}/>})}</g>}

function DrawnLine({ mark, viewport, muted = false, teacher = false }: { mark: Line; viewport: Viewport; muted?: boolean; teacher?: boolean }) {
  const clipped = clipLineToRange(mark,viewport); if (!clipped) return null;
  const a = projectPoint(clipped.a, viewport), b = projectPoint(clipped.b, viewport), color = muted ? GRAY : mark.color || (teacher ? 'var(--appearance-ink-ffd17f, #ffd17f)' : 'var(--appearance-ink-ff8e11, #ff8e11)');
  const showLabel = !!mark.label && barInViewport(mark.b.bar,viewport);
  return <g><line x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke={color} strokeWidth={muted ? 1.7 : 2.6} strokeDasharray={mark.style === 'dotted' || !teacher ? '1 5' : undefined} strokeLinecap="round" />{teacher && <>{barInViewport(mark.a.bar,viewport) && <circle cx={a.x} cy={a.y} r="3" fill={color} />}{barInViewport(mark.b.bar,viewport) && <circle cx={b.x} cy={b.y} r="3" fill={color} />}</>}{showLabel && <text x={Math.min(viewport.width - 260, Math.max(viewport.left + 5, b.x + 6))} y={Math.max(viewport.top + 14, b.y - 9)} fill={color} fontSize="13" paintOrder="stroke" stroke="var(--appearance-line-091521, #091521)" strokeWidth="4">{mark.label!.length > 42 ? mark.label!.slice(0, 39) + '…' : mark.label}</text>}{showLabel && <title>{mark.label}</title>}</g>;
}

export function SlideIndicators({data,viewport,hideEMA20=false}:{data:Preview;viewport:Viewport;hideEMA20?:boolean}) {
  const saved=savedIndicatorSettings(data.lesson),settings={...saved,ema20:saved.ema20&&!hideEMA20},series=data.indicatorSeries;
  if (!series || !settings.ema20 && !settings.pivotDiamonds) return null;
  let path='',continuous=false;
  const prior=Array.isArray(data.chart?.prior)?data.chart.prior as Preview['candles']:[],rows=visibleViewportCandles(data.candles,viewport,prior);
  if(settings.ema20)for(const {bar:index} of rows){
    const value=index<0?series.priorEma[prior.length+index]:series.ema[index];if(!Number.isFinite(value)){continuous=false;continue;}
    const point=projectPoint({bar:index,price:value},viewport);path+=(continuous?' L ':'M ')+point.x+' '+point.y;continuous=true;
  }
  let path10='',continuous10=false;
  if(settings.ema20)for(const {bar:index} of rows){const value=index<0?series.priorEma10?.[prior.length+index]:series.ema10?.[index];if(!Number.isFinite(value)){continuous10=false;continue;}const point=projectPoint({bar:index,price:value as number},viewport);path10+=(continuous10?' L ':'M ')+point.x+' '+point.y;continuous10=true;}
  const singleEma=settings.ema20&&viewport.count===1&&Number.isFinite(series.ema[viewport.startBar])?projectPoint({bar:viewport.startBar,price:series.ema[viewport.startBar]},viewport):null;
  const pivots=settings.pivotDiamonds?series.pivots.filter(pivot=>barInViewport(pivot.index,viewport)&&pivot.confirmedAt<=viewport.endBar+1):[];
  return <g data-layer="indicators" pointerEvents="none" aria-label="Saved chart indicators">
    {settings.ema20 && path10 && <path data-indicator="ema10" d={path10} fill="none" stroke="var(--appearance-ink-f6c760, #f6c760)" strokeWidth=".7" opacity=".3" vectorEffect="non-scaling-stroke"/>}
    {settings.ema20 && path && !singleEma && <path data-indicator="ema20" d={path} fill="none" stroke="var(--appearance-ink-f6c760, #f6c760)" strokeWidth="2" vectorEffect="non-scaling-stroke"><title>EMA20 · fixed period 20</title></path>}
    {singleEma && <circle data-indicator="ema20" cx={singleEma.x} cy={singleEma.y} r="2" fill="var(--appearance-ink-f6c760, #f6c760)"><title>EMA20 · fixed period 20</title></circle>}
    {pivots.map(pivot=>{const anchor=projectPoint({bar:pivot.index,price:pivot.price},viewport),y=anchor.y+(pivot.kind==='high'?-6:6),radius=4,held=pivot.heldFive&&pivot.index+5<=viewport.endBar,color=pivot.kind==='high'?(held?'var(--appearance-ink-f3d7ff, #f3d7ff)':'var(--appearance-ink-9276af, #9276af)'):(held?'var(--appearance-ink-c7efff, #c7efff)':'var(--appearance-ink-648dac, #648dac)');return <path key={`${pivot.kind}-${pivot.index}`} data-indicator="pivot-diamond" d={`M ${anchor.x} ${y-radius} L ${anchor.x+radius} ${y} L ${anchor.x} ${y+radius} L ${anchor.x-radius} ${y} Z`} fill={color} stroke="var(--appearance-line-142437, #142437)" strokeWidth="1"><title>{`${pivot.kind==='high'?'High':'Low'} pivot · candle ${pivot.index+1} · confirmed by candle ${pivot.confirmedAt}${held?' · held for the next five candles':''}`}</title></path>;})}
  </g>;
}

export function LessonChart({ data, viewport, marks, revealed, pending, cursor, selectedBars = [], foundIds = [], hideEMA20 = false, displayWidth = 960, teaching = false, interaction = {} }: { data: Preview; viewport: Viewport; marks: LearnerMark[]; revealed: boolean; pending?: Line | null; cursor?: Point | null; selectedBars?: number[]; foundIds?:string[]; hideEMA20?:boolean; displayWidth?:number; teaching?:boolean; interaction?: Record<string, unknown> }) {
  const { lesson, candles } = data, W = viewport.width, H = viewport.height;
  const {startBar,endBar,count} = viewport;
  const prior=Array.isArray(data.chart?.prior)?data.chart.prior as Preview['candles']:[],visible=visibleViewportCandles(candles,viewport,prior);
  const currentVisible=visible.filter(row=>row.bar>=0);
  const at = (bar: number, price: number) => projectPoint({ bar, price }, viewport);
  const barWidth = Math.max(1.2, (W - viewport.left - viewport.right) / count * 0.65);
  const barNumbers = layoutSlideBarNumbers(currentVisible.map(({candle,bar})=>{const point=at(bar,candle.h);return {bar,x:point.x,highY:point.y,pivotHigh:savedIndicatorSettings(lesson).pivotDiamonds&&!!data.indicatorSeries?.pivots.some(p=>p.index===bar&&p.kind==='high'&&p.confirmedAt<=endBar+1)};}),{left:viewport.left,right:W-viewport.right,top:viewport.top,bottom:H-viewport.bottom,step:(W-viewport.left-viewport.right)/count,scale:displayWidth/W});
  // Identical session/range charts share identical fixed viewBox clipping geometry.
  const clipId = `lesson-plot-${lesson.session.date}-${startBar}-${endBar}`;
  return <svg className="saved-chart lesson-attempt-chart" viewBox={`0 0 ${W} ${H}`} role="img" aria-label={`${lesson.title}: price chart${lesson.range ? `, candles ${startBar+1}–${endBar+1}` : ''}${teaching ? ' with visible teacher drawings and text' : revealed ? ' with teacher answer and your gray marks' : ' for your practice marks'}`} {...interaction} style={lesson.viewport?{...(interaction.style as object||{}),touchAction:'none',minWidth:0,maxWidth:'100%'}:interaction.style as React.CSSProperties} data-viewport-locked={lesson.viewport?'true':undefined}>
    <title>{`${lesson.title} — ${lesson.session.date}`}</title>
    <defs><clipPath id={clipId}><rect x={viewport.left} y={viewport.top} width={W-viewport.left-viewport.right} height={H-viewport.top-viewport.bottom} /></clipPath></defs>
    <rect width={W} height={H} fill="var(--appearance-surface-091521, #091521)" rx="9" />
    {Array.from({ length: 6 }, (_, i) => { const price = viewport.lo + (viewport.hi - viewport.lo) * i / 5, p = at(startBar, price); return <g key={i}><line x1={viewport.left} x2={W - viewport.right} y1={p.y} y2={p.y} stroke="var(--appearance-line-243749, #243749)" /><text x={viewport.left - 9} y={p.y + 4} textAnchor="end" fill="var(--appearance-ink-9bb3c9, #9bb3c9)" fontSize="12">{price.toFixed(2)}</text></g>; })}
    <g clipPath={lesson.range||lesson.viewport ? `url(#${clipId})` : undefined}>
    <g data-layer="learner-candle-picks" opacity={revealed ? 0.3 : 0.55}>{selectedBars.filter(bar=>barInViewport(bar,viewport)).map(bar => { const p = at(bar, 0); return <rect key={bar} x={p.x - Math.max(barWidth, 5) / 2 - 2} y={viewport.top} width={Math.max(barWidth, 5) + 4} height={H - viewport.top - viewport.bottom} fill={revealed ? GRAY : "var(--appearance-surface-275b80, #275b80)"} />; })}</g>
    {revealed && lesson.exercise?.type==='candle-picker' && <g data-layer="teacher-candle-picks" pointerEvents="none">{lesson.exercise.correctBars.filter(bar=>barInViewport(bar,viewport)).map(bar=>{const p=at(bar,0),width=Math.max(barWidth,5)+4;return <rect key={bar} x={p.x-width/2} y={viewport.top} width={width} height={H-viewport.top-viewport.bottom} fill="var(--appearance-ink-9ad1ff, #9ad1ff)" fillOpacity="0.14" stroke="var(--appearance-ink-9ad1ff, #9ad1ff)" strokeWidth="2" vectorEffect="non-scaling-stroke"><title>Correct candle {bar+1}</title></rect>;})}</g>}
    <g data-layer="candles">{visible.map(({candle,bar:i}) => { const color = candle.c >= candle.o ? 'var(--appearance-ink-8dd6b3, #8dd6b3)' : 'var(--appearance-ink-f09b9b, #f09b9b)', high = at(i, candle.h), low = at(i, candle.l), open = at(i, candle.o), close = at(i, candle.c); return <g key={candle.t}><line x1={high.x} x2={low.x} y1={high.y} y2={low.y} stroke={color} strokeWidth="1.3" /><rect x={open.x - barWidth / 2} y={Math.min(open.y, close.y)} width={barWidth} height={Math.max(1.2, Math.abs(open.y - close.y))} fill={color} /><title>{`${i<0?'Prior candle':'Candle '+(i+1)}: ${candle.t} · O ${candle.o} H ${candle.h} L ${candle.l} C ${candle.c}`}</title></g>; })}</g>
    <g data-layer="bar-numbers" pointerEvents="none" aria-label="Original session bar numbers">{barNumbers.map(label=><g key={label.bar}>{label.leader&&<line x1={label.x} y1={label.y+2} x2={label.anchorX} y2={label.anchorY} stroke="var(--appearance-ink-75849688, #75849688)" strokeWidth="0.7" vectorEffect="non-scaling-stroke"/>}<text data-bar-number={label.number} x={label.x} y={label.y} fill="var(--appearance-ink-bac8d6, #bac8d6)" fontSize={label.height} fontFamily="ui-monospace, monospace" textAnchor="middle" paintOrder="stroke" stroke="var(--appearance-line-091521, #091521)" strokeWidth={3/(displayWidth/W)} strokeLinejoin="round">{label.number}</text></g>)}</g>
    <SlideIndicators data={data} viewport={viewport} hideEMA20={hideEMA20} />
    {data.lesson.exercise?.type === 'clickable-areas' && foundIds.length > 0 && <g data-layer="found-targets">{data.lesson.exercise.targets.filter(target => foundIds.includes(target.id) && (viewport.frameStart!==undefined ? Math.max(target.a.bar,target.b.bar)+.5>viewport.frameStart&&Math.min(target.a.bar,target.b.bar)+.5<viewport.frameStart+viewport.count&&Math.max(target.a.price,target.b.price)>viewport.lo&&Math.min(target.a.price,target.b.price)<viewport.hi : barInViewport(target.a.bar,viewport) && barInViewport(target.b.bar,viewport))).map(target => {const a=projectPoint(target.a,viewport),b=projectPoint(target.b,viewport);return <rect key={target.id} x={Math.min(a.x,b.x)} y={Math.min(a.y,b.y)} width={Math.abs(b.x-a.x)} height={Math.abs(b.y-a.y)} fill="var(--appearance-ink-55b5dd, #55b5dd)" fillOpacity={revealed?0.1:0.2} stroke="var(--appearance-ink-80d8ff, #80d8ff)" strokeWidth="2" />;})}</g>}
    <g data-layer="learner" opacity={revealed ? 0.46 : 1}>{marks.map(mark => {const clipped=mark.kind==='line'?clipLineToRange(mark,viewport):null;if(mark.kind==='line'?!clipped:!barInViewport(mark.at.bar,viewport))return null;return <g key={mark.id} data-learner-id={revealed ? undefined : mark.id}>{mark.kind === 'line' ? <><line x1={projectPoint(clipped!.a,viewport).x} y1={projectPoint(clipped!.a,viewport).y} x2={projectPoint(clipped!.b,viewport).x} y2={projectPoint(clipped!.b,viewport).y} stroke="transparent" strokeWidth="14" /><DrawnLine mark={mark} viewport={viewport} muted={revealed} /></> : mark.kind === 'arrow' ? <ArrowMark mark={mark} viewport={viewport} muted={revealed} /> : <Label mark={mark} viewport={viewport} muted={revealed} />}</g>;})}</g>
    {revealed && <g data-layer="teacher"><g clipPath={`url(#${clipId})`}>{(lesson.filledShapes||[]).map(mark=><FilledDrawing key={mark.id} mark={mark} viewport={viewport}/>)}</g>{(lesson.connectedLines||[]).map(mark=><ConnectedDrawing key={mark.id} mark={mark} viewport={viewport}/>)}{lesson.lines.map(mark => <DrawnLine key={mark.id} mark={mark} viewport={viewport} teacher />)}{(lesson.arrows || []).filter(mark=>barInViewport(mark.at.bar,viewport)).map(mark => <ArrowMark key={mark.id} mark={mark} viewport={viewport} />)}{lesson.annotations.filter(mark=>barInViewport(mark.at.bar,viewport)).map(mark => <Label key={mark.id} mark={mark} viewport={viewport} />)}</g>}
    {!revealed && pending && <g data-layer="pending" opacity="0.65"><DrawnLine mark={pending} viewport={viewport} />{barInViewport(pending.a.bar,viewport)&&<circle cx={projectPoint(pending.a, viewport).x} cy={projectPoint(pending.a, viewport).y} r="4" fill={pending.color} />}</g>}
    {!revealed && cursor && barInViewport(cursor.bar,viewport) && <circle cx={projectPoint(cursor, viewport).x} cy={projectPoint(cursor, viewport).y} r="6" fill="none" stroke="var(--appearance-ink-c2e6ff, #c2e6ff)" strokeWidth="1.6" />}
    </g>
    {Array.from(new Set([0,Math.floor((visible.length-1)/4),Math.floor((visible.length-1)/2),Math.floor((visible.length-1)*3/4),visible.length-1])).filter(offset=>offset>=0&&visible[offset]).map(offset=>{const {bar:i,candle}=visible[offset];return <text key={i} x={at(i,0).x} y={H-16} fill="var(--appearance-ink-9bb3c9, #9bb3c9)" fontSize="12" textAnchor="middle">{lesson.range?`${i+1} · ${candle.t.slice(-5)}`:candle.t.slice(-5)}</text>})}
  </svg>;
}

export function LessonAttempt({ data, onNext, hasNext = false, onPhaseChange, navigation }: { data: Preview; navigation?: ReactNode; onNext?: () => void | Promise<void>; hasNext?: boolean; onPhaseChange?: (phase: string) => void }) {
  const picker = data.lesson.exercise?.type === 'candle-picker', areas = data.lesson.exercise?.type === 'clickable-areas';
  const targets = data.lesson.exercise?.type === 'clickable-areas' ? data.lesson.exercise.targets : [];
  const settings = savedIndicatorSettings(data.lesson);
  const viewport = useMemo(() => createViewport(data.candles, data.lesson.lines, data.lesson.annotations, data.lesson.arrows || [], targets, data.lesson.range, settings.ema20 ? data.indicatorSeries?.ema || [] : [], data.lesson.connectedLines || [],data.lesson.filledShapes||[],data.lesson.viewport,Array.isArray(data.chart?.prior)?data.chart.prior:[]), [data]);
  const [attempt, setAttempt] = useState<Attempt>(() => newAttempt()), attemptRef = useRef<Attempt>(attempt);
  const [tool, setTool] = useState<Tool>(null), toolRef = useRef<Tool>(null);
  const [color, setColor] = useState('var(--appearance-ink-ff8e11, #ff8e11)'), [size, setSize] = useState(18), [text, setText] = useState('');
  const [direction, setDirection] = useState<'up' | 'down'>('up'), [arrowStyle, setArrowStyle] = useState<'normal' | 'study' | 'crossed'>('normal');
  const [pending, setPending] = useState<Line | null>(null), anchor = useRef<Point | null>(null);
  const [cursor, setCursor] = useState<Point | null>(null), [message, setMessage] = useState('');
  const [selectedId, setSelectedId] = useState(''), selectedRef = useRef('');
  const [candleNumber, setCandleNumber] = useState(viewport.startBar + 1);
  const [nextBusy,setNextBusy]=useState(false),nextPending=useRef(false),mounted=useRef(true);
  useEffect(()=>{mounted.current=true;return()=>{mounted.current=false;};},[]);
  const gesture = useRef<{ id: number; start: Point | null; hadAnchor: boolean; clientX:number;clientY:number } | null>(null), sequence = useRef(0);
  const completed = attempt.phase === 'revealed', studyRevealed = attempt.phase === 'study-revealed', revealed = completed || studyRevealed;
  useEffect(() => { onPhaseChange?.(attempt.phase); }, [attempt.phase,onPhaseChange]);
  const chartShell = useRef<HTMLDivElement | null>(null), [chartWidth,setChartWidth] = useState(960);
  useEffect(()=>{const element=chartShell.current;if(!element||typeof ResizeObserver==='undefined')return;const observer=new ResizeObserver(entries=>{const width=entries[0]?.contentRect.width;if(width>0)setChartWidth(width);});observer.observe(element);return()=>observer.disconnect();},[]);
  const currentOptions = useRef({ color, size, text, direction, arrowStyle }); currentOptions.current = { color, size, text, direction, arrowStyle };
  const cursorRef = useRef<Point | null>(null);
  // Only a committed preview can admit actions. Discarded renders never invalidate live handlers.
  const committedData = useRef<Preview | null>(null);
  const policyKey = JSON.stringify(learnerToolPolicy(data.lesson));
  useLayoutEffect(() => { committedData.current = data; return () => { committedData.current = null; }; }, [data]);
  useLayoutEffect(() => {
    if (toolRef.current && !learnerToolAllowed(data.lesson, toolRef.current)) { cancelDraft(); toolRef.current = null; setTool(null); }
    if (selectedRef.current && !learnerActionAllowed(data.lesson, {type:'select',id:selectedRef.current}, attemptRef.current.marks)) { selectedRef.current = ''; setSelectedId(''); }
  }, [data, policyKey]);
  function currentAttempt() { return mounted.current && committedData.current === data; }
  function allowed(control: string) { return currentAttempt() && learnerToolAllowed(committedData.current!.lesson, control); }
  function activeToolAllowed() { return currentAttempt() && (!toolRef.current || allowed(toolRef.current)); }
  function apply(action: { type: string; mark?: LearnerMark; id?: string; bar?: number; ids?:string[] }) { if (!currentAttempt()) return; const next = attemptReducer(attemptRef.current, action, committedData.current!.lesson) as Attempt; const phaseChanged = next.phase !== attemptRef.current.phase; attemptRef.current = next; if (phaseChanged) onPhaseChange?.(next.phase); setAttempt(next); }
  function cancelDraft() { gesture.current = null; anchor.current = null; setPending(null); }
  function chooseTool(next: Tool) { if (!currentAttempt() || next && !allowed(next)) return; cancelDraft(); selectedRef.current = ''; setSelectedId(''); toolRef.current = next; setTool(next); setMessage(''); }
  function changePhase(type: 'reveal' | 'study-reveal' | 'replay') { if (!currentAttempt()) return; if(type!=='replay'&&(attemptRef.current.phase!=='practice'||type==='study-reveal'&&!picker))return; if (type === 'reveal' && areas && !allTargetsFound(targets,attemptRef.current.foundIds)) return; if (type === 'reveal' && picker && !exactCandleSelection(attemptRef.current.selectedBars, data.lesson.exercise?.type === 'candle-picker' ? data.lesson.exercise.correctBars : [])) { setMessage('Not quite. Change your candle selection and try again.'); return; } cancelDraft(); selectedRef.current = ''; setSelectedId(''); toolRef.current = null; setTool(null); setCursor(null); cursorRef.current = null; setMessage(''); setText(''); if(type==='replay')setCandleNumber(viewport.startBar + 1); apply({ type }); }
  function addMark(mark: LearnerMark) { if (!allowed(mark.kind) || attemptRef.current.phase !== 'practice') return; if (attemptRef.current.marks.length >= MAX_LEARNER_MARKS) { setMessage('This attempt has 80 marks. Undo or clear some before adding more.'); return; } apply({ type: 'add', mark }); setMessage('Mark added.'); }
  function markerAt(point: Point) {
    if (!activeToolAllowed()) return;
    const settings = currentOptions.current, id = 'learner_' + (++sequence.current);
    if (toolRef.current === 'arrow') addMark({ id, kind: 'arrow', at: point, direction: settings.direction, study: settings.arrowStyle === 'study', crossed: settings.arrowStyle === 'crossed' });
    if (toolRef.current === 'text') { if (!validLearnerText(settings.text)) { setMessage('Enter a note of 1–500 characters, then select its place on the chart.'); return; } addMark({ id, kind: 'text', at: point, text: settings.text.trim(), color: settings.color, size: settings.size }); }
  }
  function finishLine(point: Point) { if (!allowed('line')) return false; const first = anchor.current; if (!first || !distantEnough(first, point, viewport)) return false; addMark({ id: 'learner_' + (++sequence.current), kind: 'line', a: first, b: point, color: currentOptions.current.color, style: 'dotted' }); anchor.current = null; setPending(null); return true; }
  function selectPoint(point: Point) { if (!activeToolAllowed()) return; if (attemptRef.current.phase !== 'practice' || !barInViewport(point.bar,viewport)) return; if (areas && !toolRef.current) { discover(point); return; } if (picker && !toolRef.current) { apply({type:'toggle-candle',bar:point.bar}); setMessage('Candle ' + (point.bar+1) + ' selection changed.'); return; } if (toolRef.current === 'line') { if (anchor.current) finishLine(point); else { anchor.current = point; setPending({ id: 'pending', a: point, b: point, color: currentOptions.current.color }); setMessage('Choose the second endpoint.'); } } else markerAt(point); }
  function selectMark(id: string) {
    if (!currentAttempt() || !learnerActionAllowed(committedData.current!.lesson, {type:'select',id}, attemptRef.current.marks)) return;
    cancelDraft(); const mark = attemptRef.current.marks.find(value => value.id === id); selectedRef.current = mark ? id : ''; setSelectedId(selectedRef.current);
    if (!mark) return; toolRef.current = mark.kind; setTool(mark.kind);
    if (mark.kind === 'arrow') { setDirection(mark.direction); setArrowStyle(mark.crossed ? 'crossed' : mark.study ? 'study' : 'normal'); }
    else { setColor(mark.color); if (mark.kind === 'text') { setText(mark.text); setSize(mark.size); } }
    setMessage('Edit this mark above and apply changes. To remove a mark, choose Eraser.');
  }
  function updateSelected() {
    const mark = attemptRef.current.marks.find(value => value.id === selectedRef.current), settings = currentOptions.current;
    if (!currentAttempt() || !mark || attemptRef.current.phase !== 'practice' || !learnerActionAllowed(committedData.current!.lesson, {type:'select',id:mark.id}, attemptRef.current.marks)) return;
    if (mark.kind === 'text' && !validLearnerText(settings.text)) { setMessage('Enter a note of 1–500 characters.'); return; }
    const next: LearnerMark = mark.kind === 'arrow' ? {...mark,direction:settings.direction,study:settings.arrowStyle==='study',crossed:settings.arrowStyle==='crossed'} : mark.kind === 'text' ? {...mark,text:settings.text.trim(),color:settings.color,size:settings.size} : {...mark,color:settings.color};
    apply({type:'update',mark:next}); setMessage('Your mark updated.');
  }
  function checkAnswer() { changePhase('reveal'); }
  function discover(position:{bar:number;price:number}) { if(!currentAttempt())return;if(attemptRef.current.phase!=='practice'||!areas)return;const ids=hitTargetIds(targets,position,attemptRef.current.foundIds);if(!ids.length){setMessage('No new area found. Try another location.');return;}apply({type:'discover',ids});if(allTargetsFound(targets,attemptRef.current.foundIds)){changePhase('reveal');setMessage('All areas found.');}else setMessage(ids.length===1?'Area found. Keep looking.':'Areas found. Keep looking.'); }
  async function nextLesson() { if(attemptRef.current.phase!=='revealed'||!hasNext||nextPending.current)return;nextPending.current=true;setNextBusy(true);try{await onNext?.();}catch{if(mounted.current)setMessage('The next slide could not be opened. Please try again.');}finally{nextPending.current=false;if(mounted.current)setNextBusy(false);} }
  function eraseAt(position: {x:number;y:number}, svg: SVGSVGElement, pointerType = 'mouse') {
    if (!allowed('erase') || attemptRef.current.phase !== 'practice' || toolRef.current !== 'erase') return;
    const rect = svg.getBoundingClientRect(), scale = Math.min(rect.width / viewport.width,rect.height / viewport.height);
    const textBounds: Record<string,{x:number;y:number;width:number;height:number}> = {};
    for (const element of svg.querySelectorAll?.('[data-layer="learner"] > g[data-learner-id]') || []) {
      const id = element.getAttribute('data-learner-id') || '';
      if (!attemptRef.current.marks.some(mark => mark.id === id && mark.kind === 'text' && barInViewport(mark.at.bar,viewport))) continue;
      try { const box = (element as SVGGElement).getBBox(); if ([box.x,box.y,box.width,box.height].every(Number.isFinite) && box.width > 0 && box.height > 0) textBounds[id] = {x:box.x,y:box.y,width:box.width,height:box.height}; } catch { /* Pure-state tests and non-rendered SVG use shared text layout. */ }
    }
    const id = hitLearnerMark(attemptRef.current.marks,position,viewport,scale,pointerType,textBounds);
    if (id) { apply({type:'remove',id}); selectedRef.current='';setSelectedId('');setMessage('Mark removed. Undo restores it.'); }
    else setMessage('No learner marking there. Tap the marking to remove');
  }
  function eventPosition(event:PointerEvent<SVGSVGElement>){const local=clientToSvg(event.clientX,event.clientY,event.currentTarget.getBoundingClientRect(),viewport);return local?chartPositionFromSvg(local.x,local.y,viewport):null;}
  function eventPoint(event: PointerEvent<SVGSVGElement>) { const local = clientToSvg(event.clientX, event.clientY, event.currentTarget.getBoundingClientRect(), viewport); return local ? pointFromSvg(local.x, local.y, viewport, data.candles) as Point | null : null; }
  function pointerDown(event: PointerEvent<SVGSVGElement>) {
    if (!activeToolAllowed() || attemptRef.current.phase !== 'practice' || !event.isPrimary || event.button !== 0 || gesture.current) return;
    const target = (event.target as Element | null)?.closest?.('[data-learner-id]'); if (target && learnerActionAllowed(committedData.current!.lesson, {type:'select',id:target.getAttribute('data-learner-id') || ''}, attemptRef.current.marks) && toolRef.current !== 'erase' && !(toolRef.current === 'line' && anchor.current)) { event.preventDefault(); selectMark(target.getAttribute('data-learner-id') || ''); return; }
    if (!toolRef.current && !picker && !areas) return;
    selectedRef.current = ''; setSelectedId('');
    const point = eventPoint(event), local = clientToSvg(event.clientX,event.clientY,event.currentTarget.getBoundingClientRect(),viewport); if (toolRef.current === 'erase' ? !local || local.x < 0 || local.y < 0 || local.x > viewport.width || local.y > viewport.height : !point) return; if (toolRef.current) event.preventDefault(); event.currentTarget.focus({preventScroll:true});
    gesture.current = { id: event.pointerId, start: point, hadAnchor: !!anchor.current,clientX:event.clientX,clientY:event.clientY }; cursorRef.current = point;
    if (toolRef.current === 'line' && point) { if (!anchor.current) anchor.current = point; setPending({ id: 'pending', a: anchor.current, b: point, color: currentOptions.current.color }); }
    try { event.currentTarget.setPointerCapture(event.pointerId); } catch { /* Keyboard/synthetic pointers can lack capture. */ }
  }
  function pointerMove(event: PointerEvent<SVGSVGElement>) {
    if (!activeToolAllowed() || attemptRef.current.phase !== 'practice' || !toolRef.current || !event.isPrimary) return;
    const point = eventPoint(event); if (!point) return; cursorRef.current = point;
    if (toolRef.current === 'line' && anchor.current) setPending({ id: 'pending', a: anchor.current, b: point, color: currentOptions.current.color });
  }
  function pointerUp(event: PointerEvent<SVGSVGElement>) {
    if (!activeToolAllowed()) return;
    const active = gesture.current; if (!active || active.id !== event.pointerId) return; gesture.current = null;
    try { if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId); } catch {}
    if (attemptRef.current.phase !== 'practice') return; if (toolRef.current === 'erase') { if (Math.hypot(event.clientX-active.clientX,event.clientY-active.clientY) <= 8) { const local=clientToSvg(event.clientX,event.clientY,event.currentTarget.getBoundingClientRect(),viewport);if(local)eraseAt(local,event.currentTarget,event.pointerType); } return; } const point = eventPoint(event); if (!point) { cancelDraft(); return; }
    if ((picker||areas) && !toolRef.current) { if(Math.hypot(event.clientX-active.clientX,event.clientY-active.clientY)<=8){if(areas){const position=eventPosition(event);if(position)discover(position);}else selectPoint(point);} return; }
    if (toolRef.current === 'line') { if (active.hadAnchor || active.start && distantEnough(active.start, point, viewport)) finishLine(point); else setMessage('Choose the second endpoint, or drag from the first to the second.'); } else markerAt(point);
  }
  function pointerCancel(event: PointerEvent<SVGSVGElement>) { if (!currentAttempt()) return; if (gesture.current?.id === event.pointerId) { cancelDraft(); setMessage('Unfinished mark canceled. Your completed marks remain.'); } }
  function keyDown(event: KeyboardEvent<SVGSVGElement>) {
    if (!activeToolAllowed()) return;
    const target = event.target as HTMLElement | null;
    if (event.defaultPrevented || event.ctrlKey || event.altKey || event.metaKey || event.nativeEvent?.isComposing || event.nativeEvent?.keyCode === 229 || target?.isContentEditable || target?.closest?.('input,textarea,select,[contenteditable]:not([contenteditable="false"])')) return;
    if (event.shiftKey && !['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(event.key)) return;
    const key = ({ w: 'ArrowUp', a: 'ArrowLeft', s: 'ArrowDown', d: 'ArrowRight' } as Record<string, string>)[event.key.toLowerCase()] || event.key;
    if (attemptRef.current.phase !== 'practice' || (!toolRef.current && !picker && !areas)) return;
    if (key === 'Escape') { event.preventDefault(); event.stopPropagation?.(); cancelDraft(); setMessage('Unfinished mark canceled.'); return; }
    if(viewport.startBar>viewport.endBar||!data.candles[viewport.startBar])return;
    const middle=Math.floor((viewport.startBar+viewport.endBar)/2);
    const point = cursorRef.current || { bar: middle, t: data.candles[middle].t, price: (viewport.lo + viewport.hi) / 2 };
    if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(key)) { event.preventDefault(); event.stopPropagation?.(); const bar = Math.max(viewport.startBar, Math.min(viewport.endBar, point.bar + (key === 'ArrowRight' ? 1 : key === 'ArrowLeft' ? -1 : 0))); const price = Math.max(viewport.lo, Math.min(viewport.hi, point.price + (key === 'ArrowUp' ? 1 : key === 'ArrowDown' ? -1 : 0) * (viewport.hi - viewport.lo) / (event.shiftKey ? 400 : 40))); const next = { bar, t: data.candles[bar].t, price }; cursorRef.current = next; setCursor(next); if (anchor.current) setPending({ id: 'pending', a: anchor.current, b: next, color }); }
    else if (key === 'Enter' || key === ' ') { event.preventDefault(); event.stopPropagation?.(); cursorRef.current = point; setCursor(point); if(toolRef.current==='erase')eraseAt(projectPoint(point,viewport),event.currentTarget,'keyboard');else selectPoint(point); }
  }
  const toolVisible = (value: string) => learnerToolAllowed(data.lesson, value);
  const editableMarks = attempt.marks.filter(mark => toolVisible('select') && toolVisible(mark.kind));
  const interaction = { tabIndex: 0, 'aria-description': 'Use arrow keys or W A S D to move the cursor, Enter to act, and Escape to cancel an unfinished mark. Hold Shift with Up or Down for finer price movement.', 'aria-keyshortcuts': 'ArrowUp ArrowLeft ArrowDown ArrowRight W A S D Enter Escape', onPointerDown: pointerDown, onPointerMove: pointerMove, onPointerUp: pointerUp, onPointerCancel: pointerCancel, onLostPointerCapture: pointerCancel, onKeyDown: keyDown, onBlur: () => { if (currentAttempt()) { cancelDraft(); setCursor(null); } }, onContextMenu: (event: { preventDefault: () => void }) => { if (toolRef.current) event.preventDefault(); }, style: { touchAction: data.lesson.viewport || tool && !revealed ? 'none' : 'auto', cursor: tool === 'erase' && !revealed ? ERASER_CURSOR : tool && !revealed ? 'crosshair' : 'default' } };
  return <section className="saved-lesson-review lesson-attempt" aria-label="Slide practice" data-phase={attempt.phase}>
    <div className="lesson-practice-controls" tabIndex={0} role="region" aria-label="Slide question and drawing controls">
    <div className="lesson-question"><p className="lesson-initial-prompt">{data.lesson.prompt?.trim() || 'Study the chart.'}</p>{!revealed && <p className="field-help lesson-drawing-help">{tool === 'erase' ? 'Click a mark to erase it.' : tool === 'line' ? 'Click two endpoints or drag to draw a line.' : tool === 'arrow' ? 'Click the chart to place an arrow.' : tool === 'text' ? 'Enter your text, then click the chart to place it.' : areas ? 'Click each target area on the chart.' : picker ? 'Select the answer candles, then choose Check Answer.' : 'Choose Reveal to see the teacher’s drawings.'}</p>}</div>
    {revealed && <section className="lesson-final-answer" aria-label="Teacher answer" aria-live="polite"><h3>{studyRevealed ? 'Answer · study mode' : 'Final explanation'}</h3>{studyRevealed && <p className="lesson-study-notice">Study only — Replay and answer correctly to continue.</p>}{picker && data.lesson.exercise?.type==='candle-picker' && <p className="lesson-correct-candles"><strong>Correct candles:</strong> {[...data.lesson.exercise.correctBars].sort((a,b)=>a-b).map(bar=>bar+1).join(', ')}</p>}{data.lesson.notes && <p className="saved-lesson-notes">{data.lesson.notes}</p>}{(data.lesson.lines.some(line => line.label && barInViewport(line.b.bar,viewport) && clipLineToRange(line,viewport)) || data.lesson.annotations.some(mark=>barInViewport(mark.at.bar,viewport))) && <details className="review-mark-list"><summary>Teacher labels &amp; annotations</summary><ul>{data.lesson.lines.filter(line => line.label && barInViewport(line.b.bar,viewport) && clipLineToRange(line,viewport)).map(line => <li key={line.id}>{line.label}</li>)}{data.lesson.annotations.filter(mark=>barInViewport(mark.at.bar,viewport)).map(mark => <li key={mark.id}>{mark.text}</li>)}</ul></details>}</section>}
    {areas && !revealed && <p className="field-help" role="status">{attempt.foundIds.length} areas found.</p>}
    {picker && !revealed && <section className="lesson-candle-picker" aria-label="Candle Picker"><div className="lesson-tool-options"><label>Candle number<input type="number" min={viewport.startBar+1} max={viewport.endBar+1} step={1} value={candleNumber} onChange={event => setCandleNumber(Number(event.target.value))} /></label><button className="quiet-button" disabled={!Number.isInteger(candleNumber) || candleNumber < viewport.startBar+1 || candleNumber > viewport.endBar+1} onClick={() => { if (Number.isInteger(candleNumber) && candleNumber >= viewport.startBar+1 && candleNumber <= viewport.endBar+1) apply({type:'toggle-candle',bar:candleNumber-1}); }}>Toggle candle</button><span className="field-help">Candles {viewport.startBar+1}–{viewport.endBar+1}</span></div><div className="lesson-selected-candles" aria-label="Your selected candles">{attempt.selectedBars.length ? attempt.selectedBars.map(bar => <button key={bar} className="quiet-button" aria-label={`Unselect candle ${bar+1}`} onClick={() => apply({type:'toggle-candle',bar})}>{bar+1} ×</button>) : <p className="field-help">No candles selected.</p>}</div></section>}
    {!revealed && <><div className="lesson-mark-toolbar" role="group" aria-label="Learner mark tools">{([['arrow', '↕ Arrows'], ['line', '⋯ Line'], ['text', 'T Text'], ['erase', 'Eraser']] as const).filter(([value]) => toolVisible(value)).map(([value, label]) => <button key={value} className="quiet-button" aria-pressed={tool === value} onClick={() => chooseTool(toolRef.current === value ? null : value)}>{label}</button>)}<button className="quiet-button" disabled={!tool} onClick={() => chooseTool(null)}>Done drawing</button>{toolVisible('undo') && <button className="quiet-button" disabled={!attempt.history.length} onClick={() => { if (!allowed('undo')) return; cancelDraft(); apply({ type: 'undo' }); setMessage('Last change undone.'); }}>Undo</button>}{toolVisible('clear') && <button className="quiet-button" disabled={!attempt.marks.length} onClick={() => { if (!allowed('clear')) return; cancelDraft(); apply({ type: 'clear' }); setMessage('Your marks cleared. Undo restores them.'); }}>Clear</button>}</div>
      {tool === 'arrow' && <div className="lesson-tool-options"><label>Direction<select value={direction} onChange={event => setDirection(event.target.value as 'up' | 'down')}><option value="up">Up · green</option><option value="down">Down · red</option></select></label><label>Style<select value={arrowStyle} onChange={event => setArrowStyle(event.target.value as 'normal' | 'study' | 'crossed')}><option value="normal">Normal arrow</option><option value="study">Study · blue</option><option value="crossed">Crossed · purple X</option></select></label></div>}
      {(tool === 'line' || tool === 'text') && <div className="lesson-tool-options"><div className="lesson-palette" role="group" aria-label="Line and text color">{COLORS.map(value => <button key={value} type="button" aria-label={`Color ${value}`} aria-pressed={color === value} style={{ backgroundColor: value }} onClick={() => setColor(value)} />)}<label>Custom color<input type="color" value={color} onChange={event => setColor(event.target.value)} /></label></div>{tool === 'text' && <><label>Text size<select value={size} onChange={event => setSize(Number(event.target.value))}>{[14,18,22,26].map(value => <option key={value} value={value}>{value}</option>)}</select></label><label className="lesson-text-entry">Your text<textarea maxLength={500} value={text} onChange={event => setText(event.target.value)} placeholder="Write a note, then select its place on the chart" /></label></>}</div>}
      </>}
    </div>
    <div className="lesson-chart-area"><div className="saved-chart-scroll" ref={chartShell} style={data.lesson.viewport?{overflow:'hidden'}:undefined}><LessonChart data={data} viewport={viewport} marks={attempt.marks} revealed={revealed} pending={pending} cursor={cursor} selectedBars={attempt.selectedBars} foundIds={attempt.foundIds} hideEMA20={false} displayWidth={chartWidth} interaction={interaction} /></div></div>
    {!revealed && cursor && <p className="field-help" aria-live="polite">Cursor: candle {cursor.bar + 1}, price {cursor.price.toFixed(4)}.</p>}
    {(picker || areas) && !revealed && editableMarks.length > 0 && <div className="lesson-tool-options lesson-edit-mark"><label>Edit your marks<select value={editableMarks.some(mark => mark.id === selectedId) ? selectedId : ''} onChange={event => selectMark(event.target.value)}><option value="">Select a mark to edit</option>{editableMarks.map((mark,index) => <option key={mark.id} value={mark.id}>{index+1} · {mark.kind}{mark.kind === 'text' ? ' · ' + mark.text.slice(0,30) : ''}</option>)}</select></label><button className="quiet-button" disabled={!editableMarks.some(mark => mark.id === selectedId)} onClick={updateSelected}>Apply changes</button></div>}
    <p className="lesson-attempt-status" role="status" aria-live="polite">{message}</p>

    <div className="lesson-attempt-actions">{(picker || areas || revealed) && <button className="quiet-button" disabled={nextBusy} onClick={() => changePhase('replay')}>Replay</button>}{!revealed && !areas && <button className={`primary-button lesson-reveal${picker ? '' : ' lesson-reveal-primary'}`} onClick={picker ? checkAnswer : () => changePhase('reveal')}>{picker ? 'Check Answer' : 'Reveal'}</button>}{picker && !revealed && <button className="quiet-button lesson-study-reveal" onClick={() => changePhase('study-reveal')}>Reveal Answer</button>}{navigation}{hasNext ? (picker || areas || revealed) && <button className="primary-button" disabled={!completed || nextBusy} onClick={nextLesson}>{nextBusy ? <LoadingIndicator label="Opening next slide…" size="small" /> : 'Next Slide →'}</button> : !onPhaseChange && (picker || areas || revealed) && <p className="field-help">{completed ? 'You completed the last slide in this selection.' : studyRevealed ? 'Study the answer, then Replay for a fresh attempt.' : 'Complete this slide to finish this selection.'}</p>}</div>
  </section>;
}
function LessonLoader({ lesson, onNext, hasNext }: { lesson: Lesson; onNext?: () => void | Promise<void>; hasNext?: boolean }) {
  const [preview, setPreview] = useState<Preview | null>(null), [error, setError] = useState('');
  useEffect(() => { const controller = new AbortController(); setPreview(null); setError(''); loadLessonReview(lesson, { signal: controller.signal }).then(value => { if (!controller.signal.aborted) setPreview(value as Preview); }).catch(problem => { if (!controller.signal.aborted) setError(problem instanceof Error ? problem.message : 'The saved slide could not be loaded.'); }); return () => controller.abort(); }, [lesson.packUrl, lesson.pack?.sha256, lesson.pack?.bytes]);
  if (error) return <p className="notice error" role="alert">{error} Your saved slide has not been changed.</p>;
  if (!preview) return <p className="notice info" role="status"><LoadingIndicator label="Loading the original price chart…" /></p>;
  return <LessonAttempt data={preview} onNext={onNext} hasNext={hasNext} />;
}
export default function SavedLessonReview({ lesson, onNext, hasNext }: { lesson: Lesson; onNext?: () => void | Promise<void>; hasNext?: boolean }) {
  // A new lesson/version unmounts the entire old attempt before loading; no old revealed answer flashes.
  return <LessonLoader key={`${lesson.id}:${lesson.versionId}:${lesson.pack?.sha256 || ''}:${lesson.packUrl || ''}`} lesson={lesson} onNext={onNext} hasNext={hasNext} />;
}
