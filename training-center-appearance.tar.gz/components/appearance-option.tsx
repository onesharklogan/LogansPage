"use client";
import {useEffect,useRef,useState} from 'react';
import {createLearnerClient} from '../lib/learner/client.mjs';
export default function AppearanceOption({client,canChange,disabled=false}:{client:ReturnType<typeof createLearnerClient>;canChange:()=>boolean;disabled?:boolean}){
 const [snapshot,setSnapshot]=useState(client.getSnapshot),[saving,setSaving]=useState(false),[message,setMessage]=useState('');const live=useRef(false);
 useEffect(()=>{live.current=true;const off=client.subscribe(setSnapshot);return()=>{live.current=false;off();};},[client]);
 async function change(appearance:string){const capture=client.captureContext();if(!canChange()||saving||!capture)return;setSaving(true);setMessage('');try{await client.saveAppearance(appearance,capture);if(live.current&&client.guard(capture))setMessage('Appearance saved to your profile.');}catch(e){if(live.current&&client.guard(capture))setMessage(e instanceof Error?e.message:'Appearance could not be saved.');}finally{if(live.current)setSaving(false);}}
 return <fieldset className="appearance-choice" disabled={disabled||saving}><legend>Appearance</legend><div>{['light','dark'].map(value=><label key={value}><input type="radio" name="appearance" value={value} checked={(snapshot.preferences.appearance||'dark')===value} onChange={()=>void change(value)}/>{value==='light'?'Light':'Dark'}</label>)}</div><p>Saved to your profile across pages and devices.</p><p role="status">{saving?'Saving appearance…':message}</p></fieldset>;
}
