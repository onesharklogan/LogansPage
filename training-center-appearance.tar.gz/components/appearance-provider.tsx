"use client";
import {useEffect} from 'react';
import {learnerClient} from '../lib/learner/client.mjs';
/** Only a verified account selects a theme. No shared localStorage preference leaks between users. */
export default function AppearanceProvider(){
 useEffect(()=>{
  const paint=(theme:string)=>{document.documentElement.dataset.appearance=theme;for(const frame of document.querySelectorAll('iframe')){try{frame.contentWindow?.postMessage({type:'patc-appearance',appearance:theme},location.origin);}catch{}}};
  const receive=(event:MessageEvent)=>{if(window.parent!==window&&event.source===window.parent&&event.origin===location.origin&&event.data?.type==='patc-appearance'&&['light','dark'].includes(event.data.appearance))paint(event.data.appearance);};
  const apply=(snapshot:ReturnType<typeof learnerClient.getSnapshot>)=>{
   const theme=snapshot.mode==='account'&&snapshot.profile&&snapshot.ready&&!snapshot.reconcileRequired&&!snapshot.signOutNeeded&&snapshot.preferences.appearance==='light'?'light':'dark';
   paint(theme);
  };
  const onLoad=(event:Event)=>{if(event.target instanceof HTMLIFrameElement)apply(learnerClient.getSnapshot());};
  const off=learnerClient.subscribe(apply);apply(learnerClient.getSnapshot());void learnerClient.refresh();document.addEventListener('load',onLoad,true);window.addEventListener('message',receive);
  return()=>{off();document.removeEventListener('load',onLoad,true);window.removeEventListener('message',receive);};
 },[]);return null;
}
