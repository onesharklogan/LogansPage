# Account appearance (local implementation, not deployed)

Light / Dark is stored in `learner_app.accounts.appearance`. Existing accounts default to Dark. `027_learner_appearance.sql` is a prepared, additive migration, tested on disposable PGlite only. It is not called by the build or existing migration runner. Applying it to any real database is a separate deployment action.

The preference follows the current learner principal and existing account/session/generation/CSRF checks. The client applies only a validated server acknowledgement. Failed saves retain the confirmed appearance. There is no global browser-storage theme key. Guest/sign-out/account changes cannot inherit another account's saved preference. Full navigation reloads the account session and reads its saved choice.

`AppearanceProvider` sets the root `data-appearance` attribute. `public/appearance.css` pairs the extensive legacy literal colors with Light tokens; each original declaration retains its exact Dark fallback. The profile selector is `AppearanceOption`. Same-origin embedded workspaces accept theme messages only from their own parent. Market Orders canvas paint values are resolved by `patcPaint`; geometry, candles, decisions, matching, scoring and calculations are unchanged. Existing uploaded screenshots and annotation pixels are not inverted, recolored or re-encoded. Red/green meaning and EMA widths/opacities are preserved.

## Verification

- `npm test`: 163 tests, including current branch regressions, compatible recovered matcher/account/simulator tests, appearance persistence/isolation/failure tests, and identical ranking across all 718 historical candidates for 42/45/81-bar source sessions.
- `npm run typecheck`, `npm run build -- --webpack`, `npm run check:release`.
- The accompanying `verify-preservation.mjs` compares the reconstructed baseline and candidate: immutable computation/data/image files; paint-only React changes; identical standalone script logic after removing the explicit paint wrapper and redraw listener.
- No upstream lint command/configuration exists. The accompanying syntax audit validates JS/TS/TSX/inline scripts and CSS; it is not an ESLint pass.

## Browser verification

The managed local preview at http://127.0.0.1:4173/ uses a separate QA wrapper and disposable PGlite synthetic account, with external auth disabled. No production account or database was used. CUA verified saving Light in the profile, a successful acknowledgement, reload and navigation persistence; desktop Market Orders candles/overview/EMA and matcher previews in both themes; Limit Orders at a 390×844 responsive frame in both themes; Light full-chart viewer, Chart Marker controls and Pattern Finder. Mobile simulator document width and scroll width both measured 375 pixels (inside the 390-pixel frame with scrollbar), without horizontal overflow.

For the same 2024-01-02 session at 20/81 bars (EMA20 5445.22), the browser matcher compared 199 eligible candidates and returned identical ordered result text in both themes: 2024-04-02/end21, 2025-04-04/end15, 2025-04-03/end26, 2025-11-07/end15, 2024-03-19/end14. Theme changes preserved current bars, EMA and points. Visual checks found and corrected named-white input labels and dark labels on the Light primary-button accent.

Screenshots were displayed in the QA conversation; the browser's read-only filesystem prevented exporting screenshot files. This was responsive-width desktop-browser QA, not physical-device/touch testing. Populated saved history/review screens, every hover/selection state, and uploaded-image pixel comparisons were not manually exercised. Preservation checks cover image files and calculation logic. The standalone Playwright harness remains unexecuted because that executor cannot create Chromium sockets; the managed-browser checks supplied the visual evidence instead. Broader physical-device and saved-history visual review remains appropriate before release.
