// Preview runs are deliberately ephemeral. Persist/export only the previous
// scored checkpoint, never a future-exposed run or one of its parked copies.
const copy=value=>JSON.parse(JSON.stringify(value));
const emptyChart=()=>({id:1,runID:'preview-discarded',format:'rth-v2',source:null,finalBar:78,firstBar:5,revealed:5,flips:[],ledger:[],bias:[],direction:0,scoreStart:4,finished:false,cancelled:true,replaying:false});
export function projectScoredDatabase(database,baseline){
 const next=copy(database);
 for(const profile of next.profiles||[]){
  const previous=baseline?.profiles?.find(row=>row.learnerId===profile.learnerId&&row.key===profile.key);
  for(const field of ['chart','realChart','demoChart']){
   if(profile[field]?.previewTrading!==true)continue;
   const saved=previous?.[field];
   profile[field]=saved&&saved.previewTrading!==true&&(!saved.source||next.datasets?.[saved.source])?copy(saved):field==='chart'?emptyChart():null;
   if(field==='chart')profile.mode=previous?.mode||'real';
  }
 }
 return next;
}
