import {practiceIsMobile} from './practice-device.js';
import {validCandidatePreferences} from './candidate-highlights.js';
import {replayBracket} from './direction-exit-bracket.js';
/** Market Direction account adapter. No browser-profile imports or persistent storage.
 * Server identity lives in the canonical learner client; this adapter owns one
 * captured page generation and deliberately never adopts a later account. */
import {loadHistoryCandleIndex} from './history-candle-data.js';
import {deriveDirectionBuckets} from './history-time-buckets.js';
import {safeGoogleAvatarUrl} from './learner-client.js';
const UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
const copy=value=>JSON.parse(JSON.stringify(value));
const need=(ok,message)=>{if(!ok)throw Error(message);};
// Parent-frame client errors are not instanceof this frame's Error.
const saveErrorMessage=(error,fallback)=>{try{const value=error?.message;return typeof value==='string'&&value.length>0&&value.length<=240&&!/[\p{Cc}\p{Cf}]/u.test(value)?value:fallback;}catch{return fallback;}};
const iso=value=>typeof value==='string'&&/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(value)&&Number.isFinite(Date.parse(value));
export function memoryStorage(){const values=new Map();return Object.freeze({get length(){return values.size;},key:index=>[...values.keys()][index]??null,getItem:key=>values.has(String(key))?values.get(String(key)):null,setItem:(key,value)=>{values.set(String(key),String(value));},removeItem:key=>{values.delete(String(key));},clear:()=>values.clear()});}
const disabled=Object.freeze({enabled:false,redirected:false,guard:()=>true,canMutate:()=>true,navigationReady:()=>true,dispose(){}});
export function createMarketDirectionAccountBridge({client,canPractice=()=>true,requestPanel=()=>false,randomUUID=()=>crypto.randomUUID(),now=()=>new Date().toISOString(),detectMobile=practiceIsMobile}={}){
 const initial=client.getSnapshot();
 need(initial.ready&&!initial.reconcileRequired,'Your sign-in state could not be confirmed. Retry before practicing.');
 if(initial.authConfigured===false)return disabled;
 need(initial.authConfigured===true&&['guest','account'].includes(initial.mode),'Your sign-in state could not be confirmed.');
 const capture=client.captureContext();need(capture&&client.guard(capture),'The learner account changed before practice started.');
 const profile=initial.mode==='account'?{name:initial.profile.name,learnerId:initial.profile.id}:{name:'Guest',learnerId:randomUUID()};
 need(UUID.test(profile.learnerId),'The learner identity could not be verified.');
 const storage=memoryStorage(),sources=new Map(),runs=new Map(),listeners=new Set();let disposed=false,changed=false,pending=null,failure=null,latest=null,preferencePending=false,guestPreferences={useExitBracket:false,exitBracketDistance:5};
 function guard(){const snapshot=client.getSnapshot();return !disposed&&!changed&&snapshot.ready&&!snapshot.reconcileRequired&&!snapshot.signOutNeeded&&client.guard(capture);}
 function presentation(){if(!guard())return null;return Object.freeze({mode:initial.mode,name:profile.name,avatarUrl:initial.mode==='account'?safeGoogleAvatarUrl(client.getSnapshot().avatarUrl):null});}
 function ownerValid(){return !disposed&&!changed&&(client.ownsCapture?client.ownsCapture(capture):guard());}
 function status(){return Object.freeze({valid:guard(),ownerValid:ownerValid(),verifying:ownerValid()&&client.getSnapshot().revalidating===true,pending:!!pending||preferencePending,error:failure,retryAvailable:!!(latest?.payload||latest?.completion),message:!guard()?(ownerValid()?'Checking your learner account. Practice is paused until verification finishes.':'Your learner account or saved history changed. Reload before continuing.'):failure||(preferencePending?'Saving account preference…':pending?'Saving completed practice to your account…':initial.mode==='guest'?'Guests will not be able to track their history + skill progress':latest?.saved?'Practice saved to your learner account.':'Signed in. Finish a session to save it to your learner account.')});}
 // A broken view subscriber must never cancel an upload or turn a confirmed
 // server acknowledgement into a failed save.
 function notify(){const value=status();for(const fn of listeners){try{fn(value);}catch{}}}
 const unsubscribe=client.subscribe(()=>{if(!ownerValid()){changed=true;storage.clear();sources.clear();runs.clear();failure=null;latest=null;}notify();});
 function own(){need(guard(),'Your learner account or saved history changed. Reload before continuing.');}
 function rememberSource(reference){own();if(reference?.kind!=='historical'||!/^mes1-\d{4}-\d{2}-\d{2}-(?:42|45|81)$/.test(reference?.id)||!/^[a-f0-9]{64}$/.test(reference?.sha256))return false;const previous=sources.get(reference.id);need(!previous||previous.sha256===reference.sha256,'This chart source changed. Reload before continuing.');sources.set(reference.id,{id:reference.id,sha256:reference.sha256});return true;}
 function start(runID,chartId,options={}){own();if(runs.has(runID)){need(runs.get(runID).previewTrading===(options.previewTrading===true),'Start a new session to change preview mode.');return;}if(options.previewTrading===true){runs.set(runID,{previewTrading:true});return;}const source=sources.get(chartId);if(!source)return;const id=randomUUID(),startedAt=now();need(UUID.test(id)&&iso(startedAt),'A private attempt identity could not be created.');runs.set(runID,{previewTrading:false,id,startedAt,isMobile:detectMobile()===true,source,payload:null,saved:false});}
 async function send(record){own();need(record?.previewTrading!==true,'Preview practice cannot be saved.');if(initial.mode==='guest')return{guest:true};if(record.saved)return{saved:true,duplicate:true};need(!preferencePending,'Wait for the pending preference save before saving practice.');if(pending){if(pending.record===record)return pending.promise;throw Error('Wait for the completed practice save.');}
  failure=null;const task={record,promise:null};pending=task;
  // Start the request before notifying views or opening the parent trade dialog.
  // Deferring dispatch by a microtask lets its focus recheck invalidate the save.
  let submission;try{submission=client.saveAttempt(copy(record.payload),capture);}catch(error){submission=Promise.reject(error);}
  task.promise=Promise.resolve(submission).then(result=>{own();need(result?.attempt?.id===record.id&&result.attempt.module==='market-direction'&&result.attempt.chartId===record.source.id&&result.attempt.chartSha256===record.source.sha256&&result.attempt.startedAt===record.payload.startedAt&&result.attempt.completedAt===record.payload.completedAt,'The saved attempt response did not match this practice. Retry to verify it.');record.saved=true;return result;}).catch(error=>{if(ownerValid())failure=saveErrorMessage(error,'The account save was not confirmed. Keep this page open and retry.');throw error;}).finally(()=>{if(pending===task)pending=null;notify();});notify();return task.promise;
 }
 // Freeze completion before any presentation work. Preparation failures must be
 // visible and block navigation just like a failed POST, never look saved.
 async function complete(runID,run,finalBar,completedAt,exitBracket){
  own();if(runs.get(runID)?.previewTrading===true)return{preview:true,saved:false};if(initial.mode==='guest')return{guest:true};
  try{
   const record=runs.get(runID);latest=record||null;need(record,'This completed session has no verified chart reference. It was not saved. Keep this page open.');
   if(!record.completion&&!record.payload)record.completion=copy({run,finalBar,completedAt,...(exitBracket?{exitBracket}:{})});
   if(!record.payload){const frozen=record.completion;need(iso(frozen.completedAt)&&Date.parse(frozen.completedAt)>=Date.parse(record.startedAt),'The practice completion time could not be verified. Keep this page open; it has not been saved.');need(frozen.run&&[1,2].includes(frozen.run.version)&&frozen.run.practiceCutoff!==null,'Complete the recorded practice before saving.');const normalized={version:frozen.run.version,...(frozen.run.startBar===undefined?{}:{startBar:frozen.run.startBar}),choices:copy(frozen.run.choices),practiceCutoff:frozen.run.practiceCutoff};record.payload={version:1,id:record.id,module:'market-direction',chartId:record.source.id,chartSha256:record.source.sha256,startedAt:record.startedAt,completedAt:frozen.completedAt,isMobile:record.isMobile,practice:{run:normalized,finalBar:frozen.finalBar,...(frozen.exitBracket?{exitBracket:copy(frozen.exitBracket)}:{})}};}
   return await send(record);
  }catch(error){if(ownerValid()){failure=saveErrorMessage(error,'The completed practice could not be prepared for saving. Keep this page open and retry.');notify();}throw error;}
 }

 function readCandidatePreferences(){if(!guard()||initial.mode!=='account')return null;const value=client.getSnapshot().preferences?.candidateHighlights;return validCandidatePreferences(value)?{...value}:null;}
 async function saveCandidatePreferences(value){own();need(readCandidatePreferences()&&validCandidatePreferences(value),'Candidate highlights are not available for this account.');need(!preferencePending&&!pending&&!failure,'Wait for the pending save before changing preferences.');preferencePending=true;notify();try{const saved=await client.saveCandidatePreferences({...value},capture);own();return saved;}finally{preferencePending=false;notify();}}
 function readPointLimitPreference(){if(!readCandidatePreferences())return null;return{usePointLimit:client.getSnapshot().preferences?.usePointLimit===true};}
 async function savePointLimitPreference(usePointLimit){own();need(readPointLimitPreference()&&typeof usePointLimit==='boolean','The 20-point limit is not available for this account.');need(!preferencePending&&!pending&&!failure,'Wait for the pending save before changing preferences.');preferencePending=true;notify();try{const saved=await client.savePointLimitPreference(usePointLimit,capture);own();need(saved?.usePointLimit===usePointLimit,'The 20-point limit preference was not confirmed. Retry before using it.');return{usePointLimit};}finally{preferencePending=false;notify();}}
 function readDirectionPreferences(){own();const preferences=initial.mode==='guest'?guestPreferences:client.getSnapshot().preferences;return{useExitBracket:preferences?.useExitBracket===true,exitBracketDistance:Math.min(20,preferences?.exitBracketDistance??5)};}
 async function saveDirectionPreferences(useExitBracket,exitBracketDistance){own();need(typeof useExitBracket==='boolean'&&Number.isFinite(exitBracketDistance)&&exitBracketDistance>=.25&&exitBracketDistance<=100000&&Number.isInteger(exitBracketDistance*4),'Choose a valid exit bracket distance.');need(exitBracketDistance<=20,'Exit brackets cannot be more than 20 points from entry.');need(!preferencePending&&!pending&&!failure,'Wait for the pending save before changing preferences.');if(initial.mode==='guest'){guestPreferences={useExitBracket,exitBracketDistance};return readDirectionPreferences();}preferencePending=true;notify();try{const saved=await client.saveDirectionPreferences(useExitBracket,exitBracketDistance,capture);own();need(saved?.useExitBracket===useExitBracket&&saved?.exitBracketDistance===exitBracketDistance,'The exit bracket preference was not confirmed. Retry before using it.');return{useExitBracket,exitBracketDistance};}finally{preferencePending=false;notify();}}
 async function history(catalog){own();if(initial.mode==='guest')return{history:[],attempts:[],importDone:[]};need(Array.isArray(catalog),'The chart catalog could not be verified.');const index=await loadHistoryCandleIndex();own();const references=new Map(catalog.map(row=>[row.id,row])),all=[],cursors=new Set();let cursor;
  for(;;){const page=await client.listAttempts({module:'market-direction',limit:50,...(cursor?{cursor}:{})},capture);own();for(const row of page.attempts){need(row.module==='market-direction','Account history returned a different simulator. Nothing was mixed.');need(all.length<1000&&!all.some(a=>a.id===row.id),'Account history is duplicated or exceeds its limit.');all.push(row);}if(!page.nextCursor)break;need(!cursors.has(page.nextCursor),'Account history pagination did not advance.');cursors.add(page.nextCursor);cursor=page.nextCursor;}
  const byId=new Map(index.sessions.map(row=>[row.id,row])),attempts=[],first=new Map();all.sort((a,b)=>Date.parse(a.savedAt)-Date.parse(b.savedAt)||a.id.localeCompare(b.id));
  for(const item of all){own();const source=byId.get(item.chartId),reference=references.get(item.chartId);need(source&&reference&&source.sourceSha256===item.chartSha256&&reference.sha256===item.chartSha256,'An exact historical chart is unavailable. No account history was mixed with local data.');const s=copy(item.summary),proof=s.practiceEvidence||s.directionAccuracy;need(proof&&Array.isArray(proof.choices)&&proof.practiceCutoff!==null,'An older account attempt has no complete practice evidence. Download account history to inspect it.');const start=proof.startBar??0,final=s.finalBar,exposures=Array(81).fill(0),bias=Array(81).fill(0),flips=[];need(Number.isSafeInteger(final)&&final>=proof.practiceCutoff&&final<=81,'Saved practice range is invalid.');for(let i=start;i<final;i++){const choice=proof.choices[Math.min(i-start,proof.choices.length-1)];need(choice&&[-1,0,1].includes(choice.direction),'Saved practice choices are invalid.');bias[i]=choice.direction;if(i+1<final)exposures[i+1]=choice.direction;if(i>start&&bias[i-1]!==0&&choice.direction!==bias[i-1]&&i<proof.practiceCutoff)flips.push({bar:i,direction:choice.direction});}
   if(s.exitBracket){need(source.candles,'Exact OHLC are unavailable for saved exit brackets.');const replay=replayBracket(proof,source.candles,final,s.exitBracket);exposures.splice(0,exposures.length,...replay.exposures);}
   const report={...s,definition:s.definition||'close-bias-v1',key:source.key,sessionBars:Number(reference.id.slice(-2)),firstBar:start+1,sessionDate:reference.date,chartId:reference.id,sampleType:'hosted historical (publisher-supplied)',hosted:{id:reference.id,title:reference.title},completedAt:item.completedAt,flipEvents:flips,accuracy:s.eligibleBars?s.correctBars/s.eligibleBars:null};
   // Reuse the unchanged points/bucket validator. It checks neutral, carry,
   // legs and source closes without storing or inventing candle evidence.
   const attempt={id:item.id,sessionKey:source.key,completedAt:item.completedAt,report,decisions:{exposures,bias,flips}};
   const verified=deriveDirectionBuckets({learnerId:profile.learnerId,reports:[report],attempts:[attempt],closesByKey:new Map([[source.key,source]])},profile.learnerId);need(verified.unallocatedCount===0,'Saved practice does not reconcile with the exact chart.');attempts.push(attempt);if(!first.has(source.key))first.set(source.key,report);
  }
  own();return{history:[...first.values()],attempts,importDone:[...first.keys()].map(key=>key.slice(4))};
 }
 return Object.freeze({enabled:true,redirected:false,mode:initial.mode,profile:Object.freeze(profile),storage,guard,ownerValid,presentation,canMutate:()=>guard()&&canPractice()&&!pending&&!preferencePending&&!failure,navigationReady:()=>guard()&&!pending&&!preferencePending&&!failure,rememberSource,start,complete,history,status,readCandidatePreferences,saveCandidatePreferences,readPointLimitPreference,savePointLimitPreference,readDirectionPreferences,saveDirectionPreferences,subscribe(fn){listeners.add(fn);return()=>listeners.delete(fn);},requestPanel(){own();return requestPanel({view:'details',module:'market-direction'});},retry(){own();need(latest?.payload||latest?.completion,'No completed practice save is available to retry. Keep this page open.');if(latest.payload)return send(latest);const frozen=latest.completion,runID=[...runs].find(([,record])=>record===latest)?.[0];return complete(runID,frozen.run,frozen.finalBar,frozen.completedAt,frozen.exitBracket);},dispose(){disposed=true;unsubscribe();storage.clear();sources.clear();runs.clear();listeners.clear();}});
}
export async function connectMarketDirectionAccount({windowObject=window,loadClient=()=>import('/modules/learner-client.js')}={}){
 let host=null;try{if(windowObject.parent!==windowObject&&windowObject.parent.location.origin===windowObject.location.origin)host=windowObject.parent.PriceActionLearner||null;}catch{}
 const client=host?.client||(await loadClient()).learnerClient;
 if(!host)await client.refresh();
 const snapshot=client.getSnapshot();need(snapshot.ready&&!snapshot.reconcileRequired,'Your sign-in state could not be confirmed. Retry before practicing.');
 if(snapshot.authConfigured===false)return disabled;
 need(snapshot.authConfigured===true,'The account readiness check could not be verified.');
 if(!host){const input=new URLSearchParams(windowObject.location.search||''),query=new URLSearchParams();if(input.get('history')==='1')query.set('history','1');if(UUID.test(input.get('replay')||''))query.set('replay',input.get('replay'));windowObject.location.replace('/market-direction'+(query.size?'?'+query:''));return Object.freeze({...disabled,redirected:true});}
 return createMarketDirectionAccountBridge({client,canPractice:()=>host.canPractice?.()!==false,requestPanel:input=>host.requestPanel?.(input)??client.requestPanel(input)});
}
