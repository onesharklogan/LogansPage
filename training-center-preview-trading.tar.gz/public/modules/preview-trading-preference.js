// Browser-local, per-profile preference only. Scoring isolation belongs to each session lifecycle.
const PREFIX='price-action-preview-trading-v1:',EVENT='price-action-preview-trading-change';
const key=owner=>typeof owner==='string'&&owner.length>0&&owner.length<160?PREFIX+owner:null;
function eventTarget(){try{return window.top?.location.origin===window.location.origin?window.top:window}catch{return window}}
export function readPreviewPreference(owner){try{const k=key(owner);return !!k&&window.localStorage.getItem(k)==='true'}catch{return false}}
export function writePreviewPreference(owner,enabled){try{const k=key(owner);if(!k||typeof enabled!=='boolean')return false;window.localStorage.setItem(k,String(enabled));if(readPreviewPreference(owner)!==enabled)return false;eventTarget().dispatchEvent(new CustomEvent(EVENT,{detail:{owner,enabled}}));return true}catch{return false}}
export function subscribePreviewPreference(owner,callback){const target=eventTarget(),changed=e=>{if(e.type==='storage'&&e.key!==null&&e.key!==key(owner))return;if(e.type===EVENT&&e.detail?.owner!==owner)return;callback(readPreviewPreference(owner))};target.addEventListener(EVENT,changed);window.addEventListener('storage',changed);return()=>{target.removeEventListener(EVENT,changed);window.removeEventListener('storage',changed)}}
