'use client';
import {useEffect,useState} from 'react';
import {readPreviewPreference,writePreviewPreference,subscribePreviewPreference} from '../public/modules/preview-trading-preference.js';
export default function PreviewTradingOption({owner,canChange,disabled=false}:{owner:string;canChange:()=>boolean;disabled?:boolean}){
 const [enabled,setEnabled]=useState(false),[error,setError]=useState('');
 useEffect(()=>{setEnabled(readPreviewPreference(owner));setError('');return subscribePreviewPreference(owner,(value:boolean)=>setEnabled(value));},[owner]);
 return <div style={{margin:'16px 0'}}><label style={{display:'flex',alignItems:'center',gap:10,minHeight:44,cursor:'pointer'}}><input type="checkbox" checked={enabled} disabled={disabled} onChange={event=>{if(!canChange())return;const next=event.target.checked;if(writePreviewPreference(owner,next)){setEnabled(next);setError('')}else setError('Could not save this change. The previous setting is unchanged.');}}/>Preview trading (results not scored)</label><p style={{fontSize:12,opacity:.75,margin:'4px 0'}}>Applies to your next new session. Full-session preview on desktop and mobile; preview results are not scored or saved. This setting is for this profile on this browser.</p>{error&&<p role="alert">{error}</p>}</div>;
}
