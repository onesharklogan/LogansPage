"use client";
import {useEffect,useState} from 'react';
import PatternOutcomes from './pattern-outcomes';
import {loadChartMatchSessions} from './chart-match-data.mjs';
import {savedPatternOutcomes} from '../lib/saved-pattern-outcomes.mjs';
import {learnerClient} from '../lib/learner/client.mjs';
import type {PatternSnapshot} from './pattern-encyclopedia';
type Sessions=Awaited<ReturnType<typeof loadChartMatchSessions>>;
type Matches=Awaited<ReturnType<typeof savedPatternOutcomes>>['matches'];
export default function SavedPatternOutcomes({snapshot}:{snapshot:PatternSnapshot}){
 const [result,setResult]=useState<{snapshot:PatternSnapshot;sessions:Sessions;matches:Matches}|null>(null),[error,setError]=useState(''),[progress,setProgress]=useState('Loading historical comparisons…'),[retry,setRetry]=useState(0);
 useEffect(()=>{
  const controller=new AbortController(),owner=learnerClient.captureContext();
  const current=()=>!controller.signal.aborted&&learnerClient.ownsCapture(owner);
  setResult(null);setError('');setProgress('Loading historical comparisons…');
  const unsubscribe=learnerClient.subscribe(()=>{if(!learnerClient.ownsCapture(owner))controller.abort();});
  void (async()=>{
   try{
    const sessions=await loadChartMatchSessions({signal:controller.signal});
    if(!current())return;
    const ranked=await savedPatternOutcomes(snapshot,sessions,{signal:controller.signal,onProgress:(p:{scanned:number})=>{if(current())setProgress(`Comparing historical patterns… ${p.scanned.toLocaleString()} windows checked`);}});
    if(current())setResult({snapshot,sessions,matches:ranked.matches});
   }catch(e){if(current())setError(e instanceof Error?e.message:'Historical comparisons could not be loaded.');}
  })();
  return()=>{controller.abort();unsubscribe();};
 },[snapshot,retry]);
 const shown=result?.snapshot===snapshot?result:null;
 return <section aria-label="Saved pattern historical outcomes">
  <p>Recomputed from the saved source using the current chart catalog{snapshot.searchOptions?.earlierOnly?' · earlier sessions only':''}. Saved examples are unchanged.</p>
  {error?<div role="alert"><p>{error}</p><button type="button" onClick={()=>setRetry(n=>n+1)}>Retry outcome comparison</button></div>:!shown?<p role="status">{progress}</p>:<PatternOutcomes matches={shown.matches} sessions={shown.sessions} ready/>}
 </section>;
}
