import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {savedPatternOutcomes} from '../lib/saved-pattern-outcomes.mjs';
import {buildPatternWindow,rankPatternMatches} from '../lib/pattern-match.mjs';
import {patternOutcomes,summarizePatternOutcomes} from '../lib/pattern-outcomes.mjs';
const sessions=JSON.parse(fs.readFileSync(new URL('../public/modules/chart-match-index.json',import.meta.url))).sessions;
const source=sessions.at(-1),example={chartId:source.reference.id,chartSha256:source.reference.sha256,startBar:1,endBar:15};
const snapshot={version:1,algorithmVersion:'pattern-v1',source:example,matches:[],searchOptions:{earlierOnly:false,limit:10}};
const opts={yieldControl:async()=>{}};
test('legacy entry without archives recomputes identical top25 Finder matches without changing saved selection',async()=>{
 const before=JSON.stringify(snapshot),data=JSON.stringify(sessions);
 const got=await savedPatternOutcomes(snapshot,sessions,opts),expected=await rankPatternMatches(buildPatternWindow(source,1,15),sessions,{...opts,limit:25,earlierOnly:false});
 assert.deepEqual(got.matches,expected.matches);assert.equal(got.matches.length,25);
 assert.equal(JSON.stringify(snapshot),before);assert.equal(JSON.stringify(sessions),data);
});
test('archived source works outside current catalog and earlier-only option remains honored',async()=>{
 const saved={...snapshot,charts:{[example.chartId]:source.chart},searchOptions:{earlierOnly:true,limit:10}},without=sessions.slice(0,-1),before=JSON.stringify(saved);
 const got=await savedPatternOutcomes(saved,without,opts);assert.equal(got.matches.length,25);assert.ok(got.matches.every(m=>m.date<source.reference.date));assert.equal(JSON.stringify(saved),before);
});
test('missing exact source, unsupported version, invalid range and canceled work fail explicitly',async()=>{
 await assert.rejects(savedPatternOutcomes({...snapshot,source:{...example,chartSha256:'0'.repeat(64)}},sessions,opts),/exact saved source/);
 await assert.rejects(savedPatternOutcomes({...snapshot,algorithmVersion:'unknown'},sessions,opts),/unsupported/);
 await assert.rejects(savedPatternOutcomes({...snapshot,source:{...example,endBar:1}},sessions,opts),/2–25/);
 const abort=new AbortController();abort.abort();await assert.rejects(savedPatternOutcomes(snapshot,sessions,{signal:abort.signal}),{name:'AbortError'});
 const noMatches=await savedPatternOutcomes({...snapshot,charts:{[example.chartId]:source.chart}},[],opts);assert.equal(noMatches.matches.length,0);
});
test('below percentage counts exact +15 close, includes flat denominator and excludes short or missing continuations',()=>{
 const lines=[{points:[...Array(15).fill(0),-1,5]},{points:[...Array(15).fill(0),2,-5]},{points:Array(16).fill(0)},{points:Array(15).fill(-3)}];
 const r=summarizePatternOutcomes(lines);assert.equal(r.belowPercent,100/3);assert.equal(r.horizon.count,3);assert.equal(r.horizon.excluded,1);
 assert.equal(summarizePatternOutcomes([]).belowPercent,null);assert.equal(summarizePatternOutcomes([{points:Array(16).fill(0)}]).belowPercent,0);
 const bars=Array.from({length:20},(_,i)=>({c:100-i,t:new Date(Date.UTC(2025,0,2,8,30+i*5)).toISOString().slice(0,16).replace('T',' ')}));bars[10].t='2025-01-02 12:00';
 const model=patternOutcomes([{id:'a',date:'2025-01-02',startBar:1,endBar:2}],[{reference:{id:'a'},chart:{current:bars}}]);assert.equal(model.truncated,1);assert.equal(summarizePatternOutcomes(model.lines).belowPercent,null);
});
