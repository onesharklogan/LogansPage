'use client';
import SimulatorProfileGate from './simulator-profile-gate';
import AccountTradeSimulator from './account-trade-simulator';
import TradeSimulator from './trade-simulator';
export default function ProfiledTradeSimulator({accountsEnabled=false,unifiedNavigation=false}:{accountsEnabled?:boolean;unifiedNavigation?:boolean}={}){if(accountsEnabled)return <AccountTradeSimulator unifiedNavigation={unifiedNavigation}/>;return <SimulatorProfileGate section="ORDERS SIMULATOR" current="/trade-simulator" unifiedNavigation={unifiedNavigation}>{access=><TradeSimulator profileAccess={access} unifiedNavigation={unifiedNavigation}/>}</SimulatorProfileGate>;}
