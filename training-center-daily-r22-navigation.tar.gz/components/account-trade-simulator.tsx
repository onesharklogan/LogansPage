'use client';
import LoadingIndicator from './loading-indicator';
import {useEffect,useRef,useState} from 'react';
import {learnerClient,safeGoogleAvatarUrl} from '../lib/learner/client.mjs';
import {createAccountTradeAdapter} from '../lib/learner/trade-adapter.mjs';
import LearnerAccountControl from './learner-account-control';
import TradeSimulator from './trade-simulator';
import type {SimulatorProfileAccess} from './simulator-profile-gate';

function modeActive(){return typeof window==='undefined'||!(window as any).PriceActionCombined||(window as any).PriceActionCombined.isActive('limit');}

function OwnedTrade({capture,profile,headerReady,avatarUrl,panelOpen,suspend,navigation,unifiedNavigation}:{unifiedNavigation:boolean;capture:any;profile:{key:string;name:string;learnerId:string};headerReady:boolean;avatarUrl:string|null;panelOpen:React.RefObject<boolean>;suspend:React.RefObject<(()=>void)|null>;navigation:React.RefObject<(()=>boolean)|null>}){
 const [store]=useState(()=>createAccountTradeAdapter({client:learnerClient,capture,profile,replayId:typeof window==='undefined'?null:(window as any).PriceActionCombined?(window as any).PriceActionCombined.initialReplay('limit'):new URLSearchParams(window.location.search).get('replay')})),[ready,setReady]=useState(false),[error,setError]=useState(''),[retry,setRetry]=useState(0),[verification,setVerification]=useState(0);
 const mounted=useRef(false);
 useEffect(()=>{mounted.current=true;return()=>{mounted.current=false;};},[]);
 // Observe verification edges directly: React can batch a fast false/true pair.
 useEffect(()=>{let verified=learnerClient.guard(capture);const unsubscribe=learnerClient.subscribe(()=>{const next=learnerClient.guard(capture);if(next&&!verified)setVerification(v=>v+1);verified=next;});return()=>{unsubscribe();};},[store]);
 // A second mode can mount while the shared account control revalidates. Wait for
 // the same owner to be verified, without discarding an already loaded attempt.
 useEffect(()=>{if(ready||!headerReady)return;const controller=new AbortController();setError('');void Promise.resolve().then(async()=>{if(controller.signal.aborted||!learnerClient.guard(capture))return false;await store.loadRemote({signal:controller.signal});return true;}).then(loaded=>{if(loaded&&!controller.signal.aborted&&learnerClient.guard(capture))setReady(true);}).catch((error:Error)=>{if(!controller.signal.aborted)setError(error.message);});return()=>{controller.abort();};},[store,retry,headerReady,ready,verification]);
 const access:SimulatorProfileAccess={profile,mode:capture.mode,accountHeader:{ready:headerReady,avatarUrl:headerReady&&capture.mode==='account'?safeGoogleAvatarUrl(avatarUrl):null,isCurrent:()=>mounted.current&&learnerClient.guard(capture)},store,guard:()=>mounted.current&&ready&&!panelOpen.current&&learnerClient.guard(capture),choose:()=>{if(modeActive())learnerClient.requestPanel();},registerSuspend:fn=>{suspend.current=fn;},registerNavigationGuard:fn=>{navigation.current=fn;}};
 if(!ready)return <main className="training-main"><p role="status">{error||<LoadingIndicator label="Loading your account history…" />}</p>{error&&<button className="quiet-button" onClick={()=>setRetry(v=>v+1)}>Retry account history</button>}</main>;
 return <TradeSimulator profileAccess={access} unifiedNavigation={unifiedNavigation} hideProfileTrigger={unifiedNavigation}/>;
}
/** Online mode is only mounted by the server readiness gate. Local mode never enters here. */
export default function AccountTradeSimulator({unifiedNavigation=false}:{unifiedNavigation?:boolean}={}){
 const [snapshot,setSnapshot]=useState(learnerClient.getSnapshot),panelOpen=useRef(false),suspend=useRef<(()=>void)|null>(null),navigation=useRef<(()=>boolean)|null>(null),owner=useRef<{capture:any;profile:{key:string;name:string;learnerId:string}}|null>(null);
 useEffect(()=>{const unsubscribe=learnerClient.subscribe((next:ReturnType<typeof learnerClient.getSnapshot>)=>{if(!learnerClient.guard(learnerClient.captureContext()))suspend.current?.();setSnapshot(next);});void learnerClient.refresh();return()=>{unsubscribe();};},[]);
 const capture=learnerClient.captureContext(),profile=snapshot.profile?{key:'account:'+snapshot.profile.id,name:snapshot.profile.name,learnerId:snapshot.profile.id}:{key:'guest',name:'Guest',learnerId:'00000000-0000-4000-8000-000000000001'};
 if(capture&&snapshot.authConfigured)owner.current={capture,profile};if(owner.current&&!learnerClient.ownsCapture(owner.current.capture))owner.current=null;
 const verified=!!capture&&snapshot.authConfigured,verifying=!verified&&!snapshot.signOutNeeded&&(snapshot.revalidating||!snapshot.ready&&!snapshot.reconcileRequired&&!snapshot.error&&!snapshot.busy);
 return <><LearnerAccountControl isActive={modeActive} idPrefix="limit-learner-account" hideTrigger={unifiedNavigation||verified||verifying} onOpenChange={open=>{panelOpen.current=open;if(open)suspend.current?.();else if(modeActive())setTimeout(()=>{if(modeActive())document.querySelector<HTMLButtonElement>(unifiedNavigation?'#simulator-profile-trigger':'[data-learner-profile-control]')?.focus();},0);}} onBeforeNavigate={()=>(window as any).PriceActionCombined?.navigationReady?.()!==false&&navigation.current?.()!==false}/>{owner.current&&<div hidden={!verified} inert={!verified} style={!verified?{display:'none'}:undefined}><OwnedTrade unifiedNavigation={unifiedNavigation} key={owner.current.capture.epoch} capture={owner.current.capture} profile={owner.current.profile} headerReady={verified} avatarUrl={verified?snapshot.avatarUrl:null} panelOpen={panelOpen} suspend={suspend} navigation={navigation}/></div>}{!verified&&<main className="training-main"><p role="status">{verifying?<LoadingIndicator label="Verifying profile…" />:snapshot.error||(snapshot.busy?<LoadingIndicator label={snapshot.busy} />:'Profile verification is unavailable. Retry to continue.')}</p>{!verifying&&<button className="quiet-button" disabled={snapshot.revalidating} onClick={()=>void learnerClient.revalidate()}>Retry account check</button>}</main>}</>;
}
