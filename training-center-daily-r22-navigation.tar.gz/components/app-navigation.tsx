'use client';

import { useEffect, useRef, type MouseEvent, type ReactNode } from 'react';

export type NavigateHandler = (event: MouseEvent<HTMLAnchorElement>) => void;
const destinations = [
  ['/', 'Daily Balance'], ['/training', 'Training Home'], ['/chart-marker', 'Chart Marker'], ['/market-direction', 'Trade Simulator'],
  ['/chart-match', 'Chart Match'], ['/pattern-match', 'Pattern Finder'], ['/pattern-encyclopedia', 'Pattern Encyclopedia'],
] as const;
const sharedDailyRoutes = new Set<string>(destinations.map(([path]) => path));

export function CandleMark() {
  return <svg className="app-candle-mark" viewBox="0 0 48 48" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="24" cy="24" r="9"/><path d="M24 3v5m0 32v5M3 24h5m32 0h5M9 9l4 4m22 22 4 4M9 39l4-4m22-22 4-4"/></svg>;
}

/** Navigation only: no account lookup, storage writes, or inferred student profile. */
export default function AppHeader({ section, current, onNavigate, children, className = '', teacher = false }: {
  section: string; current?: string; onNavigate?: NavigateHandler; children?: ReactNode; className?: string; teacher?: boolean;
}) {
  const menu = useRef<HTMLDetailsElement>(null);
  useEffect(() => {
    const outside = (event: globalThis.PointerEvent) => { if (menu.current?.open && !menu.current.contains(event.target as Node)) menu.current.open = false; };
    document.addEventListener('pointerdown', outside);
    return () => document.removeEventListener('pointerdown', outside);
  }, []);
  const sharedSubtitle = current && sharedDailyRoutes.has(current) && section !== 'DAILY DASHBOARD';
  function navigate(event: MouseEvent<HTMLAnchorElement>) {
    onNavigate?.(event);
    if (event.type !== 'contextmenu' && !event.defaultPrevented && menu.current) menu.current.open = false;
  }
  return <header className={`app-header ${className}`}>
    <div className="app-nav-left">
      <a className="app-brand" href="/" aria-label="Home" title="Home" onClick={navigate} onAuxClick={onNavigate && navigate} onContextMenu={onNavigate && navigate}><CandleMark /><span className="app-brand-text"><strong>Daily Balance</strong><small data-page-subtitle={sharedSubtitle ? true : undefined}>{section}</small>{sharedSubtitle&&<small data-daily-subtitle>DAILY DASHBOARD</small>}</span></a>
      <details className="app-nav-menu" ref={menu} onKeyDown={event => { if (event.key === 'Escape' && menu.current?.open) { event.preventDefault(); event.stopPropagation(); menu.current.open = false; menu.current.querySelector<HTMLElement>('summary')?.focus(); } }}>
        <summary aria-label="Navigation menu" title="Navigation menu"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true"><path d="M4 6h16M4 12h16M4 18h16" /></svg></summary>
        <nav aria-label="Site navigation">{destinations.map(([href, label]) => <a key={href} href={href} aria-current={current === href ? 'page' : undefined} onClick={navigate} onAuxClick={onNavigate && navigate} onContextMenu={onNavigate && navigate}>{label}</a>)}</nav>
      </details>
    </div>
    {children && <div className="app-account" aria-label="Account">{children}</div>}
  </header>;
}
