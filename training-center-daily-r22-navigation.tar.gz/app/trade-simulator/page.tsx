import './simulator.css';
import CombinedSimulator from '../../components/combined-simulator';
import {DAILY_BALANCE_ORIGIN,learnerConfiguration} from '../../lib/learner/google-config.mjs';
export const dynamic='force-dynamic';
export const metadata={title:'PATC Simulator',description:'Order practice with one combined history.'};
/** Existing saved links retain their limit-mode replay semantics. */
export default async function TradeSimulatorPage({searchParams}:{searchParams?:Promise<{history?:string}>}){const params=await searchParams;return <CombinedSimulator unifiedNavigation={process.env.LEARNER_APP_ORIGIN===DAILY_BALANCE_ORIGIN} accountsEnabled={!!learnerConfiguration()} initialMode="limit" initialHistory={params?.history==='1'}/>;}
