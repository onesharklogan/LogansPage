import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {DAILY_BALANCE_ORIGIN, LEARNER_APP_ORIGINS, LEARNER_ORIGIN} from '../lib/learner/google-config.mjs';

const read=path=>fs.readFileSync(new URL('../'+path,import.meta.url),'utf8');
const html=read('public/modules/market-direction.html');
const frameScript=html.match(/<script>(try\{if\(parent!==window[\s\S]*?)<\/script>/)[1];

test('the dashboard shell is selected from the deployment config, never browser input',()=>{
 assert.equal(DAILY_BALANCE_ORIGIN,'https://dailybalancelogan.onrender.com');
 assert.notEqual(LEARNER_ORIGIN,DAILY_BALANCE_ORIGIN);
 assert.deepEqual(LEARNER_APP_ORIGINS,[LEARNER_ORIGIN,DAILY_BALANCE_ORIGIN]);
 for(const path of ['app/layout.tsx','app/market-direction/page.tsx','app/trade-simulator/page.tsx'])assert.match(read(path),/process\.env\.LEARNER_APP_ORIGIN===DAILY_BALANCE_ORIGIN/);
});

test('hide embedded navigation only inside the same-origin combined Daily Balance shell',()=>{
 const origin=DAILY_BALANCE_ORIGIN, window={location:{origin}};
 const displaysCombined=parent=>{
  const classes=[];
  vm.runInNewContext(frameScript,{window,parent,location:window.location,document:{documentElement:{classList:{add:value=>classes.push(value)}}}});
  return classes.includes('combined-nav');
 };
 assert.equal(displaysCombined(window),false);
 assert.equal(displaysCombined({location:{origin},PriceActionCombined:{unifiedNavigation:false}}),false);
 assert.equal(displaysCombined({location:{origin},PriceActionCombined:{unifiedNavigation:true}}),true);
 assert.equal(displaysCombined({location:{origin:'https://unrelated.example'},PriceActionCombined:{unifiedNavigation:true}}),false);
 assert.equal(displaysCombined({get location(){throw new Error('cross origin');}}),false);
 assert.match(html,/html\.combined-nav #moduleHeader\{display:none!important\}/);
 assert.match(html,/if\(!accountBridge\.enabled\)\{const controls=\$\('moduleHeader'\)\.querySelector\('\.profile'\)/);
});

test('both simulator modes and history share one header without discarding order, profile, or save controls',()=>{
 const combined=read('components/combined-simulator.tsx');
 const header=combined.slice(combined.indexOf('{unifiedNavigation?<AppHeader'),combined.indexOf('</AppHeader>:<>'));
 assert.match(header,/Finish saving your current practice before leaving this page/);
 assert.match(header,/aria-controls="combined-limit-panel"/);
 assert.match(header,/Trade History/);
 assert.match(header,/learnerClient\.requestPanel\(\)/);
 assert.match(combined,/<AccountMarketDirection source=\{marketSource\} unifiedNavigation=\{unifiedNavigation\}\/>/);
 assert.match(combined,/<ProfiledTradeSimulator accountsEnabled=\{accountsEnabled\} unifiedNavigation=\{unifiedNavigation\}\/>/);
 assert.match(read('components/trade-simulator.tsx'),/!unifiedNavigation&&<AppHeader/);
 assert.match(read('components/simulator-profile-gate.tsx'),/!unifiedNavigation&&<div onAuxClickCapture/);
 assert.match(read('components/app-navigation.tsx'),/onNavigate\?\.\(event\)/);
 assert.match(read('components/app-navigation.tsx'),/data-daily-subtitle/);
 assert.match(html,/id="nameDisplay"/);
 assert.match(html,/id="chart"/);
});
