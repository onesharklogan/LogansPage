import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read=p=>fs.readFileSync(new URL('../'+p,import.meta.url),'utf8');
test('shared app dropdown always includes encyclopedia independently of teacher access',()=>{
 const s=read('components/app-navigation.tsx');
 const destinations=s.slice(s.indexOf('const destinations'),s.indexOf('] as const;'));
 assert.match(destinations,/\['\/pattern-encyclopedia', 'Pattern Encyclopedia'\]/);
 const nav=s.match(/<nav aria-label="Site navigation">([\s\S]*?)<\/nav>/)[1];
 assert.doesNotMatch(nav,/\['\/admin'(?:,|\])/);
 assert.doesNotMatch(nav,/Teacher workspace/);
 assert.doesNotMatch(nav,/\/library/);
 assert.match(s,/onNavigate\?\.\(event\)/);
 assert.match(s,/!event.defaultPrevented && menu.current/);
 assert.match(s,/event.key === 'Escape'/);
});
for(const file of ['public/modules/market-direction.html','public/modules/chart-marker.html','public/editor/index.html'])test(file+' dropdown includes unhidden encyclopedia and no Teacher Area shortcut',()=>{
 const s=read(file),details=[...s.matchAll(/<details\b[^>]*>([\s\S]*?)<\/details>/g)].map(m=>m[1]).find(x=>x.includes('Navigation menu'));
 assert.ok(details);
 const link=details.match(/<a\b([^>]*href="\/pattern-encyclopedia"[^>]*)>Pattern Encyclopedia<\/a>/);
 assert.ok(link);assert.doesNotMatch(link[1],/hidden|display:none|data-teacher/);
 assert.equal((details.match(/href="\/pattern-encyclopedia"/g)||[]).length,1);
 assert.doesNotMatch(details,/href="\/admin"/);
 assert.doesNotMatch(details,/href="\/library"/);
 if(file.endsWith('market-direction.html'))assert.match(link[1],/target="_top"/);
});
test('admin remains while teacher routes retire',()=>{
 for(const path of ['app/admin/page.tsx','app/admin/modules/page.tsx','app/studio/page.tsx','components/admin-area.tsx'])assert.ok(read(path).length);
 assert.doesNotMatch(read('components/admin-area.tsx'),/Teacher Area/);
 assert.match(read('app/studio/page.tsx'),/redirect/);
});
