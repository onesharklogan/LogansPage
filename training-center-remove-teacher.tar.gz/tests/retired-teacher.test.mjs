import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {isRetiredTeacherPage,retiredTeacherResponse} from '../lib/portal/retired-teacher.mjs';
test('teacher pages and raw editor retired, training tools retained',()=>{
 for(const path of ['/library','/library/old','/studio','/editor/index.html','/admin/modules','/admin/lesson-preview'])assert.equal(isRetiredTeacherPage(path),true);
 for(const path of ['/','/admin','/chart-marker','/pattern-match','/pattern-encyclopedia','/market-direction','/admin/trader-history'])assert.equal(isRetiredTeacherPage(path),false);
});
test('retired reads/writes return Gone without a database; unrelated API preserved',()=>{
 for(const scope of ['author','public'])for(const resource of ['workspace','folders','lessons','sequences','save-status'])for(const method of ['GET','POST','DELETE','HEAD']){
  const res=retiredTeacherResponse(new Request(`https://example.com/api/${scope}/${resource}/old`,{method}));assert.equal(res.status,410);
 }
 for(const path of ['/api/status','/api/author/members','/api/author/trader-history','/api/author/admin-invitations','/api/author/guest-visits','/api/learner/history'])assert.equal(retiredTeacherResponse(new Request('https://example.com'+path)),null);
});
test('home and navigation no longer mount teacher surfaces',async()=>{
 const home=await readFile(new URL('../app/page.tsx',import.meta.url),'utf8');
 assert.doesNotMatch(home,/HomeTeacherStudioCard|HomeLessons/);assert.match(home,/pattern-encyclopedia/);
 const nav=await readFile(new URL('../components/app-navigation.tsx',import.meta.url),'utf8');assert.doesNotMatch(nav,/\/library/);
 const admin=await readFile(new URL('../components/admin-area.tsx',import.meta.url),'utf8');assert.doesNotMatch(admin,/href="\/(studio|admin\/modules)"/);assert.match(admin,/\/admin\/trader-history/);
});
