import {redirect} from 'next/navigation';
export default function RetiredTeacherPage() { redirect('/'); }
