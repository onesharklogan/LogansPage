import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {randomUUID,createHash} from 'node:crypto';
import {compactPatternChart,freezePattern,validatePattern,PATTERN_LIMITS} from '../lib/learner/pattern-encyclopedia.mjs';
import {historicalPrefix,historicalGap} from '../lib/chart-match.mjs';
import {buildPatternWindow,patternDistance} from '../lib/pattern-match.mjs';
import {verifiedSavedChart} from '../lib/pattern-encyclopedia-client.mjs';
import Model from '../lib/portal/lesson-model.cjs';
const root=new URL('../',import.meta.url),bytes=v=>Buffer.byteLength(JSON.stringify(v));
async function sources(){const catalog=JSON.parse(await readFile(new URL('public/charts/catalog.json',root),'utf8'));return Promise.all(catalog.sessions.map(async reference=>{const raw=await readFile(new URL('public'+reference.url,root));assert.equal(createHash('sha256').update(raw).digest('hex'),reference.sha256);return {reference,chart:JSON.parse(raw)};}));}

test('every catalog session preserves exact full-session candles, EMA, prior indicators, provenance and prior close without mutating original',async()=>{
 const entries=await sources();assert.ok(entries.length>=718);let biggest=[];
 for(const {chart,reference} of entries){const before=JSON.stringify(chart),compact=compactPatternChart(chart,reference.sha256);
  assert.equal(JSON.stringify(chart),before,chart.id+' original mutated');
  assert.deepEqual(historicalPrefix(compact,compact.current.length,{useEma:true}),historicalPrefix(chart,chart.current.length,{useEma:true}),chart.id);
  assert.deepEqual(Model.chartIndicators(compact),Model.chartIndicators(chart),chart.id+' indicators');
  assert.deepEqual(historicalGap(compact),historicalGap(chart),chart.id+' previous close');
  assert.deepEqual(compact.current,chart.current);assert.deepEqual(compact.source,chart.source);assert.deepEqual(compact.rights,chart.rights);assert.deepEqual(compact.previousSession,chart.previousSession);
  assert.equal(Array.isArray(compact.warmup),false);assert.ok(Number.isFinite(compact.warmup.value));
  assert.deepEqual(compactPatternChart(compact,reference.sha256),compact,'already compact is stable');
  const example={chartId:chart.id,chartSha256:reference.sha256,startBar:2,endBar:3};
  assert.ok(verifiedSavedChart([],example,{charts:{[chart.id]:chart}}),'legacy saved chart readable');
  assert.ok(verifiedSavedChart([],example,{charts:{[chart.id]:compact}}),'compact saved chart readable');
  biggest.push(bytes(compact));
 }
 biggest.sort((a,b)=>b-a);assert.ok(biggest.slice(0,49).reduce((a,b)=>a+b,0)<1024*1024,'49 largest compact charts leave ample space for references');
});

test('maximum 48 matches that previously exceed 2 MiB freeze safely with unchanged scores and source hashes',async()=>{
 const entries=(await sources()).sort((a,b)=>bytes(b.chart)-bytes(a.chart)).slice(0,49),source=entries[0];
 const reference=e=>({chartId:e.chart.id,chartSha256:e.reference.sha256,startBar:2,endBar:3});
 const query=buildPatternWindow(source,2,3);
 const pattern={id:randomUUID(),title:'Large regression',description:'Full-session data',expectation:'Preserved expectation',notes:'',tags:[],exampleNotes:{},snapshot:{version:1,algorithmVersion:'pattern-v1',matchedAt:new Date().toISOString(),searchOptions:{earlierOnly:false,limit:48},source:reference(source),matches:entries.slice(1).map(e=>({...reference(e),score:patternDistance(query.normalized,buildPatternWindow(e,2,3).normalized).distance}))}};
 validatePattern(pattern,Date.now());assert.ok(bytes({...pattern.snapshot,charts:Object.fromEntries(entries.map(e=>[e.chart.id,e.chart]))})>PATTERN_LIMITS.snapshotBytes);
 const before=JSON.stringify(pattern),resolve=async(id,hash)=>{const e=entries.find(e=>e.chart.id===id);assert.equal(hash,e.reference.sha256);return e.chart;};
 const frozen=await freezePattern(pattern,resolve);assert.equal(JSON.stringify(pattern),before);assert.ok(bytes(frozen.snapshot)<PATTERN_LIMITS.snapshotBytes);assert.deepEqual(frozen.snapshot.matches,pattern.snapshot.matches);assert.equal(frozen.expectation,pattern.expectation);
 const {charts,...saved}=frozen.snapshot;assert.deepEqual(saved,pattern.snapshot);assert.equal(Object.keys(charts).length,49);
 const wrong=structuredClone(pattern);wrong.snapshot.matches[0].score+=1;await assert.rejects(freezePattern(wrong,resolve),/match distance differs/);
 const wrongHash=structuredClone(pattern);wrongHash.snapshot.source.chartSha256='0'.repeat(64);await assert.rejects(freezePattern(wrongHash,resolve));
});

test('invalid chronology or prior context cannot become a trusted compact seed',async()=>{
 const {chart,reference}=(await sources())[0];const bad=structuredClone(chart);bad.warmup[1].t=bad.warmup[0].t;assert.throws(()=>compactPatternChart(bad,reference.sha256),/chronological/);
 const prior=structuredClone(chart);prior.prior[0].c+=1;assert.throws(()=>compactPatternChart(prior,reference.sha256),/prior context/);
});

test('PostgreSQL legacy full-history records survive edit, replay, trash and restore without rewriting snapshot',async()=>{
 const {PGlite}=await import('@electric-sql/pglite');const {PatternRepository}=await import('../lib/learner/pattern-repository.mjs');const db=new PGlite();
 try{
  await db.exec('CREATE SCHEMA learner_app; CREATE TABLE learner_app.accounts(id uuid PRIMARY KEY); CREATE TABLE learner_app.schema_migrations(version integer,description text);');await db.exec(await readFile(new URL('migrations/025_pattern_encyclopedia.sql',root),'utf8'));
  const now=Date.now(),account={id:randomUUID(),generation:1},session={session_tag:'test',expires_at:now+1e6},principal={expiresAt:now+1e6},id=randomUUID();await db.query('INSERT INTO learner_app.accounts VALUES($1)',[account.id]);
  const chart=JSON.parse(await readFile(new URL('public/charts/mes1-2026-11-05-81.json',root),'utf8'));
  const snapshot={version:1,algorithmVersion:'pattern-v1',matchedAt:new Date(now).toISOString(),searchOptions:{earlierOnly:true,limit:10},source:{chartId:chart.id,chartSha256:'a'.repeat(64),startBar:2,endBar:3},matches:[],charts:{[chart.id]:chart}};
  const metadata={title:'Legacy study',notes:'Original',description:'Original',expectation:'',tags:[],exampleNotes:{}};
  await db.query('INSERT INTO learner_app.pattern_entries(account_id,pattern_id,metadata,snapshot,revision,created_at,updated_at,payload_bytes) VALUES($1,$2,$3,$4,1,$5,$5,$6)',[account.id,id,JSON.stringify(metadata),JSON.stringify(snapshot),now,bytes({id,...metadata,snapshot})]);
  const repository=new PatternRepository({patternEncyclopediaEnabled:true,owned:(_p,_n,_f,fn)=>fn(db,account,session,now),check(){}}),resolve=async()=>{throw Error('Existing record must not reload its chart');};
  const changes={...metadata,expectation:'Continuation'},command={id,requestId:randomUUID(),action:'update',revision:1,changes};
  const updated=await repository.write(principal,{},command,now,resolve);assert.deepEqual(updated.pattern.snapshot,snapshot);
  const replay=await repository.write(principal,{},command,now,resolve);assert.equal(replay.duplicate,true);assert.equal(replay.pattern.revision,2);assert.deepEqual(replay.pattern.snapshot,snapshot);
  for(const [action,revision] of [['delete',2],['restore',3]]){const result=await repository.write(principal,{}, {id,requestId:randomUUID(),action,revision},now,resolve);assert.deepEqual(result.pattern.snapshot,snapshot);}
  const saved=(await repository.detail(principal,id,now)).pattern;assert.equal(saved.revision,4);assert.equal(saved.expectation,'Continuation');assert.equal(saved.deletedAt,null);assert.ok(Array.isArray(saved.snapshot.charts[chart.id].warmup));
 }finally{await db.close();}
});
