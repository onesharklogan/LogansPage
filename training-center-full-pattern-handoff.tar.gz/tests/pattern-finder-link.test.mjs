import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {patternFinderUrl,readPatternFinderLink,resolvePatternFinderLink,openPatternFinderTab} from '../public/modules/pattern-finder-link.js';
const ref={id:'mes1-2026-06-10-81',sha256:'a'.repeat(64)},opts={...ref,revealed:20,total:81};
test('all simulator handoffs open the full chart without changing simulator scoring',()=>{
 for(const [extra,end] of [[{},81],[{finished:true},81],[{preview:true},81]]){const url=patternFinderUrl({...opts,...extra}),link=readPatternFinderLink(url.split('?')[1]);assert.equal(link.through,end);assert.equal(link.id,ref.id);assert.equal(new URLSearchParams(url.split('?')[1]).size,4);}
 assert.throws(()=>patternFinderUrl({...opts,revealed:1}));assert.throws(()=>patternFinderUrl({...opts,revealed:82}));assert.throws(()=>patternFinderUrl({...opts,id:'https://evil.test'}));
});
test('exact chart identity and no automatic pattern selection',()=>{
 const rows=[{reference:ref,chart:{current:Array(81).fill({})}}],link=readPatternFinderLink(patternFinderUrl(opts).split('?')[1]);
 const result=resolvePatternFinderLink(rows,link);assert.equal(result.start,'');assert.equal(result.end,'');assert.equal(result.limited,false);
 assert.throws(()=>resolvePatternFinderLink(rows,{...link,sha256:'b'.repeat(64)}));assert.throws(()=>resolvePatternFinderLink(rows,{...link,through:82}));
 assert.equal(readPatternFinderLink(''),null);assert.throws(()=>readPatternFinderLink('study=simulator&source=bad'));
});
test('popup blocking leaves current tab untouched and gives usable error',()=>{
 assert.throws(()=>openPatternFinderTab(patternFinderUrl(opts),{open:()=>null}),/Allow pop-ups/);
 let opened,location;const tab={opener:{},location:{replace:url=>location=url}};openPatternFinderTab(patternFinderUrl(opts),{open:(...args)=>{opened=args;return tab;}});assert.deepEqual(opened,['about:blank','_blank']);assert.equal(tab.opener,null);assert.match(location,/through=81/);
});
test('finder constrains source and hides navigation that could reveal its future',()=>{
 const source=fs.readFileSync('components/pattern-match.tsx','utf8');assert.match(source,/Math.min\(source.chart.current.length,handoff\?\.id===sourceId\?handoff.through/);assert.match(source,/hideNavigation=\{limited\}/);assert.match(source,/disabled=\{limited\}/);assert.match(source,/disabled=\{saving\|\|limited\}/);
 const editor=fs.readFileSync('components/pattern-encyclopedia.tsx','utf8');assert.match(editor,/savedId&&!hideNavigation/);
 for(const file of ['components/trade-simulator.tsx','public/modules/market-direction.html'])assert.match(fs.readFileSync(file,'utf8'),/Open in Pattern Finder/);
});
