/** Public chart reference only. Never transfers account or trades. Full historical chart study is explicitly requested. */
const ID=/^mes1-\d{4}-\d{2}-\d{2}-(?:42|45|78|81)$/;
const HASH=/^[a-f0-9]{64}$/;
export function patternFinderUrl({id,sha256,revealed,total,finished=false,preview=false}){
 if(!ID.test(id||'')||!HASH.test(sha256||'')||!Number.isInteger(total)||total<2||total>81||!Number.isInteger(revealed)||revealed<2||revealed>total)throw Error('Reveal at least two bars of a catalog chart to open Pattern Finder.');
 const max=total;
 return '/pattern-match?'+new URLSearchParams({source:id,sha256,through:String(max),study:'simulator'}).toString();
}
export function readPatternFinderLink(search){
 const p=new URLSearchParams(search);if(p.get('study')!=='simulator')return null;
 const id=p.get('source'),sha256=p.get('sha256'),through=Number(p.get('through'));
 if(!ID.test(id||'')||!HASH.test(sha256||'')||!Number.isInteger(through)||through<2||through>81)throw Error('The simulator chart link is invalid. Return to the simulator and open Pattern Finder again.');
 return {id:String(id),sha256:String(sha256),through};
}
export function resolvePatternFinderLink(rows,link){
 if(!link)return null;
 const source=rows.find(row=>row.reference.id===link.id&&row.reference.sha256===link.sha256);
 if(!source||link.through>source.chart.current.length)throw Error('The exact simulator chart is unavailable. Return to the simulator and try again.');
 return {source,start:'',end:'',limited:link.through<source.chart.current.length};
}

export function openPatternFinderTab(url,win=window){
 if(typeof url!=='string'||!url.startsWith('/pattern-match?'))throw Error('Invalid Pattern Finder destination.');
 const tab=win.open('about:blank','_blank');
 if(!tab)throw Error('Allow pop-ups for this site, then press Open in Pattern Finder again.');
 try{tab.opener=null;tab.location.replace(url);}catch(error){try{tab.close();}catch{}throw Error('Pattern Finder could not open. Your simulator is unchanged.');}
}
