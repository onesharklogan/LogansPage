-- Additive only. Apply on publication approval, never reset existing history.
BEGIN;
CREATE TABLE IF NOT EXISTS learner_app.improvement_notes (
 account_id uuid PRIMARY KEY REFERENCES learner_app.accounts(id),
 notes text NOT NULL DEFAULT '' CHECK(length(notes)<=20000),
 revision integer NOT NULL DEFAULT 1 CHECK(revision>0),
 updated_at bigint NOT NULL
);
COMMENT ON TABLE learner_app.improvement_notes IS 'Private inert app-improvement notes. Not instructions to execute or publish. Independent of trading history resets.';
REVOKE ALL ON learner_app.improvement_notes FROM PUBLIC;
GRANT SELECT,INSERT ON learner_app.improvement_notes TO learner_runtime;
GRANT UPDATE(notes,revision,updated_at) ON learner_app.improvement_notes TO learner_runtime;
COMMIT;
