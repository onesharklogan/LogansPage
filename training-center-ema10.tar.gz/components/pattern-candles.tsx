import type {SVGProps} from 'react';

type Candle={o:number;h:number;l:number;c:number;ema?:number|null;ema10?:number|null;t?:string};
type Props={candles:Candle[];referenceCandles?:Candle[];referenceWidth?:number;startBar?:number;selection?:{start:number;end:number};label:string;compact?:boolean;interactive?:boolean;fullSession?:boolean;numberFontSize?:number}&SVGProps<SVGSVGElement>;

/** Full charts use their visible candles; selected previews inherit the source chart geometry. */
export default function PatternCandles({candles,referenceCandles,referenceWidth,startBar=1,selection,label,compact=false,interactive=false,fullSession=false,numberFontSize,style,...props}:Props){
 // A preview is a crop of the source coordinate system, not a new x/y fit.
 // The same units per price and per bar preserve bodies, gaps, wicks and EMA slope.
 const left=24,right=72,top=38,bottom=34,sourceWidth=1000,sourceHeight=380;
 if(!candles.length)return null;
 const extent=(bars:Candle[])=>{const values=bars.flatMap(c=>[c.l,c.h,...(Number.isFinite(c.ema)?[c.ema as number]:[])]);const lo=Math.min(...values),hi=Math.max(...values),range=Math.max(.01,hi-lo);return {min:lo-range*.1,max:hi+range*.1};};
 const reference=compact&&referenceCandles?.length?referenceCandles:candles;
 const domain=extent(reference),visible=extent(candles);
 const step=(sourceWidth-left-right)/reference.length;
 const priceScale=(sourceHeight-top-bottom)/(domain.max-domain.min);
 const cropped=compact&&!!referenceCandles?.length;
 const width=cropped?left+step*candles.length+right:sourceWidth;
 const min=cropped?visible.min:domain.min,max=cropped?visible.max:domain.max;
 const height=cropped?top+(max-min)*priceScale+bottom:sourceHeight;
 const x=(i:number)=>left+step*(i+.5),y=(p:number)=>top+(max-p)*priceScale;
 const selected=(i:number)=>!selection||i+startBar>=selection.start&&i+startBar<=selection.end;
 const emaPath=(key:'ema'|'ema10')=>{let connected=false;return candles.map((c,i)=>{const value=c[key];if(!Number.isFinite(value)){connected=false;return '';}const segment=`${connected?'L':'M'}${x(i)} ${y(value as number)}`;connected=true;return segment;}).join(' ');};
 const ema10=emaPath('ema10');
 const ema=candles.map((c,i)=>Number.isFinite(c.ema)?`${i?'L':'M'}${x(i)} ${y(c.ema as number)}`:'').join(' ');
 return <svg viewBox={`0 0 ${width} ${height}`} width={cropped?(referenceWidth&&referenceWidth>0?referenceWidth*width/sourceWidth:`${width/sourceWidth*100}%`):"100%"} preserveAspectRatio="xMidYMid meet" role={interactive?'group':'img'} aria-label={label} {...props} style={cropped?{...style,maxWidth:"100%",height:"auto",maxHeight:"none"}:style}>
  <rect width={width} height={height} fill="#08131f" rx="8"/>
  {[0,.25,.5,.75,1].map((p,i)=>{const price=min+(max-min)*p;return <g key={i} pointerEvents="none"><line x1={left} x2={width-right} y1={y(price)} y2={y(price)} stroke="#1c3042"/><text x={width-8} y={y(price)+5} textAnchor="end" fontSize={fullSession?16:12} fill="#8ba1b6">{price.toFixed(2)}</text></g>;})}
  {selection&&<rect data-pattern-highlight x={left+Math.min(candles.length,Math.max(0,selection.start-startBar))*step} y={top-10} width={Math.max(0,Math.min(candles.length,selection.end-startBar+1)-Math.min(candles.length,Math.max(0,selection.start-startBar)))*step} height={height-top-bottom+15} fill="#cbd5e1" fillOpacity={.025} stroke="#cbd5e1" strokeOpacity={.55} strokeWidth={1} vectorEffect="non-scaling-stroke" pointerEvents="none"/>}
  {candles.map((c,i)=>{const color=c.c>=c.o?'#67dfb3':'#f18da6',w=Math.min(step*.58,18),n=i+startBar;return <g key={i} opacity={fullSession||selected(i)?1:.38} pointerEvents="none" data-pattern-bar={n}>
   <line x1={x(i)} x2={x(i)} y1={y(c.h)} y2={y(c.l)} stroke={color} strokeWidth={1.4}/>
   <rect x={x(i)-w/2} y={Math.min(y(c.o),y(c.c))} width={w} height={Math.max(1.5,Math.abs(y(c.o)-y(c.c)))} fill={color}/>
   {(candles.length<=25||(!fullSession&&compact)||(n%5===0&&(!fullSession||startBar+candles.length-1-n>=3))||n===startBar||n===startBar+candles.length-1)&&<text x={x(i)} y={Math.max(18,y(c.h)-9)} textAnchor="middle" fontSize={numberFontSize??(fullSession?16:compact?Math.min(12,step*.75):12)} fill={fullSession||selected(i)?'#b2c5d7':'#6b8094'}>{n}</text>}
   <title>{`Bar ${n}${c.t?' · '+c.t:''} · O ${c.o} H ${c.h} L ${c.l} C ${c.c}`}</title>
  </g>;})}
  <path d={ema10} fill="none" stroke="#f6c760" strokeWidth={.7} strokeOpacity={.3} strokeLinejoin="round" vectorEffect="non-scaling-stroke" pointerEvents="none" data-pattern-ema10/>
  <path d={ema} fill="none" stroke="#f6c760" strokeWidth={2} strokeLinejoin="round" pointerEvents="none" data-pattern-ema/>
  {compact?<text x={width/2} y={height-10} textAnchor="middle" fontSize={Math.min(12,width/16)} fill="#8ba1b6">{`Bars ${startBar}–${startBar+candles.length-1} · Chicago`}</text>:<><text x={left} y={height-10} fontSize={fullSession?16:12} fill="#8ba1b6">{candles[0].t?.slice(11,16)||`Bar ${startBar}`}</text><text x={width-right} y={height-10} textAnchor="end" fontSize={fullSession?16:12} fill="#8ba1b6">{candles.at(-1)?.t?.slice(11,16)||`Bar ${startBar+candles.length-1}`} · Chicago</text></>}
 </svg>;
}
