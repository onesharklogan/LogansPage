-- PREPARED ONLY. Private optional Daily Balance rating, independent of checklist completion.
BEGIN;
CREATE TABLE IF NOT EXISTS learner_app.daily_positivity (
 account_id uuid NOT NULL REFERENCES learner_app.accounts(id),
 day_key text NOT NULL CHECK(day_key ~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$'),
 percentage integer NOT NULL CHECK(percentage BETWEEN 0 AND 100),
 revision integer NOT NULL DEFAULT 1 CHECK(revision > 0),
 updated_at bigint NOT NULL CHECK(updated_at > 0),
 PRIMARY KEY(account_id,day_key)
);
REVOKE ALL ON learner_app.daily_positivity FROM PUBLIC;
GRANT SELECT,INSERT ON learner_app.daily_positivity TO learner_runtime;
GRANT UPDATE(percentage,revision,updated_at) ON learner_app.daily_positivity TO learner_runtime;
COMMIT;
