-- Reversible lesson removal. App rollback can leave these columns and data intact.
BEGIN;
ALTER TABLE learner_app.life_lessons
 ADD COLUMN IF NOT EXISTS revision integer NOT NULL DEFAULT 1 CHECK (revision > 0),
 ADD COLUMN IF NOT EXISTS removed_at bigint CHECK (removed_at > 0);
GRANT UPDATE (lesson_text, revision, removed_at) ON learner_app.life_lessons TO learner_runtime;
COMMIT;
