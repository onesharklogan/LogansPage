'use client';
import {useEffect,useRef,useState} from 'react';
import styles from './daily-positivity.module.css';

type Owner={accountId:string;generation:number;sessionTag:string};
type RequestError=Error&{status?:number};
type Rating={context:Owner;date:string;today:string;percentage:number|null;revision:number};
const endpoint='/api/learner/daily-positivity';
const keyOf=(owner?:Owner,date?:string)=>owner&&date?JSON.stringify([owner.accountId,owner.generation,owner.sessionTag,date]):'';

async function request(path:string,key:string,init?:RequestInit){
 const response=await fetch(path,{...init,cache:'no-store',credentials:'same-origin'});
 const result=await response.json();
 if(!response.ok)throw Object.assign(Error(result.error||'Could not confirm your check-in.'),{status:response.status});
 if(keyOf(result.context,result.date)!==key)throw Error('The check-in response could not be verified.');
 return result as Rating;
}

function Dial({value}:{value:number|null}){
 return <div className={styles.dial} aria-hidden="true"><svg viewBox="0 0 88 74"><path className={styles.track} d="M 19 65 A 34 34 0 1 1 69 65"/>{value!==null&&<path className={styles.fill} d="M 19 65 A 34 34 0 1 1 69 65" pathLength="100" strokeDasharray={`${value} 100`} />}</svg><strong>{value===null?'–':`${value}%`}</strong></div>;
}

export default function DailyPositivity({owner,date,csrf,dayChanged=false}:{owner?:Owner;date?:string;csrf:string;dayChanged?:boolean}){
 const key=keyOf(owner,date);
 const [data,setData]=useState<Rating|null>(null),[draft,setDraft]=useState<{percentage:number;revision:number}|null>(null),[error,setError]=useState(''),[status,setStatus]=useState(''),[loading,setLoading]=useState(false),[conflict,setConflict]=useState(false),[saving,setSaving]=useState(false),[retry,setRetry]=useState(0);
 const previous=useRef(''),latest=useRef(key),pending=useRef<string|null>(null);
 latest.current=key;
 useEffect(()=>{
  if(!key)return;
  const controller=new AbortController();
  if(previous.current!==key){setData(null);setDraft(null);previous.current=key;}
  setLoading(true);setSaving(false);setError('');setStatus('');setConflict(false);
  void request(endpoint+'?date='+encodeURIComponent(date!),key,{signal:controller.signal}).then(next=>{
   if(controller.signal.aborted||latest.current!==key)return;
   setData(prev=>prev&&keyOf(prev.context,prev.date)===key&&prev.revision>next.revision?prev:next);
  }).catch(e=>{
   if(controller.signal.aborted||latest.current!==key)return;
   if(e.status===401||e.status===403){setData(null);setDraft(null);}
   setError(e.message||'Could not load the check-in.');
  }).finally(()=>{if(!controller.signal.aborted&&latest.current===key)setLoading(false);});
  return()=>controller.abort();
 },[key,date,retry]);
 async function save(){
  if(!data||!key||draft===null||pending.current||conflict||loading||dayChanged||data.date!==data.today)return;
  pending.current=key;setSaving(true);setError('');setStatus('');
  try{
   const next=await request(endpoint,key,{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify({context:data.context,date:data.date,percentage:draft.percentage,revision:draft.revision})});
   if(latest.current===key){setData(next);setDraft(null);setStatus('Saved.');}
  }catch(e){
   if(latest.current===key){
    const result=e instanceof Error?e as RequestError:null;
    if(result?.status===401||result?.status===403){setData(null);setDraft(null);}
    setConflict(result?.status===409);setError(result?.message||'Save not confirmed. Please retry.');
   }
  }finally{pending.current=null;if(latest.current===key)setSaving(false);}
 }
 const shown=key&&data&&keyOf(data.context,data.date)===key?data:null;
 const editable=shown&&shown.date===shown.today&&!dayChanged;
 const displayed=shown?((editable?draft?.percentage:null)??shown.percentage):null;
 return <section className={styles.panel} aria-labelledby="positivity-heading">
  <div><h2 id="positivity-heading">Positive words &amp; attitude</h2><p>What percentage of your words and attitudes felt positive that day?</p></div>
  {shown?<div className={styles.controls}>
   <Dial value={displayed}/>
   {editable?<form onSubmit={e=>{e.preventDefault();void save();}}>
    <label htmlFor="positivity-rating">Positive percentage</label>
    <input id="positivity-rating" type="range" min="0" max="100" step="1" value={displayed??50} aria-valuetext={displayed===null?'Not rated; move slider to choose a percentage':`${displayed}%`} disabled={saving||loading||conflict} onClick={e=>{if(displayed===null)setDraft({percentage:Number(e.currentTarget.value),revision:shown.revision});}} onChange={e=>{const percentage=Number(e.target.value);setDraft(prev=>({percentage,revision:prev?.revision??shown.revision}));setStatus('');}} />
    <div className={styles.scale} aria-hidden="true"><span>0%</span><span>100%</span></div>
    <button disabled={draft===null||saving||loading||conflict}>{saving?'Saving…':shown.percentage===null?'Save rating':'Update rating'}</button>
   </form>:<p>{shown.percentage===null?'No rating recorded.':`${shown.percentage}% positive`}</p>}
  </div>:!error&&<p role="status">Loading check-in…</p>}
  {status&&<p role="status">{status}</p>}
  {error&&<div className={styles.error} role="alert">{error} {(!shown||conflict)&&<button type="button" onClick={()=>{setDraft(null);setRetry(i=>i+1);}}>Reload</button>}</div>}
 </section>;
}
