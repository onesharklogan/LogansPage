'use client';
import {useEffect,useRef,useState} from 'react';
import LoadingIndicator from './loading-indicator';
import styles from './hourly-reminders.module.css';
type Owner={accountId:string;generation:number;sessionTag:string};
type Saved={context:Owner;text:string;revision:number};
const identity=(owner?:Owner)=>owner?JSON.stringify(owner):'';
async function request(url:string,init?:RequestInit){const response=await fetch(url,{...init,credentials:'same-origin',cache:'no-store'});let value;try{value=await response.json();}catch{throw Error('Save not confirmed. Your reminders are still here.');}if(!response.ok)throw Object.assign(Error(value.error||'Could not load or save reminders.'),{status:response.status});return value;}
export default function HourlyReminders({owner}:{owner?:Owner}){
 const [saved,setSaved]=useState<Saved|null>(null),[text,setText]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState(''),[status,setStatus]=useState(''),[conflict,setConflict]=useState(false);
 const active=useRef(''),epoch=useRef(0),alive=useRef(true),locked=useRef(false),token=useRef(''),draft=useRef(''),baseline=useRef<Saved|null>(null);
 const ownerKey=identity(owner),currentOwner=useRef(ownerKey);currentOwner.current=ownerKey;
 const dirty=!!saved&&text!==saved.text;
 const current=(ticket:number,key:string)=>alive.current&&epoch.current===ticket&&active.current===key&&currentOwner.current===key;
 async function load(key=active.current){
  if(!key||locked.current)return;
  if(baseline.current&&draft.current!==baseline.current.text&&!window.confirm('Reload saved reminders and discard your unsaved changes?'))return;
  locked.current=true;setBusy(true);setError('');const ticket=++epoch.current;
  try{const session=await request('/api/learner/session');if(!session.profile||identity(session.context)!==key)throw Object.assign(Error('Your account changed. Refresh the dashboard to continue.'),{status:401});const next:Saved=await request('/api/learner/hourly-reminders');if(identity(next.context)!==key)throw Object.assign(Error('Your account changed. Refresh the dashboard to continue.'),{status:401});if(current(ticket,key)){token.current=session.csrfToken;baseline.current=next;draft.current=next.text;setSaved(next);setText(next.text);setConflict(false);setStatus('');}}
  catch(e){if(current(ticket,key)){setError(e instanceof Error?e.message:'Could not load reminders.');if((e as {status?:number}).status===401||(e as {status?:number}).status===403){baseline.current=null;draft.current='';setSaved(null);setText('');}}}
  finally{if(current(ticket,key)){locked.current=false;setBusy(false);}}
 }
 useEffect(()=>{alive.current=true;return()=>{alive.current=false;};},[]);
 useEffect(()=>{if(!ownerKey){epoch.current++;locked.current=false;setBusy(false);return;}if(ownerKey===active.current){if(!baseline.current)void load(ownerKey);return;}epoch.current++;active.current=ownerKey;locked.current=false;baseline.current=null;draft.current='';setSaved(null);setText('');setError('');setStatus('');setConflict(false);void load(ownerKey);},[ownerKey]);
 useEffect(()=>{const refresh=()=>{if(!currentOwner.current||currentOwner.current!==active.current||locked.current||baseline.current&&draft.current!==baseline.current.text)return;void load();};window.addEventListener('focus',refresh);return()=>window.removeEventListener('focus',refresh);},[]);
 useEffect(()=>{if(!dirty)return;const warn=(event:BeforeUnloadEvent)=>{event.preventDefault();event.returnValue='';};window.addEventListener('beforeunload',warn);return()=>window.removeEventListener('beforeunload',warn);},[dirty]);
 async function save(){
  if(!saved||locked.current||conflict||!ownerKey||ownerKey!==active.current)return;
  if(saved.text.trim()&&!text.trim()&&!window.confirm('Clear all saved reminders? Choose Cancel to keep them.'))return;
  locked.current=true;setBusy(true);setError('');setStatus('');const ticket=++epoch.current,key=active.current;
  try{const next:Saved=await request('/api/learner/hourly-reminders',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':token.current},body:JSON.stringify({context:saved.context,text,revision:saved.revision})});if(identity(next.context)!==key)throw Object.assign(Error('Your account changed. Refresh the dashboard to continue.'),{status:401});if(current(ticket,key)){baseline.current=next;draft.current=next.text;setSaved(next);setText(next.text);setStatus('Reminders saved.');}}
  catch(e){if(current(ticket,key)){const code=(e as {status?:number}).status;if(code===401||code===403){baseline.current=null;draft.current='';setSaved(null);setText('');setError('Your account changed. Refresh the dashboard to continue.');}else{setConflict(code===409);setError(code===409?'Reminders changed on another screen. Your draft is kept here. Copy it before reloading the saved version.':e instanceof Error?e.message:'Save not confirmed. Your draft is kept here.');}}}
  finally{if(current(ticket,key)){locked.current=false;setBusy(false);}}
 }
 return <div className={styles.reminders}>
  {!saved&&ownerKey&&(error?<><p role="alert">{error}</p><button type="button" disabled={busy} onClick={()=>void load()}>Retry reminders</button></>:<p role="status"><LoadingIndicator size="small" label="Loading reminders…" /></p>)}
  <div hidden={!saved||!ownerKey||ownerKey!==active.current}>
  <label htmlFor="hourly-reminders">Reminders</label>
  <textarea id="hourly-reminders" rows={5} maxLength={20000} value={!ownerKey||ownerKey!==active.current?'':text} disabled={busy||!saved||!ownerKey||ownerKey!==active.current} onChange={event=>{draft.current=event.target.value;setText(event.target.value);setStatus('');}} placeholder="Write the reminders or affirmations you want to read each hour…"/>
  <div className={styles.actions}><button type="button" disabled={busy||!saved||!dirty||conflict||!ownerKey} onClick={()=>void save()}>Save reminders</button>{error&&<button type="button" disabled={busy||!ownerKey} onClick={()=>void load()}>Reload saved</button>}<span role="status">{busy?'Syncing reminders…':status|| (dirty?'Unsaved changes':'Saved reminders carry over each day.')}</span></div>
  {error&&<p role="alert">{error}</p>}
  </div>
 </div>;
}
