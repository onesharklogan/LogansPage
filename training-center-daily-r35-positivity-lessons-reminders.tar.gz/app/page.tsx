import {DAILY_BALANCE_ORIGIN} from '../lib/learner/google-config.mjs';
import DailyDashboard from '../components/daily-dashboard';
export const dynamic='force-dynamic';
export const metadata={title:'Daily Balance',description:'Balanced Day Goals'};
export default function Home(){return <DailyDashboard lifeLessonsEnabled={process.env.LEARNER_APP_ORIGIN===DAILY_BALANCE_ORIGIN} positivityEnabled={process.env.LEARNER_APP_ORIGIN===DAILY_BALANCE_ORIGIN} weightEnabled={process.env.LEARNER_APP_ORIGIN===DAILY_BALANCE_ORIGIN}/>;}
