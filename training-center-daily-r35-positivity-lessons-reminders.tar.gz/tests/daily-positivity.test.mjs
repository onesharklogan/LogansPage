import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {PGlite} from '@electric-sql/pglite';
import {LearnerRepository} from '../lib/learner/repository.mjs';
import {createLearnerService} from '../lib/learner/server.mjs';
import {DAILY_BALANCE_ORIGIN,LEARNER_ORIGIN} from '../lib/learner/google-config.mjs';
import {restrictToPrivateOwner,PRIVATE_OWNER_EMAIL} from '../lib/learner/private-owner.mjs';

const migration=n=>fs.readFileSync(new URL('../migrations/'+n+'.sql',import.meta.url),'utf8');
test('private positivity API distinguishes missing and 0, scopes owner and Chicago day, and leaves daily completion alone',async()=>{
 const db=new PGlite();
 let who='synthetic-one',mail=PRIVATE_OWNER_EMAIL,now=Date.parse('2026-11-20T05:59:59Z');
 try{
  await db.exec('CREATE ROLE learner_runtime');
  const ddl=migration('038_daily_positivity');
  for(const name of ['006_learner_accounts','028_daily_dashboard','032_daily_categories_order','033_daily_hourly_checkins','038_daily_positivity'])await db.exec(migration(name));
  const repository=new LearnerRepository({transaction:fn=>db.transaction(tx=>fn(tx))}),issuer='https://positivity.test';
  const service=origin=>createLearnerService({origin,repository,identityProvider:restrictToPrivateOwner({issuer,resolve:async()=>who?{issuer,subject:who,name:'Synthetic',email:mail,emailVerified:true,sessionId:'synthetic-positivity-'+who,expiresAt:now+3600000}:null}),csrfSecret:'synthetic-only-secret-more-than-32-characters',charts:async()=>null,now:()=>now});
  const services={[DAILY_BALANCE_ORIGIN]:service(DAILY_BALANCE_ORIGIN),[LEARNER_ORIGIN]:service(LEARNER_ORIGIN)};
  const req=async(path='daily-positivity',{payload,csrf,origin=DAILY_BALANCE_ORIGIN}={})=>{
   const headers={host:new URL(origin).host,origin,'sec-fetch-site':'same-origin',...(payload?{'content-type':'application/json','x-csrf-token':csrf??''}:{})};
   const r=await services[origin](new Request(origin+'/api/learner/'+path,{method:payload?'POST':'GET',headers,...(payload?{body:JSON.stringify(payload)}:{})}));
   return {status:r.status,cache:r.headers.get('cache-control'),body:await r.json()};
  };
  let session=(await req('session')).body;
  let cmd={context:session.context,date:'2026-11-19',percentage:0,revision:0};
  const post=(payload=cmd,csrf=session.csrfToken)=>req(undefined,{payload,csrf});
  const before=await req('daily');
  assert.equal(before.status,200);
  assert.deepEqual((await req()).body,{context:session.context,today:cmd.date,date:cmd.date,percentage:null,revision:0});
  assert.equal((await post(cmd,'bad')).status,403);
  for(const percentage of [-1,101,75.5,'50',null])assert.equal((await post({...cmd,percentage})).status,400);
  assert.equal((await post({...cmd,accountId:'spoof'})).status,400);
  assert.equal((await post({...cmd,date:'2026-11-18'})).status,409);
  for(const path of ['daily-positivity?date=','daily-positivity?date=2026-02-30','daily-positivity?date=2026-11-19&date=2026-11-18','daily-positivity?accountId=spoof'])assert.equal((await req(path)).status,400);
  const saved=await post();assert.equal(saved.status,200);assert.equal(saved.cache,'private, no-store');
  assert.deepEqual(await post(),saved);assert.equal(saved.body.percentage,0);assert.equal(saved.body.revision,1);
  assert.equal((await post({...cmd,percentage:100})).status,409);
  assert.equal((await post({...cmd,percentage:100,revision:1})).body.revision,2);
  assert.equal((await req()).body.percentage,100);
  assert.deepEqual(await req('daily'),before);
  assert.equal((await req(undefined,{origin:LEARNER_ORIGIN})).status,404);
  assert.equal((await req(undefined,{origin:LEARNER_ORIGIN,payload:cmd,csrf:session.csrfToken})).status,404);
  mail='nobody@example.test';assert.equal((await req()).status,403);
  mail=PRIVATE_OWNER_EMAIL;who='synthetic-two';const second=(await req('session')).body;
  assert.equal((await req()).body.percentage,null);assert.equal((await post(cmd,second.csrfToken)).status,409);
  who=null;assert.equal((await req()).status,401);
  who='synthetic-one';now=Date.parse('2026-11-20T06:00:00Z');
  assert.equal((await post()).status,409);
  assert.equal((await req()).body.percentage,null);
  assert.equal((await req('daily-positivity?date=2026-11-19')).body.percentage,100);
  await db.exec(ddl);
  const grants=(await db.query("SELECT has_table_privilege('learner_runtime','learner_app.daily_positivity','DELETE') AS del,has_column_privilege('learner_runtime','learner_app.daily_positivity','percentage','UPDATE') AS edit,has_column_privilege('learner_runtime','learner_app.daily_positivity','day_key','UPDATE') AS rekey")).rows[0];
  assert.deepEqual(grants,{del:false,edit:true,rekey:false});
  await assert.rejects(db.query('UPDATE learner_app.daily_positivity SET percentage=-1'),{code:'23514'});
 }finally{await db.close();}
});
