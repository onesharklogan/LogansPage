import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';import ts from 'typescript';
// Executes real component handlers with hook doubles, not a browser/layout test.
function mount(fetcher,initial){let states=[],refs=[],effects=[],cursor=0,dirty=true,tree,props=initial,pending=[];const events={};const react={useState(init){const i=cursor++;if(!(i in states))states[i]=typeof init==='function'?init():init;return[states[i],v=>{states[i]=typeof v==='function'?v(states[i]):v;dirty=true;}];},useRef(v){const i=cursor++;return refs[i]??= {current:v};},useEffect(fn,deps){const i=cursor++,old=effects[i];if(!old||deps.some((v,j)=>v!==old.deps[j])){pending.push(()=>{old?.cleanup?.();effects[i]={deps,cleanup:fn()};});}}};const jsx=(type,props)=>({type,props:props||{}});const exports={};const code=ts.transpileModule(fs.readFileSync(new URL('../components/daily-positivity.tsx',import.meta.url),'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS,jsx:ts.JsxEmit.ReactJSX}}).outputText;vm.runInNewContext(code,{exports,require:n=>n==='react'?react:n==='react/jsx-runtime'?{jsx,jsxs:jsx}:{default:{}},fetch:fetcher,window:{confirm:()=>false,addEventListener:(n,f)=>{(events[n]??=new Set()).add(f);},removeEventListener:(n,f)=>events[n]?.delete(f)},console,JSON,Error,AbortController});const flush=()=>{let loops=0;while(dirty){if(++loops>30)throw Error('render loop');dirty=false;cursor=0;tree=exports.default(props);const callbacks=pending;pending=[];callbacks.forEach(f=>f());}return tree;};return{flush,update(p){props=p;dirty=true;flush();},async settle(){for(let i=0;i<15;i++){await Promise.resolve();flush();}},fire(n){events[n]?.forEach(f=>f({preventDefault(){}}));},unmount(){effects.forEach(e=>e?.cleanup?.());}};}
const walk=(node,predicate)=>!node||typeof node!=='object'?[]:Array.isArray(node)?node.flatMap(n=>walk(n,predicate)):[...(predicate(node)?[node]:[]),...walk(node.props?.children,predicate)];
const owner={accountId:'owner',generation:1,sessionTag:'session'},date='2026-11-20';
function setup(){
 let saved={context:owner,today:date,date,percentage:null,revision:0},mode='';
 const calls=[];
 const props={owner,date,csrf:'test-csrf'};
 const h=mount(async(url,init)=>{
  if(!init?.method){
   const day=new URL(url,'https://fixture.test').searchParams.get('date');
   return {ok:true,json:async()=>day===date?{...saved}:{...saved,date:day,percentage:0,revision:1}};
  }
  assert.equal(init.headers['X-CSRF-Token'],'test-csrf');
  calls.push(JSON.parse(init.body));
  if(mode==='network')throw Error('Connection lost');
  if(mode==='conflict')return {ok:false,status:409,json:async()=>({error:'Changed elsewhere'})};
  saved={...saved,percentage:calls.at(-1).percentage,revision:saved.revision+1};
  return {ok:true,json:async()=>({...saved})};
 },props);
 const input=()=>walk(h.flush(),n=>n.type==='input')[0];
 const button=()=>walk(h.flush(),n=>n.type==='form').flatMap(f=>walk(f,n=>n.type==='button'))[0];
 const submit=()=>walk(h.flush(),n=>n.type==='form')[0].props.onSubmit({preventDefault(){}});
 return {h,props,input,button,submit,calls,setMode:x=>mode=x};
}
test('positivity dial starts unrated, accepts 0, and locks duplicate submissions',async()=>{
 const x=setup();await x.h.settle();
 assert.match(x.input().props['aria-valuetext'],/^Not rated/);
 assert.equal(x.button().props.disabled,true);
 x.input().props.onChange({target:{value:'0'}});
 assert.equal(x.input().props['aria-valuetext'],'0%');
 x.submit();x.submit();await x.h.settle();
 assert.equal(x.calls.length,1);
 assert.equal(x.calls[0].percentage,0);
 assert.equal(x.calls[0].revision,0);
 assert.equal(x.input().props['aria-valuetext'],'0%');
 x.h.update({...x.props,dayChanged:true});
 assert.equal(x.input(),undefined);
 x.h.update({...x.props,date:'2026-11-19',dayChanged:false});await x.h.settle();
 assert.equal(x.input(),undefined);
 assert.equal(walk(x.h.flush(),n=>n.type==='p'&&n.props.children==='0% positive').length,1);
 x.h.unmount();
});
test('positivity retry keeps the chosen rating until success and blocks conflicts',async()=>{
 const x=setup();await x.h.settle();
 x.input().props.onClick({currentTarget:{value:'50'}});
 x.setMode('network');x.submit();await x.h.settle();
 assert.equal(x.input().props['aria-valuetext'],'50%');assert.equal(x.button().props.disabled,false);
 x.setMode('');x.submit();await x.h.settle();
 assert.deepEqual(x.calls[0],x.calls[1]);
 x.input().props.onChange({target:{value:'90'}});
 x.setMode('conflict');x.submit();await x.h.settle();
 assert.equal(x.calls.at(-1).revision,1);
 assert.equal(x.input().props['aria-valuetext'],'90%');
 assert.equal(x.button().props.disabled,true);
 x.h.unmount();
});
