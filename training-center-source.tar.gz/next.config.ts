import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  poweredByHeader: false,
  experimental: { turbopackPluginRuntimeStrategy: 'workerThreads' },
  async rewrites() {
    return { beforeFiles: [{
      // Keep the first cache hotfix's digest-qualified URL working across releases.
      source: '/modules/history-candle-index.json',
      has: [{ type: 'query' as const, key: 'sha256', value: '(?<historyDigest>[a-f0-9]{64})' }],
      destination: '/modules/history-candle-index/:historyDigest.json',
    }], afterFiles: [], fallback: [] };
  },
  async headers() {
    return [{ source: '/modules/:path*', headers: [{ key: 'Cache-Control', value: 'no-store' }] }, { source: '/:path*', headers: [
      { key: 'X-Content-Type-Options', value: 'nosniff' },
      { key: 'Referrer-Policy', value: 'no-referrer' },
      { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=()' },
      { key: 'Cross-Origin-Opener-Policy', value: 'same-origin' },
      { key: 'X-Frame-Options', value: 'SAMEORIGIN' },
      { key: 'Content-Security-Policy', value: "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' blob: data: https://lh3.googleusercontent.com; connect-src 'self'; frame-src 'self'; frame-ancestors 'self'; object-src 'none'; base-uri 'none'; form-action 'self'" },
    ] }, ...['/chart-match', '/chart-match/ocr/:path*'].map(source => ({ source, headers: [
      // OCR compiles same-origin WebAssembly only on its own page/worker assets.
      // This does not allow JavaScript eval, remote scripts, or remote image upload.
      { key: 'Content-Security-Policy', value: "default-src 'self'; script-src 'self' 'unsafe-inline' 'wasm-unsafe-eval'; worker-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' blob: data: https://lh3.googleusercontent.com; connect-src 'self'; frame-src 'self'; frame-ancestors 'self'; object-src 'none'; base-uri 'none'; form-action 'self'" },
    ] }))];
  },
};

export default nextConfig;
