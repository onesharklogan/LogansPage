import {NextResponse,type NextRequest} from 'next/server';
import {handleRenderRequest} from './lib/portal/render-runtime.mjs';
import {teacherRouteAccess} from './lib/portal/teacher-route-guard.mjs';

export async function proxy(request:NextRequest) {
  const result=await teacherRouteAccess(request,handleRenderRequest);
  if(result.allowed){const response=NextResponse.next();response.headers.set('Cache-Control','private, no-store');return response;}
  // The sign-in page is deliberately outside this matcher; no redirect loop or open return URL.
  const response=NextResponse.redirect(new URL('/admin',request.url),303);
  response.headers.set('Cache-Control','private, no-store');return response;
}
export const config={matcher:['/studio/:path*','/admin/modules/:path*','/editor/:path*']};
