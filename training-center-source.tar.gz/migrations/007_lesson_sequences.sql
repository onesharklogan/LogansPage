-- DRAFT: additive only. Production requires a reviewed recovery point and explicit migration approval.
-- Existing folders, lessons and immutable lesson_versions are not rewritten.
BEGIN;
SELECT pg_advisory_xact_lock(761142019);
DO $migration$
BEGIN
 IF EXISTS(SELECT 1 FROM teacher_studio.schema_migrations WHERE version=4 AND sha256<>'43993c26b548ce7cbdf93ca35ba14198293fd52d676b7dcb2675f8d54a88ef47') THEN
  RAISE EXCEPTION 'Migration checksum mismatch';
 ELSIF NOT EXISTS(SELECT 1 FROM teacher_studio.schema_migrations WHERE version=4) THEN
  CREATE TABLE teacher_studio.lesson_sequences (
 id TEXT PRIMARY KEY, folder_id TEXT NOT NULL REFERENCES teacher_studio.folders(id), title TEXT NOT NULL,
 revision INTEGER NOT NULL DEFAULT 1, version_id TEXT NOT NULL, trashed INTEGER NOT NULL DEFAULT 0 CHECK (trashed IN (0,1)), created_at BIGINT NOT NULL, updated_at BIGINT NOT NULL
);
CREATE INDEX lesson_sequences_folder_idx ON teacher_studio.lesson_sequences(folder_id,trashed);
CREATE TABLE teacher_studio.lesson_sequence_versions (
 id TEXT PRIMARY KEY, sequence_id TEXT NOT NULL REFERENCES teacher_studio.lesson_sequences(id), revision INTEGER NOT NULL,
 pack_text TEXT NOT NULL, pack_sha256 TEXT NOT NULL, pack_bytes INTEGER NOT NULL CHECK(pack_bytes>0 AND pack_bytes<=3145728), created_at BIGINT NOT NULL
);
CREATE INDEX lesson_sequence_versions_parent_idx ON teacher_studio.lesson_sequence_versions(sequence_id);
CREATE TABLE teacher_studio.lesson_sequence_requests (
 id TEXT PRIMARY KEY, fingerprint TEXT NOT NULL, sequence_id TEXT NOT NULL REFERENCES teacher_studio.lesson_sequences(id), version_id TEXT NOT NULL REFERENCES teacher_studio.lesson_sequence_versions(id), response_json TEXT NOT NULL, created_at BIGINT NOT NULL
);
  INSERT INTO teacher_studio.schema_migrations(version,sha256) VALUES(4,'43993c26b548ce7cbdf93ca35ba14198293fd52d676b7dcb2675f8d54a88ef47');
 END IF;
END $migration$;
COMMIT;
