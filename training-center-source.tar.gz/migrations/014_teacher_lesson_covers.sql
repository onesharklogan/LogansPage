-- REVIEW-ONLY: separate action-time authorization required before installation.
-- Nullable metadata only. No data backfill, rewritten Slide JSON, auth change, or new grants.
-- Existing table-level SELECT/INSERT/UPDATE grants already cover the new columns.
BEGIN;
SELECT pg_advisory_xact_lock(761142019);
DO $migration$
BEGIN
 IF current_user='teacher_studio_app' THEN RAISE EXCEPTION 'Migration requires separate schema owner'; END IF;
 IF NOT EXISTS(SELECT 1 FROM teacher_studio.schema_migrations WHERE version=6 AND sha256='e6fa50fd96ee85a393e7986ac4743995b1bdb44b5aeade4704d8f907bb89ca2a') THEN RAISE EXCEPTION 'Expected reviewed workspace schema is not installed'; END IF;
 IF EXISTS(SELECT 1 FROM teacher_studio.schema_migrations WHERE version=8 AND sha256<>'f57f0e16788ed5eef13f34a9cf41ce6f917722ec71e77958b62eb7a890a2ee2f') THEN RAISE EXCEPTION 'Migration checksum mismatch';
 ELSIF NOT EXISTS(SELECT 1 FROM teacher_studio.schema_migrations WHERE version=8) THEN
ALTER TABLE teacher_studio.folders ADD COLUMN cover_artwork TEXT CONSTRAINT folders_lesson_cover_artwork CHECK (cover_artwork IN ('ema-touch','trend','breakout','waves','fin','sailboat'));
ALTER TABLE teacher_studio.lesson_sequences ADD COLUMN cover_artwork TEXT CONSTRAINT sequences_lesson_cover_artwork CHECK (cover_artwork IN ('ema-touch','trend','breakout','waves','fin','sailboat'));
  INSERT INTO teacher_studio.schema_migrations(version,sha256) VALUES(8,'f57f0e16788ed5eef13f34a9cf41ce6f917722ec71e77958b62eb7a890a2ee2f');
 END IF;
END $migration$;
COMMIT;
