-- Apply after 003; existing restricted runtime role remains unchanged.
BEGIN;
REVOKE ALL ON teacher_studio.password_credentials, teacher_studio.enrollment_tokens FROM PUBLIC;
REVOKE ALL ON teacher_studio.password_credentials, teacher_studio.enrollment_tokens FROM teacher_studio_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON teacher_studio.password_credentials, teacher_studio.enrollment_tokens TO teacher_studio_app;
COMMIT;
