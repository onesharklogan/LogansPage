-- Additive account preferences only. Apply through the approved migration process.
-- Existing history, Lesson checkmarks, Trade Simulator settings and grants are untouched.
-- Run only as the approved learner schema owner on the verified target DB.
-- Existing-column/ledger conflicts fail closed; no roles, grants or policies change.
BEGIN;
ALTER TABLE learner_app.accounts
 ADD COLUMN use_exit_bracket boolean NOT NULL DEFAULT false,
 ADD COLUMN exit_bracket_distance numeric NOT NULL DEFAULT 5
 CONSTRAINT learner_exit_bracket_distance_check CHECK (exit_bracket_distance >= 0.25 AND exit_bracket_distance <= 100000 AND mod(exit_bracket_distance, 0.25) = 0);
INSERT INTO learner_app.schema_migrations(version,description) VALUES(3,'Market Direction symmetric exit bracket profile preferences');
COMMIT;
