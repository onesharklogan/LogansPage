-- Additive recoverable module trash. Never deletes slides, versions or save requests.
-- Checksum is SHA256 of the exact ALTER TABLE statement below; direct admin connection only.
BEGIN;
SELECT pg_advisory_xact_lock(761142019);
SET LOCAL search_path = teacher_studio;
DO $migration$
BEGIN
 IF EXISTS (SELECT 1 FROM schema_migrations WHERE version=3 AND sha256<>'66199d5b3289c6ec11831db18e8212368d48f41cd9071d0ed79f203c298e9086') THEN
  RAISE EXCEPTION 'Migration checksum mismatch; preserve existing data and original migration';
 ELSIF NOT EXISTS (SELECT 1 FROM schema_migrations WHERE version=3) THEN
  ALTER TABLE folders ADD COLUMN trashed INTEGER NOT NULL DEFAULT 0 CHECK (trashed IN (0,1));
  INSERT INTO schema_migrations(version,sha256) VALUES (3,'66199d5b3289c6ec11831db18e8212368d48f41cd9071d0ed79f203c298e9086');
 END IF;
END $migration$;
COMMIT;
