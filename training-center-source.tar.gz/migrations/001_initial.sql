-- Schema only: no credentials, user data, or paid resources. Direct admin connection only.
BEGIN;
SELECT pg_advisory_xact_lock(761142019);
CREATE SCHEMA IF NOT EXISTS teacher_studio;
REVOKE ALL ON SCHEMA teacher_studio FROM PUBLIC;
SET LOCAL search_path = teacher_studio;
CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, sha256 TEXT NOT NULL);
DO $migration$
BEGIN
 IF EXISTS (SELECT 1 FROM schema_migrations WHERE version=1 AND sha256<>'8e512e0551a2e5c5e64e484bb6bd66d6e7b4c7eda5d2155890b01290efc03cc1') THEN
  RAISE EXCEPTION 'Migration checksum mismatch; preserve existing data and original migration';
 ELSIF NOT EXISTS (SELECT 1 FROM schema_migrations WHERE version=1) THEN

CREATE TABLE app_config (key TEXT PRIMARY KEY, value TEXT NOT NULL, created_at BIGINT NOT NULL);
CREATE TABLE author_members (
 email TEXT PRIMARY KEY, google_subject TEXT UNIQUE, role TEXT NOT NULL CHECK (role IN ('admin','author')),
 active INTEGER NOT NULL CHECK (active IN (0,1)), last_event_id TEXT, created_at BIGINT NOT NULL, updated_at BIGINT NOT NULL
);
CREATE TABLE membership_audit (
 id TEXT PRIMARY KEY, actor_email TEXT NOT NULL, target_email TEXT NOT NULL,
 action TEXT NOT NULL, detail TEXT NOT NULL, created_at BIGINT NOT NULL
);
CREATE TABLE auth_tokens (
 token_hash TEXT PRIMARY KEY, kind TEXT NOT NULL CHECK (kind IN ('author','preauth')),
 expires_at BIGINT NOT NULL, created_at BIGINT NOT NULL, author_email TEXT, author_subject TEXT
);
CREATE INDEX auth_expiry_idx ON auth_tokens(expires_at);
CREATE TABLE rate_limits (bucket_key TEXT PRIMARY KEY, hits INTEGER NOT NULL, expires_at BIGINT NOT NULL);
CREATE INDEX rate_expiry_idx ON rate_limits(expires_at);
CREATE TABLE folders (
 id TEXT PRIMARY KEY, name TEXT NOT NULL, revision INTEGER NOT NULL DEFAULT 1,
 created_at BIGINT NOT NULL, updated_at BIGINT NOT NULL
);
CREATE TABLE lessons (
 id TEXT PRIMARY KEY, folder_id TEXT NOT NULL REFERENCES folders(id), title TEXT NOT NULL, purpose TEXT NOT NULL,
 revision INTEGER NOT NULL DEFAULT 1, version_id TEXT NOT NULL, trashed INTEGER NOT NULL DEFAULT 0 CHECK (trashed IN (0,1)),
 created_at BIGINT NOT NULL, updated_at BIGINT NOT NULL
);
CREATE INDEX lessons_folder_idx ON lessons(folder_id,trashed);
CREATE TABLE lesson_versions (
 id TEXT PRIMARY KEY, lesson_id TEXT NOT NULL REFERENCES lessons(id), revision INTEGER NOT NULL,
 source_lesson_id TEXT NOT NULL, session_id TEXT NOT NULL, session_date TEXT NOT NULL, session_sha256 TEXT NOT NULL,
 pack_text TEXT NOT NULL, pack_sha256 TEXT NOT NULL, pack_bytes INTEGER NOT NULL CHECK (pack_bytes > 0 AND pack_bytes <= 3145728),
 created_at BIGINT NOT NULL
);
CREATE INDEX versions_lesson_idx ON lesson_versions(lesson_id);
CREATE TABLE save_requests (
 id TEXT PRIMARY KEY, fingerprint TEXT NOT NULL, lesson_id TEXT NOT NULL REFERENCES lessons(id),
 version_id TEXT NOT NULL REFERENCES lesson_versions(id), response_json TEXT NOT NULL, created_at BIGINT NOT NULL
);

  INSERT INTO schema_migrations(version,sha256) VALUES (1,'8e512e0551a2e5c5e64e484bb6bd66d6e7b4c7eda5d2155890b01290efc03cc1');
 END IF;
END $migration$;
COMMIT;
