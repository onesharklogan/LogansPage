-- LOCAL DRAFT ONLY: separate action-time approval after exact 011 verification.
-- Existing restricted role only; no role creation, credential change, or DELETE privilege.
BEGIN;
REVOKE ALL ON teacher_studio.teacher_slide_registry, teacher_studio.teacher_slide_versions, teacher_studio.teacher_lesson_composition_versions, teacher_studio.teacher_workspace_requests FROM PUBLIC;
REVOKE ALL ON teacher_studio.teacher_slide_registry, teacher_studio.teacher_slide_versions, teacher_studio.teacher_lesson_composition_versions, teacher_studio.teacher_workspace_requests FROM teacher_studio_app;
GRANT SELECT, INSERT ON teacher_studio.teacher_slide_registry TO teacher_studio_app;
GRANT UPDATE (lesson_folder_id,lesson_sequence_id,revision,version_id,version_storage,trashed,updated_at) ON teacher_studio.teacher_slide_registry TO teacher_studio_app;
GRANT SELECT, INSERT ON teacher_studio.teacher_slide_versions, teacher_studio.teacher_lesson_composition_versions, teacher_studio.teacher_workspace_requests TO teacher_studio_app;
COMMIT;
