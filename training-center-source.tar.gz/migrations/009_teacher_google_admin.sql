-- LOCAL CANDIDATE ONLY: production requires separately approved security storage setup.
-- Additive two-table schema; no identity/member rows or existing content are changed.
BEGIN;
SELECT pg_advisory_xact_lock(761142019);
DO $migration$
BEGIN
 IF EXISTS(SELECT 1 FROM teacher_studio.schema_migrations WHERE version=5 AND sha256<>'0f417c3e246d080495fa4d295f89be826184658439ec53efa9274aa903d42111') THEN
  RAISE EXCEPTION 'Migration checksum mismatch';
 ELSIF NOT EXISTS(SELECT 1 FROM teacher_studio.schema_migrations WHERE version=5) THEN
CREATE TABLE teacher_studio.author_google_identities (
 member_email text PRIMARY KEY REFERENCES teacher_studio.author_members(email),
 issuer text NOT NULL CHECK(issuer='https://ep-aged-thunder-ak033iip.neonauth.c-3.us-west-2.aws.neon.tech/teacher_studio/auth'),
 google_subject text NOT NULL CHECK(length(google_subject) BETWEEN 1 AND 256 AND google_subject !~ '[[:cntrl:]]'),
 created_at bigint NOT NULL CHECK(created_at>0),
 binding_event_id text NOT NULL CHECK(length(binding_event_id) BETWEEN 1 AND 128),
 UNIQUE(issuer,google_subject)
);
CREATE TABLE teacher_studio.admin_invitations (
 id text PRIMARY KEY CHECK(id ~ '^[a-f0-9]{32}$'),
 token_hash text NOT NULL UNIQUE CHECK(token_hash ~ '^[a-f0-9]{64}$'),
 recipient_email text NOT NULL CHECK(length(recipient_email) BETWEEN 3 AND 254 AND recipient_email=lower(trim(recipient_email))),
 role text NOT NULL CHECK(role='admin'),
 creator_email text NOT NULL REFERENCES teacher_studio.author_members(email),
 creator_subject text NOT NULL, creator_event_id text,
 created_at bigint NOT NULL CHECK(created_at>0),
 expires_at bigint NOT NULL CHECK(expires_at>created_at AND expires_at<=created_at+3600000),
 revoked_at bigint, used_at bigint, used_subject text, used_event_id text,
 CHECK(revoked_at IS NULL OR revoked_at>=created_at),
 CHECK(used_at IS NULL OR (used_at>=created_at AND used_at<expires_at)),
 CHECK((used_at IS NULL AND used_subject IS NULL AND used_event_id IS NULL) OR (used_at IS NOT NULL AND used_subject IS NOT NULL AND used_event_id IS NOT NULL)),
 CHECK(revoked_at IS NULL OR used_at IS NULL)
);
CREATE INDEX admin_invitations_recipient_idx ON teacher_studio.admin_invitations(recipient_email,expires_at);
  INSERT INTO teacher_studio.schema_migrations(version,sha256) VALUES(5,'0f417c3e246d080495fa4d295f89be826184658439ec53efa9274aa903d42111');
 END IF;
END $migration$;
REVOKE ALL ON teacher_studio.author_google_identities, teacher_studio.admin_invitations FROM PUBLIC;
COMMIT;
