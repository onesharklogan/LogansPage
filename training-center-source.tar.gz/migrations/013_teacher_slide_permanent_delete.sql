-- REVIEW-ONLY. Separate action-time approval required before installation or enabling.
-- Installing this function does NOT delete any content. No direct DELETE privileges are granted.
BEGIN;
SELECT pg_advisory_xact_lock(761142019);
DO $review$ BEGIN
 IF current_user='teacher_studio_app' THEN RAISE EXCEPTION 'Migration requires separate schema owner'; END IF;
 IF to_regprocedure('teacher_studio.permanently_delete_slide(text,integer,integer,text,text,text,text)') IS NOT NULL AND NOT EXISTS(SELECT 1 FROM teacher_studio.schema_migrations WHERE version=7) THEN RAISE EXCEPTION 'Unexpected preexisting deletion function; review before installation'; END IF;
 IF NOT EXISTS(SELECT 1 FROM teacher_studio.schema_migrations WHERE version=6 AND sha256='e6fa50fd96ee85a393e7986ac4743995b1bdb44b5aeade4704d8f907bb89ca2a') THEN RAISE EXCEPTION 'Expected reviewed workspace schema is not installed'; END IF;
 IF EXISTS(SELECT 1 FROM teacher_studio.schema_migrations WHERE version=7 AND sha256<>'bbacc6299dcefda2600aa0f463e40ec59c86a0058fb88d4e78078a37dfbf7193') THEN RAISE EXCEPTION 'Migration checksum mismatch'; END IF;
END $review$;
CREATE OR REPLACE FUNCTION teacher_studio.permanently_delete_slide(
 p_key text,p_revision integer,p_lesson_revision integer,p_title text,p_version text,p_token text,p_actor text
) RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog,pg_temp AS $delete_slide$
DECLARE
 r teacher_studio.teacher_slide_registry%ROWTYPE;
 l teacher_studio.lessons%ROWTYPE;
 s teacher_studio.lesson_sequences%ROWTYPE;
 item record; retired_count bigint; raw text; next_raw text; checksum text; bytes integer;
 fields text[]; source_folder text; source_sequence text; registry_id text;
 storage text; version_id text; actual_revision integer; actual_lesson_revision integer; current_title text;
BEGIN
 PERFORM pg_catalog.pg_advisory_xact_lock(761142019);
 IF p_key IS NULL OR p_revision IS NULL OR p_revision<1 OR p_title IS NULL OR p_version IS NULL OR p_actor IS NULL OR p_token IS NULL THEN
  RAISE EXCEPTION 'Confirmed Slide identity required' USING ERRCODE='P0001';
 END IF;
 IF NOT EXISTS(SELECT 1 FROM teacher_studio.author_members m JOIN teacher_studio.auth_tokens t ON t.author_email=m.email AND t.author_subject=m.google_subject
  WHERE m.active=1 AND m.google_subject=p_actor AND t.token_hash=p_token AND t.kind='author' AND t.expires_at>floor(extract(epoch FROM clock_timestamp())*1000)) THEN
  RAISE EXCEPTION 'Active author access required' USING ERRCODE='42501';
 END IF;
 fields:=string_to_array(p_key,':');
 IF NOT ((array_length(fields,1)=2 AND fields[1] IN('slide','legacy')) OR (array_length(fields,1)=3 AND fields[1]='sequence'))
  OR fields[2]!~'^[A-Za-z0-9_-]{1,90}$' OR (fields[1]='sequence' AND fields[3]!~'^[A-Za-z0-9_-]{1,90}$') THEN
  RAISE EXCEPTION 'Invalid Slide identity' USING ERRCODE='P0001';
 END IF;
 SELECT * INTO r FROM teacher_studio.teacher_slide_registry WHERE origin_key=p_key;
 IF FOUND THEN
  IF r.trashed<>0 THEN RAISE EXCEPTION 'Existing Slide Trash is protected' USING ERRCODE='P0001'; END IF;
  registry_id:=r.id; source_folder:=r.lesson_folder_id; source_sequence:=r.lesson_sequence_id;
  storage:=r.version_storage; version_id:=r.version_id; actual_revision:=r.revision;
 ELSIF fields[1]='legacy' THEN
  SELECT * INTO l FROM teacher_studio.lessons WHERE id=fields[2];
  IF NOT FOUND OR l.trashed<>0 THEN RAISE EXCEPTION 'Active Slide not found' USING ERRCODE='P0001'; END IF;
  storage:='legacy'; version_id:=l.version_id; actual_revision:=l.revision; source_folder:=l.folder_id;
 ELSIF fields[1]='sequence' THEN
  SELECT * INTO s FROM teacher_studio.lesson_sequences WHERE id=fields[2];
  IF NOT FOUND THEN RAISE EXCEPTION 'Active Slide not found' USING ERRCODE='P0001'; END IF;
  storage:='sequence'; version_id:=s.version_id; actual_revision:=s.revision; source_sequence:=s.id;
 ELSE RAISE EXCEPTION 'Active Slide not found' USING ERRCODE='P0001';
 END IF;
 IF actual_revision<>p_revision OR version_id<>p_version THEN RAISE EXCEPTION 'Slide changed' USING ERRCODE='P0001'; END IF;
 IF source_folder IS NOT NULL THEN SELECT revision INTO actual_lesson_revision FROM teacher_studio.folders WHERE id=source_folder;
 ELSIF source_sequence IS NOT NULL THEN SELECT revision INTO actual_lesson_revision FROM teacher_studio.lesson_sequences WHERE id=source_sequence;
 END IF;
 IF actual_lesson_revision IS DISTINCT FROM p_lesson_revision THEN RAISE EXCEPTION 'Lesson changed' USING ERRCODE='P0001'; END IF;
 IF storage='workspace' THEN
  SELECT content_text,content_sha256,content_bytes INTO raw,checksum,bytes FROM teacher_studio.teacher_slide_versions WHERE id=version_id AND slide_id=registry_id;
 ELSIF storage='legacy' AND fields[1]='legacy' THEN
  SELECT pack_text,pack_sha256,pack_bytes INTO raw,checksum,bytes FROM teacher_studio.lesson_versions WHERE id=version_id AND lesson_id=fields[2];
 ELSIF storage='sequence' AND fields[1]='sequence' THEN
  SELECT pack_text,pack_sha256,pack_bytes INTO raw,checksum,bytes FROM teacher_studio.lesson_sequence_versions WHERE id=version_id AND sequence_id=fields[2];
 ELSE RAISE EXCEPTION 'Invalid Slide source' USING ERRCODE='P0001';
 END IF;
 IF raw IS NULL OR octet_length(raw)<>bytes OR encode(sha256(convert_to(raw,'UTF8')),'hex')<>checksum THEN RAISE EXCEPTION 'Slide integrity check failed' USING ERRCODE='P0001'; END IF;
 IF storage='workspace' THEN current_title:=raw::json #>> '{slide,title}';
 ELSIF storage='legacy' THEN current_title:=raw::json #>> '{lessons,0,title}';
 ELSE SELECT v->>'title' INTO current_title FROM json_array_elements(raw::json->'slides') v WHERE v->>'id'=fields[3];
 END IF;
 IF current_title IS DISTINCT FROM p_title THEN RAISE EXCEPTION 'Slide confirmation changed' USING ERRCODE='P0001'; END IF;

 retired_count:=0;
 IF fields[1]='legacy' THEN SELECT count(*) INTO retired_count FROM teacher_studio.save_requests WHERE lesson_id=fields[2]; END IF;
 IF (SELECT count(*) FROM teacher_studio.teacher_workspace_requests)+1+retired_count>400000 THEN
  RAISE EXCEPTION 'Operation receipt capacity reached' USING ERRCODE='P0001';
 END IF;
 -- Remove ONLY this member from shared packs. JSON item text preserves every sibling,
 -- its order, original identifiers and historical version. No shared chart/media delete.
 IF fields[1]='sequence' THEN
  FOR item IN SELECT * FROM teacher_studio.lesson_sequence_versions v WHERE v.sequence_id=fields[2] LOOP
   IF octet_length(item.pack_text)<>item.pack_bytes OR encode(sha256(convert_to(item.pack_text,'UTF8')),'hex')<>item.pack_sha256
    OR item.pack_text::json->>'format' IS DISTINCT FROM 'price-action-lesson-sequence' OR item.pack_text::json->>'version' IS DISTINCT FROM '1'
    OR json_typeof(item.pack_text::json->'slides') IS DISTINCT FROM 'array' OR json_typeof(item.pack_text::json->'title') IS DISTINCT FROM 'string'
    OR EXISTS(SELECT 1 FROM json_object_keys(item.pack_text::json) k WHERE k NOT IN('format','version','title','slides'))
    OR EXISTS(SELECT 1 FROM json_array_elements(item.pack_text::json->'slides') x WHERE json_typeof(x) IS DISTINCT FROM 'object' OR x->>'id' IS NULL OR x->>'id'!~'^[A-Za-z0-9_-]{1,90}$')
    OR (SELECT count(*)<>count(DISTINCT x->>'id') FROM json_array_elements(item.pack_text::json->'slides') x) THEN
    RAISE EXCEPTION 'Historical Slide integrity check failed' USING ERRCODE='P0001';
   END IF;
   IF NOT EXISTS(SELECT 1 FROM json_array_elements(item.pack_text::json->'slides') x WHERE x->>'id'=fields[3]) THEN CONTINUE; END IF;
   SELECT '{"format":"price-action-lesson-sequence","version":1,"title":'||(item.pack_text::json->'title')::text||',"slides":['||coalesce(string_agg(x::text,',' ORDER BY position),'')||']}' INTO next_raw
    FROM json_array_elements(item.pack_text::json->'slides') WITH ORDINALITY AS entries(x,position) WHERE x->>'id' IS DISTINCT FROM fields[3];
   UPDATE teacher_studio.lesson_sequence_versions SET pack_text=next_raw,pack_sha256=encode(sha256(convert_to(next_raw,'UTF8')),'hex'),pack_bytes=octet_length(next_raw) WHERE id=item.id;
  END LOOP;
 END IF;
 -- Historical Lesson snapshots contain references only; retain every other member.
 FOR item IN SELECT * FROM teacher_studio.teacher_lesson_composition_versions c
  WHERE EXISTS(SELECT 1 FROM json_array_elements(c.composition_text::json->'members') x WHERE x->>'key'=p_key) LOOP
  IF octet_length(item.composition_text)<>item.composition_bytes OR encode(sha256(convert_to(item.composition_text,'UTF8')),'hex')<>item.composition_sha256
   OR item.composition_text::json->>'format' IS DISTINCT FROM 'price-action-lesson-composition' OR item.composition_text::json->>'version' IS DISTINCT FROM '1'
   OR json_typeof(item.composition_text::json->'members') IS DISTINCT FROM 'array' OR json_typeof(item.composition_text::json->'title') IS DISTINCT FROM 'string'
   OR EXISTS(SELECT 1 FROM json_object_keys(item.composition_text::json) k WHERE k NOT IN('format','version','title','members'))
   OR EXISTS(SELECT 1 FROM json_array_elements(item.composition_text::json->'members') x WHERE json_typeof(x) IS DISTINCT FROM 'object' OR x->>'key' IS NULL)
   OR (SELECT count(*)<>count(DISTINCT x->>'key') FROM json_array_elements(item.composition_text::json->'members') x) THEN
   RAISE EXCEPTION 'Lesson history integrity check failed' USING ERRCODE='P0001';
  END IF;
  SELECT '{"format":"price-action-lesson-composition","version":1,"title":'||(item.composition_text::json->'title')::text||',"members":['||coalesce(string_agg(x::text,',' ORDER BY position),'')||']}' INTO next_raw
   FROM json_array_elements(item.composition_text::json->'members') WITH ORDINALITY AS entries(x,position) WHERE x->>'key' IS DISTINCT FROM p_key;
  UPDATE teacher_studio.teacher_lesson_composition_versions SET composition_text=next_raw,composition_sha256=encode(sha256(convert_to(next_raw,'UTF8')),'hex'),composition_bytes=octet_length(next_raw) WHERE id=item.id;
 END LOOP;
 -- Retain content-free recovery/audit markers so replay cannot recreate a deleted save.
 UPDATE teacher_studio.teacher_workspace_requests SET response_json=json_build_object('version',1,'requestId',id,'op',response_json::json->>'op','retired',true,'deleted',json_build_object('key',p_key,'permanent',true))::text
  WHERE response_json::json #>> '{slide,key}'=p_key;
 IF fields[1]='legacy' THEN
  INSERT INTO teacher_studio.teacher_workspace_requests(id,fingerprint,response_json,actor_member_key,created_at)
   SELECT 'legacy-save:'||id,fingerprint,json_build_object('retired',true,'deleted',json_build_object('key',p_key,'permanent',true))::text,p_actor,floor(extract(epoch FROM clock_timestamp())*1000)
   FROM teacher_studio.save_requests WHERE lesson_id=fields[2];
  DELETE FROM teacher_studio.save_requests WHERE lesson_id=fields[2];
 END IF;
 IF registry_id IS NOT NULL THEN
  DELETE FROM teacher_studio.teacher_slide_versions WHERE slide_id=registry_id;
  DELETE FROM teacher_studio.teacher_slide_registry WHERE id=registry_id;
 END IF;
 IF fields[1]='legacy' THEN
  DELETE FROM teacher_studio.lesson_versions WHERE lesson_id=fields[2];
  DELETE FROM teacher_studio.lessons WHERE id=fields[2];
 END IF;
 RETURN true;
END;
$delete_slide$;
REVOKE ALL ON FUNCTION teacher_studio.permanently_delete_slide(text,integer,integer,text,text,text,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION teacher_studio.permanently_delete_slide(text,integer,integer,text,text,text,text) TO teacher_studio_app;
INSERT INTO teacher_studio.schema_migrations(version,sha256) VALUES(7,'bbacc6299dcefda2600aa0f463e40ec59c86a0058fb88d4e78078a37dfbf7193') ON CONFLICT(version) DO NOTHING;
COMMIT;
