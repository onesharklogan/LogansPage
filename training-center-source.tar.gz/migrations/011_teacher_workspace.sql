-- LOCAL DRAFT ONLY: exact action-time migration approval and recovery verification required.
-- Additive tables/indexes only. No existing content, IDs, versions, credentials or memberships are converted.
BEGIN;
SELECT pg_advisory_xact_lock(761142019);
DO $migration$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM teacher_studio.schema_migrations WHERE version=5 AND sha256='0f417c3e246d080495fa4d295f89be826184658439ec53efa9274aa903d42111') THEN
  RAISE EXCEPTION 'Expected reviewed Teacher authentication schema is not installed';
 END IF;
 IF EXISTS(SELECT 1 FROM teacher_studio.schema_migrations WHERE version=6 AND sha256<>'e6fa50fd96ee85a393e7986ac4743995b1bdb44b5aeade4704d8f907bb89ca2a') THEN
  RAISE EXCEPTION 'Migration checksum mismatch';
 ELSIF NOT EXISTS(SELECT 1 FROM teacher_studio.schema_migrations WHERE version=6) THEN
CREATE TABLE teacher_studio.teacher_slide_registry (
 id TEXT PRIMARY KEY, origin_key TEXT NOT NULL UNIQUE,
 origin_lesson_id TEXT REFERENCES teacher_studio.lessons(id),
 origin_sequence_id TEXT REFERENCES teacher_studio.lesson_sequences(id), origin_slide_id TEXT,
 lesson_folder_id TEXT REFERENCES teacher_studio.folders(id),
 lesson_sequence_id TEXT REFERENCES teacher_studio.lesson_sequences(id),
 revision INTEGER NOT NULL CHECK(revision>0), version_id TEXT NOT NULL,
 version_storage TEXT NOT NULL CHECK(version_storage IN('legacy','sequence','workspace')),
 trashed INTEGER NOT NULL DEFAULT 0 CHECK(trashed IN(0,1)),
 created_at BIGINT NOT NULL, updated_at BIGINT NOT NULL,
 CHECK(NOT(lesson_folder_id IS NOT NULL AND lesson_sequence_id IS NOT NULL)),
 CHECK((origin_lesson_id IS NOT NULL AND origin_key='legacy:'||origin_lesson_id) OR (origin_sequence_id IS NOT NULL AND origin_key='sequence:'||origin_sequence_id||':'||origin_slide_id) OR (origin_lesson_id IS NULL AND origin_sequence_id IS NULL AND origin_key='slide:'||id)),
 CHECK((origin_lesson_id IS NULL AND origin_sequence_id IS NULL AND origin_slide_id IS NULL) OR
       (origin_lesson_id IS NOT NULL AND origin_sequence_id IS NULL AND origin_slide_id IS NULL) OR
       (origin_lesson_id IS NULL AND origin_sequence_id IS NOT NULL AND origin_slide_id IS NOT NULL))
);
CREATE UNIQUE INDEX teacher_slides_legacy_origin_idx ON teacher_studio.teacher_slide_registry(origin_lesson_id) WHERE origin_lesson_id IS NOT NULL;
CREATE UNIQUE INDEX teacher_slides_sequence_origin_idx ON teacher_studio.teacher_slide_registry(origin_sequence_id,origin_slide_id) WHERE origin_sequence_id IS NOT NULL;
CREATE INDEX teacher_slides_folder_idx ON teacher_studio.teacher_slide_registry(lesson_folder_id,trashed,id);
CREATE INDEX teacher_slides_sequence_idx ON teacher_studio.teacher_slide_registry(lesson_sequence_id,trashed,id);
CREATE TABLE teacher_studio.teacher_slide_versions (
 id TEXT PRIMARY KEY, slide_id TEXT NOT NULL REFERENCES teacher_studio.teacher_slide_registry(id),
 revision INTEGER NOT NULL CHECK(revision>0), content_text TEXT NOT NULL,
 content_sha256 TEXT NOT NULL, content_bytes INTEGER NOT NULL CHECK(content_bytes>0 AND content_bytes<=3145728),
 created_at BIGINT NOT NULL, UNIQUE(slide_id,revision)
);
CREATE INDEX teacher_slide_versions_parent_idx ON teacher_studio.teacher_slide_versions(slide_id);
CREATE TABLE teacher_studio.teacher_lesson_composition_versions (
 id TEXT PRIMARY KEY, folder_id TEXT REFERENCES teacher_studio.folders(id),
 sequence_id TEXT REFERENCES teacher_studio.lesson_sequences(id),
 revision INTEGER NOT NULL CHECK(revision>0), composition_text TEXT NOT NULL,
 composition_sha256 TEXT NOT NULL, composition_bytes INTEGER NOT NULL CHECK(composition_bytes>0 AND composition_bytes<=262144),
 created_at BIGINT NOT NULL,
 CHECK((folder_id IS NULL)<>(sequence_id IS NULL))
);
CREATE UNIQUE INDEX teacher_compositions_folder_revision_idx ON teacher_studio.teacher_lesson_composition_versions(folder_id,revision) WHERE folder_id IS NOT NULL;
CREATE UNIQUE INDEX teacher_compositions_sequence_revision_idx ON teacher_studio.teacher_lesson_composition_versions(sequence_id,revision) WHERE sequence_id IS NOT NULL;
CREATE TABLE teacher_studio.teacher_workspace_requests (
 id TEXT PRIMARY KEY, fingerprint TEXT NOT NULL, response_json TEXT NOT NULL,
 actor_member_key TEXT NOT NULL, created_at BIGINT NOT NULL
);
  INSERT INTO teacher_studio.schema_migrations(version,sha256) VALUES(6,'e6fa50fd96ee85a393e7986ac4743995b1bdb44b5aeade4704d8f907bb89ca2a');
 END IF;
END $migration$;
COMMIT;
