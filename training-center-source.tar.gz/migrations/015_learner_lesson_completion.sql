-- REVIEWED APPLICATION REQUIRED. Do not run automatically at app startup.
-- Additive account data only; no roles, grants, policies, teacher or Auth data change.
-- Existing SELECT/UPDATE ON learner_app.accounts covers this column.
-- Deliberately fail closed on existing column or ledger conflict; inspect catalog first.
-- Run only as the separately approved learner schema owner on the verified target DB.
BEGIN;
ALTER TABLE learner_app.accounts ADD COLUMN lesson_completions jsonb NOT NULL DEFAULT '{}'::jsonb
 CONSTRAINT learner_accounts_lesson_completions_check CHECK (jsonb_typeof(lesson_completions) = 'object' AND octet_length(lesson_completions::text) <= 600000);
INSERT INTO learner_app.schema_migrations(version,description) VALUES(2,'Account-scoped Lesson completion marks, independent of simulator history');
COMMIT;
