-- Apply only after an authorized administrator creates the SQL role teacher_studio_app.
-- That role must be LOGIN, NOSUPERUSER, NOCREATEDB, NOCREATEROLE, NOINHERIT,
-- NOREPLICATION, NOBYPASSRLS and NOT a member of neon_superuser or any owner role.
-- This file does not create, print, or rotate any credential.
BEGIN;
REVOKE ALL ON SCHEMA teacher_studio FROM PUBLIC;
REVOKE ALL ON ALL TABLES IN SCHEMA teacher_studio FROM PUBLIC;
REVOKE ALL ON SCHEMA teacher_studio FROM teacher_studio_app;
REVOKE ALL ON ALL TABLES IN SCHEMA teacher_studio FROM teacher_studio_app;
GRANT USAGE ON SCHEMA teacher_studio TO teacher_studio_app;
GRANT SELECT, INSERT ON teacher_studio.app_config TO teacher_studio_app;
GRANT SELECT, INSERT, UPDATE ON teacher_studio.author_members TO teacher_studio_app;
GRANT INSERT ON teacher_studio.membership_audit TO teacher_studio_app;
GRANT SELECT, INSERT, DELETE ON teacher_studio.auth_tokens TO teacher_studio_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON teacher_studio.rate_limits TO teacher_studio_app;
GRANT SELECT, INSERT, UPDATE ON teacher_studio.folders, teacher_studio.lessons TO teacher_studio_app;
GRANT SELECT, INSERT ON teacher_studio.lesson_versions, teacher_studio.save_requests TO teacher_studio_app;
COMMIT;
