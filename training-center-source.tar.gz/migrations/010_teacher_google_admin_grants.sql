-- LOCAL CANDIDATE ONLY. Apply only after exact two-table/grant setup approval and 009.
-- Existing runtime only. No role, login, credential, membership, Auth or learner privileges.
BEGIN;
REVOKE ALL ON teacher_studio.author_google_identities, teacher_studio.admin_invitations FROM PUBLIC;
REVOKE ALL ON teacher_studio.author_google_identities, teacher_studio.admin_invitations FROM teacher_studio_app;
GRANT SELECT, INSERT ON teacher_studio.author_google_identities TO teacher_studio_app;
GRANT SELECT, INSERT ON teacher_studio.admin_invitations TO teacher_studio_app;
GRANT UPDATE (revoked_at, used_at, used_subject, used_event_id) ON teacher_studio.admin_invitations TO teacher_studio_app;
COMMIT;
