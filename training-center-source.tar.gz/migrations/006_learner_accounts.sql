-- DRAFT ONLY. No production application, credentials, grants, or teacher schema changes authorized.
-- Dedicated learner runtime role/grants must be reviewed and provisioned separately.
BEGIN;
CREATE SCHEMA IF NOT EXISTS learner_app;
REVOKE ALL ON SCHEMA learner_app FROM PUBLIC;
CREATE TABLE IF NOT EXISTS learner_app.schema_migrations(version integer PRIMARY KEY, description text NOT NULL);
CREATE TABLE IF NOT EXISTS learner_app.accounts(
 id uuid PRIMARY KEY, provider_issuer text NOT NULL, provider_subject text NOT NULL,
 display_name text NOT NULL CHECK(length(display_name) BETWEEN 1 AND 128),
 equal_tp_sl boolean NOT NULL DEFAULT false,
 generation integer NOT NULL DEFAULT 1 CHECK(generation>0),
 attempt_count integer NOT NULL DEFAULT 0 CHECK(attempt_count BETWEEN 0 AND 1000),
 storage_bytes integer NOT NULL DEFAULT 0 CHECK(storage_bytes BETWEEN 0 AND 8388608),
 created_at bigint NOT NULL, UNIQUE(provider_issuer,provider_subject)
);
CREATE TABLE IF NOT EXISTS learner_app.sessions(
 session_tag text PRIMARY KEY CHECK(session_tag ~ '^[a-f0-9]{64}$'),
 account_id uuid NOT NULL REFERENCES learner_app.accounts(id),
 expires_at bigint NOT NULL, revoked boolean NOT NULL DEFAULT false, created_at bigint NOT NULL
);
CREATE INDEX IF NOT EXISTS learner_sessions_account ON learner_app.sessions(account_id);
CREATE TABLE IF NOT EXISTS learner_app.attempts(
 account_id uuid NOT NULL REFERENCES learner_app.accounts(id), generation integer NOT NULL,
 attempt_id uuid NOT NULL, module text NOT NULL CHECK(module IN ('trade-simulator','market-direction')),
 payload jsonb NOT NULL, summary jsonb NOT NULL, fingerprint text NOT NULL,
 -- Total canonical payload + recomputed summary bytes; no duplicated candle arrays.
 payload_bytes integer NOT NULL CHECK(payload_bytes BETWEEN 1 AND 61440), saved_at bigint NOT NULL,
 PRIMARY KEY(account_id,generation,attempt_id)
);
CREATE INDEX IF NOT EXISTS learner_attempts_page ON learner_app.attempts(account_id,generation,saved_at DESC,attempt_id DESC);
CREATE TABLE IF NOT EXISTS learner_app.reset_intents(
 token_hash text PRIMARY KEY, account_id uuid NOT NULL REFERENCES learner_app.accounts(id),
 session_tag text NOT NULL REFERENCES learner_app.sessions(session_tag), generation integer NOT NULL,
 expires_at bigint NOT NULL, UNIQUE(account_id,session_tag)
);
CREATE TABLE IF NOT EXISTS learner_app.reset_receipts(
 account_id uuid NOT NULL REFERENCES learner_app.accounts(id), request_id uuid NOT NULL,
 fingerprint text NOT NULL, response jsonb NOT NULL, expires_at bigint NOT NULL,
 PRIMARY KEY(account_id,request_id)
);
REVOKE ALL ON ALL TABLES IN SCHEMA learner_app FROM PUBLIC;
INSERT INTO learner_app.schema_migrations(version,description) VALUES(1,'Isolated provider-independent learner practice storage draft') ON CONFLICT(version) DO NOTHING;
COMMIT;
