-- REVIEW ONLY. Requires separately authorized schema-owner installation.
-- Adds only an empty publication registry. Every existing Lesson remains a draft.
BEGIN;
SELECT pg_advisory_xact_lock(761142019);
CREATE TABLE IF NOT EXISTS teacher_studio.lesson_publications (
 lesson_key TEXT PRIMARY KEY CHECK(lesson_key ~ '^(folder|sequence):[A-Za-z0-9_-]{1,90}$'),
 published_revision INTEGER CHECK(published_revision>0),
 parent_revision INTEGER CHECK(parent_revision>0),
 updated_at BIGINT NOT NULL,
 CHECK(lesson_key NOT LIKE 'folder:%' OR parent_revision IS NULL)
);
REVOKE ALL ON teacher_studio.lesson_publications FROM PUBLIC;
GRANT SELECT,INSERT,UPDATE ON teacher_studio.lesson_publications TO teacher_studio_app;
COMMIT;
