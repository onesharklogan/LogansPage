-- Additive password authentication only. Does not seed tokens, passwords, or identities.
BEGIN;
SELECT pg_advisory_xact_lock(761142019);
SET LOCAL search_path = teacher_studio;
DO $migration$
BEGIN
 IF EXISTS (SELECT 1 FROM schema_migrations WHERE version=2 AND sha256<>'12359ab1f9681157e689433ed470c0a0bcef54b071f09e169afebffa7ccd76bf') THEN
  RAISE EXCEPTION 'Migration checksum mismatch; preserve existing data and original migration';
 ELSIF NOT EXISTS (SELECT 1 FROM schema_migrations WHERE version=2) THEN

CREATE TABLE password_credentials (
 email TEXT PRIMARY KEY REFERENCES author_members(email), password_salt TEXT NOT NULL,
 password_hash TEXT NOT NULL, cost_n INTEGER NOT NULL, cost_r INTEGER NOT NULL, cost_p INTEGER NOT NULL,
 last_enrollment_hash TEXT NOT NULL, created_at BIGINT NOT NULL, updated_at BIGINT NOT NULL
);
CREATE TABLE enrollment_tokens (
 token_hash TEXT PRIMARY KEY, email TEXT NOT NULL REFERENCES author_members(email),
 expires_at BIGINT NOT NULL, created_at BIGINT NOT NULL, created_by TEXT NOT NULL,
 used_at BIGINT, used_event_id TEXT
);
CREATE INDEX enrollment_email_idx ON enrollment_tokens(email);
CREATE INDEX enrollment_expiry_idx ON enrollment_tokens(expires_at);

 INSERT INTO schema_migrations(version,sha256) VALUES (2,'12359ab1f9681157e689433ed470c0a0bcef54b071f09e169afebffa7ccd76bf');
 END IF;
END $migration$;
COMMIT;
