-- DRAFT: apply only after separate approval and recovery verification, following 007.
-- Existing restricted role only. No role, credential, membership or auth change.
BEGIN;
REVOKE ALL ON teacher_studio.lesson_sequences, teacher_studio.lesson_sequence_versions, teacher_studio.lesson_sequence_requests FROM PUBLIC;
REVOKE ALL ON teacher_studio.lesson_sequences, teacher_studio.lesson_sequence_versions, teacher_studio.lesson_sequence_requests FROM teacher_studio_app;
GRANT SELECT, INSERT, UPDATE ON teacher_studio.lesson_sequences TO teacher_studio_app;
GRANT SELECT, INSERT ON teacher_studio.lesson_sequence_versions, teacher_studio.lesson_sequence_requests TO teacher_studio_app;
COMMIT;
