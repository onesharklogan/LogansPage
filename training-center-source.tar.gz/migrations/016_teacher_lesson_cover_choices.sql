-- REVIEW-ONLY: apply only after reviewed isolated validation and production coordination.
-- Expand two CHECK constraints only; no data updates, defaults, grants or security changes.
-- Install before deploying UI choices; rollback retains this superset and disables new UI choices.
BEGIN;
SET LOCAL lock_timeout='5s';
SET LOCAL statement_timeout='30s';
SET LOCAL search_path=pg_catalog,pg_temp;
SELECT pg_advisory_xact_lock(761142019);
LOCK TABLE teacher_studio.folders,teacher_studio.lesson_sequences IN ACCESS EXCLUSIVE MODE;
DO $migration$
DECLARE expected_definition text; found_count integer; already_installed boolean;
BEGIN
 IF session_user<>current_user OR EXISTS(SELECT 1 FROM pg_class WHERE oid IN('teacher_studio.folders'::regclass,'teacher_studio.lesson_sequences'::regclass) AND relowner<>(SELECT oid FROM pg_roles WHERE rolname=current_user)) THEN RAISE EXCEPTION 'Separate actual schema owner login required'; END IF;
 IF NOT EXISTS(SELECT 1 FROM teacher_studio.schema_migrations WHERE version=8 AND sha256='f57f0e16788ed5eef13f34a9cf41ce6f917722ec71e77958b62eb7a890a2ee2f') THEN RAISE EXCEPTION 'Exact reviewed cover014 ledger required'; END IF;
 IF EXISTS(SELECT 1 FROM teacher_studio.schema_migrations WHERE version=9 AND sha256<>'5d9e3cbf402f9fb1da6f71ad330966c551c1532e23d3b888820aa781fcf2e084') THEN RAISE EXCEPTION 'Cover016 ledger checksum mismatch'; END IF;
 SELECT EXISTS(SELECT 1 FROM teacher_studio.schema_migrations WHERE version=9) INTO already_installed;
 expected_definition:=CASE WHEN already_installed THEN 'CHECK ((cover_artwork = ANY (ARRAY[''ema-touch''::text, ''trend''::text, ''breakout''::text, ''waves''::text, ''fin''::text, ''sailboat''::text, ''glacier''::text, ''lavender''::text, ''mint''::text, ''horizon''::text, ''graphite''::text])))' ELSE 'CHECK ((cover_artwork = ANY (ARRAY[''ema-touch''::text, ''trend''::text, ''breakout''::text, ''waves''::text, ''fin''::text, ''sailboat''::text])))' END;
 SELECT count(*) INTO found_count FROM pg_attribute a WHERE a.attrelid IN('teacher_studio.folders'::regclass,'teacher_studio.lesson_sequences'::regclass) AND a.attname='cover_artwork' AND a.atttypid='text'::regtype AND NOT a.attnotnull AND NOT a.atthasdef AND a.attidentity='' AND a.attgenerated='' AND NOT a.attisdropped;
 IF found_count<>2 THEN RAISE EXCEPTION 'Exact nullable text cover014 columns required'; END IF;
 SELECT count(*) INTO found_count FROM pg_constraint WHERE (conrelid='teacher_studio.folders'::regclass AND conname='folders_lesson_cover_artwork' OR conrelid='teacher_studio.lesson_sequences'::regclass AND conname='sequences_lesson_cover_artwork') AND contype='c' AND convalidated AND NOT connoinherit AND pg_get_constraintdef(oid)=expected_definition;
 IF found_count<>2 THEN RAISE EXCEPTION 'Exact reviewed cover CHECK definitions required'; END IF;
 IF NOT already_installed THEN
ALTER TABLE teacher_studio.folders DROP CONSTRAINT folders_lesson_cover_artwork;
ALTER TABLE teacher_studio.folders ADD CONSTRAINT folders_lesson_cover_artwork CHECK (cover_artwork IN ('ema-touch','trend','breakout','waves','fin','sailboat','glacier','lavender','mint','horizon','graphite'));
ALTER TABLE teacher_studio.lesson_sequences DROP CONSTRAINT sequences_lesson_cover_artwork;
ALTER TABLE teacher_studio.lesson_sequences ADD CONSTRAINT sequences_lesson_cover_artwork CHECK (cover_artwork IN ('ema-touch','trend','breakout','waves','fin','sailboat','glacier','lavender','mint','horizon','graphite'));
  INSERT INTO teacher_studio.schema_migrations(version,sha256) VALUES(9,'5d9e3cbf402f9fb1da6f71ad330966c551c1532e23d3b888820aa781fcf2e084');
 END IF;
 SELECT count(*) INTO found_count FROM pg_constraint WHERE (conrelid='teacher_studio.folders'::regclass AND conname='folders_lesson_cover_artwork' OR conrelid='teacher_studio.lesson_sequences'::regclass AND conname='sequences_lesson_cover_artwork') AND contype='c' AND convalidated AND NOT connoinherit AND pg_get_constraintdef(oid)='CHECK ((cover_artwork = ANY (ARRAY[''ema-touch''::text, ''trend''::text, ''breakout''::text, ''waves''::text, ''fin''::text, ''sailboat''::text, ''glacier''::text, ''lavender''::text, ''mint''::text, ''horizon''::text, ''graphite''::text])))';
 IF found_count<>2 THEN RAISE EXCEPTION 'Cover016 final CHECK validation failed'; END IF;
END $migration$;
COMMIT;
