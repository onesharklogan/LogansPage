# Teacher permanent Slide deletion — review-only rollout

## Scope and current status

Prepared from live v66 `a2095df230f5df943889267961a6ba7cf11a1fb3`. No production mutation, schema/grant change, configuration change, deletion, Trash purge, commit, push or deployment was performed by this implementation task.

Only new **Slide** deletion changes. Lesson/Module/Folder Trash behavior and existing Slide Trash read/restore remain. A request to change the app is **not** standing permission to delete any real Slide. Each later action requires a named, irreversible confirmation.

## Separate approval needed

1. Publish the reviewed compatible application artifact through the coordinator's existing release process with `TEACHER_SLIDE_PERMANENT_DELETES_ENABLED` absent/false. Do not publish this working directory directly or include dependencies, private test fixtures, logs or build output. Confirm ordinary reads/restores and the disabled deletion capability read-only.
2. Review and apply only `migrations/013_teacher_slide_permanent_delete.sql` using a separately authorized schema-owner connection on the existing DB coordinator's verified production project/branch. Its SHA256 is `bb51cde86cf9b8c2ea92ae2f73243bc9c27a668a8163a7e592ccfc1b0f66c83b`. Existing schema migration 6 checksum must match. Migration installation itself does not erase content. Verify exact function/grants/readiness read-only, leaving the new flag off.
3. Enable `TEACHER_SLIDE_PERMANENT_DELETES_ENABLED=true` only after the migration, reviewed app, recovery verification and explicit authorization. Existing `TEACHER_WORKSPACE_WRITES_ENABLED=true` is also required. Absent/false/malformed flags disable deletion; there is no soft-delete fallback.
4. Verify status capability read-only. Never delete a real Slide just to test deployment. Real-content deletion requires a new specific confirmation; use only local disposable fixtures for destructive QA.

Installing/enabling the feature is distinct from executing a deletion. Do not run the function manually against a real Slide as part of rollout.

## Privilege change

Adds `teacher_studio.permanently_delete_slide(text,integer,integer,text,text,text,text) RETURNS boolean`, a fixed-SQL PL/pgSQL SECURITY DEFINER function with `search_path=pg_catalog,pg_temp` and explicitly schema-qualified content tables. PUBLIC receives no EXECUTE; only the existing `teacher_studio_app` role receives EXECUTE, alongside the function owner. The owner must remain the separately privileged migration owner, never the runtime role. No new runtime role, membership, credential, broad UPDATE, DELETE, schema usage or learner permission is added.

The app capability checks function identity/signature, boolean result, function kind, PL/pgSQL language, security-definer status, non-runtime owner, exact body hash, fixed search path, runtime EXECUTE, and absence of EXECUTE grants to unexpected roles. A mismatch disables only permanent deletion. The old read/restore/write capabilities remain separate. Runtime does not read the protected migration ledger or execute DDL.

The function is a narrow internal primitive inside the existing serialized repository transaction; the API transaction additionally writes the new parent snapshot and actor-bound receipt and rechecks auth, cancellation and feature flags before commit. Do not call this internal primitive as a substitute for the application operation.

## Exact content impact of one confirmed operation

| Table | Selected-Slide impact |
| --- | --- |
| `teacher_slide_registry` | Delete only the exact logical Slide registry row, when adopted/standalone. |
| `teacher_slide_versions` | Delete all versions owned by that registry row. |
| `lessons` | For a legacy single-Slide origin only, delete that legacy Slide row. These legacy `lessons` rows are Slides, not workspace Lessons. |
| `lesson_versions` | For that legacy Slide only, delete all owned versions. |
| `save_requests` | For that legacy Slide only, remove FK-bound receipts after preserving content-free `legacy-save:<requestId>` replay tombstones in workspace requests. |
| `lesson_sequence_versions` | For a sequence-origin Slide only, inspect all versions of that exact origin sequence; redact only members with that origin member ID. Preserve other members' raw JSON text, order, content and version IDs. Recompute hash and byte count. Empty packs remain non-playable; the Lesson is not deleted. |
| `teacher_lesson_composition_versions` | Remove only references to the exact logical Slide key from historical composition snapshots, preserving other members/order and recomputing integrity metadata. Add the new current parent snapshot normally. |
| `teacher_workspace_requests` | Retire older receipts that refer to the erased Slide into content-free audit/replay markers. Store minimal deletion acknowledgement (identity, confirmed title/version/revision, permanent flag), parent summary and actor key. No deleted Slide body/marks/answers are retained here. |
| `folders` / `lesson_sequences` | Increment the current parent revision/update time as usual, and a sequence's implementation parent revision where applicable. Preserve names, identities and Trash flags. Never delete parents. |

This is an explicit deletion-only exception to ordinary immutable history. It is not acceptable to retain the erased Slide in historical packs reachable by author URLs and call that permanent. Conversely, deleting an entire shared pack would destroy sibling Slides and is forbidden. Integrity failures or capacity limits abort the entire transaction.

No uploaded blob/image storage exists for these Slides: content is JSON. Charts, artwork presets and templates are shared static assets and are never deleted. Independent copies in other Slides remain independent. Learner accounts/progress, author membership/auth data and unrelated content remain unchanged.

## Confirmation, conflicts and recovery

The operation binds exact Slide key, revision, parent revision, title and current content version. Already-trashed Slides are rejected. Approved collaborators retain the existing shared-workspace access model; public/unauthenticated/cross-origin/CSRF-invalid requests cannot mutate.

Older clients' `trash-slide` and legacy Slide `/trash` calls reject with `slide_confirmation_required`; they are never silently reinterpreted as destructive. Existing restore paths remain. Historical old creation request IDs cannot recreate a deleted Slide, including stale concurrent legacy retries.

One transaction includes content redaction/removal, parent revision/snapshot, receipt and final access/flag checks. Failure before commit restores everything. A lost commit response remains uncertain: check the actor-bound request status. Only a specific verified absent-status response allows one exact-body retry, with a fresh confirmation. A committed receipt is replayed without running deletion again. Generic 404/network failure is not evidence of non-execution.

## Recovery preparation and rollback boundary

Before approval, verify the provider's existing backup/PITR retention and an isolated recovery workflow for the exact production branch, without copying secrets into artifacts. Do not assume that a backup exists, create a paid backup resource, or restore production without authorization.

Operational rollback: turn the new deletion flag off and keep this compatible application/read/restore code and the replay tombstones. Revoking function EXECUTE is an optional separately authorized additional lock. Do not blindly revert below this compatibility version: older code does not understand deletion tombstones/empty historical packs. No destructive down migration is provided.

A completed deletion has no app-level restore. Database backups, provider-retained WAL/PITR, exported files and previously downloaded copies are outside this feature; do not promise forensic erasure of them. An accidental deletion requires separately approved recovery from a verified recovery point into an **isolated** branch, then a narrowly reviewed reconstruction of only the intended content. Never restore the whole live database over newer unrelated work. Preparing this feature did not inspect, create or modify production backups.

## Local verification

- 90 final targeted tests pass: 31 new deletion tests (18 actual API + disposable PGlite/PostgreSQL restricted-role tests and 13 current-source synthetic UI tests), plus 59 workspace/model/auth regression tests. Three prior trash-creation fixtures now seed preexisting synthetic Trash and explicitly assert that new trash requests are rejected; restore/privacy/auth assertions remain.
- Coverage: all four Slide types, standalone/legacy/sequence origins, adopted/edited/reassigned Slides, last sequence member, historical siblings and Trash restore, shared assets, stale/missing confirmation, collaborator/unauthenticated/CSRF/origin, direct function denial, privilege tampering, migration reapplication, legacy retry race, corrupted history, capacity rollback, revocation-before-commit, lost COMMIT/status/exact replay, Cancel/double click/unmount/stale UI/editor/retry guards.
- TypeScript, release source/provenance guard (450 charts), release-style webpack build, and default Turbopack build pass. The initial Turbopack attempt rejected the inherited external node_modules symlink; making a local dependency copy resolved that test-environment issue without a source/config change.
- The historical sequence/module suites have 22 failures reproduced on untouched v66 (old fixtures lack the required workspace schema). These are not newly passing tests; the full historical suite is not claimed clean.
- Browser-native/production destructive flows were deliberately not exercised. No live deletion is required for acceptance.
