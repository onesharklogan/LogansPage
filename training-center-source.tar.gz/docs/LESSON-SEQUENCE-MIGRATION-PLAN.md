# Ordered lessons: staged migration and recovery plan

**Status:** draft implementation; no production database, grant, role, teacher-record or publication action has been performed. This plan requires separate administrator approval before execution. Existing learner accounts are preserved and not altered by this feature.

## Compatibility and deployment order

Existing `folders`, `lessons`, `lesson_versions` and `save_requests` remain unchanged. Existing single-slide packs, IDs, revisions, private teacher membership/passwords and local learner profiles/history are not migrated. New ordered lessons live alongside existing slides. All 450 immutable chart files, their source/provenance and canonical slide model remain unchanged.

The old released application works after the additive migration (verified using the exact v33 server against disposable PGlite). The new application queries the new tables when showing Lessons; **do not deploy it before both schema and minimal grants have passed verification**. Current migration runner intentionally remains unchanged; it does not silently apply these drafts.

1. Identify the exact production project, branch and `teacher_studio` database from the approved deployment record. Recheck current ledger and release before mutation; never infer an old connection target.
2. Obtain approval for the precise two SQL files below and their recorded hashes, and verify an available recovery point/PITR or administrator-approved branch snapshot. Do not create paid resources, credentials, roles or grants beyond this plan without separate approval.
3. Record read-only preconditions below. If target, ledger/checksum, schema or runtime-role privileges differ, stop and investigate.
4. Run `007_lesson_sequences.sql` with a direct migration-owner connection, not the runtime role. It is one transaction with the existing advisory lock. It creates three tables and two indexes, then records **teacher ledger version4** and the exact DDL SHA256. Repeating the same migration is a no-op; mismatched version4 checksum aborts. The descriptive filename007 does not depend on any account006 migration.
5. Separately run reviewed `008_lesson_sequence_grants.sql`. It is a transaction and repeatable; it does not create/change roles or credentials. It revokes accidental PUBLIC/new-table privileges, then gives the existing `teacher_studio_app` role only the privileges listed below.
6. Re-run schema, privilege and retained-data checks. Require an exact old-data digest/count match, empty new tables, expected ledger4 checksum and unchanged prior ledger rows. Exercise read-only status/public/author APIs with the existing release. Do not create a real teacher lesson for testing without explicit authorization.
7. Only then publish the independently reviewed application artifact. Verify old library access and new empty ordered-lesson lists. Creation of real course material remains the teacher's action.

## Additive schema and minimal grants

| New table | Purpose | Runtime privileges |
|---|---|---|
| `teacher_studio.lesson_sequences` | Current sequence pointer, module and optimistic revision; recoverable trash | SELECT, INSERT, UPDATE |
| `teacher_studio.lesson_sequence_versions` | Immutable JSON pack and hash/byte count | SELECT, INSERT |
| `teacher_studio.lesson_sequence_requests` | Idempotency and uncertain-save recovery receipts | SELECT, INSERT |

No DELETE, DDL, ownership, role membership, credential or schema-wide privilege is granted. Existing runtime permissions remain unchanged. The grants script is separate from schema DDL and from any deployment/start/build script.

## Read-only pre/post evidence

Capture counts and deterministic aggregate digests (not raw personal records) for `folders`, `lessons`, `lesson_versions`, `save_requests`, `app_config`, `author_members`, `membership_audit`, `password_credentials` and `enrollment_tokens`. Use a consistent read-only snapshot; for each table compute SHA256 over deterministic JSON rows ordered by its primary key in a private administrator process, retaining only count and digest. Record existing schema_migrations rows/checksums separately. Existing auth tokens/rate-limit rows can naturally change; avoid confusing normal live activity with this migration and do not expose them in logs.

Verify new column types, FK targets, checks, indexes and three table names. Confirm new tables have zero rows immediately after DDL. Confirm runtime role can SELECT/INSERT/UPDATE the sequence pointer but cannot DELETE it, and can SELECT/INSERT—but cannot UPDATE/DELETE—immutable versions/requests. Validate privileges via catalog inspection in production; the destructive-denial probes have already been run only in disposable PGlite. Confirm no new account tables or learner-account dependency.

## Limits and truthful progress

Each sequence pack is at most3MiB UTF-8; canvas marks use the existing bounded resources. There is a 100-slide cap. At most1000 sequence containers,200 immutable versions per sequence and100MiB total sequence-version text are permitted, separate from the unchanged legacy slide budget. Save requests use current teacher membership, CSRF/same-origin checks, optimistic revision, atomic current pointer/version/receipt changes and upload rate limits. An unconfirmed save is retried with the same request ID, not as a new lesson.

Player progress is client-reported, in-memory `viewed`/`revealed`/`correct` UI state. It is not trusted grading and is not uploaded to a learner account. Public packs contain practice examples under the existing client-side answer protocol; hidden examples are pedagogical, not a confidentiality boundary.

## Recovery / rollback

On any uncertain SQL outcome, inspect ledger/schema/privileges before retrying. Never blindly replay a denied or uncertain action. Transactions rollback failed DDL/grants; verify rather than assuming.

If the new application fails after migration, restore the previous reviewed application artifact. Keep the additive tables and any new teacher content intact; the old application ignores them. **Do not DROP, truncate, rewrite or remove ledger rows** as an application rollback. If data restoration becomes necessary, stop writes and obtain a separate administrator-reviewed recovery plan tied to the verified recovery point. Do not discard newly created lesson content to restore older code.

## Current rebase note (31 October 2026)

The prior v35 lesson build was held, not published. Rebase only its approved lesson delta onto the latest release; do not restore the old application artifact. Current learner-account migration006 uses the separate `learner_app` schema/ledger and must remain unchanged. Lesson007 still uses teacher ledger version4. The production schema/grant approval and exact-target/recovery checks above remain mandatory. The Teacher slide background-color extension changes only JSON validation/rendering; it requires no additional SQL tables, roles or grants.

## Flat Lessons and limits

The visible hierarchy is **Lessons → Slides**. Existing folder records appear as Lessons with their original slides and versions; ordered sequence records are sibling Lessons. No existing content, identifier, Trash state, or parent relationship is converted or deleted. New ordered Lessons create a server-owned internal parent only on explicit Save, atomically with the Lesson, first immutable version, and request receipt. Internal parents are never another visible bucket. Existing ordered Lesson parents are pinned on edit.

An ordered Lesson contains **1–100 slides**. The independent 3 MiB serialized text limit, 200 immutable versions per Lesson, 1,000 saved ordered Lessons, 100 MiB total ordered-version storage, annotation limits, and chart validation remain enforced. Migrations 007 and 008 are unchanged; no data migration or production setup is performed by this UI change.
