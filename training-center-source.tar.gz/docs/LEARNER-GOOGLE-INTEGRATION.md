# Learner Google accounts — isolated current-source candidate

## Status: default OFF; not deployable or activated

This tree was materialized file-by-file from the frozen v41 `CONTENTS.json` (594 production-source files, manifest SHA-256 `fe190b7e4d09f35c67c94a9d93a541077330f915c39aff2a502aec81353783b3`). Only the reviewed account additions from the old v35 account draft were ported. No old lesson source was copied. The separately reviewed v42 Neutral-time presentation delta was then composed exactly. `evidence/BASELINE-V41.json`, `V42-COMPOSED-DELTA.json`, `PORT-INVENTORY.json`, and `ACCOUNT-DELTA.diff` establish the boundary. All 450 chart files and catalog remain byte-identical.

No production publication, external database migration, role/grant, secret, OAuth provider, Render setting or readiness change is part of this implementation. `LEARNER_GOOGLE_READY` still defaults off. The inactive sign-in callback shows a clear not-ready page without invoking the browser provider or creating an account. Native Google sign-in, real two-device operation, production build and full aggregate remain separate gates. Focused SDK tests use the installed official SDK with mocked upstream responses; database tests use only disposable PGlite.

## Activation policy

`learnerConfiguration()` returns null unless the operator explicitly sets `LEARNER_GOOGLE_READY=true`, the managed Auth URL matches the reviewed endpoint, both independent server secrets are at least 32 bytes, and `LEARNER_DATABASE_URL` uses the dedicated `learner_runtime` role in `teacher_studio`, not the teacher `DATABASE_URL`.

Home and simulator server pages choose the online boundary only when that full configuration is ready. When off, the original local Trade gate and original MD iframe source remain selected. MD's disabled bridge preserves the original storage calls/bytes, profile lock, migration and controls. An uncertain network/session response is not interpreted as Guest or local mode.

Required before any activation:
1. Separately approve and configure a dedicated Google web OAuth client/provider using only basic `openid`, `email`, `profile`. No Gmail, Drive or other scopes. The browser driver also rejects a returned authorization URL with missing/basic-identity-incomplete or extra scopes before navigation.
2. Verify the actual app origin, managed callback, consent audience and provider-only policy. Keep teacher auth independent.
3. Securely configure server-only managed Auth URL, cookie secret, learner CSRF secret and approved dedicated-role learner database URL. Never paste secret values into code, logs, backups or chat.
4. Review draft006 including the Equal preference column, least-privilege grants and a verified recovery plan. No production SQL has been run. The existing teacher migration script does not apply draft006.
5. Run independent security review, full tests/build, and native desktop/mobile Google login, cancellation, callback, reload, logout, Back/BFCache, two identities and two devices. Only then may the separately authorized operator enable readiness.

## Identity and authorization

- Every account API request calls the managed SDK's live `getSession({query:{disableCookieCache:'true'}})` and live `listAccounts`.
- Checks include verified email, matching user/session IDs, bounded expiry, and exactly one linked Google identity. The account ownership key is the pinned managed issuer plus the live linked Google `accountId` (Google subject), not email, managed user ID, local learner UUID, body owner or browser claims.
- Auth proxy permits only Google sign-in with the fixed application callback, session verification and sign-out. Password, signup, linking, admin and arbitrary callback operations are denied. Same-origin/Host/Fetch-Site checks, no-store responses and body bounds apply.
- App mutations require a session-derived CSRF token and exact account/session/history-generation context. Transactions lock the server-derived account before its session, then reread the clock and recheck both live-principal and local-session expiry at lock admission. Ownership is never selected from a client ID.
- Sign-out invalidates client capture guards immediately, before the response arrives. Account/reset changes discard old private caches. Late reads, saves and preferences cannot become another learner's result.

## Storage and replay

`learner_app` draft006 contains only `schema_migrations`, `accounts`, `sessions`, `attempts`, `reset_intents`, `reset_receipts`. The account row additionally has `equal_tp_sl boolean NOT NULL DEFAULT false`; it is private to the Google subject and persists across devices. Runtime grants must be limited to required operations on these learner objects, with no teacher or `neon_auth` access, no schema creation and no migration-ledger write permission.

A completed attempt stores a UUID, module, catalog chart ID/hash, start/completion timestamps and observed decision actions, plus a server-recomputed summary. Candle arrays and client metrics are not accepted. Limits are 512 Trade actions, 81 MD choices, 1,000 attempts and 8 MiB per account; quota accounting includes the canonical payload **and** recomputed summary. Attempts are immutable and idempotent; lost acknowledgements retry exactly the same UUID, actions and completion timestamp.

Trade replay uses the unchanged deterministic engine and actual fill ledger. On another device the adapter loads lean account exports and fetches hash-verified public charts only to reconstruct the original engine state for existing history and time buckets. Unfinished account attempts remain on the current page, not in cloud storage. Equal changes are a separate guarded preference mutation and do not change historical points. If verification interrupts a toggle, its boolean intent remains retry-required; the checkbox and current bracket are not silently changed by remote preference hydration. Explicit retry verifies that same setting and applies the existing stop-preserving equal-target calculation before clearing the pending intent.

Market Direction accepts the dormant v1 signed run and current PE v2 explicit Neutral run. A selected Neutral closes the signed leg at that close; following Neutral intervals score zero. Initial unselected is never manufactured into Neutral. Neutral Finish has no future carry. Signed Finish may carry points to configured Final Bar, but Finish choice/carry is excluded from practiced exposure. V42 Time neutral coaching remains the exact read-only interval calculation. No accuracy metric has been restored to UI.

MD native history retains every completed attempt/replay, while first server-recorded completion per chart supplies session aggregates and `/progress` MD points. Per-account lock-serialized saved timestamps are monotonic even for same-millisecond completions; idempotent retries retain the original timestamp. Trade aggregates all completed attempts. Overall completed-attempt counts include replays and are not presented as a skill rating. Source charts are restricted to the recorded immutable catalog; arbitrary imports/demo charts are not silently uploaded.

## UI and local separation

Home offers Google sign-in and Guest with exact text:

> Guests will not be able to track their history + skill progress

Enabled Guest practice is memory-only and sends no persistent personal-history saves. Signed-in controls provide account history, replay, JSON download, sign-out and a typed `RESET MY HISTORY` confirmation. Reset deletes only that account's attempts/history and increments its generation; identity, Equal preference, other accounts, teacher data and browser-local history remain intact. A server-bound one-use reset intent plus idempotent receipt protects retries.

The MD iframe shares one same-origin client facade with its React host. Direct raw-module visits verify readiness and route enabled users to that host. Focus/pageshow starts a private-UI suspension: actions and downloads are denied, simulators pause and their private trees are hidden/inert. A freshly confirmed identical account/session/generation resumes the same paused run; transport uncertainty keeps it hidden, and an owner/session/generation change clears it. Unconfirmed saves retain identical retry payloads. Reset responses cannot substitute for a pending identity check, and focus checks cannot cancel a pending sign-out.

The protocol is canonical in `public/modules/learner-client.js`; `lib/learner/client.mjs` re-exports it instead of maintaining a second implementation.

When readiness is enabled, Chart Marker, the automatic matcher and full read-only chart use the same account control, not a separate legacy profile badge or misleading local-history destination. These tools remain anonymous and unsaved: Google/Guest status never gates their images, drawings or chart controls. Opening the panel pauses Marker using its existing tokened iframe message and preserves its image/marks; pending chart replacement or screenshot recognition is canceled without clearing the current workspace. Closing resumes manual interaction, never autoplay. Identity refresh does not key/remount/reload the workspace or chart. Explicit warnings explain that navigating to sign-in/history leaves the unsaved workspace. When readiness is off, their original optional local profile controls remain intact.

Existing local profiles/history are never uploaded or used as account proof. `/learner/local-history` is an explicit read-only viewer: no selection, migration, new UUID, reset, delete, repair or upload. There is no automatic or implicit migration feature.

## Evidence and limits

- `evidence/backend-focused.log`: disposable database/API ownership, two-user/session isolation, stale reset/logout saves, idempotency, current PE v2, Equal and first-chart aggregates.
- `evidence/identity-ui-trade-focused.log`: provider/SDK/client/actual account TSX controls and lean Trade adapter checks.
- `evidence/trade-adapter-focused.log`: actual Trade TSX account completion/replay/preferences and stale-identity guards; no local writes.
- `evidence/MD-INDEPENDENT-REVIEW.json`: independent real inline-runtime checks, off-mode byte/trace parity, Guest zero persistent writes and v42 composition.
- `evidence/rebased-preservation-focused.log`: exact account/v42 inverse proof plus current MD/Trade functional preservation.
- `evidence/typecheck-current.log` and `check-release.log`: type/source-integrity checks, not native UI/provider or deployment evidence.

All candidate changes stay in `learner-account-current-stage`. Do not deploy the old v35 account tree, and do not merge held lesson work. Do not infer production readiness from mocked SDK, inert DOM/hook tests or successful local type/source checks.
