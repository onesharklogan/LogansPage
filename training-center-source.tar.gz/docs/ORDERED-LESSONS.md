# Lessons → Slides

The teacher and public libraries present one flat **Lessons** list. Existing Lessons open their original Slides; ordered Lessons open their saved slide sequence. Existing records have not been converted, renamed in storage, overwritten, or removed.

1. Choose **Create Lesson**. No parent or bucket selection is needed; Cancel creates nothing.
2. **Add Teacher slide** opens a color canvas with information text and text/line/arrow tools. Click/tap to place marks. Keyboard arrows move the crosshair, Enter places a mark or line endpoint, and Escape cancels an unfinished line. Undo and Clear drawings affect only this draft canvas.
3. **Add Activity slide** opens the existing historical-session calendar and chart editor. Use its established visible-range crop, drawings, indicators, Reveal Drawings, Candle Picker and Clickable Areas. Apply the slide to return to the lesson.
4. Teacher slides have a direct **Background** choice: **Color** (with a background color picker) or **Choose chart**. Choosing a chart edits the selected slide, not a second slide. Calendar or editor Cancel leaves the old background intact; Apply accepts the replacement. Replacing existing drawings asks before discarding incompatible canvas/chart coordinates. Teacher text and marks are visible immediately, with no Reveal step or activity answer controls. A color canvas never invents a chart reference.
5. Use the up/down buttons to order slides, and **Student preview** to test the exact current draft. Save lesson stores an immutable version with optimistic revision protection. The older version remains unchanged.

Learners open a lesson from the public Lessons. Next/Back navigate its ordered slides. Teacher slides can advance immediately. Practice slides must reach their existing completed state; studying an answer alone does not count as correct. Returning to a practice slide starts a fresh local attempt. Chart crops and indicator settings are respected. The current lesson is pinned to the saved version opened, not silently switched by a later teacher edit.

The player reports only client-side/in-memory viewed/completed events, not server-certified grading or online learner progress. Existing browser-local simulator profiles and histories are unchanged. No new online account, Guest account, password or email setup is involved.

## Unsaved work and recovery

Closing an edited draft asks before discarding it; browser reload/navigation receives the usual unsaved-work warning. Browser warning behavior itself depends on the browser. A pending server save uses an idempotent request ID: **Check save status** or **Retry same save** before closing. Closing discards that tab's recovery ID; the save might already have succeeded, so inspect the Lessons before creating another lesson.

A failed existing-lesson load disables editing/saving and offers Retry. A stale revision cannot overwrite a newer lesson. Chart editor drafts are isolated in memory and do not read or overwrite the legacy browser-local teacher library.

The text pack has independent limits of 100 slides and 3 MiB. Existing per-mark and history/storage resource limits still apply. Client-side packs include teacher examples as in existing practice slides; hiding them is a learning step, not a secure exam/answer-key mechanism.

## Release dependency

This feature is staged and has not been deployed. See `LESSON-SEQUENCE-MIGRATION-PLAN.md` for the separately approved additive schema and restricted-grants prerequisites. Do not publish new application code before those prerequisites are verified.

## Integration contract

- `GET /api/{public|author}/sequences?folderId=<id>` lists active ordered lessons. The public list omits archived lessons and archived legacy Lessons; it cannot request teacher trash.
- `GET /api/{scope}/sequences/<id>/manifest` pins `id`, `folderId`, current optimistic `revision`, immutable `versionId`, title and same-origin `packUrl`, plus `{sha256,bytes,contentType}`. The reader verifies URL identity, exact bytes and SHA256 before decoding.
- `GET|HEAD /api/{scope}/sequences/<id>/versions/<versionId>/pack` returns the pinned immutable JSON. Every public read rechecks current Lesson/legacy-parent visibility, including older versions. No image blobs are stored.
- `POST /api/author/sequences` requires the existing authenticated teacher, CSRF and same-origin guards. Body: `{requestId,pack}` for a new Lesson; add `{sequenceId,expectedRevision}` to save an edit. New requests reject `folderId`; edits keep the stored parent and reject retargeting. `pack` is UTF-8 JSON text with format`price-action-lesson-sequence`, version1, title and ordered unique-ID slides. A successful response contains `sequence` with the new revision/version. Reusing the same request ID and exact payload returns the original result; another payload with that ID conflicts. A409 is not success.
- `GET /api/author/sequences/save-status?requestId=<id>` returns `state:'committed'` and the original sequence receipt, or404/`unknown`. An unknown/failed status is not proof a preceding network request cannot still complete; retry its exact request rather than creating a new one.
- Author `POST /sequences/<id>/trash|restore` uses `{expectedRevision}`. This is recoverable; immutable versions are retained. Legacy Lesson Trash affects visibility without changing child flags.

The player emits `priceaction:lesson-progress` only when Next/Finish is actually allowed, once per slide per loaded sequence:

```json
{"version":1,"moduleId":"module-id","lessonId":"sequence-id","versionId":"immutable-version-id","slideId":"slide-id","position":0,"kind":"info","completion":"viewed"}
```

Practice completion is `revealed` for Reveal Drawings, or `correct` for completed Candle Picker/Clickable Areas. `study-revealed` never advances the gate. The event and optional `onProgress` callback are **untrusted client reports**, not authenticated proof of learning. No listener persists/sends them in this feature. Reload or a different immutable version resets in-memory progress.

## Backward-compatible Teacher backgrounds

Stored slide kinds remain `info` and `practice`. An optional `backgroundColor` is accepted only on blank `info` slides, validated as six-digit hexadecimal and rendered as a color—not arbitrary CSS. Older packs without the property keep `#091521`. Chart and activity slides reject this property. Current single-click calendar behavior is retained. Learner Google accounts/avatars, simulator profiles/history and existing teacher authorization remain separate and unchanged; lesson-viewed events are still in-memory only, not cross-device progress.

## Flat Lessons and limits

The visible hierarchy is **Lessons → Slides**. Existing folder records appear as Lessons with their original slides and versions; ordered sequence records are sibling Lessons. No existing content, identifier, Trash state, or parent relationship is converted or deleted. New ordered Lessons create a server-owned internal parent only on explicit Save, atomically with the Lesson, first immutable version, and request receipt. Internal parents are never another visible bucket. Existing ordered Lesson parents are pinned on edit.

An ordered Lesson contains **1–100 slides**. The independent 3 MiB serialized text limit, 200 immutable versions per Lesson, 1,000 saved ordered Lessons, 100 MiB total ordered-version storage, annotation limits, and chart validation remain enforced. Migrations 007 and 008 are unchanged; no data migration or production setup is performed by this UI change.
