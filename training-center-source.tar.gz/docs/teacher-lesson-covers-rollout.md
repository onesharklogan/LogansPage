# Lesson cover artwork — review-only preparation

The current workspace displays both `folder:<id>` and `sequence:<id>` Lesson containers, including legacy sequence Lessons. Both need the same metadata field; a folder-only change would leave some visible Lessons unable to save a cover.

## Exact activation blocker

1. Separately authorize schema-owner application of `migrations/014_teacher_lesson_covers.sql` to the intended database after recovery verification. It adds **nullable `cover_artwork TEXT`** columns to `teacher_studio.folders` and `teacher_studio.lesson_sequences`, each constrained to the existing six preset IDs. No existing rows are backfilled. No original Slide JSON, chart, artwork or composition snapshots are changed.
2. Verify the existing restricted runtime role can SELECT/INSERT/UPDATE these columns. Existing table-level grants already provide this: **no new grant/role/auth migration is proposed**. The optional capability fails closed if column privileges are absent.
3. Separately authorize deployment of reviewed code and activation of `TEACHER_LESSON_COVERS_ENABLED=true`. It defaults OFF, remains independent of permanent deletion, and requires the existing workspace write flag for writes. Runtime performs no DDL. Missing schema, disabled flag, wrong column shape or insufficient column privileges leave the original workspace functional, show the default Lesson cover, and hide/disable cover editing.

Only these existing local artwork IDs are accepted: `ema-touch`, `trend`, `breakout`, `waves`, `fin`, `sailboat`. NULL/absent metadata displays EMA touch without rewriting stored data. Save of a cover uses the existing actor-bound idempotent operation, parent revision checks, transaction lock, authentication and CSRF. It changes only Lesson metadata. Older clients that omit `coverArtwork` preserve it. Lost acknowledgements use existing status/exact-retry recovery.

The permanent-delete SQL/function, its ABI/body checksum and all grants remain byte-for-byte unchanged. Keeping cover metadata outside composition JSON avoids breaking its strict snapshot validator. Lesson cover metadata survives Slide deletion and Lesson Trash/restore. Legacy Slide `coverArtwork` remains valid and preserved but is no longer offered as a card-artwork choice. Chart images, actual content/backgrounds and teacher content remain intact. Slide cards continue using bounded, hash-verified real-content previews.

This preparation does not authorize or perform production schema/configuration/content writes or deployment. Tests use disposable local SQL only. No database branch is created.
