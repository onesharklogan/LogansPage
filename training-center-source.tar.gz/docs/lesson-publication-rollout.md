# Explicit Lesson publishing

Teacher Studio has per-Lesson Publish and Unpublish controls. All existing and new Lessons are drafts until a teacher explicitly publishes one. Publication allows only verified, signed-in learners to read that Lesson; anonymous visitors and local-only profiles remain excluded. Existing author/admin memberships retain draft access.

Publishing covers the current logical Lesson and its included Slides. Any subsequent revision change makes it a draft again, including slide edits, moves, order changes, title/artwork changes and trash/restore. The teacher must publish again. Sequence publication also pins its original parent revision, so changes to that parent may conservatively withdraw it. Unpublish is reversible; saved content, immutable versions and learner progress are not deleted.

Only the current workspace Lesson/Slide/preview endpoints are eligible for learner access. Historical whole-folder, sequence pack, manifest and version endpoints remain teacher-only, preventing an old shared pack from revealing a sibling draft. Current workspace responses select only members of the authorized Lesson. Every response remains private/no-store; live managed Google identity verification is required. Previously downloaded information cannot be recalled by unpublishing.

## Controlled rollout

1. Review and separately authorize `migrations/018_lesson_publications.sql`. It creates an empty registry and gives the existing restricted teacher runtime SELECT/INSERT/UPDATE on that table only. It does not grant learner database access or alter roles/content/progress.
2. Install using an authorized schema owner. Runtime never runs DDL. The regular migration script does not auto-install this optional migration.
3. Deploy the reviewed build and explicitly enable `TEACHER_LESSON_PUBLICATION_ENABLED=true`. With the flag off or missing schema, all learner Lesson reads fail closed and teacher publication controls are disabled. Existing draft editing remains available.
4. Verify authenticated learner draft denial and empty list before any publication. Do not publish actual lessons as a deployment test without the teacher choosing them.
5. Teacher chooses Publish for individual Lessons. Unpublish immediately denies subsequent learner requests.

Rollback: disable the publication flag, which withdraws all learner access without deleting registry rows/content. Retain the additive table rather than dropping data. Re-enabling restores only explicit publications whose revisions still match; it does not automatically publish drafts.
