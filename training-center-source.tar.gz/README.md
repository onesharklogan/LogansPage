# Price Action Center

Standalone Node 24 / Next.js application for a new Render Web Service. Do not change an existing Static Site or its main branch.

## Foundation

- Public home with separate Market Direction Simulator and Trade Simulator modules.
- Trendlines, Wedges, Shapes and Market Phases are explicitly Coming Soon.
- All 203 chart files remain byte-for-byte unchanged. The Training Center's Bias module adds a clear initial-direction prompt, highlighted Long/Short choices and a guarded disabled Play control; its scoring, same-bar net-flip logic and mobile chart fitting are unchanged. Original and reviewed module hashes are recorded in `data/bias-provenance.json`. Browser progress keys are unchanged, but a new hostname cannot read progress on an older hostname.
- `/admin` uses separate approved email/password accounts. There is no Google dependency, app-wide password, public registration or claim-by-email endpoint.
- Admins can grant Author/Admin roles and revoke access. The last active admin cannot be removed/demoted. Removal revokes sessions, pending enrollment links and stored password credentials; reactivation requires new enrollment. No invitations or emails are sent automatically.
- Slide editor/library work remains at `/studio` and `/library`, linked from Teacher Studio navigation. Saved references, geometry, labels, prompts, explanations, modules and immutable revisions are JSON in PostgreSQL. No uploaded images are stored.

## Modules and Slide practice

Shared collections are called Modules; each saved record is a Slide. The Module Library remains at `/library`. This is a display-terminology change only: legacy `folders`, `lessons`, `folderId`, `lessonId` and `price-action-lessons` wire/storage names are retained for compatibility. Existing authored names, text and saved bytes are not renamed.

Each Slide can choose **Cover artwork** for its large blue library-card header: EMA touch, trend, breakout, waves, fin or sailboat. The editor previews the decorative navy/teal/gold vector artwork; Save Slide stores only its preset ID in the existing JSON. Legacy slides automatically display EMA touch without changing their saved bytes. Covers are intentionally illustrative, not historical price-chart thumbnails, and never change chart data or answers.

Teachers choose one of three slide types and enter an initial question/action separately from the final explanation:

- **Reveal Drawings:** the original price chart starts without teacher marks. Learners may add lines, arrows and text. Reveal completes the slide automatically and shows the teacher answer over the learner's dull-gray marks.
- **Candle Picker:** learners select candle numbers, then Check Answer. Only the exact correct set (no missing or extra candles) passes Check Answer and enables Next. Reveal Answer is also available before any pick or after a wrong answer: it highlights the correct candles and explanation for study, without marking the attempt correct or enabling Next. Replay clears study mode for a fresh attempt.
- **Clickable Areas:** learners discover hidden chart-anchored rectangles. A click reveals every containing target; repeated clicks never add duplicate credit. Finding all targets reveals the answer and enables Next.

Teachers can save an inclusive Start bar / End bar range (for example 8–20) to fill the chart with a close-up. Visible bar numbers use the original 1-based session indices, with adaptive spacing on small screens; teacher view, student view and PNG export use the same numbering. Candle numbers and markup anchors remain those of the original chart. Full chart removes the optional range. Out-of-range marks stay stored but are hidden/clipped; quiz answers and target boxes must fit inside the saved range before publishing. Legacy slides retain their original full-session behavior.

Each Slide can save EMA20 and Pivot Point Diamonds, matching the Market Direction Simulator calculations and colors. New slides and older slides without saved indicator settings start with EMA20 on and pivots off; an explicitly saved EMA20-off choice remains off. Teachers control the saved options. Learners can hide/show an enabled EMA20 locally before or after Reveal without changing the saved slide, their marks or answer progress; the chart scale remains stable. Teacher PNG exports always use the saved/default configuration, not a learner visibility choice. EMA20 retains the full supplied historical warmup and prefix before a crop. Pivots are strict three-candle highs/lows; equal highs/lows do not qualify. A pivot needs its following candle, and brighter diamonds mean the next five candles held its level (touches count). No candle after the saved End bar is used for confirmation or strength. Teacher view, learner view and downloaded PNG use the same saved settings; no indicator values or images are stored in the record.

Replay clears the current attempt and hides the answer again. Next follows the library's displayed slide order. Drawings, candle selections and discovered areas stay only in transient page memory; no learner account or tracking is added. Public slide JSON remains downloadable/inspectable, so these are practice gates, not secure assessments.

Teacher and learner tools include dotted lines, editable text, touch-friendly up/down/study/cross arrows, colors, text sizes, a click/tap Eraser, Undo and Clear. The Eraser removes one foreground marking at a time and never changes answer completion. Slide practice opens in a centered, expanded viewport with a proportional chart and reachable action controls; small screens use the full chart width without cropping. Existing slides remain valid Reveal Drawings slides with a neutral initial instruction; their old notes remain final-only. New prompt, style, arrow and exercise fields are optional additive version-1 JSON extensions. No SQL migration is required for these features.

## Runtime environment (never commit real values)

- `NODE_VERSION=24`
- `DATABASE_URL`: private pooled PostgreSQL URL for restricted `teacher_studio_app`. Verified TLS is mandatory.
- `APP_ORIGIN`: exact public HTTPS origin, no path/trailing slash.
- `BOOTSTRAP_ADMIN_EMAILS`: approved initial emails supplied privately. Used once only; later membership changes are authoritative and never undone on restart.

Public pages boot without environment configuration; authentication/storage fail closed. No Google client, email service or paid disk is required.

## Database administration

Apply `001_initial.sql`, then `003_password_auth.sql`. Create a SQL login `teacher_studio_app` with `NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOREPLICATION NOBYPASSRLS`, a private credential, and no owner/neon_superuser membership. Apply grants `002_runtime_grants.sql`, then `004_password_grants.sql`. Runtime never runs DDL. Keep owner credentials out of Render.

`npm run db:migrate` accepts a privately supplied direct `MIGRATION_DATABASE_URL`; do not paste credentials into shell history. It applies schema migrations, not roles/grants or account activation.

## Private account activation

An authorized operator issues the first owner's one-use, one-hour enrollment capability. Only its SHA-256 hash is stored, bound to the exact existing active member. A password cannot be claimed merely by knowing an email address.

The private link uses `/activate#token=...`. The page removes the fragment promptly, retains it only in transient page memory, and lets the user enter/confirm a password privately. Never publish or log links or passwords. Do not inspect the user's password fields. The initial activation must not silently become a password reset if a credential already exists.

After login, admins may explicitly create a setup/reset link for a member in Manage Authors. Links are displayed once for private sharing, never emailed automatically. Issuing a new link invalidates prior unused links; redeeming it atomically sets the credential, consumes the capability and revokes prior sessions. Link creation is rate-limited. Removing an account invalidates both pending links and credentials.

Passwords use asynchronous scrypt N=32768, r=8, p=3, random 32-byte salts, 64-byte keys and a fixed 64MiB memory ceiling. Policy: 14–128 Unicode characters, at most 512 UTF-8 bytes, no controls or all-whitespace values. Passwords are never trimmed. Sessions last eight hours and use Secure/HttpOnly/SameSite=Strict cookies. All mutations require same-origin CSRF; active membership/session is rechecked at commit. Login and enrollment share a conservative throttle without trusting forwarded IP headers.

## Build/deploy

```sh
npm ci
npm run build
npm start
```

Browser-upload release: upload only `training-center-source.tar.gz`, `render-build.sh`, `render-start.sh` to the separate source branch. Render root blank, build `bash render-build.sh`, start `bash render-start.sh`, health `/`. Set Node version explicitly because package.json is inside the archive. `/api/status` tests database readiness separately. Durable data resides in PostgreSQL, never Render's ephemeral filesystem.

Deployment archive excludes credentials, real author emails, tests/fixture inputs, QA HTML, local reports and build outputs. Local automated tests and built-HTTP checks do not substitute for live database, real-user activation or visual/mobile browser QA. Existing public main and original private deployment remain unchanged.

## Shared learner profile entry

Both simulators require a valid selected local learner profile before practice. A nickname is the only required field; this is not teacher/admin authentication. Trade Simulator shares the existing Market Direction profile store and writer lock, preserving its profiles, histories, datasets and legacy migration backups. Existing selected profiles enter directly after validation. New or unselected browsers choose/create a profile first, including direct URLs; the raw Market Direction module enforces the same identity requirement. Corrupt/unavailable storage never creates a guest or overwrites existing progress.

Trade remains unmounted until profile validation, so no chart fetch, order action or replay timer starts early. Its top-right profile control pauses before showing the picker. Returning to the same profile preserves the paused attempt; selecting another starts a fresh attempt. Cross-tab changes, deleted profiles, page restoration and stale input/timer callbacks revalidate current selection before practice. Profile editing coordinates with Market Direction’s writer lock; a busy or unsupported lock explains how to retry safely. The Home icon remains accessible from the profile gate. Trade attempts still remain memory-only; this does not add server accounts or score persistence.

## Market Direction Simulator

The visible module name is **Market Direction Simulator**. Its `/market-direction` URL, internal IDs, local progress keys and chart data are unchanged. Direction Accuracy is now the primary completed-session score; the original points and flip-marker review remain secondary. On phones, compact navigation and one-line chart status keep the focus on the candles; the actual plot reserves at least half the visible viewport, with its axes added outside that space. The default mobile view uses wider candles while retaining the 12-bar prior context plus the opening candle; pan/zoom still reveal only observed bars. Long/Short, Play, Next and Finish remain directly below the chart. Detailed market context and help remain available without the bulky default top rows.

Direction Accuracy snapshots the final chosen Long/Short direction once when leaving each genuinely practiced candle (including held directions). It compares that candle’s close with the close three candles later, only after that candle has actually been revealed. Moves of 0.25 points or less in either direction are neutral and excluded; accuracy is correct / scored non-neutral decisions. The last three practiced choices have insufficient future bars and are shown separately. Earlier decisions cannot be rewritten by later flips. Early Finish freezes accuracy at the last actually reached candle, before the original points review carries forward to its configured final bar; review-only candles never create or mature accuracy decisions. The end panel explains the horizon, neutral threshold and excluded counts. This is short-term direction accuracy, not a profitability score or a definitive Always In judgment. New attempts reset snapshots; legacy saved attempts without snapshots remain unavailable rather than being backfilled. Optional versioned report fields preserve existing saved records and imports.

## Trade Simulator

`/trade-simulator` is a separate public, browser-memory-only practice module using the same 203 immutable MES chart sessions. It does not replace the Market Direction Simulator module and does not change author accounts, storage or saved Slides. No broker is connected. The simulator opens like Market Direction Simulator: 12 dim prior-session context candles, prior close and day-open divider, followed only by revealed current-day candles. Candle density retains the reviewed Bias-style opening view; portrait stays readable with chart/axis drag and zoom, with only Fit and Latest in the bottom view-control row. Price scale, EMA20 and markers do not use hidden future candles. EMA20 starts on and can be hidden.

No order lines appear initially. Armed placement shows a left-pointing tip, a faint horizontal guide and the exact snapped entry price; hovering never creates an order. Mouse and touch taps use the same transformed candidate. Buy/Sell arms chart placement; tapping the chart immediately places all three linked orders. There are no numeric order-entry fields or order Apply/Confirm steps. Slide a line and release to apply a valid update for the next candle; invalid or canceled moves restore the last valid bracket. Right Arrow/D reveals one next candle and pauses. Focused order lines use Up/W and Down/S; existing Shift+Arrow coarse adjustments remain. Typing fields, modified letters and dialogs are protected. Stop and target tags align at the right edge; visible tags are about 30% smaller but retain at least 44px touch targets. Crowded tags separate with connectors to their true price lines so labels and entry actions remain reachable. Arming, placement, dragging and chart navigation pause immediately; press Play explicitly to resume. The ✓ beside × minimizes the controls and summary to clean chart lines, keeping the dynamic risk/reward percentage above the chart. Tapping any minimized line or using Enter/Space reopens the controls without moving an order. Minimize/reopen pauses replay and never changes prices, eligibility or scoring; both actions require explicit Play to resume. Compact display survives a pending entry filling, and a new bracket starts expanded. The entry-line × cancels a pending bracket or closes an open simulated position at the latest revealed close, removes both exits and records Manual close in the ledger. Replay/session/Finish safeguards remain separate. All prices snap to the MES 0.25-point tick. Only one bracket or position is active. Entry/exit edits apply atomically starting on the next candle, never a previously visible candle. An unfilled bracket remains active until filled, moved, canceled or the run ends; an open entry is locked. Completed exits cancel the paired order.

Favorable opening gaps fill resting limits at the open; adverse stop gaps also exit at the open. An entry gapping through its stop opens and closes at the same opening print, for zero points. When the open is between exits and both levels are reached, the stop wins. On an intrabar entry candle, a target wick alone is not credited because it may predate entry; a close beyond target proves a subsequent crossing only when the stop was not touched. An opening fill may use a same-candle target touch. These deterministic OHLC rules are conservative practice assumptions, not execution guarantees, and are explained in the module.

The live planned-bracket label above the chart is `Your risk/reward requires X% win rate`, with risk / (risk + reward) rounded to one decimal. The ledger uses actual fill prices, with entry/exit candles, reason, win/loss/flat and points. Session end closes any open position at the last revealed close, labels it explicitly, and cancels pending orders. A clear completed panel offers Replay, Next Random (avoiding the current session when possible) and Choose a Session using the existing selector. The chart stays draggable; actual closed trades show colored signed points labels, entry/exit markers and connecting annotations. These are actual simulator fill results, not invented bias-flip trades. No future candle is used by Finish. Replay clears orders, ledger and points; leaving or refreshing clears the attempt. No SQL migration, runtime environment change or user-data backfill is required.
