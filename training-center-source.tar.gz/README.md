# Price Action Training Center

Standalone Node 24 / Next.js application for a new Render Web Service. Do not change an existing Static Site or its main branch.

## Foundation

- Public home; Market Direction Bias is the only active module.
- Trendlines, Wedges, Shapes and Market Phases are explicitly Coming Soon.
- All 203 chart files remain byte-for-byte unchanged. The Training Center's Bias module adds a clear initial-direction prompt, highlighted Long/Short choices and a guarded disabled Play control; its scoring, same-bar net-flip logic and mobile chart fitting are unchanged. Original and reviewed module hashes are recorded in `data/bias-provenance.json`. Browser progress keys are unchanged, but a new hostname cannot read progress on an older hostname.
- `/admin` uses separate approved email/password accounts. There is no Google dependency, app-wide password, public registration or claim-by-email endpoint.
- Admins can grant Author/Admin roles and revoke access. The last active admin cannot be removed/demoted. Removal revokes sessions, pending enrollment links and stored password credentials; reactivation requires new enrollment. No invitations or emails are sent automatically.
- Slide editor/library work remains at `/studio` and `/library`, linked from Teacher Studio navigation. Saved references, geometry, labels, prompts, explanations, modules and immutable revisions are JSON in PostgreSQL. No uploaded images are stored.

## Modules and Slide practice

Shared collections are called Modules; each saved record is a Slide. The Module Library remains at `/library`. This is a display-terminology change only: legacy `folders`, `lessons`, `folderId`, `lessonId` and `price-action-lessons` wire/storage names are retained for compatibility. Existing authored names, text and saved bytes are not renamed.

Teachers choose one of three slide types and enter an initial question/action separately from the final explanation:

- **Reveal Drawings:** the original price chart starts without teacher marks. Learners may add lines, arrows and text. Reveal completes the slide automatically and shows the teacher answer over the learner's dull-gray marks.
- **Candle Picker:** learners select candle numbers, then Check Answer. Only the exact correct set (no missing or extra candles) reveals the answer and enables Next.
- **Clickable Areas:** learners discover hidden chart-anchored rectangles. A click reveals every containing target; repeated clicks never add duplicate credit. Finding all targets reveals the answer and enables Next.

Teachers can save an inclusive Start bar / End bar range (for example 8–20) to fill the chart with a close-up. Candle numbers and markup anchors remain those of the original chart. Full chart removes the optional range. Out-of-range marks stay stored but are hidden/clipped; quiz answers and target boxes must fit inside the saved range before publishing. Legacy slides retain their original full-session behavior.

Each Slide can save EMA20 and Pivot Point Diamonds, matching the Market Direction calculations and colors. New slides start with EMA20 on and pivots off; older slides without settings keep both off. Teachers control these options; learners see the saved configuration unchanged before and after Reveal. EMA20 retains the full supplied historical warmup and prefix before a crop. Pivots are strict three-candle highs/lows; equal highs/lows do not qualify. A pivot needs its following candle, and brighter diamonds mean the next five candles held its level (touches count). No candle after the saved End bar is used for confirmation or strength. Teacher view, learner view and downloaded PNG use the same saved settings; no indicator values or images are stored in the record.

Replay clears the current attempt and hides the answer again. Next follows the library's displayed slide order. Drawings, candle selections and discovered areas stay only in transient page memory; no learner account or tracking is added. Public slide JSON remains downloadable/inspectable, so these are practice gates, not secure assessments.

Teacher and learner tools include dotted lines, editable text, touch-friendly up/down/study/cross arrows, colors, text sizes, a click/tap Eraser, Undo and Clear. The Eraser removes one foreground marking at a time and never changes answer completion. Slide practice opens in a centered, expanded viewport with a proportional chart and reachable action controls; small screens use the full chart width without cropping. Existing slides remain valid Reveal Drawings slides with a neutral initial instruction; their old notes remain final-only. New prompt, style, arrow and exercise fields are optional additive version-1 JSON extensions. No SQL migration is required for these features.

## Runtime environment (never commit real values)

- `NODE_VERSION=24`
- `DATABASE_URL`: private pooled PostgreSQL URL for restricted `teacher_studio_app`. Verified TLS is mandatory.
- `APP_ORIGIN`: exact public HTTPS origin, no path/trailing slash.
- `BOOTSTRAP_ADMIN_EMAILS`: approved initial emails supplied privately. Used once only; later membership changes are authoritative and never undone on restart.

Public pages boot without environment configuration; authentication/storage fail closed. No Google client, email service or paid disk is required.

## Database administration

Apply `001_initial.sql`, then `003_password_auth.sql`. Create a SQL login `teacher_studio_app` with `NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOREPLICATION NOBYPASSRLS`, a private credential, and no owner/neon_superuser membership. Apply grants `002_runtime_grants.sql`, then `004_password_grants.sql`. Runtime never runs DDL. Keep owner credentials out of Render.

`npm run db:migrate` accepts a privately supplied direct `MIGRATION_DATABASE_URL`; do not paste credentials into shell history. It applies schema migrations, not roles/grants or account activation.

## Private account activation

An authorized operator issues the first owner's one-use, one-hour enrollment capability. Only its SHA-256 hash is stored, bound to the exact existing active member. A password cannot be claimed merely by knowing an email address.

The private link uses `/activate#token=...`. The page removes the fragment promptly, retains it only in transient page memory, and lets the user enter/confirm a password privately. Never publish or log links or passwords. Do not inspect the user's password fields. The initial activation must not silently become a password reset if a credential already exists.

After login, admins may explicitly create a setup/reset link for a member in Manage Authors. Links are displayed once for private sharing, never emailed automatically. Issuing a new link invalidates prior unused links; redeeming it atomically sets the credential, consumes the capability and revokes prior sessions. Link creation is rate-limited. Removing an account invalidates both pending links and credentials.

Passwords use asynchronous scrypt N=32768, r=8, p=3, random 32-byte salts, 64-byte keys and a fixed 64MiB memory ceiling. Policy: 14–128 Unicode characters, at most 512 UTF-8 bytes, no controls or all-whitespace values. Passwords are never trimmed. Sessions last eight hours and use Secure/HttpOnly/SameSite=Strict cookies. All mutations require same-origin CSRF; active membership/session is rechecked at commit. Login and enrollment share a conservative throttle without trusting forwarded IP headers.

## Build/deploy

```sh
npm ci
npm run build
npm start
```

Browser-upload release: upload only `training-center-source.tar.gz`, `render-build.sh`, `render-start.sh` to the separate source branch. Render root blank, build `bash render-build.sh`, start `bash render-start.sh`, health `/`. Set Node version explicitly because package.json is inside the archive. `/api/status` tests database readiness separately. Durable data resides in PostgreSQL, never Render's ephemeral filesystem.

Deployment archive excludes credentials, real author emails, tests/fixture inputs, QA HTML, local reports and build outputs. Local automated tests and built-HTTP checks do not substitute for live database, real-user activation or visual/mobile browser QA. Existing public main and original private deployment remain unchanged.
