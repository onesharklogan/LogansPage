# Price Action Training Center

Standalone Node 24 / Next.js application for a **new Render Web Service**. Do not point an existing Static Site at this directory or change its main branch.

## Included

- Public training-center home; Market Direction Bias is the only active module.
- Trendlines, Wedges, Shapes, and Market Phases are clearly Coming Soon.
- The existing Market Direction Bias module is preserved byte-for-byte. Provenance is in `data/bias-provenance.json`; all 203 chart files are checked against their catalog hashes. Its browser-local progress keys are unchanged. A new hostname cannot automatically read progress saved on the old hostname.
- `/admin` uses Google's official Identity Services button and server-side `google-auth-library` verification. There is no app password or Google client secret.
- Admins can explicitly grant Author/Admin roles and revoke access. The last active admin cannot be removed or demoted. Removals revoke sessions, are checked on subsequent requests and again at commit, and are not undone by a restart. No invitations are sent.
- Earlier lesson editor/library work remains at `/studio` and `/library`, intentionally absent from the foundation home. Saved chart references, geometry, labels, notes, folders and immutable revisions are small JSON records in PostgreSQL; no images or uploaded files are stored.

## Runtime configuration (Render environment only)

| Name | Purpose |
| --- | --- |
| `DATABASE_URL` | Private pooled PostgreSQL URL for restricted `teacher_studio_app` role. TLS certificate verification is always enabled. |
| `APP_ORIGIN` | Exact public HTTPS origin, without a path or trailing slash. |
| `GOOGLE_CLIENT_ID` | Google Web client ID authorized for that exact JavaScript origin. It is public client configuration, not a secret. |
| `BOOTSTRAP_ADMIN_EMAILS` | Comma-separated approved initial Google-account emails, supplied privately. Used only once on an empty membership database. |

Omitting Google configuration disables sign-in; it does not enable an alternative login. Never commit environment values or database URLs. The initial email list is not an ongoing allowlist: subsequent membership is authoritative in PostgreSQL.

Create a Google Web OAuth client with the verified `APP_ORIGIN` as an authorized JavaScript origin. GIS uses a popup/token callback in the page: no redirect URI or client secret is needed. The app requests identity only, not Gmail access. Verify both intended accounts in the live browser before calling login complete.

## Database setup (administrator action, not app startup)

1. Apply `migrations/001_initial.sql` to the dedicated database through a direct administrator connection. The migration has a checksum ledger and is idempotent.
2. Create SQL role `teacher_studio_app` with `LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOREPLICATION NOBYPASSRLS`, a private strong credential, and no owner or `neon_superuser` membership.
3. Apply `migrations/002_runtime_grants.sql`. Runtime cannot create/alter schemas, update initialization config, delete lessons/history, or read the membership audit table.
4. Put only the restricted role's pooled URL in Render `DATABASE_URL`. Keep owner credentials out of the app.

Optional migration command: `MIGRATION_DATABASE_URL=<private direct admin URL> npm run db:migrate`. Supply that variable securely; do not paste credentials into command history or tracked files. Runtime startup never runs DDL.

## Build and serve

```sh
npm ci
npm run build
npm start
```

Node 24 is required. Render supplies `PORT`. Health path `/` tests the public service; `/api/status` additionally tests configured database access. Free hosting may sleep; durable data lives in the separate PostgreSQL service, not Render's ephemeral filesystem. Do not enable paid resources without approval.

The browser-upload release uses `training-center-source.tar.gz`, `render-build.sh` and `render-start.sh` on a separate source branch. Build command: `bash render-build.sh`. Start command: `bash render-start.sh`. The archive is extracted into `training-center-app`, never served as a Static Site.

## Verification and limitations

The complete local engineering tree has tests for JSON saves/reloads, optimistic conflicts, exact request-ID retry after uncertain commit, rollback, real PostgreSQL migration/grants, session/CSRF/nonce validation, official Google cryptographic verification, revocation races, and last-admin protection. The deployment archive excludes tests, disposable fixture inputs, local reports, credentials and build output.

A local production-HTTP smoke is separate from live Neon, Google-account sign-in and real-device browser QA. Those external checks must be completed after authorized configuration. The existing public main branch and original private native deployment are not modified by this package.
