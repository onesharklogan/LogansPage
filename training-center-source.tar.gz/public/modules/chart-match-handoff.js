/** One-shot, memory-only screenshot handoff. No storage, network or full-session data. */
export const HANDOFF_PREFIX='chart-match-image-v1:';
const TTL=90000,MAX_BYTES=20*1024*1024;
const receiving=new WeakMap();
/** Strip the source down to observed, currently visible opening bars. Reject panned-away openings. */
export function visibleOpeningSnapshot(view,{showEma=true}={}){
  if(!view||![view.width,view.height,view.left,view.right,view.top,view.bottom,view.lo,view.hi,view.start,view.step,view.priorCount].every(Number.isFinite)||view.hi<=view.lo||view.step<=0)throw Error('Open a chart before opening Chart Matcher.');
  const visible=view.visible||[],prior=visible.find(c=>c.prior&&c.slot===view.priorCount-1),opening=visible.find(c=>!c.prior&&c.index===0);
  if(!prior||!opening)throw Error('Bring the last prior-context candle and today’s opening candle into view, then try Open Chart Matcher again. Use Fit or zoom out; hidden candles are never captured.');
  const priorTime=typeof prior.t==='string'?prior.t.slice(-5):'';
  if(!/^(?:0[89]|1[0-5]):[0-5][05]$/.test(priorTime)||priorTime>'15:10'||!/^\d{4}-\d{2}-\d{2} /.test(prior.t)||!/^\d{4}-\d{2}-\d{2} 08:30$/.test(opening.t)||prior.t.slice(0,10)>=opening.t.slice(0,10))throw Error('The visible prior candle time could not be verified. Choose a historical chart and try again.');
  const selected=visible.filter(c=>c===prior||!c.prior),slots=new Set(selected.map(c=>c.slot));
  if(selected.length<8)throw Error('Reveal at least seven opening candles, then try Open Chart Matcher again.');
  if(selected.some((c,i)=>!['o','h','l','c'].every(k=>Number.isFinite(c[k]))||c.slot!==prior.slot+i))throw Error('The visible opening sequence is incomplete. Fit the chart and try again.');
  // No original references or unrecognized fields survive this boundary.
  return {width:view.width,height:view.height,left:view.left,right:view.right,top:view.top,bottom:view.bottom,lo:view.lo,hi:view.hi,start:view.start,step:view.step,
    candles:selected.map(c=>({o:c.o,h:c.h,l:c.l,c:c.c,slot:c.slot,prior:!!c.prior})),
    ema:showEma?(view.visibleEma||[]).filter(p=>slots.has(p.slot)&&Number.isFinite(p.value)).map(p=>({slot:p.slot,value:p.value})):[],
    priorTime};
}
/** A clean chart-only export of the same visible prices/viewport, without trade/account overlays.
 * Earlier prior context is cropped to the one prior-final candle required by opening matching.
 * Rasterizing at 2x improves small wick/axis readability without changing any candle values. */
export function renderVisibleChart(snapshot,doc=document){
  const s=snapshot,firstX=s.left+(s.candles[0].slot-s.start)*s.step,plotRight=s.width-s.right;
  const cropLeft=Math.max(s.left,firstX),plotWidth=plotRight-cropLeft,axis=100,width=Math.max(240,Math.ceil(plotWidth+axis+16)),height=Math.max(160,Math.ceil(s.height));
  if(plotWidth<12||s.height-s.top-s.bottom<20||width>4000||height>1500||width*height*4>12000000)throw Error('Resize the chart to a readable size, then try again.');
  const canvas=doc.createElement('canvas');canvas.width=width*2;canvas.height=height*2;
  const ctx=canvas.getContext('2d');if(!ctx)throw Error('Chart export is unavailable in this browser.');
  ctx.scale(2,2);ctx.fillStyle='#101a27';ctx.fillRect(0,0,width,height);
  const left=12,right=12+plotWidth,top=s.top,bottom=s.height-s.bottom,x=slot=>left+s.left+(slot-s.start+.5)*s.step-cropLeft,y=value=>bottom-(value-s.lo)/(s.hi-s.lo)*(bottom-top);
  ctx.font='16px monospace';ctx.textAlign='left';
  const minTick=Math.ceil(s.lo*4)/4,maxTick=Math.floor(s.hi*4)/4;if(maxTick-minTick<1||bottom-top<80)throw Error('Zoom out the price scale or enlarge the chart so five price labels fit, then try again.');
  for(let i=0;i<=4;i++){const price=Math.round((maxTick-(maxTick-minTick)*i/4)*4)/4,yy=y(price);ctx.strokeStyle='#29384a';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(left,yy);ctx.lineTo(right,yy);ctx.stroke();ctx.fillStyle='#c8d8e8';ctx.fillText(price.toFixed(2),right+8,yy+4);}
  ctx.save();ctx.beginPath();ctx.rect(left,top,plotWidth,bottom-top);ctx.clip();
  for(const c of s.candles){ctx.strokeStyle=ctx.fillStyle=c.c>=c.o?'#67dfb3':'#f18da6';ctx.lineWidth=Math.min(1.4,Math.max(.6,s.step*.3));ctx.beginPath();ctx.moveTo(x(c.slot),y(c.h));ctx.lineTo(x(c.slot),y(c.l));ctx.stroke();const w=Math.max(.7,s.step*.56);ctx.fillRect(x(c.slot)-w/2,Math.min(y(c.o),y(c.c)),w,Math.max(1,Math.abs(y(c.o)-y(c.c))));}
  if(s.ema.length){ctx.strokeStyle='#f6c760';ctx.lineWidth=2;ctx.beginPath();s.ema.forEach((p,i)=>{if(i===0)ctx.moveTo(x(p.slot),y(p.value));else ctx.lineTo(x(p.slot),y(p.value));});ctx.stroke();}
  ctx.restore();ctx.fillStyle='#c8d8e8';ctx.font='12px monospace';
  // Ordered layout is explicit: exactly one prior-final candle, then today's opening prefix.
  ctx.font='16px monospace';ctx.fillText(s.priorTime,left,Math.max(16,top-12));
  ctx.fillText('08:30',Math.max(left,x(s.candles[1].slot)-20),bottom+30);
  return canvas;
}
/** Call synchronously from a trusted click, after freezing the chart and pausing playback. */
export function openChartMatchImage(canvas,{onStatus=(_message)=>{},onError=(_message)=>{},onDone=()=>{},priorTime='',excludeSha256=''}={},win=window){
  if(typeof win.BroadcastChannel!=='function'||!win.crypto?.getRandomValues){onError('This browser cannot transfer a chart between tabs. Use a recent browser or save/paste a chart screenshot manually.');onDone();return()=>{};}
  const token=Array.from(win.crypto.getRandomValues(new Uint8Array(24)),n=>n.toString(16).padStart(2,'0')).join('');
  const channel=new win.BroadcastChannel(HANDOFF_PREFIX+token);let popup=null,blob=null,ready=false,sent=false,ended=false,expiry=null,closed=null;
  const finish=()=>{if(ended)return;ended=true;blob=null;channel.close();win.clearTimeout(expiry);win.clearInterval(closed);win.removeEventListener('pagehide',cancel);onDone();};
  const fail=message=>{if(ended)return;try{channel.postMessage({type:'error',message});}catch{}finish();onError(message);};
  const cancel=()=>{if(!ended)fail('The chart transfer was canceled. Return to the simulator and try again.');};
  const send=()=>{if(ended||!ready||!blob)return;sent=true;channel.postMessage({type:'image',blob,priorTime,excludeSha256});};
  channel.onmessage=event=>{if(ended)return;if(event.data?.type==='ready'){ready=true;send();}else if(event.data?.type==='cancelled'){finish();onStatus('Chart transfer canceled in the matcher tab. Click Open Chart Matcher to try again.');}else if(event.data?.type==='received'&&sent){finish();onStatus('Chart opened in a new tab. Your simulator stays paused here.');}};
  try{
    // Opening before asynchronous encoding preserves the user gesture on mobile and popup blockers.
    popup=win.open('about:blank','_blank');
    if(!popup){fail('The new tab was blocked. Allow pop-ups for this site, then click Open Chart Matcher again.');return cancel;}
    // A brand-new blank tab must not inherit private opener state or keep navigation access to it.
    popup.opener=null;popup.sessionStorage.clear();
    popup.location.replace('/chart-match#'+HANDOFF_PREFIX+token);
    onStatus('Opening Chart Matcher with this visible chart…');
    expiry=win.setTimeout(()=>fail('The chart transfer expired. Return here and click Open Chart Matcher to retry.'),TTL);
    closed=win.setInterval(()=>{if(popup?.closed)fail('The Chart Matcher tab was closed before the chart arrived. Click Open Chart Matcher to retry.');},500);
    win.addEventListener('pagehide',cancel,{once:true});
    canvas.toBlob(value=>{if(ended)return;if(!value||value.size<1||value.size>MAX_BYTES){fail('The chart image could not be prepared. Resize the chart and try again.');return;}blob=value;send();},'image/png');
  }catch{try{popup?.close();}catch{}fail('The new tab could not receive this chart. Allow pop-ups for this site and try again.');}
  return cancel;
}
/** Receives only a bounded PNG. Does not read storage, session data or an opener. */
export function receiveChartMatchHandoff({onImage,onStatus=(_message)=>{},onError=(_message)=>{}},win=window){
  const match=new RegExp('^#'+HANDOFF_PREFIX+'([a-f0-9]{48})$').exec(win.location.hash);
  if(match)receiving.set(win,{token:match[1],expires:Date.now()+TTL});
  const pending=receiving.get(win);if(!pending||pending.expires<=Date.now()){receiving.delete(win);return()=>{};}
  win.clearTimeout(pending.releaseTimer);const subscription=Symbol();pending.active=subscription;
  // Keep reload/back history free of even the ephemeral transfer token.
  win.history.replaceState(win.history.state,'',win.location.pathname+win.location.search);
  if(typeof win.BroadcastChannel!=='function'){onError('Chart transfer is unavailable in this browser. Paste a chart screenshot instead.');return()=>{};}
  const channel=new win.BroadcastChannel(HANDOFF_PREFIX+pending.token);let done=false;
  const cleanup=(discard=false)=>{if(done)return;done=true;win.clearTimeout(timer);if(discard)channel.postMessage({type:'cancelled'});channel.close();if(discard){receiving.delete(win);return;}if(receiving.get(win)===pending)pending.releaseTimer=win.setTimeout(()=>{if(receiving.get(win)===pending&&pending.active===subscription)receiving.delete(win);},0);};
  const timer=win.setTimeout(()=>{receiving.delete(win);cleanup();onError('No chart arrived. Keep the simulator tab open and click Open Chart Matcher there again.');},Math.max(1,pending.expires-Date.now()));
  channel.onmessage=event=>{if(done)return;const data=event.data;if(data?.type==='error'){receiving.delete(win);cleanup();onError('The chart transfer failed. Return to the simulator and click Open Chart Matcher again.');return;}if(data?.type!=='image')return;
    if(!/^[a-f0-9]{64}$/.test(data.excludeSha256)||!/^(?:0[89]|1[0-5]):[0-5][05]$/.test(data.priorTime)||data.priorTime>'15:10'||!(data.blob instanceof Blob)||data.blob.type!=='image/png'||data.blob.size<1||data.blob.size>MAX_BYTES){receiving.delete(win);cleanup();onError('This chart image could not be accepted. Try opening it again from the simulator.');return;}
    channel.postMessage({type:'received'});receiving.delete(win);cleanup();onImage(new File([data.blob],'visible-simulator-chart.png',{type:'image/png'}),data.priorTime,data.excludeSha256);
  };
  onStatus('Receiving the visible simulator chart…');channel.postMessage({type:'ready'});return cleanup;
}
