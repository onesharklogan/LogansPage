import {decodeStats,STATS_BYTES} from './learner-stats.js';
/** Provider-independent learner state. No cookie, localStorage or legacy-profile reads/writes. */
export function safeGoogleAvatarUrl(value){
 if(typeof value!=='string'||value.length>2048||!/^https:\/\/lh3\.googleusercontent\.com\/[A-Za-z0-9_\/=.,~+-]+$/.test(value))return null;
 try{const url=new URL(value);return url.origin==='https://lh3.googleusercontent.com'&&url.pathname!=='/'&&url.href===value?value:null;}catch{return null;}
}
const MODULES=['trade-simulator','market-direction'];
const UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
const opaque=value=>typeof value==='string'&&/^[A-Za-z0-9_-]{16,128}$/.test(value);
const object=value=>!!value&&typeof value==='object'&&!Array.isArray(value);
const integer=value=>Number.isSafeInteger(value)&&value>=0;
const exact=(value,keys)=>object(value)&&Object.keys(value).length===keys.length&&keys.every(key=>Object.hasOwn(value,key));
const sameContext=(a,b)=>!!a&&!!b&&a.accountId===b.accountId&&a.generation===b.generation&&a.sessionTag===b.sessionTag;
function profile(value){return exact(value,['id','name','generation'])&&UUID.test(value.id)&&typeof value.name==='string'&&value.name.trim()===value.name&&value.name.length>=1&&value.name.length<=32&&!/[\u0000-\u001f\u007f]/.test(value.name)&&integer(value.generation);}
function context(value){return exact(value,['accountId','generation','sessionTag'])&&UUID.test(value.accountId)&&integer(value.generation)&&opaque(value.sessionTag);}
function validOwner(payload){return profile(payload?.profile)&&context(payload.context)&&payload.profile.id===payload.context.accountId&&payload.profile.generation===payload.context.generation;}
function freeze(value){if(value&&typeof value==='object'){for(const child of Object.values(value))freeze(child);Object.freeze(value);}return value;}
const empty=()=>({ready:false,reconcileRequired:false,revalidating:false,epoch:0,panelRequest:null,mode:'guest',profile:null,avatarUrl:null,context:null,csrfToken:null,authConfigured:false,busy:null,error:null,preferences:{equalTpSl:false},progress:null,completedLessons:null,attempts:[],nextCursor:null,resetReady:false,signOutNeeded:false});
export class LearnerClientError extends Error{constructor(message,code='request_failed',status=0){super(message);this.name='LearnerClientError';this.code=code;this.status=status;}}
// Public support codes contain only a fixed stage and, where applicable, an
// integer HTTP status. Never serialize provider errors, URLs, bodies or causes.
const GOOGLE_DIAGNOSTIC_CODES=Object.freeze({sdk_load:'G01',sdk_request:'G02',server_handler:'G03',response_shape:'G04',destination_policy:'G05',scope_policy:'G06',navigation:'G07'});
function ownDiagnosticValue(value,key){const descriptor=Object.getOwnPropertyDescriptor(value,key);if(!descriptor||!Object.hasOwn(descriptor,'value'))return undefined;return descriptor.value;}
export function googleSignInDiagnostic(value){
 try{
  if(!value||typeof value!=='object'||Array.isArray(value))return null;
  const keys=Reflect.ownKeys(value),hasMasks=keys.includes('destinationMask')||keys.includes('scopeMask');if(keys.length!==(hasMasks?4:2)||!keys.includes('stage')||!keys.includes('httpStatus')||hasMasks&&(!keys.includes('destinationMask')||!keys.includes('scopeMask')))return null;
  const stage=ownDiagnosticValue(value,'stage'),httpStatus=ownDiagnosticValue(value,'httpStatus');
  if(typeof stage!=='string'||!Object.hasOwn(GOOGLE_DIAGNOSTIC_CODES,stage))return null;
  if(stage==='server_handler'){if(httpStatus!==503)return null;}
  else if(stage==='sdk_request'){if(httpStatus!==null&&(!Number.isInteger(httpStatus)||httpStatus<100||httpStatus>599))return null;}
  else if(httpStatus!==null)return null;
  if(hasMasks){const destinationMask=ownDiagnosticValue(value,'destinationMask'),scopeMask=ownDiagnosticValue(value,'scopeMask');if(!Number.isInteger(destinationMask)||!Number.isInteger(scopeMask)||scopeMask<0||scopeMask>15||!(stage==='destination_policy'&&destinationMask>=1&&destinationMask<=31||stage==='scope_policy'&&destinationMask===0&&scopeMask>=1))return null;return Object.freeze({stage,httpStatus,destinationMask,scopeMask});}
  return Object.freeze({stage,httpStatus});
 }catch{return null;}
}
export function createGoogleSignInFailure(stage,httpStatus=null,destinationMask,scopeMask){
 const diagnostic=googleSignInDiagnostic({stage,httpStatus,...(destinationMask===undefined&&scopeMask===undefined?{}:{destinationMask,scopeMask})})||Object.freeze({stage:'sdk_request',httpStatus:null});
 const support=GOOGLE_DIAGNOSTIC_CODES[diagnostic.stage]+(diagnostic.httpStatus===null?'':'-'+diagnostic.httpStatus)+(diagnostic.destinationMask===undefined?'':'-D'+String(diagnostic.destinationMask).padStart(2,'0')+'-S'+String(diagnostic.scopeMask).padStart(2,'0'));
 const error=new LearnerClientError('Google sign-in could not be completed. Try again. ('+support+')','google_initiation_failed');
 Object.defineProperty(error,'diagnostic',{value:diagnostic});return error;
}
function driverDiagnostic(error){try{return googleSignInDiagnostic(ownDiagnosticValue(error,'diagnostic'));}catch{return null;}}
const stale=()=>new LearnerClientError('This account action is no longer current.','stale_action');
function preferences(value){if(!exact(value,['equalTpSl'])||typeof value.equalTpSl!=='boolean')throw new LearnerClientError('Account preferences could not be verified.','invalid_response');return value;}
function decodeSession(payload){
 if(payload?.mode==='guest'&&payload.authConfigured===true&&payload.profile===null)return{...empty(),ready:true,authConfigured:true};
 if(payload?.mode!=='account'||payload.authConfigured!==true||!validOwner(payload)||!opaque(payload.csrfToken))throw new LearnerClientError('The account response could not be verified.','invalid_response');
 return{...empty(),ready:true,mode:'account',authConfigured:true,profile:payload.profile,avatarUrl:safeGoogleAvatarUrl(payload.avatarUrl),context:payload.context,csrfToken:payload.csrfToken,preferences:preferences(payload.preferences??{equalTpSl:false})};
}
function decodeProgress(value){
 const finite=n=>typeof n==='number'&&Number.isFinite(n);
 if(!object(value)||!integer(value.completedAttempts)||!object(value.byModule)||!MODULES.every(key=>integer(value.byModule[key]))||!object(value.trade)||!['trades','wins','losses','flats'].every(key=>integer(value.trade[key]))||!['netPoints','grossProfit','grossLoss'].every(key=>finite(value.trade[key]))||!object(value.direction)||!['practicedIntervals','practicedLongIntervals','practicedShortIntervals','practicedNeutralIntervals'].every(key=>integer(value.direction[key]))||!['netAlignedPoints','favorablePoints','adversePoints'].every(key=>finite(value.direction[key]))||value.skillScore!==null)throw new LearnerClientError('Saved progress could not be verified.','invalid_response');
 return value;
}
function decodeAttempts(attempts){
 if(!Array.isArray(attempts)||attempts.length>25||attempts.some(value=>!object(value)||!UUID.test(value.id)||!MODULES.includes(value.module)||typeof value.chartId!=='string'||value.chartId.length<1||value.chartId.length>128||!/^[a-f0-9]{64}$/.test(value.chartSha256)||!['startedAt','completedAt','savedAt'].every(key=>typeof value[key]==='string'&&Number.isFinite(Date.parse(value[key])))||!object(value.summary)))throw new LearnerClientError('Saved attempt summaries could not be verified.','invalid_response');
 return attempts;
}
function safeMessage(payload,fallback){return typeof payload?.error==='string'&&payload.error.length>0&&payload.error.length<=240?payload.error:fallback;}
async function jsonResponse(response,limit){
 if(!response.headers.get('content-type')?.toLowerCase().includes('application/json'))throw new LearnerClientError('The account service returned an unreadable response.','invalid_response',response.status);
 const declared=response.headers.get('content-length');if(declared!==null&&(!/^\d+$/.test(declared)||Number(declared)>limit))throw new LearnerClientError('The account response is too large.','response_limit',response.status);
 const reader=response.body?.getReader();let text='';
 if(reader){const decoder=new TextDecoder('utf-8',{fatal:true});let size=0;try{for(;;){const part=await reader.read();if(part.done)break;size+=part.value.byteLength;if(size>limit){await reader.cancel();throw new LearnerClientError('The account response is too large.','response_limit',response.status);}text+=decoder.decode(part.value,{stream:true});}text+=decoder.decode();}finally{reader.releaseLock();}}
 else{text=await response.text();if(new TextEncoder().encode(text).byteLength>limit)throw new LearnerClientError('The account response is too large.','response_limit',response.status);}
 try{return JSON.parse(text);}catch{throw new LearnerClientError('The account response could not be read.','invalid_response',response.status);}
}
export function createLearnerClient({fetcher=(input,init)=>fetch(input,init),randomUUID=()=>crypto.randomUUID(),now=()=>Date.now()}={}){
 let state=freeze(empty()),epoch=0,ownerEpoch=0,request=0,panelRequestId=0,controllers=new Set(),resetIntent=null,guestOverride=false,authPending=null,authReconciliation=null,authSessionPending=false,completionRevision=0,completionWrite=false;
 const listeners=new Set();
 const notify=patch=>{const next={...state,...patch};if(state.authConfigured!==next.authConfigured||state.mode!==next.mode||!((state.context===null&&next.context===null)||sameContext(state.context,next.context)))ownerEpoch++;state=freeze({...next,epoch:ownerEpoch});for(const listener of listeners)listener(state);return state;};
 function invalidate(){epoch++;request++;for(const controller of controllers)controller.abort();controllers.clear();resetIntent=null;}
 const current=(ticket,owner)=>ticket===epoch&&(!owner||sameContext(state.context,owner));
 const controller=()=>{const value=new AbortController();controllers.add(value);return value;};
 const cleanup=value=>controllers.delete(value);
 async function api(path,{method='GET',body,signal,csrfToken=state.csrfToken,limit=1024*1024}={}){
  const headers={Accept:'application/json'};if(method!=='GET'){headers['Content-Type']='application/json';if(csrfToken)headers['X-CSRF-Token']=csrfToken;}
  const response=await fetcher('/api/learner/'+path,{method,credentials:'same-origin',cache:'no-store',redirect:'error',headers,...(body?{body:JSON.stringify(body)}:{}),signal});
  const payload=await jsonResponse(response,limit);
  if(!response.ok)throw new LearnerClientError(safeMessage(payload,'The account service could not complete this request.'),typeof payload?.code==='string'?payload.code:'request_failed',response.status);
  return payload;
 }
 function error(error,ticket,owner){
  if(!current(ticket,owner))return;
  if(error?.name==='AbortError'||error?.code==='stale_action')return;
  if(error?.code==='auth_unavailable'){invalidate();notify({...empty(),ready:true,authConfigured:false,error:'Account sign-in is not configured yet. Continue as Guest.'});return;}
  if(error?.status===401||error?.code==='session_changed'||error?.code==='generation_conflict'||error?.code==='account_changed'){
   invalidate();notify({...empty(),reconcileRequired:true,signOutNeeded:state.signOutNeeded,authConfigured:state.authConfigured,error:'Your sign-in or saved practice changed. Refresh before continuing.'});return;
  }
  notify({busy:null,...(error?.code==='auth_unavailable'?{ready:true,reconcileRequired:false}:{}),error:error instanceof LearnerClientError?error.message:'The account service is unavailable. No success has been confirmed.',...(error?.code==='auth_unavailable'?{authConfigured:false}:{})});
 }
 function owner(){if(!state.ready||state.reconcileRequired||state.revalidating||authPending||guestOverride||!state.profile||!state.context||!state.csrfToken)throw new LearnerClientError('Sign in to track account history. Guest practice is not saved.','sign_in_required');return{...state.context};}
 async function refresh({force=false,signOutCheck=false}={}){
  if(state.signOutNeeded&&!signOutCheck)return state;
  if(guestOverride&&!force)return state;
  if(authPending||authSessionPending)return state;
  if(state.busy&&!force)return state;
  const ticket=epoch,read=++request,c=controller();notify({revalidating:true});
  try{const payload=await api('session',{signal:c.signal});if(ticket!==epoch||read!==request)throw stale();const decoded=decodeSession(payload),next=state.signOutNeeded?{...decoded,signOutNeeded:true}:decoded;
   if(!sameContext(state.context,next.context)){invalidate();guestOverride=false;notify(next);}else notify({...next,progress:state.progress,completedLessons:state.completedLessons,attempts:state.attempts,nextCursor:state.nextCursor});return state;
  }catch(e){if(ticket===epoch&&read===request){notify({ready:false,reconcileRequired:true,revalidating:false});error(e,ticket);}return state;}finally{cleanup(c);}
 }
 async function loadDetails(){
  let account;try{account=owner();}catch{return state;}if(state.busy)return state;
  const ticket=epoch,c=controller();notify({busy:'Loading saved practice…',error:null});
  try{const [history,progress]=await Promise.all([api('attempts?limit=25',{signal:c.signal}),api('progress',{signal:c.signal})]);if(!current(ticket,account)||state.revalidating||!state.ready||state.reconcileRequired||state.signOutNeeded)throw stale();
   if(!sameContext(history.context,account)||!sameContext(progress.context,account)||!Array.isArray(history.attempts)||history.attempts.length>25||!(history.nextCursor===null||typeof history.nextCursor==='string'&&history.nextCursor.length<=512))throw new LearnerClientError('Saved practice belongs to a different or changed account.','invalid_response');
   notify({busy:null,progress:decodeProgress(progress.progress),attempts:decodeAttempts(history.attempts),nextCursor:history.nextCursor,error:null});return state;
  }catch(e){error(e,ticket,account);return state;}finally{cleanup(c);}
 }
 async function authenticate(driver,kind,credentials){
  if(kind!=='signIn'||typeof driver?.[kind]!=='function'||!state.authConfigured)throw new LearnerClientError('Account sign-in is not configured yet. Continue as Guest.','auth_unavailable');
  if(state.busy||!state.ready||state.reconcileRequired||state.revalidating||authPending)throw new LearnerClientError('Wait for the current account action to finish.','busy');
  invalidate();guestOverride=false;const ticket=epoch,c=controller();notify({...empty(),authConfigured:true,reconcileRequired:true,busy:'Opening Google sign-in…'});
  let providerFailed=false,providerDiagnostic=null;
  try{
   authPending=Promise.resolve().then(()=>driver[kind]({...credentials,signal:c.signal}));try{await authPending;}catch(error){providerFailed=true;providerDiagnostic=driverDiagnostic(error);}authPending=null;authSessionPending=true;
   if(!current(ticket)){authSessionPending=false;await reconcileAuth();throw stale();}
   const payload=await api('session',{signal:c.signal});if(!current(ticket)){authSessionPending=false;await reconcileAuth();throw stale();}const next=decodeSession(payload);notify(next);
   if(next.mode!=='account'){const detail=providerFailed&&providerDiagnostic?createGoogleSignInFailure(providerDiagnostic.stage,providerDiagnostic.httpStatus,providerDiagnostic.destinationMask,providerDiagnostic.scopeMask):null,failure=new LearnerClientError(providerFailed?detail?.message??'Google sign-in could not be completed. Try again.':'Google sign-in is not confirmed. Please try again.','sign_in_unconfirmed');if(detail)Object.defineProperty(failure,'diagnostic',{value:detail.diagnostic});notify({error:failure.message});throw failure;}
   return state;
  }catch(e){authPending=null;authSessionPending=false;if(!current(ticket)){authSessionPending=false;await reconcileAuth();throw stale();}error(e,ticket);throw e;}finally{authSessionPending=false;cleanup(c);}
 }

 async function retrySignOut(driver){
  if(!state.signOutNeeded)throw new LearnerClientError('No unfinished sign-out needs retrying.','sign_out_not_pending');
  if(typeof driver?.signOut!=='function')throw new LearnerClientError('Provider sign-out is not configured. Sign-out cannot yet be confirmed.','provider_unavailable');
  invalidate();guestOverride=false;const ticket=epoch,c=controller();notify({ready:false,reconcileRequired:true,signOutNeeded:true,busy:'Finishing sign-out…',error:null,attempts:[],progress:null});
  try{await driver.signOut({signal:c.signal});if(ticket!==epoch)throw stale();await refresh({force:true,signOutCheck:true});if(state.mode!=='guest'||!state.ready||!state.authConfigured||state.error)throw new LearnerClientError('Sign-out is not confirmed by the account service.','sign_out_unconfirmed');guestOverride=true;notify({signOutNeeded:false,busy:null});return state;}
  catch(e){if(ticket===epoch||state.reconcileRequired)notify({busy:null,ready:false,reconcileRequired:true,signOutNeeded:true,error:'Provider sign-out could not be confirmed. Retry sign-out before sharing this browser.'});throw e;}finally{cleanup(c);}
 }
 async function logout(driver){
  const account=owner();if(state.busy)throw new LearnerClientError('Wait for the current account action to finish.','busy');
  const csrfToken=state.csrfToken;invalidate();const ticket=epoch,c=controller();notify({busy:'Signing out…',error:null,signOutNeeded:true,attempts:[],progress:null,resetReady:false});
  try{const payload=await api('logout',{method:'POST',body:{context:account},csrfToken,signal:c.signal});if(!current(ticket,account))throw stale();if(payload?.mode!=='guest'||payload.signedOut!==true)throw new LearnerClientError('Sign-out could not be confirmed.','invalid_response');notify({...empty(),reconcileRequired:true,signOutNeeded:true,authConfigured:payload.authConfigured===true});}
  catch(e){error(e,ticket,account);if(current(ticket))notify({ready:false,reconcileRequired:true,signOutNeeded:true,error:'App sign-out could not be confirmed. Retry sign-out before sharing this browser.'});throw e;}finally{cleanup(c);}
  return retrySignOut(driver);
 }

 async function prepareReset(){
  const account=owner();if(state.busy)throw new LearnerClientError('Wait for the current account action to finish.','busy');const ticket=epoch,c=controller(),capture=captureContext();resetIntent=null;notify({busy:'Preparing reset confirmation…',error:null,resetReady:false});
  try{const payload=await api('reset-intent',{method:'POST',body:{context:account},signal:c.signal});if(!current(ticket,account)||!guard(capture))throw stale();if(!sameContext(payload.context,account)||!opaque(payload.token)||!Number.isFinite(Date.parse(payload.expiresAt))||Date.parse(payload.expiresAt)<=now())throw new LearnerClientError('Reset confirmation expired or could not be verified.','invalid_response');resetIntent={token:payload.token,expiresAt:Date.parse(payload.expiresAt),context:account,requestId:randomUUID()};notify({busy:null,resetReady:true});return state;
  }catch(e){error(e,ticket,account);throw e;}finally{cleanup(c);}
 }
 async function reset(confirmation){
  const account=owner(),intent=resetIntent;if(confirmation!=='RESET MY HISTORY'||!intent||!sameContext(intent.context,account)||intent.expiresAt<=now())throw new LearnerClientError('Prepare a new reset confirmation before continuing.','confirmation_required');if(state.busy)throw new LearnerClientError('Wait for the current account action to finish.','busy');
  const ticket=epoch,c=controller();notify({busy:'Resetting your saved practice…',error:null});
  try{const payload=await api('reset',{method:'POST',body:{context:account,token:intent.token,confirmation,requestId:intent.requestId},signal:c.signal});if(!current(ticket,account))throw stale();if(payload.reset!==true||!validOwner(payload)||payload.context.accountId!==account.accountId||payload.context.sessionTag!==account.sessionTag||payload.context.generation!==account.generation+1)throw new LearnerClientError('Reset could not be verified. Refresh before continuing.','invalid_response');
   const verificationPending=state.revalidating||!state.ready||state.reconcileRequired;invalidate();notify({ready:!verificationPending,reconcileRequired:verificationPending,revalidating:false,profile:payload.profile,context:payload.context,busy:null,error:null,preferences:preferences(payload.preferences??state.preferences),progress:null,completedLessons:null,attempts:[],nextCursor:null,resetReady:false});if(verificationPending)void refresh({force:true});return state;
  }catch(e){error(e,ticket,account);throw e;}finally{cleanup(c);}
 }
 async function exportHistory(){
  const account=owner(),capture=captureContext();if(state.busy)throw new LearnerClientError('Wait for the current account action to finish.','busy');const ticket=epoch,c=controller();notify({busy:'Preparing history download…',error:null});
  try{const payload=await api('export',{signal:c.signal,limit:10*1024*1024});if(!current(ticket,account)||!guard(capture))throw stale();if(payload.version!==1||!validOwner(payload)||!sameContext(payload.context,account)||!Array.isArray(payload.attempts))throw new LearnerClientError('History download could not be verified.','invalid_response');notify({busy:null});return payload;}catch(e){error(e,ticket,account);throw e;}finally{cleanup(c);}
 }
 async function listAttempts({module,cursor,limit=25}={},capture){
  if(!guard(capture)||capture.mode!=='account'||!Number.isSafeInteger(limit)||limit<1||limit>50||module!==undefined&&!MODULES.includes(module)||cursor!==undefined&&(typeof cursor!=='string'||cursor.length>512))throw new LearnerClientError('This account history request is not valid.','stale_action');
  const account=owner(),ticket=epoch,c=controller(),query=new URLSearchParams({limit:String(limit)});if(module)query.set('module',module);if(cursor)query.set('cursor',cursor);
  try{const payload=await api('attempts?'+query.toString(),{signal:c.signal});if(!current(ticket,account)||!guard(capture))throw stale();if(!sameContext(payload.context,account)||!Array.isArray(payload.attempts)||payload.attempts.length>limit||!(payload.nextCursor===null||typeof payload.nextCursor==='string'&&payload.nextCursor.length<=512))throw new LearnerClientError('Saved history could not be verified.','invalid_response');for(const attempt of payload.attempts)decodeAttempts([attempt]);return payload;}
  catch(e){error(e,ticket,account);throw e;}finally{cleanup(c);}
 }
 async function getStats(capture,{signal}={}){
  if(!guard(capture)||capture.mode!=='account'||signal?.aborted)throw stale();
  const account=owner(),ticket=epoch,c=controller(),abort=()=>c.abort();signal?.addEventListener('abort',abort,{once:true});
  try{const payload=await api('stats',{signal:c.signal,limit:STATS_BYTES});if(c.signal.aborted||!current(ticket,account)||!guard(capture))throw stale();
   if(!sameContext(payload?.context,account))throw new LearnerClientError('Saved stats belong to a different account.','invalid_response');
   try{decodeStats(payload);}catch{throw new LearnerClientError('Saved stats could not be verified.','invalid_response');}return freeze(payload);
  }catch(e){error(e,ticket,account);throw e;}finally{signal?.removeEventListener('abort',abort);cleanup(c);}
 }
 async function saveAttempt(attempt,capture){
  if(!guard(capture)||capture.mode!=='account')throw new LearnerClientError('This attempt no longer belongs to the current signed-in account.','stale_action');
  const account=owner(),ticket=epoch,c=controller();
  try{const payload=await api('attempts',{method:'POST',body:{context:account,attempt},signal:c.signal});if(!current(ticket,account)||!guard(capture))throw stale();if(!sameContext(payload.context,account)||typeof payload.duplicate!=='boolean')throw new LearnerClientError('The saved attempt could not be verified.','invalid_response');decodeAttempts([payload.attempt]);if(!['id','module','chartId','chartSha256','startedAt','completedAt'].every(key=>payload.attempt[key]===attempt[key]))throw new LearnerClientError('The saved result does not match this attempt.','invalid_response');return payload;}
  catch(e){error(e,ticket,account);throw e;}finally{cleanup(c);}
 }
 async function savePreferences(equalTpSl,capture){
  if(typeof equalTpSl!=='boolean'||!guard(capture)||capture.mode!=='account')throw stale();
  const account=owner(),ticket=epoch,c=controller();
  try{const payload=await api('preferences',{method:'POST',body:{context:account,equalTpSl},signal:c.signal});if(!current(ticket,account)||!guard(capture))throw stale();if(!sameContext(payload.context,account)||preferences(payload.preferences).equalTpSl!==equalTpSl)throw new LearnerClientError('The account preference could not be verified.','invalid_response');notify({preferences:payload.preferences});return payload.preferences;}catch(e){error(e,ticket,account);throw e;}finally{cleanup(c);}
 }
 async function getAttempt(id,capture){
  if(!UUID.test(id)||!guard(capture)||capture.mode!=='account')throw new LearnerClientError('This account history is no longer current.','stale_action');
  const account=owner(),ticket=epoch,c=controller();
  try{const payload=await api('attempts/'+id,{signal:c.signal});if(!current(ticket,account)||!guard(capture))throw stale();if(!sameContext(payload.context,account)||!object(payload.attempt)||payload.attempt.id!==id||payload.attempt.version!==1||!object(payload.attempt.practice))throw new LearnerClientError('The saved attempt could not be verified.','invalid_response');decodeAttempts([payload.attempt]);return payload.attempt;}
  catch(e){error(e,ticket,account);throw e;}finally{cleanup(c);}
 }
 function decodeLessonCompletions(payload,account){
  const values=payload?.completedLessons;
  if(!sameContext(payload?.context,account)||!Array.isArray(values)||values.length>5000||values.some(key=>typeof key!=='string'||!/^(folder|sequence):[A-Za-z0-9_-]{1,90}$/.test(key))||new Set(values).size!==values.length)throw new LearnerClientError('Lesson checkmarks could not be verified.','invalid_response');
  return values;
 }
 async function loadLessonCompletions(capture){
  if(!guard(capture)||capture.mode!=='account')throw stale();
  const account=owner(),ticket=epoch,revision=completionRevision,c=controller();
  try{const payload=await api('lesson-completions',{signal:c.signal});if(!current(ticket,account)||!guard(capture))throw stale();const completedLessons=decodeLessonCompletions(payload,account);if(revision===completionRevision&&!completionWrite)notify({completedLessons});return completedLessons;}
  catch(e){error(e,ticket,account);throw e;}finally{cleanup(c);}
 }
 async function saveLessonCompletion(capture,lessonKey,completed){
  if(!guard(capture)||capture.mode!=='account')throw stale();
  if(typeof lessonKey!=='string'||!/^(folder|sequence):[A-Za-z0-9_-]{1,90}$/.test(lessonKey)||typeof completed!=='boolean')throw new LearnerClientError('This Lesson checkmark is invalid.','invalid_request');
  if(completionWrite)throw new LearnerClientError('A Lesson checkmark is being saved. Please retry in a moment.','busy');
  const account=owner(),ticket=epoch,c=controller();completionWrite=true;completionRevision++;
  try{const payload=await api('lesson-completions',{method:'POST',body:{context:account,lessonKey,completed},signal:c.signal});if(!current(ticket,account)||!guard(capture))throw stale();const completedLessons=decodeLessonCompletions(payload,account);if(completedLessons.includes(lessonKey)!==completed)throw new LearnerClientError('The Lesson checkmark save could not be confirmed. Retry.','invalid_response');notify({completedLessons});return completedLessons;}
  catch(e){error(e,ticket,account);throw e;}finally{completionWrite=false;cleanup(c);}
 }
 async function reconcileAuth(){
  if(authReconciliation)return authReconciliation;
  authReconciliation=(async()=>{guestOverride=false;notify({ready:false,reconcileRequired:true,busy:null});await refresh({force:true});if(!state.ready)notify({error:'Sign-in state could not be confirmed. Retry the account check before continuing.'});return state;})().finally(()=>{authReconciliation=null;});return authReconciliation;
 }
 function captureContext(){return state.ready&&!state.reconcileRequired&&!state.revalidating&&!state.signOutNeeded&&!authPending?freeze({mode:state.mode,epoch:ownerEpoch,context:state.context}):null;}
 function ownsCapture(capture){return !!capture&&!state.signOutNeeded&&!authPending&&capture.epoch===ownerEpoch&&capture.mode===state.mode&&(state.mode==='guest'||sameContext(capture.context,state.context));}
 function guard(capture){return state.ready&&!state.reconcileRequired&&!state.revalidating&&ownsCapture(capture);}
 return Object.freeze({captureContext,guard,ownsCapture,revalidate:()=>refresh({force:true}),getSnapshot:()=>state,subscribe(listener){listeners.add(listener);return()=>listeners.delete(listener);},refresh,loadDetails,loadLessonCompletions,saveLessonCompletion,authenticate,logout,retrySignOut,prepareReset,reset,exportHistory,savePreferences,saveAttempt,getAttempt,listAttempts,getStats,requestPanel({view='details',module}={}){if(!['details','history'].includes(view)||module!==undefined&&!MODULES.includes(module))return false;notify({panelRequest:{id:++panelRequestId,view,module}});return true;},
  continueAsGuest(){if(!state.ready||state.reconcileRequired||state.revalidating||authPending)throw new LearnerClientError('Wait for sign-in state to be checked before continuing as Guest.','session_unresolved');if(state.profile)throw new LearnerClientError('Sign out before switching to Guest.','sign_out_required');invalidate();ownerEpoch++;guestOverride=true;notify({...empty(),ready:true,authConfigured:state.authConfigured});return state;},
  cancelAuthentication(){if(authPending||authSessionPending)this.cancelPending();},
  cancelPending(){const authUncertain=!!authPending||authSessionPending;invalidate();notify({busy:null,resetReady:false,...(authUncertain?{ready:false,reconcileRequired:true,error:'Checking sign-in state after cancellation…'}:{})});if(authPending)void authPending.catch(()=>{}).then(()=>{authPending=null;return reconcileAuth();});},
 });
}

/** One in-memory account state for all same-page modules; full navigation rechecks /session. */
export const learnerClient=createLearnerClient();
