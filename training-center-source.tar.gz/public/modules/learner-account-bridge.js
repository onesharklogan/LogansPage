/** Market Direction account adapter. No browser-profile imports or persistent storage.
 * Server identity lives in the canonical learner client; this adapter owns one
 * captured page generation and deliberately never adopts a later account. */
import {loadHistoryCandleIndex} from './history-candle-data.js';
import {deriveDirectionBuckets} from './history-time-buckets.js';
const UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
const copy=value=>JSON.parse(JSON.stringify(value));
const need=(ok,message)=>{if(!ok)throw Error(message);};
const iso=value=>typeof value==='string'&&/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(value)&&Number.isFinite(Date.parse(value));
export function memoryStorage(){const values=new Map();return Object.freeze({get length(){return values.size;},key:index=>[...values.keys()][index]??null,getItem:key=>values.has(String(key))?values.get(String(key)):null,setItem:(key,value)=>{values.set(String(key),String(value));},removeItem:key=>{values.delete(String(key));},clear:()=>values.clear()});}
const disabled=Object.freeze({enabled:false,redirected:false,guard:()=>true,canMutate:()=>true,navigationReady:()=>true,dispose(){}});
export function createMarketDirectionAccountBridge({client,canPractice=()=>true,requestPanel=()=>false,randomUUID=()=>crypto.randomUUID(),now=()=>new Date().toISOString()}={}){
 const initial=client.getSnapshot();
 need(initial.ready&&!initial.reconcileRequired,'Your sign-in state could not be confirmed. Retry before practicing.');
 if(initial.authConfigured===false)return disabled;
 need(initial.authConfigured===true&&['guest','account'].includes(initial.mode),'Your sign-in state could not be confirmed.');
 const capture=client.captureContext();need(capture&&client.guard(capture),'The learner account changed before practice started.');
 const profile=initial.mode==='account'?{name:initial.profile.name,learnerId:initial.profile.id}:{name:'Guest',learnerId:randomUUID()};
 need(UUID.test(profile.learnerId),'The learner identity could not be verified.');
 const storage=memoryStorage(),sources=new Map(),runs=new Map(),listeners=new Set();let disposed=false,changed=false,pending=null,failure=null,latest=null;
 function guard(){const snapshot=client.getSnapshot();return !disposed&&!changed&&snapshot.ready&&!snapshot.reconcileRequired&&!snapshot.signOutNeeded&&client.guard(capture);}
 function ownerValid(){return !disposed&&!changed&&(client.ownsCapture?client.ownsCapture(capture):guard());}
 function status(){return Object.freeze({valid:guard(),ownerValid:ownerValid(),pending:!!pending,error:failure,message:!guard()?(ownerValid()?'Checking your learner account. Practice is paused until verification finishes.':'Your learner account or saved history changed. Reload before continuing.'):failure||(pending?'Saving completed practice to your account…':initial.mode==='guest'?'Guests will not be able to track their history + skill progress':'Completed practice is saved to your learner account. In-progress practice stays on this page.')});}
 function notify(){const value=status();for(const fn of listeners)fn(value);}
 const unsubscribe=client.subscribe(()=>{if(!ownerValid()){changed=true;storage.clear();sources.clear();runs.clear();failure=null;latest=null;}notify();});
 function own(){need(guard(),'Your learner account or saved history changed. Reload before continuing.');}
 function rememberSource(reference){own();if(reference?.kind!=='historical'||!/^mes1-\d{4}-\d{2}-\d{2}-81$/.test(reference?.id)||!/^[a-f0-9]{64}$/.test(reference?.sha256))return false;const previous=sources.get(reference.id);need(!previous||previous.sha256===reference.sha256,'This chart source changed. Reload before continuing.');sources.set(reference.id,{id:reference.id,sha256:reference.sha256});return true;}
 function start(runID,chartId){own();if(runs.has(runID))return;const source=sources.get(chartId);if(!source)return;const id=randomUUID(),startedAt=now();need(UUID.test(id)&&iso(startedAt),'A private attempt identity could not be created.');runs.set(runID,{id,startedAt,source,payload:null,saved:false});}
 async function send(record){own();if(initial.mode==='guest')return{guest:true};if(record.saved)return{saved:true,duplicate:true};if(pending){if(pending.record===record)return pending.promise;throw Error('Wait for the completed practice save.');}
  failure=null;const task={record,promise:null};pending=task;
  task.promise=Promise.resolve().then(()=>client.saveAttempt(copy(record.payload),capture)).then(result=>{own();need(result?.attempt?.id===record.id&&result.attempt.module==='market-direction'&&result.attempt.chartId===record.source.id&&result.attempt.chartSha256===record.source.sha256&&result.attempt.startedAt===record.payload.startedAt&&result.attempt.completedAt===record.payload.completedAt,'The saved attempt response did not match this practice. Retry to verify it.');record.saved=true;return result;}).catch(error=>{if(ownerValid())failure=error instanceof Error?error.message:'The account save was not confirmed. Keep this page open and retry.';throw error;}).finally(()=>{if(pending===task)pending=null;notify();});notify();return task.promise;
 }
 async function complete(runID,run,finalBar,completedAt){own();if(initial.mode==='guest')return{guest:true};const record=runs.get(runID);if(!record)return{unsupported:true};if(!record.payload){need(iso(completedAt)&&Date.parse(completedAt)>=Date.parse(record.startedAt),'The practice completion time could not be verified.');need(run&&[1,2].includes(run.version)&&run.practiceCutoff!==null,'Complete the recorded practice before saving.');const normalized={version:run.version,...(run.startBar===undefined?{}:{startBar:run.startBar}),choices:copy(run.choices),practiceCutoff:run.practiceCutoff};record.payload={version:1,id:record.id,module:'market-direction',chartId:record.source.id,chartSha256:record.source.sha256,startedAt:record.startedAt,completedAt,practice:{run:normalized,finalBar}};}latest=record;return send(record);}
 async function history(catalog){own();if(initial.mode==='guest')return{history:[],attempts:[],importDone:[]};need(Array.isArray(catalog),'The chart catalog could not be verified.');const index=await loadHistoryCandleIndex();own();const references=new Map(catalog.map(row=>[row.id,row])),all=[],cursors=new Set();let cursor;
  for(;;){const page=await client.listAttempts({module:'market-direction',limit:50,...(cursor?{cursor}:{})},capture);own();for(const row of page.attempts){need(row.module==='market-direction','Account history returned a different simulator. Nothing was mixed.');need(all.length<1000&&!all.some(a=>a.id===row.id),'Account history is duplicated or exceeds its limit.');all.push(row);}if(!page.nextCursor)break;need(!cursors.has(page.nextCursor),'Account history pagination did not advance.');cursors.add(page.nextCursor);cursor=page.nextCursor;}
  const byId=new Map(index.sessions.map(row=>[row.id,row])),attempts=[],first=new Map();all.sort((a,b)=>Date.parse(a.savedAt)-Date.parse(b.savedAt)||a.id.localeCompare(b.id));
  for(const item of all){own();const source=byId.get(item.chartId),reference=references.get(item.chartId);need(source&&reference&&source.sourceSha256===item.chartSha256&&reference.sha256===item.chartSha256,'An exact historical chart is unavailable. No account history was mixed with local data.');const s=copy(item.summary),proof=s.practiceEvidence||s.directionAccuracy;need(proof&&Array.isArray(proof.choices)&&proof.practiceCutoff!==null,'An older account attempt has no complete practice evidence. Download account history to inspect it.');const start=proof.startBar??0,final=s.finalBar,exposures=Array(81).fill(0),bias=Array(81).fill(0),flips=[];need(Number.isSafeInteger(final)&&final>=proof.practiceCutoff&&final<=81,'Saved practice range is invalid.');for(let i=start;i<final;i++){const choice=proof.choices[Math.min(i-start,proof.choices.length-1)];need(choice&&[-1,0,1].includes(choice.direction),'Saved practice choices are invalid.');bias[i]=choice.direction;if(i+1<final)exposures[i+1]=choice.direction;if(i>start&&bias[i-1]!==0&&choice.direction!==bias[i-1]&&i<proof.practiceCutoff)flips.push({bar:i,direction:choice.direction});}
   const report={...s,definition:'close-bias-v1',key:source.key,sessionBars:81,firstBar:start+1,sessionDate:reference.date,chartId:reference.id,sampleType:'hosted historical (publisher-supplied)',hosted:{id:reference.id,title:reference.title},completedAt:item.completedAt,flipEvents:flips,accuracy:s.eligibleBars?s.correctBars/s.eligibleBars:null};
   // Reuse the unchanged points/bucket validator. It checks neutral, carry,
   // legs and source closes without storing or inventing candle evidence.
   const attempt={id:item.id,sessionKey:source.key,completedAt:item.completedAt,report,decisions:{exposures,bias,flips}};
   const verified=deriveDirectionBuckets({learnerId:profile.learnerId,reports:[report],attempts:[attempt],closesByKey:new Map([[source.key,source]])},profile.learnerId);need(verified.unallocatedCount===0,'Saved practice does not reconcile with the exact chart.');attempts.push(attempt);if(!first.has(source.key))first.set(source.key,report);
  }
  own();return{history:[...first.values()],attempts,importDone:[...first.keys()].map(key=>key.slice(4))};
 }
 return Object.freeze({enabled:true,redirected:false,mode:initial.mode,profile:Object.freeze(profile),storage,guard,ownerValid,canMutate:()=>guard()&&canPractice()&&!pending&&!failure,navigationReady:()=>guard()&&!pending&&!failure,rememberSource,start,complete,history,status,subscribe(fn){listeners.add(fn);return()=>listeners.delete(fn);},requestPanel(){own();return requestPanel({view:'details',module:'market-direction'});},retry(){own();need(latest?.payload,'No completed practice save needs retrying.');return send(latest);},dispose(){disposed=true;unsubscribe();storage.clear();sources.clear();runs.clear();listeners.clear();}});
}
export async function connectMarketDirectionAccount({windowObject=window,loadClient=()=>import('/modules/learner-client.js')}={}){
 let host=null;try{if(windowObject.parent!==windowObject&&windowObject.parent.location.origin===windowObject.location.origin)host=windowObject.parent.PriceActionLearner||null;}catch{}
 const client=host?.client||(await loadClient()).learnerClient;
 if(!host)await client.refresh();
 const snapshot=client.getSnapshot();need(snapshot.ready&&!snapshot.reconcileRequired,'Your sign-in state could not be confirmed. Retry before practicing.');
 if(snapshot.authConfigured===false)return disabled;
 need(snapshot.authConfigured===true,'The account readiness check could not be verified.');
 if(!host){const input=new URLSearchParams(windowObject.location.search||''),query=new URLSearchParams();if(input.get('history')==='1')query.set('history','1');if(UUID.test(input.get('replay')||''))query.set('replay',input.get('replay'));windowObject.location.replace('/market-direction'+(query.size?'?'+query:''));return Object.freeze({...disabled,redirected:true});}
 return createMarketDirectionAccountBridge({client,canPractice:()=>host.canPractice?.()!==false,requestPanel:input=>host.requestPanel?.(input)??client.requestPanel(input)});
}
