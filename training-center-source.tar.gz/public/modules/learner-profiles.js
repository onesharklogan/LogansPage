/* Shared browser-local learner identities. This is not authentication.
 * Reads never write. Explicit create/select hold the original Market Direction
 * writer lock and preserve the complete stored document, including unknown data. */
const LearnerProfiles = (function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.LearnerProfiles = api;
  return api;
})(typeof globalThis === 'object' ? globalThis : this, function () {
  'use strict';
  const KEY = 'price-action-always-in-v4';
  const LOCK = 'price-action-always-in-v2-writer';
  const LEGACY_KEYS = Object.freeze(['price-action-always-in-v3', 'price-action-always-in-v2', 'logans-always-in-v1']);
  const BACKUP = 'price-action-always-in-v4-migration-backup';
  const object = value => !!value && typeof value === 'object' && !Array.isArray(value);
  const fail = (code, error) => ({ok:false,profiles:[],active:null,error,code,revision:0,sourceKey:null});
  function validIdentity(profile) {
    return object(profile) && typeof profile.name === 'string' && profile.name.length > 0 && profile.name.length <= 32 && profile.name === profile.name.trim() && !/[\u0000-\u001f\u007f]/.test(profile.name) && typeof profile.key === 'string' && profile.key === profile.name.toLocaleLowerCase();
  }
  function inspect(data, legacy = false) {
    if (!object(data) || data.version !== 1 || !Array.isArray(data.profiles) || data.profiles.length > 100 || (data.datasets !== undefined && !object(data.datasets)) || (data._revision !== undefined && (!Number.isSafeInteger(data._revision) || data._revision < 0))) throw Error('Saved profiles could not be read safely. Existing progress has not been changed.');
    const seen = new Set();
    const profiles = data.profiles.map(value => {
      const profile = legacy && object(value) && value.key === undefined && typeof value.name === 'string' ? {...value,key:value.name.toLocaleLowerCase()} : value;
      if (!validIdentity(profile) || seen.has(profile.key)) throw Error('Saved profile identities are invalid or duplicated. Existing progress has not been changed.');
      seen.add(profile.key); return {key:profile.key,name:profile.name};
    });
    const activeKey = data.active == null ? null : data.active;
    if (activeKey !== null && (typeof activeKey !== 'string' || !seen.has(activeKey))) throw Error('The selected profile is missing or invalid. Existing progress has not been changed.');
    return {profiles,active:profiles.find(profile => profile.key === activeKey) || null};
  }
  function storageFor(storage) { return storage === undefined ? globalThis.localStorage : storage; }
  function load(storage) {
    const raw = storage.getItem(KEY);
    let sourceKey = KEY, sourceRaw = raw;
    if (raw === null) {
      sourceKey = null;
      for (const key of LEGACY_KEYS) { const value = storage.getItem(key); if (value !== null) {sourceKey=key;sourceRaw=value;break;} }
    }
    const data = sourceRaw === null ? {version:1,active:null,profiles:[],datasets:{}} : JSON.parse(sourceRaw);
    const identity = inspect(data, sourceKey !== null && sourceKey !== KEY);
    return {raw,sourceKey,sourceRaw,data,snapshot:{ok:true,...identity,error:null,code:null,revision:data._revision || 0,sourceKey}};
  }
  /** No migration or selection is performed by this read. */
  function read(storage) {
    try { return load(storageFor(storage)).snapshot; }
    catch (_) { return fail('storage-invalid','Profiles are unavailable or invalid. Existing progress has not been changed.'); }
  }
  function selected(snapshot, key) { return snapshot?.ok === true && validIdentity(snapshot.active) && snapshot.active.key === key; }
  function normalizeName(value) {
    if (typeof value !== 'string') throw Error('Enter a profile name.');
    const name=value.trim().replace(/\s+/g,' ');
    if (!name || name.length>32 || /[\u0000-\u001f\u007f]/.test(name)) throw Error('Use a profile name from 1 to 32 characters.');
    return name;
  }
  function newProfile(name) {
    return {name,key:name.toLocaleLowerCase(),secondsPerBar:.85,finalBar:78,pivotDiamonds:false,ema20On:true,mode:'real',done:[],history:[],attempts:[],importDone:[],realChart:null,demoChart:null,chart:{id:1,finalBar:78,runID:'profile-'+(globalThis.crypto?.randomUUID?.() || Date.now().toString(36)+'-'+Math.random().toString(36).slice(2)),source:null,replaying:false,cancelled:true,format:'rth-v2',revealed:1,flips:[],ledger:[],scoreStart:0,bias:[],direction:0,finished:false,directionAccuracy:{version:1,choices:[],practiceCutoff:null}}};
  }
  async function mutate(kind, value, options = {}) {
    let storage, locks;
    try { storage=storageFor(options.storage);locks=options.locks === undefined ? globalThis.navigator?.locks : options.locks; }
    catch (_) { return fail('storage-unavailable','Local profiles are unavailable in this browser.'); }
    if (!locks?.request) return fail('lock-unavailable','Safe profile editing is unavailable. Use an updated browser.');
    try {
      return await locks.request(LOCK,{mode:'exclusive',ifAvailable:true},async lock => {
        if (!lock) return fail('lock-busy','Another simulator is editing profiles. Close that tab, then try again.');
        let loaded;
        try { loaded=load(storage); } catch (_) { return fail('storage-invalid','Profiles are unavailable or invalid. Existing progress has not been changed.'); }
        const next=loaded.data;
        let key=value;
        if (kind==='create') {
          let name;
          try { name=normalizeName(value); } catch (error) { return fail('invalid-name',error.message); }
          key=name.toLocaleLowerCase();
          if (loaded.snapshot.profiles.some(profile=>profile.key===key)) return fail('duplicate-name','That profile already exists. Select it instead.');
          if (next.profiles.length>=100) return fail('profile-limit','This browser has reached 100 profiles.');
          next.profiles.push(newProfile(name));
        } else if (typeof key!=='string' || !loaded.snapshot.profiles.some(profile=>profile.key===key)) return fail('missing-profile','Choose an existing saved profile.');
        if (kind==='select' && loaded.sourceKey===KEY && next.active===key) return loaded.snapshot;
        if (loaded.sourceKey && loaded.sourceKey!==KEY) {
          // Only absent legacy identity keys are materialized; every other field stays untouched.
          next.profiles=next.profiles.map(profile=>profile.key===undefined?{...profile,key:profile.name.toLocaleLowerCase()}:profile);
        }
        next.active=key;
        if (loaded.snapshot.revision>=Number.MAX_SAFE_INTEGER) return fail('revision-limit','The saved profile revision cannot be advanced safely.');
        next._revision=loaded.snapshot.revision+1;
        try {
          if (storage.getItem(KEY)!==loaded.raw || (loaded.sourceKey && loaded.sourceKey!==KEY && storage.getItem(loaded.sourceKey)!==loaded.sourceRaw)) return fail('conflict','Profiles changed elsewhere. Review the current profiles and try again.');
          if (loaded.sourceKey && loaded.sourceKey!==KEY && storage.getItem(BACKUP)===null) {storage.setItem(BACKUP,loaded.sourceRaw);if(storage.getItem(BACKUP)!==loaded.sourceRaw)return fail('write-unconfirmed','Legacy backup could not be verified. Existing profiles were kept.');}
          const raw=JSON.stringify(next);
          // A migration backup must not conceal a writer that does not honor this lock.
          if (storage.getItem(KEY)!==loaded.raw || (loaded.sourceKey && loaded.sourceKey!==KEY && storage.getItem(loaded.sourceKey)!==loaded.sourceRaw)) return fail('conflict','Profiles changed elsewhere. No selection was applied.');
          storage.setItem(KEY,raw);
          if (storage.getItem(KEY)!==raw) return fail('write-unconfirmed','Profile save could not be verified. Reload before continuing.');
          const confirmed=load(storage);return confirmed.raw===raw?confirmed.snapshot:fail('conflict','Profiles changed after saving. Review the current selection before continuing.');
        } catch (_) { return fail('write-unconfirmed','Profile save could not be verified. Reload before continuing.'); }
      });
    } catch (_) { return fail('lock-unavailable','Safe profile editing could not start. Retry after closing other simulator tabs.'); }
  }
  return Object.freeze({KEY,LOCK,LEGACY_KEYS,BACKUP,read,validIdentity,selected,inspect,normalizeName,create:(name,options)=>mutate('create',name,options),select:(key,options)=>mutate('select',key,options)});
});

export default LearnerProfiles;
