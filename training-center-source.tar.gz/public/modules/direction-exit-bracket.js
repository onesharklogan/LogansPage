/** Educational five-minute OHLC exit brackets. No orders or market connections.
 * Close decisions arm only subsequent candles. The opening print is known first;
 * otherwise an ambiguous candle touching both prices is resolved stop first.
 */
export const BRACKET_VERSION = 1;
export const BRACKET_TICK = .25;
export const DEFAULT_BRACKET_DISTANCE = 5;
const signed = value => value === 1 || value === -1;
const need = (condition, message) => { if (!condition) throw new Error(message); };
const validTick = tick => Number.isFinite(tick) && tick > 0;
export function normalizeDistance(value, tick = BRACKET_TICK) {
 need(validTick(tick), 'Invalid bracket tick.');
 const number = Number(value);
 return Number((Math.max(1, Math.round(Math.min(100000, Number.isFinite(number) && number > 0 ? number : DEFAULT_BRACKET_DISTANCE) / tick)) * tick).toFixed(8));
}
export function validateBracketConfig(config, {startBar = 0, lastBar = 80, tick = BRACKET_TICK} = {}) {
 need(validTick(tick), 'Invalid bracket tick.');
 need(config && config.version === BRACKET_VERSION && Object.keys(config).every(key => ['version', 'actions'].includes(key)) && Array.isArray(config.actions) && config.actions.length <= 81, 'Invalid exit bracket evidence.');
 let previous = startBar - 1;
 for (const action of config.actions) {
  need(action && Object.keys(action).every(key => ['bar', 'enabled', 'distance'].includes(key)) && Number.isInteger(action.bar) && action.bar >= startBar && action.bar <= lastBar && action.bar > previous && typeof action.enabled === 'boolean' && Number.isFinite(action.distance) && action.distance >= tick && action.distance <= 100000 && Math.abs(action.distance / tick - Math.round(action.distance / tick)) < 1e-8, 'Invalid exit bracket action.');
  previous = action.bar;
 }
 return true;
}
export function evaluateBracket(position, candle, index) {
 if (!position || index <= position.armedBar) return null;
 const {entry, direction, distance} = position;
 need(Number.isFinite(entry) && signed(direction) && Number.isFinite(distance) && distance > 0 && Number.isInteger(position.armedBar) && Number.isInteger(index), 'Invalid armed bracket.');
 need(candle && ['o','h','l','c'].every(key => Number.isFinite(candle[key])) && candle.l <= Math.min(candle.o,candle.c) && candle.h >= Math.max(candle.o,candle.c), 'Invalid bracket candle.');
 const stop = entry - direction * distance, target = entry + direction * distance;
 const stopHit = direction === 1 ? candle.l <= stop : candle.h >= stop;
 const targetHit = direction === 1 ? candle.h >= target : candle.l <= target;
 const stopOpen = direction === 1 ? candle.o <= stop : candle.o >= stop;
 const targetOpen = direction === 1 ? candle.o >= target : candle.o <= target;
 if (stopOpen) return {reason:'stop',price:candle.o,gap:candle.o !== stop,bothHit:stopHit && targetHit};
 if (targetOpen) return {reason:'target',price:target,gap:candle.o !== target,bothHit:stopHit && targetHit};
 if (stopHit) return {reason:'stop',price:stop,gap:false,bothHit:targetHit};
 if (targetHit) return {reason:'target',price:target,gap:false,bothHit:false};
 return null;
}
/** Replay observed close decisions, followed by the existing Finish carry.
 * No synthetic decisions are added. An exit neutralizes the carry until another
 * explicit observed choice; this also distinguishes same-direction re-entry.
 * finalBar is an inclusive 1-based count, like the simulator's Final Bar.
 */
export function replayBracket(run, candles, finalBar, config, {tick = BRACKET_TICK} = {}) {
 const start = run?.startBar ?? 0, choices = run?.choices;
 need(Array.isArray(candles) && Number.isInteger(finalBar) && finalBar > start && finalBar <= candles.length && finalBar <= 81 && Number.isInteger(start) && start >= 0 && Array.isArray(choices) && choices.length > 0 && choices.length <= finalBar - start && choices.every((choice, i) => choice && choice.bar === start + i && [0,1,-1].includes(choice.direction)), 'Invalid bracket practice choices.');
 validateBracketConfig(config, {startBar:start,lastBar:start+choices.length-1,tick});
 const transitions = [], exits = [], legs = [], exposures = Array(candles.length).fill(0);
 let settings = {enabled:false,distance:DEFAULT_BRACKET_DISTANCE}, actionIndex = 0, position = null, direction = 0, activeLeg = null;
 for (let from = start; from < finalBar; from++) {
  const choice = choices[from - start];
  if (choice) {
   if (choice.direction !== direction) {
    direction = choice.direction;
    position = signed(direction) ? {entry:candles[from].c,entryIndex:from,direction,armedBar:from,distance:settings.distance} : null;
    activeLeg = null;
   }
  }
  const action = config.actions[actionIndex];
  if (action?.bar === from) {
   settings = {enabled:action.enabled,distance:action.distance}; actionIndex++;
   if (position) position = {...position,distance:action.distance,armedBar:from};
  }
  if (from === finalBar - 1) break;
  const to = from + 1;
  if (!signed(direction)) continue;
  const hit = settings.enabled ? evaluateBracket(position,candles[to],to) : null;
  const exit = hit ? {...hit,bar:to,direction,entry:position.entry,entryIndex:position.entryIndex,distance:position.distance,armedBar:position.armedBar} : null;
  const price = exit ? exit.price : candles[to].c, delta = price - candles[from].c;
  transitions.push({from,to,bias:direction,delta,...(exit?{exit}:{} )}); exposures[to] = direction;
  if (!activeLeg) {
   activeLeg = {direction,entryIndex:from,exitIndex:to,entryBar:from+1,exitBar:to+1,entryClose:candles[from].c,exitClose:price,points:0,transitions:0};
   legs.push(activeLeg);
  }
  activeLeg.exitIndex = to; activeLeg.exitBar = to+1; activeLeg.exitClose = price;
  activeLeg.points += direction*delta; activeLeg.transitions++;
  if (exit) {
   activeLeg.exitReason = exit.reason;
   exits.push(exit); position = null; direction = 0; activeLeg = null;
  }
 }
 return {transitions,exits,legs,exposures,direction,position:position?{...position,enabled:settings.enabled}:null,settings:{...settings}};
}
