/** Bounded, read-only account analytics. No persistence, simulator state or auth decisions. */
export const STATS_MODULES=Object.freeze(['market-direction','trade-simulator']);
export const STATS_LIMIT=1000;
export const STATS_BYTES=1024*1024;
const UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
const exact=(v,keys)=>v&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).length===keys.length&&keys.every(k=>Object.hasOwn(v,k));
const int=(v,max=1000000)=>Number.isSafeInteger(v)&&v>=0&&v<=max;
const finite=v=>typeof v==='number'&&Number.isFinite(v)&&Math.abs(v)<=1e12;
const iso=v=>typeof v==='string'&&/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(v)&&Number.isFinite(Date.parse(v))&&new Date(v).toISOString()===v;
const near=(a,b)=>Math.abs(a-b)<=1e-6;
export const cleanStatsPoints=v=>{if(!finite(v))throw Error('Stats exceed the supported range.');return Number(v.toFixed(10));};
export function outcomeTotals(points){
 const t={wins:0,losses:0,flats:0,grossProfit:0,grossLoss:0,biggestWin:null,biggestLoss:null};
 for(const n of points){if(!finite(n))throw Error('Closed outcomes could not be verified.');if(n>0){t.wins++;t.grossProfit+=n;t.biggestWin=Math.max(t.biggestWin??n,n);}else if(n<0){t.losses++;t.grossLoss-=n;t.biggestLoss=Math.min(t.biggestLoss??n,n);}else t.flats++;}
 t.grossProfit=cleanStatsPoints(t.grossProfit);t.grossLoss=cleanStatsPoints(t.grossLoss);return t;
}
export function validStatsRow(r){
 if(!exact(r,['id','module','chartId','startedAt','completedAt','outcomes','buckets','practiced','neutral','carry'])||!UUID.test(r.id)||!STATS_MODULES.includes(r.module)||typeof r.chartId!=='string'||!/^mes1-\d{4}-\d{2}-\d{2}-81$/.test(r.chartId)||!iso(r.startedAt)||!iso(r.completedAt)||r.completedAt<r.startedAt)return false;
 if(r.outcomes===null)return r.buckets===null&&r.practiced===null&&r.neutral===null&&r.carry===null;
 const o=r.outcomes;
 if(!exact(o,['wins','losses','flats','grossProfit','grossLoss','biggestWin','biggestLoss'])||!['wins','losses','flats'].every(k=>int(o[k],512))||o.wins+o.losses+o.flats>512||![o.grossProfit,o.grossLoss].every(n=>finite(n)&&n>=0)||!(o.wins?finite(o.biggestWin)&&o.biggestWin>0&&o.biggestWin<=o.grossProfit:o.biggestWin===null&&o.grossProfit===0)||!(o.losses?finite(o.biggestLoss)&&o.biggestLoss<0&&-o.biggestLoss<=o.grossLoss:o.biggestLoss===null&&o.grossLoss===0))return false;
 if(!Array.isArray(r.buckets)||r.buckets.length!==4||!r.buckets.every(finite)||!near(r.buckets.reduce((a,b)=>a+b,0),o.grossProfit-o.grossLoss)||typeof r.carry!=='boolean')return false;
 return r.module==='trade-simulator'?r.practiced===null&&r.neutral===null&&r.carry===false:(r.practiced===null&&r.neutral===null||int(r.practiced,80)&&int(r.neutral,r.practiced));
}
export function decodeStats(value){
 if(!exact(value,['version','context','snapshot','asOf','attempts'])||value.version!==1||!exact(value.context,['accountId','generation','sessionTag'])||!UUID.test(value.context.accountId)||!int(value.context.generation,2147483646)||value.context.generation<1||typeof value.context.sessionTag!=='string'||!/^[a-f0-9]{64}$/.test(value.context.sessionTag)||typeof value.snapshot!=='string'||!/^[a-f0-9]{64}$/.test(value.snapshot)||!iso(value.asOf)||!Array.isArray(value.attempts)||value.attempts.length>STATS_LIMIT||!value.attempts.every(validStatsRow))throw Error('Account stats could not be verified.');
 const seen=new Set();let positive=0,negative=0;for(const r of value.attempts){const key=r.module+':'+r.id;if(seen.has(key))throw Error('Duplicate saved attempts could not be reconciled.');seen.add(key);positive+=r.outcomes?.grossProfit??0;negative+=r.outcomes?.grossLoss??0;if(!finite(positive)||!finite(negative))throw Error('Stats exceed the supported range.');}
 return value;
}
const compare=(a,b)=>a<b?-1:a>b?1:0;
/** All finished attempts, including replays. Does not change below-chart history policies. */
export function deriveStatsPage(snapshot,page=0){
 if(!Number.isInteger(page)||page<0||page>2)throw Error('Unknown stats page.');
 const rows=snapshot.attempts.filter(r=>page===2||r.module===STATS_MODULES[page]).slice().sort((a,b)=>compare(a.completedAt,b.completedAt)||compare(a.startedAt,b.startedAt)||compare(a.module,b.module)||compare(a.id,b.id));
 const known=rows.filter(r=>r.outcomes!==null),totals=outcomeTotals([]),buckets=[0,0,0,0];let practiced=0,neutral=0,carry=false,neutralCovered=0,neutralTotal=rows.filter(r=>r.module===STATS_MODULES[0]).length,total=0,minimum=0,maximum=0;
 const points=known.map((r,index)=>{const o=r.outcomes;for(const k of ['wins','losses','flats','grossProfit','grossLoss'])totals[k]+=o[k];if(o.biggestWin!==null)totals.biggestWin=Math.max(totals.biggestWin??o.biggestWin,o.biggestWin);if(o.biggestLoss!==null)totals.biggestLoss=Math.min(totals.biggestLoss??o.biggestLoss,o.biggestLoss);for(let i=0;i<4;i++)buckets[i]=cleanStatsPoints(buckets[i]+r.buckets[i]);practiced+=r.practiced??0;neutral+=r.neutral??0;if(r.module===STATS_MODULES[0]&&r.practiced!==null)neutralCovered++;carry ||= r.carry;const netPoints=cleanStatsPoints(o.grossProfit-o.grossLoss);total=cleanStatsPoints(total+netPoints);minimum=Math.min(minimum,total);maximum=Math.max(maximum,total);return{id:r.module+':'+r.id,attemptId:r.id,module:r.module,sessionId:r.chartId,sessionTitle:r.chartId,sessionDate:r.chartId.slice(5,15),completedAt:r.completedAt,startedAt:r.startedAt,netPoints,cumulative:total,index};});
 totals.grossProfit=cleanStatsPoints(totals.grossProfit);totals.grossLoss=cleanStatsPoints(totals.grossLoss);
 const samples=totals.wins+totals.losses+totals.flats,complete=known.length===rows.length;
 return{page,count:rows.length,covered:known.length,complete,totals,samples,buckets,practiced,neutral,neutralCovered,neutralTotal,carry,winRate:complete&&samples?totals.wins/samples:null,averageWin:complete&&totals.wins?cleanStatsPoints(totals.grossProfit/totals.wins):null,averageLoss:complete&&totals.losses?cleanStatsPoints(-totals.grossLoss/totals.losses):null,profitFactor:!complete||!samples?'unavailable':totals.grossLoss?totals.grossProfit/totals.grossLoss:totals.grossProfit?'no-losses':'flat-only',series:{learnerId:snapshot.context.accountId,points,total,minimum,maximum}};
}
export function formatProfitFactor(page){return typeof page.profitFactor==='number'?page.profitFactor.toLocaleString('en-US',{maximumFractionDigits:2}):page.profitFactor==='no-losses'?'No losses':page.profitFactor==='flat-only'?'Flat only':'N/A';}
