/* Direction Accuracy v1: pure rules shared by the browser module and Node audit tests. */
(function (root) {
  'use strict';
  const VERSION = 1, HORIZON = 3, NEUTRAL = 0.25, MAX_BARS = 81;
  const integer = (value, min, max) => Number.isInteger(value) && value >= min && value <= max;
  function newRun() { return { version: VERSION, choices: [], practiceCutoff: null }; }
  function isRun(run, maxBars = MAX_BARS) {
    return !!run && run.version === VERSION && integer(maxBars, 1, MAX_BARS) && Array.isArray(run.choices) && run.choices.length <= maxBars && run.choices.every((choice, index) => choice && choice.bar === index && (choice.direction === 1 || choice.direction === -1)) && (run.practiceCutoff === null || integer(run.practiceCutoff, 1, maxBars) && run.choices.length === run.practiceCutoff);
  }
  function copyRun(run) {
    if (run == null) return run;
    if (!isRun(run)) throw new Error('Invalid direction accuracy choices.');
    return { version: VERSION, choices: run.choices.map(({ bar, direction }) => ({ bar, direction })), practiceCutoff: run.practiceCutoff };
  }
  function capture(run, bar, direction) {
    if (run == null) return run; // Legacy runs remain unavailable; never reconstruct choices.
    if (!isRun(run)) throw new Error('Invalid direction accuracy choices.');
    if (run.practiceCutoff !== null) return run;
    if (!integer(bar, 0, MAX_BARS - 1) || ![1, -1].includes(direction)) throw new Error('A visible candle and selected direction are required.');
    if (bar < run.choices.length) return run; // A committed choice cannot be rewritten by a later flip.
    if (bar !== run.choices.length) throw new Error('Direction choices must be captured in candle order.');
    return { version: VERSION, choices: [...run.choices, { bar, direction }], practiceCutoff: null };
  }
  function finish(run, bar, direction) {
    if (run == null || isRun(run) && run.practiceCutoff !== null) return run;
    const captured = capture(run, bar, direction);
    if (captured.choices.length !== bar + 1) throw new Error('The finish candle must be the latest practiced candle.');
    return { ...captured, practiceCutoff: bar + 1 };
  }
  function score(run, candles, revealed, finalBar = candles?.length) {
    if (run == null) return null;
    if (!isRun(run) || !Array.isArray(candles) || !integer(revealed, 1, candles.length) || !integer(finalBar, 1, Math.min(candles.length, MAX_BARS))) throw new Error('Invalid direction accuracy window.');
    const end = Math.min(revealed, finalBar, run.practiceCutoff ?? MAX_BARS);
    if (run.choices.length > end) throw new Error('A direction choice lies beyond the practiced window.');
    let correct = 0, incorrect = 0, neutral = 0, insufficientFuture = 0;
    for (const { bar, direction } of run.choices) {
      if (bar + HORIZON >= end) { insufficientFuture++; continue; }
      // These are the only price reads: both endpoints are already revealed and inside practice cutoff.
      const from = candles[bar]?.c, to = candles[bar + HORIZON]?.c;
      if (!Number.isFinite(from) || !Number.isFinite(to)) throw new Error('Invalid revealed closing price.');
      const change = to - from;
      if (Math.abs(change) <= NEUTRAL) neutral++;
      else if (direction * change > 0) correct++;
      else incorrect++;
    }
    const scored = correct + incorrect;
    return { ...copyRun(run), horizon: HORIZON, neutralThreshold: NEUTRAL, evaluatedThrough: end, chosen: run.choices.length, scored, correct, incorrect, neutral, insufficientFuture, accuracy: scored ? correct / scored : null };
  }
  function isReport(report, finalBar = MAX_BARS) {
    if (!isRun(report, finalBar) || report.practiceCutoff === null || report.horizon !== HORIZON || report.neutralThreshold !== NEUTRAL || report.evaluatedThrough !== report.practiceCutoff) return false;
    const keys = ['chosen', 'scored', 'correct', 'incorrect', 'neutral', 'insufficientFuture'];
    if (!keys.every(key => integer(report[key], 0, finalBar))) return false;
    return report.chosen === report.choices.length && report.scored === report.correct + report.incorrect && report.chosen === report.scored + report.neutral + report.insufficientFuture && report.insufficientFuture === Math.min(HORIZON, report.chosen) && (report.scored ? Number.isFinite(report.accuracy) && Math.abs(report.accuracy - report.correct / report.scored) < 1e-12 : report.accuracy === null);
  }
  function matchesReport(report, candles, finalBar = candles?.length) {
    if (!isReport(report, finalBar)) return false;
    try {
      const expected = score(report, candles, report.practiceCutoff, finalBar);
      return ['evaluatedThrough', 'chosen', 'scored', 'correct', 'incorrect', 'neutral', 'insufficientFuture', 'accuracy'].every(key => expected[key] === report[key]);
    } catch (_) { return false; }
  }
  root.DirectionAccuracy = Object.freeze({ VERSION, HORIZON, NEUTRAL, newRun, isRun, copyRun, capture, finish, score, isReport, matchesReport });
})(globalThis);
