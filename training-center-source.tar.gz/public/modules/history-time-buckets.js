import {replayBracket} from './direction-exit-bracket.js';
/** Read-only history analytics. No DOM, storage, network or scoring mutations. */
import './practice-evidence.js';
const PE=globalThis.PracticeEvidence;
export const TIME_BUCKETS=Object.freeze([{id:'1-20',label:'Bars 1–20',startBar:1,endBar:20},{id:'21-40',label:'Bars 21–40',startBar:21,endBar:40},{id:'41-60',label:'Bars 41–60',startBar:41,endBar:60},{id:'61-end',label:'Bars 61–end',startBar:61,endBar:null}].map(Object.freeze));
const uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
const integer=(v,min,max)=>Number.isSafeInteger(v)&&v>=min&&v<=max;
const finite=Number.isFinite,near=(a,b)=>finite(a)&&finite(b)&&Math.abs(a-b)<=1e-6;
const need=(ok,message)=>{if(!ok)throw Error(message);};
export function cleanBucketPoints(value){need(finite(value)&&Math.abs(value)<=Number.MAX_SAFE_INTEGER,'History point total is outside the supported range.');return Number(value.toFixed(10));}
/** Returns a zero-based bucket index for a one-based CURRENT-session bar. */
export function bucketForBar(bar){need(integer(bar,1,10000),'Invalid saved session bar.');return Math.min(3,Math.floor((bar-1)/20));}
/** @typedef {{id:string,label:string,startBar:number,endBar:number|null,points:number,sampleCount:number,resultCount:number,reachedCount:number}} TimeBucket */
/** @returns {TimeBucket[]} */
export function createTimeBuckets(){return TIME_BUCKETS.map(row=>({...row,points:0,sampleCount:0,resultCount:0,reachedCount:0}));}
export function validHistoryLearnerId(value){return typeof value==='string'&&uuid.test(value);}
function canonical(value,depth=0){need(depth<20,'Saved report is too deeply nested.');if(value===null||typeof value==='string'||typeof value==='boolean')return JSON.stringify(value);if(typeof value==='number'){need(finite(value),'Saved report contains an invalid number.');return JSON.stringify(value);}need(value&&typeof value==='object','Saved report is not lossless data.');if(Array.isArray(value)){need(value.length<=10000,'Saved report is too large.');return '['+value.map(v=>canonical(v,depth+1)).join(',')+']';}return '{'+Object.keys(value).sort().map(k=>JSON.stringify(k)+':'+canonical(value[k],depth+1)).join(',')+'}';}
function practiceProof(report,first,final){
 if(Object.hasOwn(report,'practiceEvidence')){need(report.directionAccuracy==null,'Saved report has conflicting practice evidence authorities.');const p=report.practiceEvidence;need(PE.isReport(p,final)&&p.startBar>=first-1,'Saved Neutral practice evidence is invalid for its original range.');return {version:2,start:p.startBar,cutoff:p.practiceCutoff,choices:p.choices};}
 const d=report.directionAccuracy;if(!d||d.version!==1||d.horizon!==3||d.neutralThreshold!==.25||(d.startBar??0)!==first-1||!integer(d.practiceCutoff,first,final)||d.evaluatedThrough!==d.practiceCutoff||!Array.isArray(d.choices)||d.choices.length!==d.practiceCutoff-first+1||!Array.from(d.choices).every((c,i)=>c&&c.bar===first-1+i&&[1,-1].includes(c.direction)))return null;
 const keys=['chosen','scored','correct','incorrect','neutral','insufficientFuture'];if(!keys.every(k=>integer(d[k],0,final))||d.chosen!==d.choices.length||d.scored!==d.correct+d.incorrect||d.chosen!==d.scored+d.neutral+d.insufficientFuture||d.insufficientFuture!==Math.min(3,d.chosen)||(d.scored?(!finite(d.accuracy)||Math.abs(d.accuracy-d.correct/d.scored)>=1e-12):d.accuracy!==null))return null;
 return {cutoff:d.practiceCutoff,choices:d.choices};
}
function bracketReportMoves(report,source){
 need(source&&source.key===report.key&&Array.isArray(source.candles),'Exact saved OHLC are unavailable for exit bracket history.');
 const first=report.firstBar??1,final=report.finalBar,proof=report.practiceEvidence||report.directionAccuracy;
 need(integer(first,1,source.candles.length)&&integer(final,first,source.candles.length),'Invalid saved bracket range.');
 const practice=practiceProof(report,first,final);need(practice&&proof,'Saved bracket practice evidence is unavailable.');
 const replay=replayBracket(proof,source.candles,final,report.exitBracket),moves=replay.transitions.map(m=>({...m,points:m.bias*m.delta}));
 let favorable=0,adverse=0;for(const m of moves){if(m.points>0)favorable+=m.points;else adverse-=m.points;}
 need(report.legDefinition==='symmetric-exit-bracket-legs-v1'&&canonical(report.legs)===canonical(replay.legs)&&canonical(report.bracketExits)===canonical(replay.exits)&&report.recordedMoves===moves.length&&report.fullMoves===final-first&&near(report.netAlignedPoints,favorable-adverse)&&near(report.favorablePoints,favorable)&&near(report.adversePoints,adverse),'Saved exit bracket points do not reconcile with exact OHLC.');
 return{moves,first,final,practice};
}
function reportMoves(report,attempts,source){
 if(report.definition==='symmetric-exit-bracket-v1')return bracketReportMoves(report,source);
 need(report.definition==='close-bias-v1','This older score has no supported points definition.');
 need(source&&source.key===report.key&&Array.isArray(source.closes)&&source.closes.length>=2&&source.closes.length<=81&&Array.from(source.closes).every(v=>finite(v)&&v>0&&v<=1e9),'Exact saved source closes are unavailable.');
 const closes=source.closes,total=closes.length,first=report.firstBar??1,final=report.finalBar??(report.fullMoves+1);
 need(integer(first,1,total)&&integer(final,first,total)&&(report.sessionBars===undefined||report.sessionBars===total)&&integer(report.recordedMoves,0,80)&&report.fullMoves===final-first&&report.recordedMoves<=report.fullMoves,'Saved first/final range or sample count is inconsistent.');
 const reportKey=canonical(report),matching=attempts.filter(a=>a&&a.sessionKey===report.key&&a.report&&canonical(a.report)===reportKey),byId=new Map();let exposures=null;
 for(const a of matching){need(typeof a.id==='string'&&a.id.length<=180&&/^[a-zA-Z0-9:._-]+$/.test(a.id),'Saved attempt identity is invalid.');const encoded=canonical(a),prior=byId.get(a.id);need(prior===undefined||prior===encoded,'Conflicting saved copies of the original attempt exist.');byId.set(a.id,encoded);if(a.decisions!=null){const e=a.decisions.exposures;need(Array.isArray(e)&&e.length===total&&Array.from(e).every((bias,i)=>[0,1,-1].includes(bias)&&(i>=first&&i<final||bias===0)),'Original saved exposures are inconsistent with its range.');need(exposures===null||canonical(exposures)===canonical(e),'Original report has conflicting saved exposures.');exposures=e;}}
 const moves=[];
 if(exposures){for(let to=first;to<final;to++)if(exposures[to])moves.push({from:to-1,to,bias:exposures[to],delta:closes[to]-closes[to-1]});}
 else{
  need(report.legDefinition==='contiguous-frozen-close-legs-v1'&&Array.isArray(report.legs)&&report.legs.length<=80,'Older result has no reliable saved per-bar exposure or legs.');let previous=first-1;
  for(const leg of report.legs){need(leg&&[1,-1].includes(leg.direction)&&integer(leg.entryIndex,first-1,final-1)&&integer(leg.exitIndex,leg.entryIndex+1,final-1)&&leg.entryIndex>=previous&&leg.entryBar===leg.entryIndex+1&&leg.exitBar===leg.exitIndex+1&&leg.transitions===leg.exitIndex-leg.entryIndex&&near(leg.entryClose,closes[leg.entryIndex])&&near(leg.exitClose,closes[leg.exitIndex])&&near(leg.points,leg.direction*(closes[leg.exitIndex]-closes[leg.entryIndex])),'Saved legs do not match the exact source or range.');previous=leg.exitIndex;for(let to=leg.entryIndex+1;to<=leg.exitIndex;to++)moves.push({from:to-1,to,bias:leg.direction,delta:closes[to]-closes[to-1]});}
 }
 let favorable=0,adverse=0;for(const m of moves){m.points=m.bias*m.delta;if(m.points>0)favorable+=m.points;else adverse-=m.points;}
 need(moves.length===report.recordedMoves&&near(favorable-adverse,report.netAlignedPoints)&&near(favorable,report.favorablePoints)&&near(adverse,report.adversePoints),'Saved exposure points do not reconcile with the original report.');
 const practice=practiceProof(report,first,final);
 if(practice?.version===2){
  const byFrom=new Map(moves.map(m=>[m.from,m]));
  for(let from=practice.start;from<final-1;from++){const choice=practice.choices[Math.min(from,practice.cutoff-1)-practice.start],move=byFrom.get(from);need(choice&&(choice.direction===0?!move:move?.bias===choice.direction),'Saved Neutral practice evidence conflicts with original points exposure.');}
 }else if(practice)for(const m of moves){const choice=practice.choices[Math.min(m.from,practice.cutoff-1)-(first-1)];need(choice&&choice.direction===m.bias,'Saved practice choices conflict with original points exposure.');}
 return {moves,first,final,practice};
}
/** First report per session only; caller snapshots ONE selected profile and supplies
 * exact-key, already verified closes. Missing/ambiguous attribution is excluded as
 * a whole report, with its saved points retained in unallocatedPoints. Top-level
 * ownership/invalid totals throw; per-report evidence failures become exclusions.
 * @param {{learnerId:string,reports:any[],attempts?:any[],closesByKey?:Map<string,{key:string,closes:number[]}>|Record<string,{key:string,closes:number[]}>,missingScoreCount?:number}} input
 * @param {string} expectedLearnerId
 */
export function deriveDirectionBuckets({learnerId,reports,attempts=[],closesByKey=new Map(),missingScoreCount=0},expectedLearnerId){
 need(validHistoryLearnerId(learnerId)&&learnerId===expectedLearnerId,'The selected learner identity changed.');need(Array.isArray(reports)&&reports.length<=2000&&Array.isArray(attempts)&&attempts.length<=50000&&integer(missingScoreCount,0,1000000),'Saved direction history is unavailable.');
 const buckets=createTimeBuckets().map(b=>({...b,practicedPoints:0,carriedPoints:0,unknownPracticePoints:0,practicedSamples:0,carriedSamples:0,unknownPracticeSamples:0,practicedBars:0,practicedResults:0})),firstReports=new Map();
 for(const r of reports){need(r&&typeof r.key==='string'&&r.key.length>0&&r.key.length<100&&finite(r.netAlignedPoints)&&Math.abs(r.netAlignedPoints)<1e8,'Saved direction result has no valid identity or total.');if(!firstReports.has(r.key))firstReports.set(r.key,r);}
 if([...firstReports.values()].some(r=>Object.hasOwn(r,'practiceEvidence')))for(const b of buckets){b.neutralPracticedBars=0;b.neutralPracticedResults=0;}
 const attemptsByKey=new Map();for(const a of attempts){if(!a||typeof a.sessionKey!=='string')continue;const list=attemptsByKey.get(a.sessionKey)||[];list.push(a);attemptsByKey.set(a.sessionKey,list);}
 let reportedPoints=0,unallocatedPoints=0,attributedCount=0;const exclusions=[];
 for(const report of firstReports.values()){
  reportedPoints=cleanBucketPoints(reportedPoints+report.netAlignedPoints);
  try{
   const source=closesByKey instanceof Map?closesByKey.get(report.key):Object.hasOwn(closesByKey,report.key)?closesByKey[report.key]:null;
   const result=reportMoves(report,attemptsByKey.get(report.key)||[],source),sampleBuckets=new Set(),practiceBuckets=new Set(),neutralBuckets=new Set();
   for(const m of result.moves){const b=buckets[bucketForBar(m.to+1)],kind=result.practice&&(result.practice.version!==2||m.from>=result.practice.start)?(m.to+1<=result.practice.cutoff?'practiced':'carried'):'unknownPractice';b.points=cleanBucketPoints(b.points+m.points);b.sampleCount++;b[kind+'Points']=cleanBucketPoints(b[kind+'Points']+m.points);b[kind+'Samples']++;sampleBuckets.add(b.id);}
   if(result.practice)for(const choice of result.practice.choices){const b=buckets[bucketForBar(choice.bar+1)];b.practicedBars++;practiceBuckets.add(b.id);if(result.practice.version===2&&choice.direction===0){b.neutralPracticedBars++;neutralBuckets.add(b.id);}}
   for(const b of buckets){if(sampleBuckets.has(b.id))b.resultCount++;if(practiceBuckets.has(b.id))b.practicedResults++;if(neutralBuckets.has(b.id))b.neutralPracticedResults++;if(result.first<=(b.endBar??Infinity)&&result.final>=b.startBar)b.reachedCount++;}
   attributedCount++;
  }catch(error){unallocatedPoints=cleanBucketPoints(unallocatedPoints+report.netAlignedPoints);exclusions.push({key:report.key,points:report.netAlignedPoints,reason:error instanceof Error?error.message:'Saved points could not be allocated reliably.'});}
 }
 const attributedPoints=cleanBucketPoints(buckets.reduce((s,b)=>s+b.points,0)),reconciliationDifference=cleanBucketPoints(reportedPoints-attributedPoints-unallocatedPoints);need(Math.abs(reconciliationDifference)<=1e-6,'Section totals do not reconcile with saved direction points.');
 return {kind:'direction',learnerId,title:'Aligned points by ending bar',policy:'First completed run per session. Finish-carried points are included, not counted as practice.',buckets,reportedPoints,attributedPoints,unallocatedPoints,reportCount:firstReports.size,attributedCount,unallocatedCount:exclusions.length,exclusions,missingScoreCount,reconciliationDifference};
}
