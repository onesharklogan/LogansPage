/* Practice Evidence v2: observed intent only. No prices, scoring or accuracy. */
(function (root) {
  'use strict';
  const VERSION = 2, MAX_BARS = 81;
  const integer = (value, min, max) => Number.isSafeInteger(value) && value >= min && value <= max;
  const direction = value => value === -1 || value === 0 || value === 1;
  const denseChoices = (choices, start, maxBars, signedOnly = false) => Array.isArray(choices) && choices.length <= maxBars - start && Array.from(choices).every((choice, index) => choice && choice.bar === start + index && (signedOnly ? choice.direction === -1 || choice.direction === 1 : direction(choice.direction)));
  function isRun(run, maxBars = MAX_BARS) {
    return !!run && run.version === VERSION && integer(maxBars, 1, MAX_BARS) && integer(run.startBar, 0, maxBars - 1) && denseChoices(run.choices, run.startBar, maxBars) && (run.practiceCutoff === null || integer(run.practiceCutoff, run.startBar + 1, maxBars) && run.startBar + run.choices.length === run.practiceCutoff);
  }
  function newRun(startBar = 0, choices = []) {
    if (!integer(startBar, 0, MAX_BARS - 1) || !denseChoices(choices, startBar, MAX_BARS)) throw new Error('Invalid observed practice choices.');
    return { version: VERSION, startBar, choices: choices.map(({ bar, direction }) => ({ bar, direction })), practiceCutoff: null };
  }
  function copyRun(run) {
    if (run == null) return run;
    if (!isRun(run)) throw new Error('Invalid practice evidence.');
    return { ...newRun(run.startBar, run.choices), practiceCutoff: run.practiceCutoff };
  }
  function capture(run, bar, intent) {
    if (run == null) return run; // Missing legacy evidence is never reconstructed.
    if (!isRun(run)) throw new Error('Invalid practice evidence.');
    if (run.practiceCutoff !== null) return run;
    if (!integer(bar, run.startBar, MAX_BARS - 1) || !direction(intent)) throw new Error('A visible candle and selected intent are required.');
    if (bar < run.startBar + run.choices.length) return run; // Frozen choices cannot be rewritten by same-bar toggles.
    if (bar !== run.startBar + run.choices.length) throw new Error('Practice choices must be captured in candle order.');
    return { version: VERSION, startBar: run.startBar, choices: [...run.choices, { bar, direction: intent }], practiceCutoff: null };
  }
  function finish(run, bar, intent) {
    if (run == null || isRun(run) && run.practiceCutoff !== null) return run;
    const captured = capture(run, bar, intent);
    if (captured.startBar + captured.choices.length !== bar + 1) throw new Error('The finish candle must be the latest practiced candle.');
    return { ...captured, practiceCutoff: bar + 1 };
  }
  function isReport(report, finalBar = MAX_BARS) {
    return isRun(report, finalBar) && report.practiceCutoff !== null && report.evaluatedThrough === report.practiceCutoff;
  }
  function toReport(run) {
    if (!isRun(run) || run.practiceCutoff === null) throw new Error('Finished practice evidence is required.');
    return { ...copyRun(run), evaluatedThrough: run.practiceCutoff };
  }
  // The caller validates the dormant v1 run with DirectionAccuracy.isRun too.
  // This predicate only proves its exact, unfinished, signed prefix was retained.
  function matchesPrefix(run, prefix) {
    const start = prefix?.startBar === undefined ? 0 : prefix.startBar;
    return isRun(run) && !!prefix && prefix.version === 1 && prefix.practiceCutoff === null && start === run.startBar && denseChoices(prefix.choices, start, MAX_BARS, true) && prefix.choices.length <= run.choices.length && prefix.choices.every((choice, index) => choice.bar === run.choices[index].bar && choice.direction === run.choices[index].direction);
  }
  root.PracticeEvidence = Object.freeze({ VERSION, MAX_BARS, newRun, copyRun, capture, finish, isRun, toReport, isReport, matchesPrefix });
})(globalThis);
