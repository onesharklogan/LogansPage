import {DAY_TYPE_CATALOG_SHA256} from './day-type-catalog-version.js';
/** Public, read-only labels. This module never reads learner storage or sends history. */
export const filters=Object.freeze([
 ['all','All day types'],['bull-trend','Bull trend'],['bear-trend','Bear trend'],['trading-range','Trading range'],['trending-trading-range','Trending trading range'],['upper-lower-ranges','Upper/lower ranges'],['reversal','Reversal'],['mixed-unclear','Mixed / unclear'],['unknown','Unknown / outside catalog']
]);
/** Require a catalog identity, not a coincident calendar date. Imported/simulated data stays unknown. */
export function dateOf(row){
 if(!row||typeof row!=='object')return '';
 if(typeof row.sampleType==='string'&&!/^hosted historical(?: |$)/.test(row.sampleType))return '';
 if(typeof row.key==='string'&&row.key.startsWith('sim:'))return '';
 if(typeof row.key==='string'&&row.key.startsWith('csv:')&&!row.hosted?.id)return '';
 const ids=[row.hosted?.id,row.sessionId,row.chartId].filter(value=>typeof value==='string'&&/^mes1-\d{4}-\d{2}-\d{2}-81$/.test(value));
 if(!ids.length||new Set(ids).size!==1)return '';
 const date=ids[0].slice(5,15);
 if(row.sessionDate!=null&&row.sessionDate!==date)return '';
 return date;
}
export function sourceEntry(row,byDate){
 const entry=byDate.get(dateOf(row));if(!entry)return undefined;
 if(typeof row.key==='string'&&row.key.startsWith('csv:')&&row.key!=='csv:'+entry.normalizedSourceSha256)return undefined;
 for(const hash of [row.sessionHash,row.hosted?.sha256,row.hosted?.sourceSha256])if(hash!=null&&hash!==entry.sourceSha256)return undefined;
 return entry;
}
export function makeLookup(data){
 if(!data||data.schemaVersion!==1||data.algorithmVersion!=='day-structure-v1.1'||!Array.isArray(data.days)||data.days.length>2000||data.manifest?.count!==data.days.length||!['sourceCatalogSha256','combinedSourceSha256','algorithmSourceSha256'].every(key=>/^[a-f0-9]{64}$/.test(data.manifest?.[key])))throw Error('Day type catalog unavailable.');
 const labels=new Map(filters),primaryTypes=new Set(['bull-trend','bear-trend','trading-range','trending-trading-range','reversal','mixed-unclear']),byDate=new Map();
 for(const row of data.days){if(!row||typeof row.date!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(row.date)||!Number.isFinite(Date.parse(row.date))||new Date(row.date).toISOString().slice(0,10)!==row.date||byDate.has(row.date)||row.id!==`mes1-${row.date}-81`||!/^[a-f0-9]{64}$/.test(row.sourceSha256)||!/^[a-f0-9]{64}$/.test(row.normalizedSourceSha256)||!primaryTypes.has(row.primaryType)||!Array.isArray(row.tags)||row.tags.length>1||row.tags.some(tag=>tag!=='upper-lower-ranges')||(row.tags.length&&row.primaryType!=='trending-trading-range'))throw Error('Day type catalog unavailable.');byDate.set(row.date,row);}
 return {algorithmVersion:data.algorithmVersion,matches(row,filter){if(filter==='all')return true;const entry=sourceEntry(row,byDate);return filter==='unknown'?!entry:!!entry&&(entry.primaryType===filter||entry.tags.includes(filter));},label(row){const entry=sourceEntry(row,byDate);return entry?labels.get(entry.primaryType):'Unknown / outside catalog';}};
}
let loading;
export function load(){if(!loading)loading=fetch('/day-types.json?v='+DAY_TYPE_CATALOG_SHA256,{credentials:'omit',cache:'no-cache'}).then(async response=>{if(!response.ok)throw Error('Day type catalog unavailable.');const text=await response.text();if(text.length>500000)throw Error('Day type catalog too large.');const hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text)))].map(n=>n.toString(16).padStart(2,'0')).join('');if(hash!==DAY_TYPE_CATALOG_SHA256)throw Error('Day type catalog version mismatch.');return makeLookup(JSON.parse(text));}).catch(error=>{loading=null;throw error;});return loading;}
