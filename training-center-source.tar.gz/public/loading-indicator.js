(function (root) {
  'use strict';
  const escape = value => String(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  function markup(label = 'Loading…', options = {}) {
    const size = ['small', 'normal', 'large'].includes(options.size) ? options.size : 'normal';
    return '<span class="pa-loading pa-loading--' + size + '"><picture class="pa-loading__graphic" aria-hidden="true"><source media="(prefers-reduced-motion: reduce)" srcset="/brand/candle-loading.png"><img src="/brand/candle-loading.gif" width="136" height="136" alt="" decoding="async"></picture><span class="pa-loading__label">' + escape(label) + '</span></span>';
  }
  function set(element, label = 'Loading…', options = {}) {
    if (!element) return;
    const size = ['small', 'normal', 'large'].includes(options.size) ? options.size : 'normal';
    const current = element.firstElementChild;
    // Repeated simulator renders must not restart the GIF or reannounce the label.
    if (element.childNodes.length === 1 && current?.classList.contains('pa-loading--' + size) && current.querySelector('.pa-loading__label')?.textContent === String(label)) return;
    element.innerHTML = markup(label, { size });
  }
  root.PriceActionLoading = Object.freeze({ markup, set });
})(globalThis);
