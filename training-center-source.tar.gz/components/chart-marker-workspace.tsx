'use client';

import { useEffect, useState } from 'react';
import AppHeader from './app-navigation';
import LearnerProfiles from '../public/modules/learner-profiles.js';
import styles from './chart-marker.module.css';

/** Image-only workspace: reads an existing local learner, never creates/selects one. */
export default function ChartMarkerWorkspace() {
  const [name, setName] = useState<string | null>(null);
  useEffect(() => {
    const refresh = () => {
      const snapshot = LearnerProfiles.read();
      setName(snapshot.ok && LearnerProfiles.validLearnerId(snapshot.active?.learnerId) ? snapshot.active.name : null);
    };
    refresh();
    window.addEventListener('storage', refresh);
    window.addEventListener('focus', refresh);
    window.addEventListener('pageshow', refresh);
    return () => {
      window.removeEventListener('storage', refresh);
      window.removeEventListener('focus', refresh);
      window.removeEventListener('pageshow', refresh);
    };
  }, []);
  return <div className={styles.page}>
    <AppHeader section="CHART MARKER" current="/chart-marker">
      {name && <span className={styles.profile} title="Existing local learner; annotations belong to this open workspace, not a saved profile."><small>Local learner</small><strong>{name}</strong></span>}
    </AppHeader>
    <main className={styles.main} aria-label="Chart Marker">
      <h1 className={styles.srOnly}>Chart Marker</h1>
      <iframe className={styles.frame} src="/modules/chart-marker.html" title="Chart Marker image workspace" allow="clipboard-write; fullscreen" allowFullScreen />
    </main>
  </div>;
}
