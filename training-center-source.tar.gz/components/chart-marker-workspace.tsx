'use client';

import {useEffect,useMemo,useRef,useState,type KeyboardEvent} from 'react';
import AppHeader from './app-navigation';
import TradeSessionCalendar from './trade-session-calendar';
import {loadChartMatchSessions} from './chart-match-data.mjs';
import {renderPredefinedChart} from '../lib/marker-predefined.mjs';
import LearnerProfiles from '../public/modules/learner-profiles.js';
import styles from './chart-marker.module.css';

type Request={token:number;phase:'catalog'|'choose'|'drawing'|'installing'|'error';candidates:any[];selected:string;error:string;retryable?:boolean};
/** Local-image workspace. Predefined images use only hash-verified historical data;
 * the iframe owns image/annotation replacement and acknowledges successful decode. */
export default function ChartMarkerWorkspace(){
 const [name,setName]=useState<string|null>(null),[request,setRequest]=useState<Request|null>(null);
 const calendarEntries=useMemo(()=>request?.candidates.map(row=>row.reference)||[],[request?.candidates]);
 const frame=useRef<HTMLIFrameElement>(null),panel=useRef<HTMLDivElement>(null),live=useRef(true),active=useRef<Request|null>(null),job=useRef<AbortController|null>(null),timer=useRef<ReturnType<typeof setTimeout>|null>(null);
 function clearJob(){job.current?.abort();job.current=null;if(timer.current!==null)clearTimeout(timer.current);timer.current=null;}
 function install(value:Request|null){active.current=value;setRequest(value);}
 function valid(value:Request){return live.current&&active.current===value;}
 function post(value:Record<string,unknown>,transfer:Transferable[]=[]){frame.current?.contentWindow?.postMessage(value,window.location.origin,transfer);}
 function close(value:Request,notify=true){if(!valid(value))return;clearJob();install(null);if(notify)post({type:'chart-marker-predefined-cancel',version:1,token:value.token});frame.current?.focus();}
 function failed(value:Request,message:string){if(!valid(value))return;clearJob();install({...value,phase:'error',error:message});}
 async function catalog(value:Request){
  clearJob();const controller=new AbortController();job.current=controller;
  try{const candidates=await loadChartMatchSessions({signal:controller.signal});if(!valid(value)||controller.signal.aborted)return;job.current=null;install({...value,phase:'choose',candidates,selected:candidates.at(-1)?.reference.id||''});}
  catch(error){if(!controller.signal.aborted)failed(value,'The predefined session calendar could not be loaded. Your current chart is unchanged.');}
 }
 async function choose(value:Request,id:string){
  if(!valid(value)||value.phase!=='choose'&&value.phase!=='error')return;
  const source=value.candidates.find(row=>row.reference.id===id);if(!source)return;
  clearJob();const next:Request={...value,phase:'drawing',selected:id,error:''};install(next);const controller=new AbortController();job.current=controller;
  try{
   const image=await renderPredefinedChart(source.chart,{signal:controller.signal,candidates:value.candidates});
   if(!valid(next)||controller.signal.aborted)return;
   const pending:Request={...next,phase:'installing'};install(pending);job.current=null;
   post({type:'chart-marker-predefined-image',version:1,token:pending.token,id:source.reference.id,date:image.date,name:image.name,mime:'image/png',buffer:image.buffer},[image.buffer]);
   timer.current=setTimeout(()=>{if(!valid(pending))return;post({type:'chart-marker-predefined-cancel',version:1,token:pending.token});clearJob();install({...pending,phase:'error',retryable:false,error:'Opening could not be confirmed. Close and check the current chart before choosing the day again.'});},10000);
  }catch(error){if(!controller.signal.aborted)failed(next,'This predefined chart could not be drawn. Your current chart is unchanged.');}
 }
 function retry(value:Request){if(!valid(value)||value.phase!=='error'||value.retryable===false)return;if(value.candidates.length&&value.selected)choose(value,value.selected);else{const next:Request={...value,phase:'catalog',error:''};install(next);catalog(next);}}
 useEffect(()=>{
  live.current=true;
  const refresh=()=>{const snapshot=LearnerProfiles.read();setName(snapshot.ok&&LearnerProfiles.validLearnerId(snapshot.active?.learnerId)?snapshot.active.name:null);};
  const message=(event:MessageEvent)=>{
   const data=event.data;if(event.origin!==window.location.origin||event.source!==frame.current?.contentWindow||!data||data.version!==1||!Number.isSafeInteger(data.token)||data.token<1)return;
   if(data.type==='chart-marker-predefined-request'){
    clearJob();const value:Request={token:data.token,phase:'catalog',candidates:[],selected:'',error:''};install(value);catalog(value);
   }else {const current=active.current;if(!current||current.token!==data.token)return;if(data.type==='chart-marker-predefined-cancel')close(current,false);else if(data.type==='chart-marker-predefined-result'&&current.phase==='installing'){if(data.ok===true)close(current,false);else if(data.ok===false)failed(current,'This chart image could not be opened. Your current chart is unchanged.');}}
  };
  refresh();window.addEventListener('message',message);window.addEventListener('storage',refresh);window.addEventListener('focus',refresh);window.addEventListener('pageshow',refresh);
  return()=>{live.current=false;clearJob();active.current=null;window.removeEventListener('message',message);window.removeEventListener('storage',refresh);window.removeEventListener('focus',refresh);window.removeEventListener('pageshow',refresh);};
 },[]);
 useEffect(()=>{if(request&&request.phase!=='choose')panel.current?.querySelector<HTMLButtonElement>('button')?.focus();},[request]);
 function panelKeys(event:KeyboardEvent<HTMLDivElement>,value:Request){event.stopPropagation();if(event.key==='Escape'){event.preventDefault();close(value);}if(event.key==='Tab'){const buttons=Array.from(panel.current?.querySelectorAll<HTMLButtonElement>('button:not(:disabled)')||[]),index=buttons.indexOf(document.activeElement as HTMLButtonElement);event.preventDefault();buttons[(index+(event.shiftKey?-1:1)+buttons.length)%buttons.length]?.focus();}}
 return <div className={styles.page}>
  <AppHeader section="CHART MARKER" current="/chart-marker">{name&&<span className={styles.profile} title="Existing local learner; annotations belong to this open workspace, not a saved profile."><small>Local learner</small><strong>{name}</strong></span>}</AppHeader>
  <main className={styles.main} aria-label="Chart Marker"><h1 className={styles.srOnly}>Chart Marker</h1><iframe ref={frame} className={styles.frame} src="/modules/chart-marker.html" title="Chart Marker image workspace" allow="clipboard-write; fullscreen" allowFullScreen inert={!!request} onLoad={()=>{const current=active.current;if(current)close(current,false);}}/></main>
  {request?.phase==='choose'?<TradeSessionCalendar entries={calendarEntries} initialId={request.selected} title="Load predefined chart" confirmLabel="Load chart" helpText="Loading a day replaces the image and clears its drawings. Cancel keeps your current chart. Arrow keys or W A S D move between dates; Enter selects." onChoose={id=>choose(request,id)} onClose={()=>close(request)}/>:request&&<div className={styles.pickerOverlay}><div ref={panel} className={styles.pickerPanel} role="dialog" aria-modal="true" aria-labelledby="marker-predefined-title" onKeyDown={event=>panelKeys(event,request)}><h2 id="marker-predefined-title">Load predefined chart</h2><p role={request.error?'alert':'status'}>{request.error||(request.phase==='catalog'?'Loading available session dates…':request.phase==='installing'?'Opening the chart image. Successful decoding replaces the current chart and its drawings.':'Preparing the selected historical chart…')}</p>{request.phase==='error'&&request.retryable!==false&&<button type="button" onClick={()=>retry(request)}>Retry</button>}<button type="button" onClick={()=>close(request)}>{request.phase==='installing'||request.retryable===false?'Close':'Cancel'}</button></div></div>}
 </div>;
}
