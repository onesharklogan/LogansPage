import {headers} from 'next/headers';
import {handleRenderRequest} from '../lib/portal/render-runtime.mjs';
import {homeTeacherAccess} from '../lib/portal/home-teacher-access.mjs';
import styles from './home-gallery.module.css';

/** Server-rendered only after the existing session verifier confirms an active admin. */
export default async function HomeTeacherStudioCard() {
  const origin = process.env.APP_ORIGIN;
  if (!origin) return null;
  const incoming = await headers();
  let request: Request;
  try { request = new Request(new URL('/', origin), {headers: incoming}); } catch { return null; }
  if (!await homeTeacherAccess(request, handleRenderRequest)) return null;
  return <a className={`training-module-card ${styles.teacherCard}`} href="/admin/modules">
    <div className="module-symbol simulator-symbol" aria-hidden="true">
      <svg data-tool-icon="teacher-studio" viewBox="0 0 104 112" width="104" height="112" fill="none" aria-hidden="true" focusable="false">
        <rect x="8" y="17" width="88" height="64" rx="7" stroke="currentColor" strokeWidth="3"/>
        <path d="M17 34h70M20 67l15-15 15 8 14-19 17 8M52 82v18m-18 4 18-4 18 4" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="m65 83 17-17 8 8-17 17-12 4 4-12Z" fill="#422435" stroke="#f4b9d6" strokeWidth="3" strokeLinejoin="round"/>
        <path d="m79 69 8 8" stroke="#f4b9d6" strokeWidth="2"/>
        <circle cx="20" cy="26" r="2" fill="currentColor"/><circle cx="28" cy="26" r="2" fill="currentColor"/>
      </svg>
    </div>
    <div><p className="eyebrow">ADMIN WORKSPACE</p><h2>Teacher Studio</h2><p>Create Lessons, design chart exercises and bring your next teaching idea to life.</p><span className="module-open">Open studio <svg viewBox="0 0 20 20" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true" focusable="false"><path d="M5 15 15 5M5 5h10v10" strokeLinecap="round" strokeLinejoin="round"/></svg></span></div>
  </a>;
}
