"use client";
import { useEffect, useRef, useState } from 'react';
import { mountGoogleButton } from './google-gis.mjs';

export default function GoogleSignIn({ clientId, onSignedIn }: { clientId: string; onSignedIn: () => Promise<void> }) {
  const element = useRef<HTMLDivElement>(null), success = useRef(onSignedIn);
  success.current = onSignedIn;
  const [attempt, setAttempt] = useState(0), [stage, setStage] = useState('loading'), [message, setMessage] = useState('');
  useEffect(() => {
    if (!element.current) return;
    const button = mountGoogleButton({ clientId, element: element.current, onState: (next, text = '') => { setStage(next); setMessage(text); }, onSuccess: () => success.current() });
    return () => button.dispose();
  }, [clientId, attempt]);
  return <div className="google-signin-control" aria-busy={stage === 'loading' || stage === 'verifying'}><div ref={element} className={stage === 'ready' ? 'google-official-button' : 'google-official-button google-button-inactive'} />{stage === 'loading' && <p role="status">Loading Google sign-in…</p>}{stage === 'verifying' && <p role="status">Checking your author access…</p>}{stage === 'success' && <p role="status">Signed in. Refreshing access…</p>}{stage === 'error' && <><p className="notice error" role="alert">{message}</p><button className="quiet-button" onClick={() => setAttempt(value => value + 1)}>Try Google sign-in again</button></>}<p className="field-help">Google handles sign-in. Never enter or share your Google password in this app.</p></div>;
}
