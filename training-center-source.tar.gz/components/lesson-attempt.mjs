// Pure, transient learner geometry/state. No storage, network requests, or teacher answer rendering.
export const CHART = Object.freeze({ width: 960, height: 470, left: 66, right: 20, top: 24, bottom: 42 });
export const MAX_LEARNER_MARKS = 80;
export const LEGACY_PROMPT = 'Study the price chart. Add your own lines, arrows or notes, then reveal the teacher’s answer.';
const clamp = (value, minimum, maximum) => Math.max(minimum, Math.min(maximum, value));

export function createViewport(candles, lines = [], annotations = [], arrows = [], targets = []) {
  const prices = [...candles.flatMap(candle => [candle.l, candle.h]), ...lines.flatMap(line => [line.a.price, line.b.price]), ...annotations.map(mark => mark.at.price), ...arrows.map(mark => mark.at.price), ...targets.flatMap(target => [target.a.price, target.b.price])];
  const minimum = Math.min(...prices), maximum = Math.max(...prices);
  const padding = Math.max((maximum - minimum) * 0.08, 0.5);
  return { ...CHART, count: candles.length, lo: minimum - padding, hi: maximum + padding };
}
export function projectPoint(point, viewport) {
  return { x: viewport.left + (point.bar + 0.5) / viewport.count * (viewport.width - viewport.left - viewport.right), y: viewport.top + (viewport.hi - point.price) / (viewport.hi - viewport.lo) * (viewport.height - viewport.top - viewport.bottom) };
}
export function pointFromSvg(x, y, viewport, candles) {
  if (!Number.isFinite(x) || !Number.isFinite(y) || x < viewport.left || x > viewport.width - viewport.right || y < viewport.top || y > viewport.height - viewport.bottom) return null;
  const bar = clamp(Math.floor((x - viewport.left) / (viewport.width - viewport.left - viewport.right) * viewport.count), 0, viewport.count - 1);
  return { bar, t: candles[bar].t, price: viewport.hi - (y - viewport.top) / (viewport.height - viewport.top - viewport.bottom) * (viewport.hi - viewport.lo) };
}
// SVG's default xMidYMid meet includes letterboxing. Offsets also account for a scrolled chart.
export function clientToSvg(clientX, clientY, rect, viewport = CHART) {
  const scale = Math.min(rect.width / viewport.width, rect.height / viewport.height);
  if (!(scale > 0) || !Number.isFinite(scale)) return null;
  return { x: (clientX - rect.left - (rect.width - viewport.width * scale) / 2) / scale, y: (clientY - rect.top - (rect.height - viewport.height * scale) / 2) / scale };
}
export function distantEnough(a, b, viewport) {
  const first = projectPoint(a, viewport), last = projectPoint(b, viewport);
  return Math.hypot(last.x - first.x, last.y - first.y) >= 8;
}
export function validLearnerText(value) {
  return typeof value === 'string' && value.trim().length > 0 && value.length <= 500 && !/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(value);
}
const validPoint = point => point && Number.isInteger(point.bar) && point.bar >= 0 && typeof point.t === 'string' && Number.isFinite(point.price);
export function validLearnerMark(mark) {
  if (!mark || typeof mark.id !== 'string' || !['line', 'arrow', 'text'].includes(mark.kind)) return false;
  if (mark.kind === 'text') return validPoint(mark.at) && validLearnerText(mark.text) && /^#[a-f0-9]{6}$/i.test(mark.color) && [14,18,22,26].includes(mark.size);
  if (mark.kind === 'arrow') return validPoint(mark.at) && ['up','down'].includes(mark.direction) && typeof mark.study === 'boolean' && typeof mark.crossed === 'boolean';
  return validPoint(mark.a) && validPoint(mark.b) && (mark.a.bar !== mark.b.bar || mark.a.price !== mark.b.price) && /^#[a-f0-9]{6}$/i.test(mark.color);
}
export function newAttempt() { return { phase: 'practice', marks: [], history: [], selectedBars: [], foundIds: [] }; }
export function attemptReducer(state, action) {
  if (action.type === 'replay') return newAttempt();
  if (action.type === 'reveal') return state.phase === 'revealed' ? state : { ...state, phase: 'revealed' };
  if (state.phase !== 'practice') return state;
  if (action.type === 'add' && state.marks.length < MAX_LEARNER_MARKS && validLearnerMark(action.mark) && !state.marks.some(mark => mark.id === action.mark.id)) return { ...state, marks: [...state.marks, action.mark], history: [...state.history, state.marks].slice(-80) };
  if (action.type === 'update' && validLearnerMark(action.mark) && state.marks.some(mark => mark.id === action.mark.id)) return { ...state, marks: state.marks.map(mark => mark.id === action.mark.id ? action.mark : mark), history: [...state.history, state.marks].slice(-80) };
  if (action.type === 'remove' && state.marks.some(mark => mark.id === action.id)) return { ...state, marks: state.marks.filter(mark => mark.id !== action.id), history: [...state.history, state.marks].slice(-80) };
  if (action.type === 'discover' && Array.isArray(action.ids)) return { ...state, foundIds: [...new Set([...state.foundIds, ...action.ids.filter(id => typeof id === 'string')])].slice(0,80) };
  if (action.type === 'toggle-candle' && Number.isInteger(action.bar) && action.bar >= 0 && action.bar < 2000) return { ...state, selectedBars: state.selectedBars.includes(action.bar) ? state.selectedBars.filter(bar => bar !== action.bar) : [...state.selectedBars, action.bar].sort((a,b) => a-b) };
  if (action.type === 'undo' && state.history.length) return { ...state, marks: state.history.at(-1), history: state.history.slice(0, -1) };
  if (action.type === 'clear' && state.marks.length) return { ...state, marks: [], history: [...state.history, state.marks].slice(-80) };
  return state;
}

export function exactCandleSelection(selectedBars, correctBars) {
  if (!Array.isArray(selectedBars) || !Array.isArray(correctBars) || !correctBars.length || selectedBars.length !== correctBars.length) return false;
  const chosen = new Set(selectedBars), correct = new Set(correctBars);
  return chosen.size === selectedBars.length && correct.size === correctBars.length && [...chosen].every(bar => Number.isInteger(bar) && correct.has(bar));
}

export function chartPositionFromSvg(x, y, viewport) {
  if (!Number.isFinite(x) || !Number.isFinite(y) || x < viewport.left || x > viewport.width - viewport.right || y < viewport.top || y > viewport.height - viewport.bottom) return null;
  return {bar:(x-viewport.left)/(viewport.width-viewport.left-viewport.right)*viewport.count-0.5,price:viewport.hi-(y-viewport.top)/(viewport.height-viewport.top-viewport.bottom)*(viewport.hi-viewport.lo),priceTolerance:Number.EPSILON*Math.max(1,Math.abs(viewport.lo),Math.abs(viewport.hi),viewport.hi-viewport.lo)*16};
}
export function hitTargetIds(targets, position, foundIds = []) {
  if (!position || !Number.isFinite(position.bar) || !Number.isFinite(position.price)) return [];
  const found = new Set(foundIds);
  return targets.filter(target => {
    const epsilon = Math.max(position.priceTolerance || 0, Number.EPSILON * Math.max(1,Math.abs(position.price),Math.abs(target.a.price),Math.abs(target.b.price)) * 8);
    return !found.has(target.id) && position.bar >= Math.min(target.a.bar,target.b.bar)-1e-9 && position.bar <= Math.max(target.a.bar,target.b.bar)+1e-9 && position.price >= Math.min(target.a.price,target.b.price)-epsilon && position.price <= Math.max(target.a.price,target.b.price)+epsilon;
  }).map(target => target.id);
}
export function allTargetsFound(targets, foundIds) {
  return targets.length > 0 && targets.every(target => foundIds.includes(target.id));
}
