// Pure, transient learner geometry/state. No storage, network requests, or teacher answer rendering.
import Model from '../lib/portal/lesson-model.cjs';
export const learnerToolPolicy = Model.learnerToolPolicy;
export const learnerToolAllowed = Model.learnerToolAllowed;
// Optional annotation actions only; answer selection and completion gates stay independent.
export function learnerActionAllowed(lesson, action, marks = []) {
  if (!lesson || !Object.prototype.hasOwnProperty.call(lesson, 'learnerTools')) return true;
  if (action.type === 'add') return learnerToolAllowed(lesson, action.mark?.kind);
  if (action.type === 'update' || action.type === 'select') {
    const mark = marks.find(mark => mark.id === (action.mark?.id ?? action.id));
    return !!mark && learnerToolAllowed(lesson, 'select') && learnerToolAllowed(lesson, mark.kind) && (action.type !== 'update' || action.mark.kind === mark.kind);
  }
  if (action.type === 'remove') return learnerToolAllowed(lesson, 'erase');
  if (action.type === 'undo' || action.type === 'clear') return learnerToolAllowed(lesson, action.type);
  return true;
}
export function savedIndicatorSettings(lesson) { return Model.indicatorSettings(lesson); }
export const CHART = Object.freeze({ width: 960, height: 470, left: 66, right: 20, top: 24, bottom: 42 });
export const MAX_LEARNER_MARKS = 80;
export const LEGACY_PROMPT = 'Study the price chart. Add your own lines, arrows or notes, then reveal the teacher’s answer.';
const clamp = (value, minimum, maximum) => Math.max(minimum, Math.min(maximum, value));

// Every saved coordinate remains global; a range changes only the view, never the lesson.
export function barInViewport(bar, viewport) {
  const start = viewport.startBar ?? 0, end = viewport.endBar ?? start + viewport.count - 1;
  return Number.isFinite(bar) && bar >= start && bar <= end && (viewport.frameStart===undefined||(bar+.5>=viewport.frameStart&&bar+.5<=viewport.frameStart+viewport.count));
}
export function clipLineToRange(line, viewport) {
  const start = viewport.frameStart===undefined?(viewport.startBar ?? 0)-.5:Math.max((viewport.disclosedStart??0)-.5,viewport.frameStart-.5), end = viewport.frameStart===undefined?(viewport.endBar ?? (viewport.startBar ?? 0) + viewport.count - 1)+.5:Math.min((viewport.disclosedEnd??viewport.endBar)+.5,viewport.frameStart+viewport.count-.5);
  const {a,b} = line, dx = b.bar - a.bar;
  if (!dx) return a.bar < start || a.bar > end ? null : {...line,a:{...a},b:{...b}};
  const atStart = (start-a.bar)/dx, atEnd = (end-a.bar)/dx;
  const from = Math.max(0,Math.min(atStart,atEnd)), to = Math.min(1,Math.max(atStart,atEnd));
  if (from > to) return null;
  const point = fraction => fraction === 0 ? {...a} : fraction === 1 ? {...b} : {...a,bar:a.bar+fraction*dx,price:a.price+fraction*(b.price-a.price)};
  return {...line,a:point(from),b:point(to)};
}
/** @typedef {{width:number,height:number,left:number,right:number,top:number,bottom:number,startBar:number,endBar:number,count:number,lo:number,hi:number,frameStart?:number,disclosedStart?:number,disclosedEnd?:number,priorCount?:number,locked?:boolean}} ChartViewport */
/** @param {{startBar:number,endBar:number}|undefined} [range]
 * @param {{version:1,start:number,span:number,low:number,high:number}|undefined} [framing]
 * @param {Array<{t:string,o:number,h:number,l:number,c:number}>} [prior]
 * @returns {ChartViewport}
 */
export function createViewport(candles, lines = [], annotations = [], arrows = [], targets = [], range = undefined, indicatorEma = [], connectedLines = [], filledShapes = [], framing = undefined, prior = []) {
  const startBar = range?.startBar ?? 0, endBar = range?.endBar ?? candles.length - 1;
  if (!Number.isInteger(startBar) || !Number.isInteger(endBar) || startBar < 0 || endBar < startBar || endBar >= candles.length) throw new Error('Invalid saved candle range.');
  if(framing!==undefined){const frame=Model.viewport(framing),problem=Model.viewportProblem({viewport:frame,...(range?{range}:{})},{current:candles,prior});if(problem)throw Error(problem);const first=Math.max(startBar,Math.ceil(frame.start-.5)),last=Math.min(endBar,Math.floor(frame.start+frame.span-.5));return {...CHART,startBar:first,endBar:last,count:frame.span,frameStart:frame.start,disclosedStart:startBar,disclosedEnd:endBar,priorCount:range?0:prior.length,lo:frame.low,hi:frame.high,locked:true};}
  const bounds = {startBar,endBar,count:endBar-startBar+1};
  const visibleLines = [...lines,...filledShapes,...connectedLines.flatMap(shape=>shape.points.slice(1).map((b,i)=>({a:shape.points[i],b})))].map(line=>clipLineToRange(line,bounds)).filter(Boolean);
  const prices = [...candles.slice(startBar,endBar+1).flatMap(candle => [candle.l,candle.h]), ...indicatorEma.slice(startBar,endBar+1).filter(Number.isFinite), ...visibleLines.flatMap(line => [line.a.price,line.b.price]), ...annotations.filter(mark=>barInViewport(mark.at.bar,bounds)).map(mark=>mark.at.price), ...arrows.filter(mark=>barInViewport(mark.at.bar,bounds)).map(mark=>mark.at.price), ...targets.filter(target=>barInViewport(target.a.bar,bounds)&&barInViewport(target.b.bar,bounds)).flatMap(target=>[target.a.price,target.b.price])];
  const minimum = Math.min(...prices), maximum = Math.max(...prices);
  const padding = Math.max((maximum - minimum) * 0.08, 0.5);
  return { ...CHART, ...bounds, lo: minimum - padding, hi: maximum + padding };
}
/** @param {Array<{t:string,o:number,h:number,l:number,c:number}>} candles
 * @param {ChartViewport} viewport
 * @param {Array<{t:string,o:number,h:number,l:number,c:number}>} [prior]
 * @returns {Array<{candle:{t:string,o:number,h:number,l:number,c:number},bar:number}>}
 */
export function visibleViewportCandles(candles, viewport, prior = []) {
 const first=viewport.frameStart===undefined?viewport.startBar:Math.max(viewport.disclosedStart,Math.floor(viewport.frameStart)),last=viewport.frameStart===undefined?viewport.endBar:Math.min(viewport.disclosedEnd,Math.ceil(viewport.frameStart+viewport.count)-1);const current=candles.slice(Math.max(0,first),Math.max(0,last+1)).map((candle,offset)=>({candle,bar:Math.max(0,first)+offset}));
 if(viewport.frameStart===undefined||!viewport.priorCount)return current;
 const count=Math.min(prior.length,viewport.priorCount),priorFirst=Math.max(-count,Math.floor(viewport.frameStart)),priorLast=Math.min(-1,Math.ceil(viewport.frameStart+viewport.count)-1),context=[];for(let bar=priorFirst;bar<=priorLast;bar++){const candle=prior[prior.length+bar];if(candle)context.push({candle,bar})}return [...context,...current];
}
export function projectPoint(point, viewport) {
  return { x: viewport.left + (point.bar - (viewport.frameStart ?? viewport.startBar ?? 0) + 0.5) / viewport.count * (viewport.width - viewport.left - viewport.right), y: viewport.top + (viewport.hi - point.price) / (viewport.hi - viewport.lo) * (viewport.height - viewport.top - viewport.bottom) };
}
export function pointFromSvg(x, y, viewport, candles) {
  if (!Number.isFinite(x) || !Number.isFinite(y) || x < viewport.left || x > viewport.width - viewport.right || y < viewport.top || y > viewport.height - viewport.bottom) return null;
  const start = viewport.startBar ?? 0, end = viewport.endBar ?? start + viewport.count - 1;
  const raw = Math.floor((viewport.frameStart ?? start)+(x - viewport.left) / (viewport.width - viewport.left - viewport.right) * viewport.count),bar=viewport.frameStart===undefined?clamp(raw,start,end):raw;
  if(bar<start||bar>end||!candles[bar])return null;
  return { bar, t: candles[bar].t, price: viewport.hi - (y - viewport.top) / (viewport.height - viewport.top - viewport.bottom) * (viewport.hi - viewport.lo) };
}
// SVG's default xMidYMid meet includes letterboxing. Offsets also account for a scrolled chart.
/** @param {{width:number,height:number}} [viewport] */
export function clientToSvg(clientX, clientY, rect, viewport = CHART) {
  const scale = Math.min(rect.width / viewport.width, rect.height / viewport.height);
  if (!(scale > 0) || !Number.isFinite(scale)) return null;
  return { x: (clientX - rect.left - (rect.width - viewport.width * scale) / 2) / scale, y: (clientY - rect.top - (rect.height - viewport.height * scale) / 2) / scale };
}
export function distantEnough(a, b, viewport) {
  const first = projectPoint(a, viewport), last = projectPoint(b, viewport);
  return Math.hypot(last.x - first.x, last.y - first.y) >= 8;
}
export function validLearnerText(value) {
  return typeof value === 'string' && value.trim().length > 0 && value.length <= 500 && !/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(value);
}
const validPoint = point => point && Number.isInteger(point.bar) && point.bar >= 0 && typeof point.t === 'string' && Number.isFinite(point.price);
export function validLearnerMark(mark) {
  if (!mark || typeof mark.id !== 'string' || !['line', 'arrow', 'text'].includes(mark.kind)) return false;
  if (mark.kind === 'text') return validPoint(mark.at) && validLearnerText(mark.text) && /^#[a-f0-9]{6}$/i.test(mark.color) && [14,18,22,26].includes(mark.size);
  if (mark.kind === 'arrow') return validPoint(mark.at) && ['up','down'].includes(mark.direction) && typeof mark.study === 'boolean' && typeof mark.crossed === 'boolean';
  return validPoint(mark.a) && validPoint(mark.b) && (mark.a.bar !== mark.b.bar || mark.a.price !== mark.b.price) && /^#[a-f0-9]{6}$/i.test(mark.color);
}
export function newAttempt() { return { phase: 'practice', marks: [], history: [], selectedBars: [], foundIds: [] }; }
export function attemptReducer(state, action, lesson) {
  if (!learnerActionAllowed(lesson, action, state.marks)) return state;
  if (action.type === 'replay') return newAttempt();
  if (action.type === 'reveal' || action.type === 'study-reveal') return state.phase !== 'practice' ? state : { ...state, phase: action.type === 'study-reveal' ? 'study-revealed' : 'revealed' };
  if (state.phase !== 'practice') return state;
  if (action.type === 'add' && state.marks.length < MAX_LEARNER_MARKS && validLearnerMark(action.mark) && !state.marks.some(mark => mark.id === action.mark.id)) return { ...state, marks: [...state.marks, action.mark], history: [...state.history, state.marks].slice(-80) };
  if (action.type === 'update' && validLearnerMark(action.mark) && state.marks.some(mark => mark.id === action.mark.id)) return { ...state, marks: state.marks.map(mark => mark.id === action.mark.id ? action.mark : mark), history: [...state.history, state.marks].slice(-80) };
  if (action.type === 'remove' && state.marks.some(mark => mark.id === action.id)) return { ...state, marks: state.marks.filter(mark => mark.id !== action.id), history: [...state.history, state.marks].slice(-80) };
  if (action.type === 'discover' && Array.isArray(action.ids)) return { ...state, foundIds: [...new Set([...state.foundIds, ...action.ids.filter(id => typeof id === 'string')])].slice(0,80) };
  if (action.type === 'toggle-candle' && Number.isInteger(action.bar) && action.bar >= 0 && action.bar < 2000) return { ...state, selectedBars: state.selectedBars.includes(action.bar) ? state.selectedBars.filter(bar => bar !== action.bar) : [...state.selectedBars, action.bar].sort((a,b) => a-b) };
  if (action.type === 'undo' && state.history.length) return { ...state, marks: state.history.at(-1), history: state.history.slice(0, -1) };
  if (action.type === 'clear' && state.marks.length) return { ...state, marks: [], history: [...state.history, state.marks].slice(-80) };
  return state;
}

export function exactCandleSelection(selectedBars, correctBars) {
  if (!Array.isArray(selectedBars) || !Array.isArray(correctBars) || !correctBars.length || selectedBars.length !== correctBars.length) return false;
  const chosen = new Set(selectedBars), correct = new Set(correctBars);
  return chosen.size === selectedBars.length && correct.size === correctBars.length && [...chosen].every(bar => Number.isInteger(bar) && correct.has(bar));
}

export function chartPositionFromSvg(x, y, viewport) {
  if (!Number.isFinite(x) || !Number.isFinite(y) || x < viewport.left || x > viewport.width - viewport.right || y < viewport.top || y > viewport.height - viewport.bottom) return null;
  return {bar:(viewport.frameStart ?? viewport.startBar ?? 0)+(x-viewport.left)/(viewport.width-viewport.left-viewport.right)*viewport.count-0.5,price:viewport.hi-(y-viewport.top)/(viewport.height-viewport.top-viewport.bottom)*(viewport.hi-viewport.lo),priceTolerance:Number.EPSILON*Math.max(1,Math.abs(viewport.lo),Math.abs(viewport.hi),viewport.hi-viewport.lo)*16};
}
export function hitTargetIds(targets, position, foundIds = []) {
  if (!position || !Number.isFinite(position.bar) || !Number.isFinite(position.price)) return [];
  const found = new Set(foundIds);
  return targets.filter(target => {
    const epsilon = Math.max(position.priceTolerance || 0, Number.EPSILON * Math.max(1,Math.abs(position.price),Math.abs(target.a.price),Math.abs(target.b.price)) * 8);
    return !found.has(target.id) && position.bar >= Math.min(target.a.bar,target.b.bar)-1e-9 && position.bar <= Math.max(target.a.bar,target.b.bar)+1e-9 && position.price >= Math.min(target.a.price,target.b.price)-epsilon && position.price <= Math.max(target.a.price,target.b.price)+epsilon;
  }).map(target => target.id);
}
export function allTargetsFound(targets, foundIds) {
  return targets.length > 0 && targets.every(target => foundIds.includes(target.id));
}

// Shared with the text renderer so erasing follows the visible wrapped/clamped label.
export function textMarkLayout(mark, viewport) {
  const p = projectPoint(mark.at, viewport), size = mark.size || 18;
  if(mark.box){const {box,...legacy}=mark,layout=textMarkLayout(legacy,viewport);return{...layout,lines:[mark.text],lineHeight:size*1.3,bounds:{...layout.bounds,width:box.width*viewport.width,height:box.height*viewport.height}}}
  const columns = Math.max(1, Math.floor(250 / (size * (mark.weight===700?0.67:0.61))));
  const chunks = mark.text.split('\n').flatMap(line => line.match(new RegExp('.{1,' + columns + '}(?:\\s|$)|.{1,' + columns + '}', 'g')) || ['']);
  const lines = chunks.slice(0,8).map((line,index) => index === 7 && chunks.length > 8 ? line.slice(0, Math.max(1,columns-2)) + '…' : line), lineHeight = size * 1.2;
  const x = Math.min(viewport.width - viewport.right - 260, Math.max(viewport.left + 4, p.x + 6));
  const y = Math.max(viewport.top + size, Math.min(viewport.height - viewport.bottom - 8 - Math.max(0,lines.length - 1) * lineHeight, p.y));
  return {x,y,size,lines,lineHeight,bounds:{x,y:y-size,width:Math.max(...lines.map(line=>line.length),1)*size*(mark.weight===700?0.71:0.65),height:size+Math.max(0,lines.length-1)*lineHeight+size*0.25}};
}
const segmentDistance = (p,a,b) => {
  const dx=b.x-a.x,dy=b.y-a.y,length=dx*dx+dy*dy;
  const fraction=length?clamp(((p.x-a.x)*dx+(p.y-a.y)*dy)/length,0,1):0;
  return Math.hypot(p.x-a.x-fraction*dx,p.y-a.y-fraction*dy);
};
const boxDistance = (p,box) => Math.hypot(Math.max(box.x-p.x,0,p.x-box.x-box.width),Math.max(box.y-p.y,0,p.y-box.y-box.height));
/** @param {Record<string,{x:number,y:number,width:number,height:number}>} [textBounds] */
export function hitLearnerMark(marks, position, viewport, screenScale=1, pointerType='mouse', textBounds={}) {
  if(!position||![position.x,position.y,screenScale].every(Number.isFinite)||screenScale<=0||position.x<0||position.y<0||position.x>viewport.width||position.y>viewport.height)return null;
  // CSS pixels, not viewBox units: touch remains forgiving at any zoom/resize.
  const tolerance=(pointerType==='touch'||pointerType==='pen'?18:10)/screenScale;
  for(let i=marks.length-1;i>=0;i--){const mark=marks[i];let distance=Infinity;
    if(mark.kind==='line'){const clipped=clipLineToRange(mark,viewport);if(clipped)distance=segmentDistance(position,projectPoint(clipped.a,viewport),projectPoint(clipped.b,viewport));}
    else if(mark.kind==='text' && barInViewport(mark.at.bar,viewport))distance=boxDistance(position,textBounds[mark.id]||textMarkLayout(mark,viewport).bounds);
    else if(mark.kind==='arrow' && barInViewport(mark.at.bar,viewport)){const p=projectPoint(mark.at,viewport);distance=boxDistance(position,mark.crossed?{x:p.x-9.3,y:p.y-9.3,width:18.2,height:18.2}:{x:p.x-10,y:p.y-15.6,width:19.6,height:30.8});}
    if(distance<=tolerance)return mark.id;
  }
  return null;
}
export const ERASER_CURSOR = 'url("data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32"><path d="M4 20 18 4a3 3 0 0 1 4 0l7 7a3 3 0 0 1 0 4L15 29H9L4 24a3 3 0 0 1 0-4Z" fill="#ffabd1" stroke="#07131e" stroke-width="2"/><path d="m4 20 7-8 12 12-5 5H9l-5-5Z" fill="#fff" stroke="#07131e" stroke-width="2"/></svg>') + '") 5 24, crosshair';

// Same layout is used by the embedded teacher/student canvas and teacher PNG export.
// Coordinates are plot units; scale keeps labels legible when the SVG fits a phone.
export function layoutSlideBarNumbers(candidates, geometry) {
  const {left,right,top,bottom,step} = geometry, scale = Math.max(0.05,geometry.scale || 1);
  if (!candidates.length || !(step > 0)) return [];
  const size=11/scale, digits=String(Math.max(...candidates.map(item=>item.bar+1))).length;
  const minimum=Math.max(1,Math.ceil((size*digits*.62+8/scale)/step));
  const stride=[1,2,3,5,10,20,25,50,100,200,500,1000,2000].find(value=>value>=minimum)||minimum;
  const first=candidates[0].bar,last=candidates.at(-1).bar;
  const chosen=candidates.filter(item=>item.bar===first||item.bar===last||(item.bar+1)%stride===0),out=[];
  for(const item of chosen){
    const width=String(item.bar+1).length*size*.62,x=Math.max(left+width/2,Math.min(right-width/2,item.x));
    // Leave room for a pivot diamond and never let a label leave the plot.
    let y=Math.max(top+size+2/scale,Math.min(bottom-2/scale,item.highY-(item.pivotHigh?20:7)/scale));
    const previous=out.at(-1);
    if(previous&&x-previous.x<(width+previous.width)/2+5/scale){
      if(item.bar!==last)continue;
      if(previous.bar!==first)out.pop();
      else y=Math.min(bottom-2/scale,previous.y+size+4/scale);
    }
    out.push({bar:item.bar,number:item.bar+1,x,y,width,height:size,anchorX:item.x,anchorY:item.highY,leader:y>=item.highY-3/scale||Math.abs(y-item.highY)>24/scale});
  }
  return out;
}
