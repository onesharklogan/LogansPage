'use client';
import LoadingIndicator from './loading-indicator';
import {useEffect,useRef,useState} from 'react';
import {learnerClient} from '../lib/learner/client.mjs';
import LearnerAccountControl from './learner-account-control';
/** Same-origin facade; temporary verification hides, but never remounts, the paused run. */
export default function AccountMarketDirection({source}:{source:string}){
 const [snapshot,setSnapshot]=useState(learnerClient.getSnapshot),[hostReady,setHostReady]=useState(false),panelOpen=useRef(false),frame=useRef<HTMLIFrameElement>(null),owner=useRef<{capture:any;epoch:number}|null>(null);
 function pause(){try{(frame.current?.contentWindow as any)?.AlwaysIn?.accountPause?.();}catch{}}
 useEffect(()=>{
  const facade={client:learnerClient,canPractice:()=>!panelOpen.current,requestPanel:(options?:any)=>learnerClient.requestPanel(options)};
  (window as any).PriceActionLearner=facade;setHostReady(true);
  const unsubscribe=learnerClient.subscribe((next:ReturnType<typeof learnerClient.getSnapshot>)=>{if(!learnerClient.captureContext())pause();setSnapshot(next);});void learnerClient.refresh();
  return()=>{pause();unsubscribe();if((window as any).PriceActionLearner===facade)delete(window as any).PriceActionLearner;};
 },[]);
 function navigationReady(){try{return (frame.current?.contentWindow as any)?.AlwaysIn?.accountNavigationReady?.()!==false;}catch{return false;}}
 const capture=learnerClient.captureContext();if(capture&&snapshot.authConfigured)owner.current={capture,epoch:snapshot.epoch};
 const verified=!!capture&&snapshot.authConfigured,verifying=!verified&&!snapshot.signOutNeeded&&(snapshot.revalidating||!snapshot.ready&&!snapshot.reconcileRequired&&!snapshot.error&&!snapshot.busy),hasFrame=hostReady&&!!owner.current;
 return <><LearnerAccountControl hideTrigger={verified||verifying} onBeforeNavigate={navigationReady} onOpenChange={open=>{panelOpen.current=open;if(open)pause();else setTimeout(()=>{try{(frame.current?.contentWindow as any)?.document.getElementById('nameDisplay')?.focus();}catch{}},0);}}/>{hasFrame&&<div className="market-direction-account-frame" hidden={!verified} inert={!verified} style={!verified?{display:'none'}:undefined}><iframe key={owner.current!.epoch} ref={frame} className="market-direction-frame" src={source} title="Market Orders Simulator practice" allow="fullscreen"/></div>}{!verified&&<section className="training-main"><p role="status">{verifying?<LoadingIndicator label="Verifying profile…" />:snapshot.error||(snapshot.busy?<LoadingIndicator label={snapshot.busy} />:'Profile verification is unavailable. Retry to continue.')}</p>{!verifying&&<button className="quiet-button" disabled={snapshot.revalidating} onClick={()=>void learnerClient.revalidate()}>Retry account check</button>}</section>}</>;
}
