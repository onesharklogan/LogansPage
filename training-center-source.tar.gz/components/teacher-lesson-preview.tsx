'use client';
import {useEffect, useState} from 'react';
import SequencePlayer from './lesson-sequence-player';
import {api} from './lesson-sequence-api';
import {parseLessonDetail, type LessonDetail, type LessonKey} from './teacher-workspace-api';
import {lessonKey as validateLessonKey} from '../lib/portal/teacher-workspace-model.mjs';
import styles from './teacher-lesson-preview.module.css';

/** Student rendering, author-only reads. No manifest means no learner progress events. */
export default function TeacherLessonPreview({requestedLesson}: {requestedLesson: string | null}) {
  const [detail, setDetail] = useState<LessonDetail | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [reload, setReload] = useState(0);
  let key: LessonKey | null = null;
  try { key = validateLessonKey(requestedLesson) as LessonKey; } catch { /* Fail closed before any request. */ }

  useEffect(() => {
    const controller = new AbortController();
    let active = true;
    setDetail(null);
    setError('');
    setLoading(true);
    if (!key) {
      setError('Choose Try this lesson from a saved Lesson in your Teacher workspace.');
      setLoading(false);
      return () => { active = false; controller.abort(); };
    }
    // This existing GET verifies the current approved author session on the server.
    // Never fall back to a public route, copy an unsaved draft, or change account role.
    api<unknown>('/api/author/workspace/lessons/' + encodeURIComponent(key), {signal: controller.signal})
      .then(value => {
        if (!active || controller.signal.aborted) return;
        const saved = parseLessonDetail(value, key);
        if (saved.lesson.trashed || saved.slides.some(slide => slide.lessonTrashed)) {
          throw Error('This Lesson is archived. Restore it in your Teacher workspace before trying it.');
        }
        setDetail(saved);
      })
      .catch(reason => {
        if (!active || controller.signal.aborted) return;
        setDetail(null);
        setError(reason?.status === 401 || reason?.status === 403
          ? 'An approved teacher session is required. Sign in in your Teacher workspace tab, then retry here.'
          : reason?.message || 'This saved Lesson could not be loaded. Please retry.');
      })
      .finally(() => { if (active && !controller.signal.aborted) setLoading(false); });
    return () => { active = false; controller.abort(); };
  }, [key, reload]);

  // A restored browser-history page must recheck access and the saved version.
  useEffect(() => {
    const restored = (event: PageTransitionEvent) => { if (event.persisted) setReload(value => value + 1); };
    window.addEventListener('pageshow', restored);
    return () => window.removeEventListener('pageshow', restored);
  }, []);

  return <main className={styles.page}>
    <a className="skip-link" href="#student-lesson">Skip to lesson</a>
    <header className={styles.header}>
      <div><p className="eyebrow">STUDENT PREVIEW · SAVED LESSON</p><h1>{detail?.lesson.title || 'Try this lesson'}</h1></div>
      {key && <button className="quiet-button" disabled={loading} onClick={() => setReload(value => value + 1)}>{error ? 'Retry saved lesson' : 'Reload latest saved'}</button>}
    </header>
    <p className={styles.note}>Try the same slides and activities students see. This tab loads the latest saved version; unsaved edits stay in your Teacher workspace tab. Preview progress is not saved.</p>
    {detail && <p className={styles.version}>Saved Lesson revision {detail.lesson.revision} · {detail.slides.length} slides</p>}
    <section id="student-lesson" className={'lesson-modal ' + styles.player} aria-label="Student lesson preview" aria-busy={loading}>
      {loading ? <p role="status">Loading saved lesson…</p> : error ? <p role="alert">{error}</p>
        : detail?.pack ? <SequencePlayer key={key + ':' + reload} draft={detail.pack}/>
        : <p role="status">{detail?.playbackUnavailable || 'This Lesson has no saved slides yet. Add a slide in your Teacher workspace, then reload here.'}</p>}
    </section>
    <p className={styles.note}>Your Teacher workspace stays open in the other tab. Close this tab whenever you are done.</p>
  </main>;
}
