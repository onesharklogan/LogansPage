import type {WorkspaceLesson} from './teacher-workspace-api';

type PreviewLesson = Pick<WorkspaceLesson, 'key' | 'title' | 'slideCount' | 'trashed'>;

/** A normal link opens immediately, without saving or navigating the editor tab. */
export default function TryLessonLink({lesson, unavailable}: {lesson: PreviewLesson; unavailable?: string}) {
  const reason = lesson.trashed ? 'Restore this Lesson before trying it.'
    : lesson.slideCount === 0 ? 'Add a saved slide to try this Lesson.'
    : unavailable || (lesson.slideCount > 100 ? 'This Lesson has more than 100 slides. Open it to review playback availability.' : '');
  return <span style={{display: 'inline-flex', flexDirection: 'column', alignItems: 'flex-start', gap: 5, maxWidth: '100%'}}>
    {reason ? <button disabled title={reason}>Try this lesson</button> : <a
      className="quiet-button"
      style={{display: 'inline-flex', alignItems: 'center', minHeight: 44, whiteSpace: 'normal'}}
      href={'/admin/lesson-preview?lessonKey=' + encodeURIComponent(lesson.key)}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={'Try this lesson: ' + lesson.title + ' (opens in a new tab)'}
      title="Open the latest saved lesson as a student in a new tab. Unsaved edits stay here."
    >Try this lesson <span aria-hidden="true"> ↗</span></a>}
    {reason && <small className="field-help">{reason}</small>}
  </span>;
}
