'use client';

import styles from './chart-match.module.css';

/** An observed body midpoint is not a close. Missing observations stay gaps. */
export default function ApproximateComparison({match,query,continuation}:{match:any,query:any,continuation:any[]|null}){
 const base=match.normalizedPrefix as any[],origin=match.prefixOrigin,scale=match.prefixPriceRange;
 const bars=continuation?[...base,...continuation.map(b=>({o:(b.o-origin)/scale,h:(b.h-origin)/scale,l:(b.l-origin)/scale,c:(b.c-origin)/scale}))]:base;
 const q=query.observations as any[],alignment=match.alignment??[],finite=(v:any):v is number=>typeof v==='number'&&Number.isFinite(v);
 const observed=(b:any,field:string)=>b?.mask?.[field==='ema'?'ema':'body']===true&&finite(b?.[field]);
 const values=[...bars.flatMap(b=>[b.h,b.l]),...q.flatMap(b=>['bodyTop','bodyBottom','center',...(query.useEma?['ema']:[])].filter(f=>observed(b,f)).map(f=>b[f]))].filter(finite);
 if(!values.length)return <p>Comparison geometry is unavailable.</p>;
 let min=Math.min(...values),max=Math.max(...values);const pad=Math.max(.05,(max-min)*.08);min-=pad;max+=pad;
 const width=800,height=320,left=48,right=24,top=24,bottom=36,step=(width-left-right)/(bars.length+1),x=(i:number)=>left+step*(i+.5),y=(v:number)=>top+(max-v)/(max-min)*(height-top-bottom);
 const path=(field:string)=>{let previous:number|null=null;return alignment.map((a:any)=>{const v=q[a.queryIndex]?.[field];if(!observed(q[a.queryIndex],field)){previous=null;return '';}const adjacent=previous!==null&&(a.queryIndex===previous||a.queryIndex===previous+1);previous=a.queryIndex;return `${adjacent?'L':'M'}${x(a.historicalIndex)},${y(v)}`;}).join(' ');};
 return <div className={styles.chartScroll}><svg className={styles.comparison} viewBox={`0 0 ${width} ${height}`} role="img" aria-label={`${match.date} approximate shape comparison: ${query.count} observed slots aligned with ${base.length} historical bars. Blue marks show observed body midpoints and ranges, not closing prices. Missing readings are not joined. Historical bars after the matched endpoint are ${continuation?'revealed':'hidden'}.`}>
 <rect width={width} height={height} fill="white"/>{Array.from({length:5},(_,i)=>{const v=min+(max-min)*i/4;return <g key={i}><line x1={left} x2={width-right} y1={y(v)} y2={y(v)} stroke="#e6ecf0"/><text x={left-5} y={y(v)+4} textAnchor="end" fontSize={10} fill="#536376">{v.toFixed(1)}</text></g>;})}
 {bars.map((b,i)=><g key={i} data-match-bar={i+1} stroke={b.c>=b.o?'#168475':'#c64b57'} fill={b.c>=b.o?'#26a69a':'#ef5350'}><line x1={x(i)} x2={x(i)} y1={y(b.h)} y2={y(b.l)}/><rect x={x(i)-Math.max(.7,step*.28)} y={Math.min(y(b.o),y(b.c))} width={Math.max(1.4,step*.56)} height={Math.max(1,Math.abs(y(b.o)-y(b.c)))}/></g>)}
 <path data-approximate-path="center" d={path('center')} fill="none" stroke="#245fbd" strokeWidth={2}/>
 {alignment.map((a:any,i:number)=>{const b=q[a.queryIndex];return observed(b,'bodyTop')&&observed(b,'bodyBottom')?<line key={i} data-observed-body={a.queryIndex} x1={x(a.historicalIndex)} x2={x(a.historicalIndex)} y1={y(b.bodyTop)} y2={y(b.bodyBottom)} stroke="#245fbd" strokeWidth={4} opacity={.55}/>:null;})}
 {query.useEma&&<><path data-approximate-path="ema" d={path('ema')} fill="none" stroke="#df8a00" strokeWidth={2}/><path d={base.map((b,i)=>finite(b.ema)?`${i&&finite(base[i-1].ema)?'L':'M'}${x(i)},${y(b.ema)}`:'').join(' ')} fill="none" stroke="#7c52a1" strokeWidth={1.5} strokeDasharray="4 3"/></>}
 {continuation&&<line x1={x(base.length-.5)} x2={x(base.length-.5)} y1={top} y2={height-bottom} stroke="#888" strokeDasharray="4 4"/>}<text x={left} y={height-10} fontSize={11} fill="#536376">Opening sequence · uncertain readings omitted</text><text x={width-right} y={height-10} textAnchor="end" fontSize={11} fill="#536376">{continuation?`${bars.length} actual bars · revealed`:`${base.length} historical bars only`}</text>
 </svg></div>;
}
