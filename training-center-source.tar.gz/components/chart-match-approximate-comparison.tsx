'use client';

import styles from './chart-match.module.css';
import {matchPreviewFrame} from '../lib/chart-match-preview.mjs';

/** An observed body midpoint is not a close. Missing observations stay gaps. */
export default function ApproximateComparison({match,query,continuation,preview}:{match:any,query:any,continuation:any[]|null,preview?:any}){
 const frame=matchPreviewFrame(match,preview,continuation),base=frame.current,bars=frame.bars,offset=frame.priorCount;
 const q=query.observations as any[],alignment=match.alignment??[],finite=(v:any):v is number=>typeof v==='number'&&Number.isFinite(v);
 const observed=(b:any,field:string)=>b?.mask?.[field==='ema'?'ema':'body']===true&&finite(b?.[field]);
 const values=[...bars.flatMap((b:any)=>[b.h,b.l,b.ema]),...q.flatMap(b=>['bodyTop','bodyBottom','center',...(query.useEma?['ema']:[])].filter(f=>observed(b,f)).map(f=>b[f])),frame.priorFinal?.c].filter(finite);
 if(!values.length)return <p>Comparison geometry is unavailable.</p>;
 let min=Math.min(...values),max=Math.max(...values);const pad=Math.max(.05,(max-min)*.08);min-=pad;max+=pad;
 const width=Math.max(800,bars.length*10+72),height=320,left=48,right=24,top=30,bottom=36,step=(width-left-right)/(bars.length+1),x=(i:number)=>left+step*(i+.5),y=(v:number)=>top+(max-v)/(max-min)*(height-top-bottom);
 const path=(field:string)=>{let previous:number|null=null;return alignment.map((a:any)=>{const v=q[a.queryIndex]?.[field];if(!observed(q[a.queryIndex],field)){previous=null;return '';}const adjacent=previous!==null&&(a.queryIndex===previous||a.queryIndex===previous+1);previous=a.queryIndex;return `${adjacent?'L':'M'}${x(offset+a.historicalIndex)},${y(v)}`;}).join(' ');};
 const historicalEma=bars.map((b:any,i:number)=>finite(b.ema)?`${i&&finite(bars[i-1].ema)&&(i!==offset||frame.priorComplete)?'L':'M'}${x(i)},${y(b.ema)}`:'').join(' ');
 return <><div className={styles.chartScroll}><svg className={styles.comparison} style={{minWidth:width}} viewBox={`0 0 ${width} ${height}`} role="img" aria-label={`${match.date} approximate shape comparison: ${query.count} observed slots aligned with ${base.length} historical bars. ${offset} actual prior-session bars appear before the session divider. Blue marks show observed body midpoints and ranges, not closing prices. Missing readings are not joined. Gold is historical EMA20. Historical bars after the matched endpoint are ${continuation?'revealed':'hidden'}.`}>
 <rect width={width} height={height} fill="#080d14"/>{offset>0&&<rect x={left} y={top} width={offset*step} height={height-top-bottom} fill="#233040" opacity={.45}/>}{Array.from({length:5},(_,i)=>{const v=min+(max-min)*i/4;return <g key={i}><line x1={left} x2={width-right} y1={y(v)} y2={y(v)} stroke="#203248"/><text x={left-5} y={y(v)+4} textAnchor="end" fontSize={11} fill="#8ea8be">{v.toFixed(1)}</text></g>;})}
 {bars.map((b:any,i:number)=><g key={i} data-prior-bar={b.prior?b.t:undefined} data-match-bar={b.prior?undefined:i-offset+1} stroke={b.c>=b.o?'#67dfb3':'#f18da6'} fill={b.c>=b.o?'#67dfb3':'#f18da6'} opacity={b.prior?.65:1}><line x1={x(i)} x2={x(i)} y1={y(b.h)} y2={y(b.l)}/><rect x={x(i)-Math.max(.7,step*.28)} y={Math.min(y(b.o),y(b.c))} width={Math.max(1.4,step*.56)} height={Math.max(1,Math.abs(y(b.o)-y(b.c)))}/><title>{b.prior?`Prior session · ${b.t}`:`Historical bar ${i-offset+1}`}</title></g>)}
 <path data-historical-ema d={historicalEma} fill="none" stroke="#f6c760" strokeWidth={2}/>
 <path data-approximate-path="center" d={path('center')} fill="none" stroke="#70b7ff" strokeWidth={2}/>
 {alignment.map((a:any,i:number)=>{const b=q[a.queryIndex];return observed(b,'bodyTop')&&observed(b,'bodyBottom')?<line key={i} data-observed-body={a.queryIndex} x1={x(offset+a.historicalIndex)} x2={x(offset+a.historicalIndex)} y1={y(b.bodyTop)} y2={y(b.bodyBottom)} stroke="#70b7ff" strokeWidth={4} opacity={.55}/>:null;})}
 {query.useEma&&<path data-approximate-path="ema" d={path('ema')} fill="none" stroke="#ff9e64" strokeWidth={2}/>}
 {offset>0&&<g data-session-divider><line x1={x(offset-.5)} x2={x(offset-.5)} y1={top} y2={height-bottom} stroke="#b6c8e0" strokeDasharray="4 4"/><text x={left} y={18} fontSize={11} fill="#91a0b3">Prior session</text><text x={x(offset-.5)+5} y={18} fontSize={11} fill="#c5d8f0">Day open · 08:30</text></g>}
 {frame.priorFinal&&<line data-prior-final-close x1={left} x2={x(offset+.5)} y1={y(frame.priorFinal.c)} y2={y(frame.priorFinal.c)} stroke="#d5b771" strokeDasharray="5 5"><title>Previous exported session final 15:10 close (reference level, not an added candle)</title></line>}
 {continuation&&<line data-matched-end x1={x(offset+base.length-.5)} x2={x(offset+base.length-.5)} y1={top} y2={height-bottom} stroke="#8ea8be" strokeDasharray="4 4"/>}<text x={left} y={height-10} fontSize={11} fill="#8ea8be">Opening sequence · uncertain readings omitted</text><text x={width-right} y={height-10} textAnchor="end" fontSize={11} fill="#8ea8be">{continuation?`${base.length+frame.future.length} actual bars · revealed`:`${base.length} historical bars only`}</text>
 </svg></div><p className={styles.small} data-preview-context>{offset?`${offset} actual prior-session bars · ${frame.priorDate} through ${frame.priorEndTime}. ${frame.priorComplete?'The final 15:10 candle is included.':'Limited context: the separate dashed level is the genuine 15:10 close, not an invented candle.'}`:'Prior-session context is unavailable for this result.'} Gold is historical EMA20, carried through the supplied warmup; prior context does not affect matching. Scroll sideways on small screens.</p></>;
}
