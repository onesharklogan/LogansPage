"use client";
import LoadingIndicator from './loading-indicator';
import { useEffect, useRef, useState, type FormEvent } from 'react';

export async function passwordRequest(path: '/api/auth/login' | '/api/auth/enroll', body: Record<string, string>, signal: AbortSignal, fetcher: typeof fetch = fetch) {
  const csrfResponse = await fetcher('/api/auth/csrf', { credentials: 'same-origin', cache: 'no-store', signal });
  if (!csrfResponse.ok) throw new Error('Sign-in is temporarily unavailable. Please try again.');
  const csrf = await csrfResponse.json();
  if (typeof csrf.csrfToken !== 'string' || !csrf.csrfToken) throw new Error('Your security check could not be started. Please try again.');
  if (signal.aborted) throw new DOMException('Canceled', 'AbortError');
  const response = await fetcher(path, { method: 'POST', credentials: 'same-origin', cache: 'no-store', signal, headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf.csrfToken }, body: JSON.stringify(body) });
  if (!response.ok) throw new Error(response.status === 429 ? 'Too many attempts. Please wait before trying again.' : path === '/api/auth/login' ? 'Sign-in was not accepted. Check your email and password, or ask an administrator for a setup/reset link.' : 'This setup/reset link could not be accepted. It may have expired or already been used. Ask an administrator for a new link.');
}

export default function PasswordSignIn({ onSignedIn }: { onSignedIn: () => Promise<void> }) {
  const [email, setEmail] = useState(''), [password, setPassword] = useState(''), [busy, setBusy] = useState(false), [error, setError] = useState('');
  const mounted = useRef(false), inFlight = useRef(false), request = useRef<AbortController | null>(null);
  useEffect(() => { mounted.current = true; return () => { mounted.current = false; request.current?.abort(); }; }, []);
  async function submit(event: FormEvent) {
    event.preventDefault(); if (inFlight.current) return;
    const submittedEmail = email.trim().toLowerCase(), submittedPassword = password;
    inFlight.current = true; setBusy(true); setError(''); setPassword('');
    const controller = new AbortController(); request.current = controller;
    try {
      await passwordRequest('/api/auth/login', { email: submittedEmail, password: submittedPassword }, controller.signal);
      if (mounted.current && !controller.signal.aborted) await onSignedIn();
    } catch (problem) { if (mounted.current && !controller.signal.aborted) setError(problem instanceof Error ? problem.message : 'Sign-in could not be confirmed. Please try again.'); }
    finally { inFlight.current = false; if (mounted.current) setBusy(false); }
  }
  return <form onSubmit={submit} style={{ display: 'grid', gap: 16, maxWidth: 480 }}>
    <label htmlFor="author-login-email">Email<input id="author-login-email" type="email" autoComplete="username" required maxLength={254} value={email} onChange={event => setEmail(event.target.value)} disabled={busy} /></label>
    <label htmlFor="author-login-password">Password<input id="author-login-password" type="password" autoComplete="current-password" required maxLength={128} value={password} onChange={event => setPassword(event.target.value)} disabled={busy} /></label>
    {error && <p className="notice error" role="alert">{error}</p>}
    <div><button className="primary-button" type="submit" disabled={busy || !email.trim() || !password}>{busy ? <LoadingIndicator label="Signing in…" size="small" /> : 'Sign in'}</button></div>
    <p className="field-help">First visit or forgotten password? Ask an administrator for a private, one-use setup/reset link. Knowing an email address does not let someone claim an account.</p>
  </form>;
}
