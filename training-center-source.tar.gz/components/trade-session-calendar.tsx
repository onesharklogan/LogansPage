'use client';

import {useEffect,useMemo,useRef,useState,type KeyboardEvent} from 'react';
import {buildCalendar,calendarKey,monthCells,moveDate,moveMonth,type Calendar,type SessionEntry} from '../lib/session-calendar.mjs';

export type TradeSessionCalendarProps={entries:SessionEntry[];initialId:string;onChoose:(id:string)=>void;onClose:()=>void;title?:string;helpText?:string;allowRandom?:boolean};
type Selection={model:Calendar|null;initialId:string;selected:string;focused:string;month:string};
const navigation=new Set(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End','PageUp','PageDown']);
function initial(model:Calendar|null,id:string):Selection{const entry=model?.entries.find(item=>item.id===id)||model?.entries[0],date=entry?.date||'';return{model,initialId:id,selected:date,focused:date,month:date.slice(0,7)}}
const css=`
.trade-session-calendar-overlay{position:fixed;inset:0;z-index:1200;display:flex;align-items:center;justify-content:center;background:#020812cc;padding:0;overscroll-behavior:contain}
.trade-session-calendar{box-sizing:border-box;width:min(440px,100%);max-height:100dvh;overflow-y:auto;overflow-x:hidden;overscroll-behavior:contain;border:1px solid #40566d;border-radius:14px;background:#0b1723;color:#e4edf7;font:14px/1.4 system-ui;padding:0 0 max(12px,env(safe-area-inset-bottom));box-shadow:0 18px 60px #0008}
.trade-session-calendar *{box-sizing:border-box}.trade-session-calendar header{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:8px 12px}.trade-session-calendar h2{margin:0;font-size:20px}.trade-session-calendar button{min-height:44px;min-width:44px;margin:0;border:1px solid #40566d;border-radius:7px;background:#142437;color:#e4edf7;font:inherit;cursor:pointer}.trade-session-calendar button:disabled{cursor:default;opacity:.35}.trade-session-calendar button:focus-visible{outline:2px solid #ffcf7c;outline-offset:-3px}.trade-session-calendar .tsc-month{display:flex;align-items:center;justify-content:space-between;gap:6px;padding:0 8px 6px}.trade-session-calendar .tsc-month strong{font-size:16px;text-align:center}.trade-session-calendar .tsc-month>button{display:grid;place-items:center;min-width:44px;min-height:44px;padding:8px;flex:0 0 44px}.trade-session-calendar .tsc-month>button svg{display:block;width:24px;height:24px;pointer-events:none}.trade-session-calendar .tsc-grid-scroll{overflow-x:auto;overscroll-behavior-x:contain;max-width:100%;outline-offset:-2px}.trade-session-calendar .tsc-grid{min-width:316px}.trade-session-calendar .tsc-week,.trade-session-calendar .tsc-days{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));gap:0;padding:0 4px}.trade-session-calendar .tsc-week{text-align:center;color:#a9bbcc;font-size:11px;padding-top:6px;padding-bottom:4px}.trade-session-calendar .tsc-days button{width:100%;min-width:44px;min-height:44px;padding:0;font-size:14px;border-radius:5px}.trade-session-calendar .tsc-days button:disabled{background:transparent;border-color:transparent}.trade-session-calendar .tsc-days button[aria-pressed=true]{background:#a9d3ff;color:#07131f;border-color:#cbe5ff;font-weight:800}.trade-session-calendar .tsc-note{margin:10px 12px;font-size:12px;color:#b7c8da;overflow-wrap:anywhere}.trade-session-calendar .tsc-error{color:#ffc4cc}.trade-session-calendar .tsc-close{font-size:25px;line-height:1}
.trade-session-calendar .tsc-random{padding:8px 12px 0}.trade-session-calendar .tsc-random button{width:100%}
`;

/** Date selection only. Parent owns pause/inert background, identity/save guards and loading. */
export default function TradeSessionCalendar({entries,initialId,onChoose,onClose,title="Choose a Session",helpText="Choose an available date to open it immediately. Arrow keys or W A S D move between available dates without loading; Enter or Space opens the focused date.",allowRandom=false}:TradeSessionCalendarProps){
  const parsed=useMemo(()=>{try{return{model:buildCalendar(entries),error:''}}catch{return{model:null,error:'Session dates could not be verified. Close this picker and reload the session list.'}}},[entries]);
  const model=parsed.model;
  const [state,setState]=useState<Selection>(()=>initial(model,initialId));
  const [submitted,setSubmitted]=useState(false),submittedRef=useRef(false);
  const current=state.model===model&&state.initialId===initialId?state:initial(model,initialId);
  const panel=useRef<HTMLDivElement>(null),closed=useRef(false),live=useRef(true),latest=useRef({model,current,onChoose,onClose,allowRandom});
  latest.current={model,current,onChoose,onClose,allowRandom};
  const dates=model?.dates||[],selected=model?.entries.find(entry=>entry.date===current.selected),cells=model?monthCells(model,current.month):[];
  const inMonth=dates.filter(date=>date.startsWith(current.month));
  const focused=inMonth.includes(current.focused)?current.focused:inMonth.includes(current.selected)?current.selected:inMonth[0]||'';
  useEffect(()=>{live.current=true;return()=>{live.current=false}},[]);
  useEffect(()=>{const root=panel.current;if(!root)return;const day=focused&&!submitted?root.querySelector<HTMLButtonElement>(`button[data-session-date="${focused}"]`):null;(day||root.querySelector<HTMLButtonElement>('.tsc-close'))?.focus({preventScroll:true});day?.scrollIntoView?.({block:'nearest',inline:'nearest'});},[model,current.month,focused,submitted]);
  const allowed=()=>live.current&&!closed.current&&latest.current.model===model&&latest.current.current===current;
  function close(){if(!allowed())return;closed.current=true;latest.current.onClose()}
  function changeMonth(delta:number){if(!allowed()||submittedRef.current||!model)return;const month=moveMonth(model,current.month,delta);if(month===current.month)return;setState({...current,month,focused:model.dates.find(date=>date.startsWith(month))||''})}
  function choose(date:string){if(!allowed()||submittedRef.current)return;const snapshot=latest.current,entry=snapshot.model?.entries.find(item=>item.date===date);if(!entry)return;submittedRef.current=true;setState({...current,selected:date,focused:date,month:date.slice(0,7)});setSubmitted(true);snapshot.onChoose(entry.id)}
  function pickRandom(){if(!allowRandom||!latest.current.allowRandom||!allowed()||submittedRef.current||!model)return;const choices=model.entries.filter(entry=>entry.id!==initialId),entry=choices[Math.floor(Math.random()*choices.length)]||(model.entries.length===1?model.entries[0]:undefined);if(entry)choose(entry.date)}
  function keys(event:KeyboardEvent<HTMLDivElement>){
    event.stopPropagation();
    if(event.defaultPrevented||event.nativeEvent.isComposing||event.nativeEvent.keyCode===229||event.keyCode===229||event.ctrlKey||event.altKey||event.metaKey)return;
    if(event.key==='Tab'){
      const root=panel.current,buttons=root?Array.from(root.querySelectorAll<HTMLElement>('button:not(:disabled),[tabindex="0"]')).filter(button=>button.tabIndex>=0):[];
      if(!buttons.length){event.preventDefault();root?.focus();return}
      const first=buttons[0],last=buttons.at(-1)!,active=document.activeElement;
      if(!root?.contains(active)||event.shiftKey&&active===first){event.preventDefault();(event.shiftKey?last:first).focus()}
      else if(!event.shiftKey&&active===last){event.preventDefault();first.focus()}
      return;
    }
    if(event.shiftKey)return;
    if(event.key==='Escape'){event.preventDefault();close();return}
    const target=(event.target as HTMLElement).closest<HTMLButtonElement>('button[data-session-date]'),key=calendarKey({...event,isComposing:event.nativeEvent.isComposing,keyCode:event.nativeEvent.keyCode});
    if(!target||target.disabled||!navigation.has(key)||!model||!allowed()||submittedRef.current)return;
    event.preventDefault();const moved=moveDate(model,target.dataset.sessionDate||'',key,current.month);
    if(moved.date||moved.month!==current.month)setState({...current,month:moved.month,focused:moved.date||''});
  }
  const monthTitle=current.month?new Intl.DateTimeFormat('en',{month:'long',year:'numeric',timeZone:'UTC'}).format(new Date(current.month+'-01T00:00:00Z')):'No available sessions';
  return <div className="trade-session-calendar-overlay"><style>{css}</style><div className="trade-session-calendar" ref={panel} role="dialog" aria-modal="true" aria-labelledby="trade-session-calendar-title" aria-describedby="trade-session-calendar-help" tabIndex={-1} onKeyDown={keys}>
    <header><h2 id="trade-session-calendar-title">{title}</h2><button className="tsc-close" type="button" aria-label="Close session picker" title="Close (Escape)" onClick={close}>×</button></header>
    <div className="tsc-month"><button type="button" aria-label="Previous month" disabled={submitted||!model||current.month<=model.firstMonth} onClick={()=>changeMonth(-1)}><svg viewBox="0 0 24 24" width={24} height={24} fill="none" stroke="currentColor" strokeWidth={2.25} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false"><path d="M15 5 8 12l7 7"/></svg></button><strong aria-live="polite">{monthTitle}</strong><button type="button" aria-label="Next month" disabled={submitted||!model||current.month>=model.lastMonth} onClick={()=>changeMonth(1)}><svg viewBox="0 0 24 24" width={24} height={24} fill="none" stroke="currentColor" strokeWidth={2.25} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false"><path d="M9 5l7 7-7 7"/></svg></button></div>
    <div className="tsc-grid-scroll" role="region" aria-label="Session dates. Scroll horizontally on narrow screens." tabIndex={0}><div className="tsc-grid"><div className="tsc-week" aria-hidden="true">{['Su','Mo','Tu','We','Th','Fr','Sa'].map(day=><span key={day}>{day}</span>)}</div>
    <div className="tsc-days" role="group" aria-label="Available session dates. Use arrows or W A S D to move between dates." aria-keyshortcuts="ArrowUp ArrowLeft ArrowDown ArrowRight W A S D Home End PageUp PageDown">{cells.map((cell,index)=>cell?<button key={cell.date} type="button" data-session-date={cell.date} disabled={submitted||!cell.id} tabIndex={!submitted&&cell.date===focused?0:-1} aria-label={cell.date+(cell.id?' · available session':' · no session available')} aria-pressed={cell.date===current.selected} onClick={()=>choose(cell.date)}>{cell.day}</button>:<span key={'blank-'+index} aria-hidden="true"/>)}</div></div></div>
    {allowRandom&&<div className="tsc-random"><button type="button" disabled={submitted||!model||!dates.length} onClick={pickRandom}>Pick random</button></div>}
    <p className="tsc-note" role="status" aria-live="polite">{submitted&&selected?'Opening '+selected.date+'…':selected?'Current selection: '+selected.date+' · choose an available date to open it.':'Choose an available date. Disabled days have no session.'}</p>
    <p className="tsc-note" id="trade-session-calendar-help">{helpText}</p>
    {parsed.error&&<p className="tsc-note tsc-error" role="alert">{parsed.error}</p>}
    {!parsed.error&&!dates.length&&<p className="tsc-note" role="status">No session dates are available.</p>}
  </div></div>;
}
