/** Shared decorative motion; the surrounding status owns announcements.
 * <picture> selects the still image before decoding when motion is reduced.
 */
export default function LoadingIndicator({ label = 'Loading…', size = 'normal', className = '' }: {
  label?: string; size?: 'small' | 'normal' | 'large'; className?: string;
}) {
  return <span className={`pa-loading pa-loading--${size}${className ? ` ${className}` : ''}`}>
    <picture className="pa-loading__graphic" aria-hidden="true">
      <source media="(prefers-reduced-motion: reduce)" srcSet="/brand/candle-loading.png" />
      <img src="/brand/candle-loading.gif" width="136" height="136" alt="" decoding="async" />
    </picture>
    <span className="pa-loading__label">{label}</span>
  </span>;
}
