import {headers} from 'next/headers';
import {handleRenderRequest} from '../lib/portal/render-runtime.mjs';
import {teacherRouteAccess} from '../lib/portal/teacher-route-guard.mjs';
import LessonAccessBoundary from './lesson-access-boundary';
import HomeLessons from './home-lessons';
/** Never send lesson navigation or content to unapproved accounts. */
export default async function TeacherHomeLessons({accountsEnabled=false}:{accountsEnabled?:boolean}={}) {
  const origin=process.env.APP_ORIGIN;
  if(!origin)return null;
  try {
    const incoming=await headers();
    const access=await teacherRouteAccess(new Request(new URL('/',origin),{headers:incoming}),handleRenderRequest);
    if(!access.allowed)return null;
    return <LessonAccessBoundary><HomeLessons accountsEnabled={accountsEnabled}/></LessonAccessBoundary>;
  }catch{return null;}
}
