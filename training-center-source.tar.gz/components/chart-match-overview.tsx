import {buildMatchOverviewFrame} from '../lib/chart-match-overview.mjs';
import styles from './chart-match-overview.module.css';

type Props={matches:any[];candidates:any[]};
const frameFor=(match:any,candidates:any[])=>{
 try{return buildMatchOverviewFrame(match,candidates.find(source=>source?.reference?.id===match?.id),candidates);}catch{return null;}
};

/** Read-only overview of completed ranking results; no upload/query overlay or
 * shared Reveal state. Full-session thumbnails intentionally show later bars. */
export default function ChartMatchOverview({matches,candidates}:Props){
 if(!Array.isArray(matches)||matches.length===0)return null;
 const sources=Array.isArray(candidates)?candidates:[];
 return <section className={styles.overview} aria-label="Full-session match overview" data-match-overview>
  <div className={styles.heading}><h2>All matches at a glance</h2><span>{matches.length} historical {matches.length===1?'match':'matches'}</span></div>
  <p className={styles.disclosure}>Full-session overview — later historical bars are visible.</p>
  <p className={styles.help}>Ranking still uses only the matched opening prefix. Select a chart to open the full viewer in a new tab. Any bars after the matched end start hidden there.</p>
  <div className={styles.legend} aria-label="Overview chart legend"><span><i className={styles.emaKey}/>EMA20</span><span><i className={styles.openKey}/>Session open</span><span><i className={styles.matchKey}/>Matched end</span></div>
  <div className={styles.grid}>{matches.map((match,index)=>{
   const frame=frameFor(match,sources);
   if(!frame)return <article key={`unavailable-${index}`} className={styles.unavailable} data-overview-card data-overview-unavailable><strong>Match {index+1}</strong><p>Full-session overview unavailable for this result. Paste or choose another image.</p></article>;
   const {geometry:g}=frame,rank=index+1,matchedLabelX=Math.max(30,Math.min(g.width-g.right-4,g.matchedX+5));
   const context=frame.priorComplete?`${frame.priorCount} prior bars · ${frame.priorDate} through ${frame.priorEndTime}`:frame.priorCount?`Limited prior context: ${frame.priorCount} supplied ${frame.priorCount===1?'candle':'candles'}${frame.priorDate?` from ${frame.priorDate}`:''}${frame.priorEndTime?` through ${frame.priorEndTime}`:''}.${frame.priorFinal&&!frame.priorComplete?` The genuine ${frame.priorFinal.t.slice(11,16)} close is a reference, not an invented candle.`:''}`:'Prior candles unavailable; no prior candles are invented.';
   return <a key={`${frame.id}-${index}`} href={frame.href} target="_blank" rel="noopener noreferrer" className={styles.card} aria-describedby={`overview-context-${frame.id}-${index}`} aria-label={`Open ${frame.date} full historical chart in a new tab; match ${rank}, matched through bar ${frame.matchedCount} of ${frame.sessionCount}. Thumbnail shows the full session, including later bars.`} data-overview-card data-overview-link data-overview-session={frame.id}>
    <div className={styles.cardHeading}><span><span className={styles.rank}>#{rank}</span><time dateTime={frame.date}>{frame.date}</time></span><span className={styles.instrument}>MES · 5 min</span></div>
    <svg className={styles.chart} viewBox={`0 0 ${g.width} ${g.height}`} preserveAspectRatio="xMidYMid meet" role="img" aria-label={`${frame.date}: complete ${frame.sessionCount}-bar historical session with ${frame.priorCount} real prior-context candles and causal EMA20. Matched end is bar ${frame.matchedCount}; later historical bars are visible.`} data-overview-chart>
     <rect width={g.width} height={g.height} fill="#000"/>
     {frame.priorCount>0&&<rect x={g.left} y={g.top} width={g.openX-g.left} height={g.height-g.top-g.bottom} fill="#080d12"/>}
     {frame.priceTicks.map((tick,i)=><g key={i}><line x1={g.left} x2={g.width-g.right} y1={tick.y} y2={tick.y} stroke="#15202a" strokeWidth=".7"/><text x={g.width-g.right+8} y={tick.y+3} fill="#879aa8" fontSize="9">{tick.price.toFixed(2)}</text></g>)}
     {frame.bars.map(bar=><g key={bar.t} opacity={bar.prior ? .78 : 1} data-overview-prior-bar={bar.prior?bar.slot:undefined} data-overview-current-bar={!bar.prior?bar.slot-frame.priorCount:undefined}>
      <line x1={bar.x} x2={bar.x} y1={bar.wickTop} y2={bar.wickBottom} stroke={bar.c>=bar.o?'#67dfb3':'#f18da6'} strokeWidth="1"/>
      <rect x={bar.x-bar.bodyWidth/2} y={bar.bodyY} width={bar.bodyWidth} height={bar.bodyHeight} fill={bar.c>=bar.o?'#67dfb3':'#f18da6'}/>
     </g>)}
     <path d={frame.emaPath} fill="none" stroke="#f6c760" strokeWidth="1.5" strokeLinejoin="round" data-overview-ema/>
     {frame.priorFinal&&!frame.priorComplete&&<line x1={Math.max(g.left,g.openX-g.step*.75)} x2={g.openX} y1={frame.priorFinal.y} y2={frame.priorFinal.y} stroke="#c3d2df" strokeWidth="1.5" data-overview-prior-close/>}
     <line x1={g.openX} x2={g.openX} y1={g.top} y2={g.height-g.bottom} stroke="#8da9bd" strokeWidth="1" data-overview-open/>
     <line x1={g.matchedX} x2={g.matchedX} y1={g.top-5} y2={g.height-g.bottom} stroke="#f6c760" strokeWidth="1" strokeDasharray="3 3" data-overview-matched-end={frame.matchedCount}/>
     <text x={matchedLabelX} y="17" fill="#f6c760" fontSize="10" textAnchor={g.matchedX>g.width-g.right-80?'end':'start'}>Matched {frame.matchedCount}</text>
     <text x={g.openX+3} y={g.height-10} fill="#bacbd6" fontSize="9">08:30 open</text>
     <text x={frame.current[39].x} y={g.height-10} fill="#879aa8" fontSize="9" textAnchor="middle">11:45</text>
     <text x={frame.current.at(-1)!.x} y={g.height-10} fill="#879aa8" fontSize="9" textAnchor="end">15:10</text>
    </svg>
    <div className={styles.cardFooter}><span>Matched <strong>{frame.matchedCount}</strong> · <strong>{frame.sessionCount}</strong> session bars</span><span className={styles.openLink}>Full chart <span aria-hidden="true">↗</span></span></div>
    <div id={`overview-context-${frame.id}-${index}`} className={styles.context} data-overview-context={frame.contextStatus}>{context}</div>
   </a>;
  })}</div>
 </section>;
}
