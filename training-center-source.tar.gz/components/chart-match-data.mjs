import {loadSimulatorCatalog} from './trade-simulator-data.mjs';
import {historicalPrefix,historicalGap,matchSessionDate,validMatchDate} from '../lib/chart-match.mjs';

export const MATCH_INDEX_URL='/modules/chart-match-index.json';
export const MATCH_INDEX_SHA256='fe4a8162470af14e950ea9128ee7f433081c5a771daa87fee506f4d8493cfb76';
function abortError(){return new DOMException('Chart matching was canceled.','AbortError');}
function checkAbort(signal){if(signal?.aborted)throw abortError();}
/** Strict catalog check before loading. Dates are derived from immutable canonical IDs.
 * @param {import('../lib/chart-match.mjs').MatchReference[]} entries */
export function verifyMatchCatalog(entries){
  if(!Array.isArray(entries)||!entries.length||entries.length>1000)throw Error('The chart catalog is unavailable.');
  const ids=new Set(),dates=new Set();
  return entries.map(entry=>{
    if(!entry||typeof entry.id!=='string')throw Error('Invalid catalog session.');
    const date=matchSessionDate(entry.id);
    if(entry.date!==undefined&&entry.date!==date||entry.url!==`/charts/${entry.id}.json`||typeof entry.title!=='string'||!/^[a-f0-9]{64}$/.test(entry.sha256)||ids.has(entry.id)||dates.has(date))throw Error('The chart catalog has an invalid or ambiguous reference.');
    ids.add(entry.id);dates.add(date);return {...entry,date};
  }).sort((a,b)=>a.date.localeCompare(b.date));
}
/** Fetch existing same-origin catalog + compact hash-pinned projection; never screenshot bytes.
 * The index carries exact OHLC, a causally derived EMA seed and actual previous exported-session final close.
 * Validation may inspect the complete fixed asset; rankMatches reads only the requested prefix.
 * @param {{signal?:AbortSignal,fetcher?:typeof fetch,onProgress?:(progress:{loaded:number,total:number})=>void,queryDate?:string,excludeId?:string}} [options]
 * @returns {Promise<import('../lib/chart-match.mjs').MatchCandidate[]>}
 */
export async function loadChartMatchSessions({signal,fetcher=fetch,onProgress,queryDate,excludeId}={}){
  checkAbort(signal);if(queryDate!==undefined&&!validMatchDate(queryDate))throw Error('Enter a valid query date or leave it blank.');
  const controller=new AbortController(),cancel=()=>controller.abort();signal?.addEventListener('abort',cancel,{once:true});
  try{
    const catalog=verifyMatchCatalog(await loadSimulatorCatalog({signal:controller.signal,fetcher}));checkAbort(signal);
    const wanted=catalog.filter(row=>row.id!==excludeId&&(!queryDate||row.date<queryDate));onProgress?.({loaded:0,total:wanted.length});checkAbort(signal);
    if(!wanted.length)return [];
    const response=await fetcher(MATCH_INDEX_URL,{signal:controller.signal,credentials:'same-origin'});checkAbort(signal);
    if(!response.ok)throw Error('Historical comparison data could not be loaded. Try again.');
    const text=await response.text();checkAbort(signal);const bytes=new TextEncoder().encode(text);
    if(bytes.length>8*1024*1024)throw Error('Historical comparison data is too large.');
    const digest=[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(x=>x.toString(16).padStart(2,'0')).join('');checkAbort(signal);
    if(digest!==MATCH_INDEX_SHA256)throw Error('Historical comparison integrity check failed.');
    const data=JSON.parse(text);
    if(data.version!==1||!Array.isArray(data.sessions)||data.sessions.length!==catalog.length)throw Error('Historical comparison catalog is incomplete.');
    const byId=new Map(catalog.map(row=>[row.id,row])),seen=new Set();
    for(const item of data.sessions){
      const ref=item?.reference,chart=item?.chart,actual=byId.get(ref?.id);
      if(!actual||seen.has(ref.id)||['id','date','title','url','sha256'].some(key=>ref[key]!==actual[key])||chart?.id!==ref.id||chart.date!==ref.date)throw Error('Historical comparison identity differs from the source catalog.');
      seen.add(ref.id);historicalPrefix(chart,chart.current.length,{useEma:true});historicalGap(chart);
    }
    checkAbort(signal);const wantedIds=new Set(wanted.map(row=>row.id));
    const results=data.sessions.filter(item=>wantedIds.has(item.reference.id));
    onProgress?.({loaded:results.length,total:wanted.length});checkAbort(signal);return results;
  }finally{signal?.removeEventListener('abort',cancel);}
}
