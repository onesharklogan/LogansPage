'use client';

import { useEffect, useMemo, useRef, useState, type PointerEvent, type KeyboardEvent } from 'react';
import { initialState, placeBracket, editBracket, cancelPending, advanceCandle, finishSession, statistics, validateBracket, bracketStats, snapPrice, type Bracket, type SimState } from '../lib/trade-simulator.mjs';
import { replayViewport, replayPoint, priceFromClient, orderHandle, defaultBracket, EXIT_LABELS } from '../lib/trade-simulator-view.mjs';
import Model from '../lib/portal/lesson-model.cjs';
import { loadSimulatorCatalog, loadSimulatorChart } from './trade-simulator-data.mjs';

type Candle = {t:string;o:number;h:number;l:number;c:number};
type Chart = {id:string;title:string;current:Candle[]};
type Reference = {id:string;title:string;url:string;sha256:string};
type Key = 'entry'|'stop'|'target';
type Draft = {side:'buy'|'sell';entry:string;stop:string;target:string};
type View = ReturnType<typeof replayViewport>;
const KEYS:Key[]=['entry','stop','target'];
const COLORS={entry:'#8ac7ff',stop:'#ff9aa9',target:'#9ee5bc'};
const LABELS={entry:'Entry',stop:'Stop',target:'Target'};
const format=(value:number)=>Number.isFinite(value)?value.toFixed(2):'—';
const signed=(value:number)=>`${value>0?'+':''}${format(value)}`;
const draftOf=(b:Bracket):Draft=>({side:b.side,entry:String(b.entry),stop:String(b.stop),target:String(b.target)});
const bracketOf=(d:Draft):Bracket=>({side:d.side,entry:d.entry.trim()?Number(d.entry):NaN,stop:d.stop.trim()?Number(d.stop):NaN,target:d.target.trim()?Number(d.target):NaN});

export default function TradeSimulator() {
  const [catalog,setCatalog]=useState<Reference[]>([]),[choice,setChoice]=useState(''),[sessionId,setSessionId]=useState('');
  const [chart,setChart]=useState<Chart|null>(null),[loading,setLoading]=useState(true),[error,setError]=useState(''),[retry,setRetry]=useState(0);
  const [state,setState]=useState<SimState>(()=>initialState()),[draft,setDraft]=useState<Draft>({side:'buy',entry:'',stop:'',target:''}),[edited,setEdited]=useState(false);
  const [playing,setPlaying]=useState(false),[speed,setSpeed]=useState(1000),[notice,setNotice]=useState(''),[width,setWidth]=useState(900);
  const [confirm,setConfirm]=useState<{kind:'reset'|'session'|'finish';id?:string}|null>(null);
  const host=useRef<HTMLDivElement>(null),svg=useRef<SVGSVGElement>(null),current=useRef(state);
  const drag=useRef<{key:Key;pointerId:number;view:View;before:Draft;beforeEdited:boolean}|null>(null);
  const [dragging,setDragging]=useState(false),[showEma,setShowEma]=useState(true);
  const active=state.position||state.pending;
  const parsed=bracketOf(draft),validation=validateBracket(parsed),metrics=bracketStats(parsed);
  const blocked=loading||!!error||!!confirm||!chart||state.ended;
  const totals=statistics(state);
  const ema=useMemo(()=>chart?Model.chartIndicators(chart,state.index).ema as number[]:[],[chart,state.index]);
  const levels=KEYS.map(k=>parsed[k]).filter(Number.isFinite).concat(showEma?ema.slice(Math.max(0,state.index-(width<600?24:59)),state.index+1):[]);
  const viewport=useMemo(()=>chart?replayViewport(chart.current,state.index,levels,width,width<600?370:440):null,[chart,state.index,width,parsed.entry,parsed.stop,parsed.target,showEma,ema]); // Only the revealed prefix reaches geometry.
  const displayedView=drag.current?.view||viewport;
  const unrealized=state.position&&chart?(chart.current[state.index].c-state.position.entryPrice)*(state.position.side==='buy'?1:-1):0;

  function commit(next:SimState) { current.current=next;setState(next); }
  function resetRun(source:Chart) { const next=initialState(0,source.current[0]);commit(next);setDraft(draftOf(defaultBracket(source.current[0]) as Bracket));setEdited(false);setNotice('Set all three levels, then place your bracket.');setPlaying(false);drag.current=null;setDragging(false); }
  useEffect(()=>{
    const controller=new AbortController();setLoading(true);setError('');
    loadSimulatorCatalog({signal:controller.signal}).then(items=>{if(controller.signal.aborted)return;setCatalog(items);setChoice(items[0].id);setSessionId(items[0].id);}).catch(e=>{if(!controller.signal.aborted){setError(e.message);setLoading(false);}});
    return()=>controller.abort();
  },[retry]);
  useEffect(()=>{
    const reference=catalog.find(s=>s.id===sessionId);if(!reference)return;
    const controller=new AbortController();setPlaying(false);setLoading(true);setError('');
    loadSimulatorChart(reference,{signal:controller.signal}).then(source=>{if(controller.signal.aborted)return;setChart(source);resetRun(source);setLoading(false);}).catch(e=>{if(!controller.signal.aborted){setError(e.message);setLoading(false);}});
    return()=>controller.abort();
  },[sessionId,catalog]);
  useEffect(()=>{
    const element=host.current;if(!element)return;
    const resize=new ResizeObserver(entries=>setWidth(Math.max(280,Math.round(entries[0].contentRect.width))));resize.observe(element);return()=>resize.disconnect();
  },[]);
  useEffect(()=>{const pause=()=>{if(document.hidden)setPlaying(false);};document.addEventListener('visibilitychange',pause);return()=>document.removeEventListener('visibilitychange',pause);},[]);
  useEffect(()=>{
    if(!playing||blocked||edited||dragging)return;
    const timer=setTimeout(()=>nextCandle(),speed);return()=>clearTimeout(timer);
  },[playing,speed,state.index,blocked,edited,dragging]);

  function nextCandle() {
    if(blocked||edited||drag.current||!chart)return;
    const before=current.current,index=before.index+1;if(index>=chart.current.length)return;
    let next=advanceCandle(before,chart.current[index],index);
    if(index===chart.current.length-1)next=finishSession(next,chart.current[index]);
    commit(next);
    if(next.ended||next.trades.length!==before.trades.length||(!before.position&&next.position)){setPlaying(false);setNotice(next.ended?'Session complete. Your points breakdown is below.':next.trades.length!==before.trades.length?'Position closed. Review the result or place another bracket.':'Limit filled. Stop and target are now active.');}
  }
  function changeDraft(key:Key,value:string) { setPlaying(false);setEdited(true);setNotice('');setDraft(d=>({...d,[key]:value})); }
  function changeSide(side:'buy'|'sell') {
    if(active||!chart)return;setPlaying(false);setEdited(true);setDraft(draftOf(defaultBracket(chart.current[state.index],side) as Bracket));
  }
  function applyBracket() {
    if(blocked||!validation.valid||!validation.bracket)return;
    try { const next=active?editBracket(current.current,validation.bracket):placeBracket(current.current,validation.bracket);commit(next);setDraft(draftOf(validation.bracket));setEdited(false);setNotice(`Bracket ${active?'updated':'placed'}. Eligible from candle ${state.index+2}, never the visible candle.`); }
    catch(e){setNotice(e instanceof Error?e.message:'The bracket could not be placed.');}
  }
  function discard() {if(!chart)return;setDraft(draftOf(active||defaultBracket(chart.current[state.index],draft.side) as Bracket));setEdited(false);setNotice('Unapplied changes discarded.');}
  function requestAction(kind:'reset'|'session'|'finish',id?:string) {setPlaying(false);setConfirm({kind,id});}
  function confirmAction() {
    if(!confirm||!chart)return;
    if(confirm.kind==='session'){setSessionId(confirm.id!);setLoading(true);}
    else if(confirm.kind==='reset')resetRun(chart);
    else{commit(finishSession(current.current,chart.current[state.index]));setEdited(false);setNotice('Session finished at the last visible close. No hidden candle was used.');}
    setConfirm(null);
  }
  function startDrag(event:PointerEvent<SVGElement>,key:Key) {
    if(blocked||drag.current||event.button!==0||!displayedView||key==='entry'&&!!state.position)return;
    event.preventDefault();setPlaying(false);setNotice('');
    drag.current={key,pointerId:event.pointerId,view:displayedView,before:draft,beforeEdited:edited};setDragging(true);
    svg.current?.setPointerCapture(event.pointerId);
  }
  function moveDrag(event:PointerEvent<SVGSVGElement>) {
    const move=drag.current;if(!move||move.pointerId!==event.pointerId||!svg.current)return;
    const price=priceFromClient(event.clientY,svg.current.getBoundingClientRect(),move.view);
    if(price!==null){setEdited(true);setDraft(d=>({...d,[move.key]:String(snapPrice(Math.max(.25,price)))}));}
  }
  function endDrag(event:PointerEvent<SVGSVGElement>,cancel=false) {
    const move=drag.current;if(!move||event.pointerId!==move.pointerId)return;
    if(cancel){setDraft(move.before);setEdited(move.beforeEdited);}
    drag.current=null;setDragging(false);
    if(svg.current?.hasPointerCapture(event.pointerId))svg.current.releasePointerCapture(event.pointerId);
  }
  function keyMove(event:KeyboardEvent<SVGGElement>,key:Key) {
    if(blocked||key==='entry'&&!!state.position||!['ArrowUp','ArrowDown'].includes(event.key))return;
    event.preventDefault();changeDraft(key,String(snapPrice(parsed[key]+(event.key==='ArrowUp'?1:-1)*(event.shiftKey?1:.25))));
  }

  return <main className="simulator-shell">
    <header className="simulator-header"><div><a className="simulator-back" href="/">← Training Center</a><p className="eyebrow">CANDLE REPLAY · POINTS PRACTICE</p><h1>Trade Simulator</h1></div><a className="quiet-button" href="/market-direction">Market Direction Bias ↗</a></header>
    <div className="simulator-session"><label>Chart session<select value={choice} disabled={loading||!!confirm} onChange={e=>setChoice(e.target.value)}>{catalog.map(s=><option key={s.id} value={s.id}>{s.title}</option>)}</select></label><button className="quiet-button" disabled={!choice||choice===sessionId||loading||!!confirm} onClick={()=>requestAction('session',choice)}>Load session</button><p>Changing sessions clears this attempt. Results stay on this page only.</p></div>
    {error&&<div className="notice error" role="alert">{error} <button className="quiet-button" onClick={()=>setRetry(v=>v+1)}>Try again</button></div>}
    {confirm&&<section className="simulator-confirm" aria-label="Confirm session action"><h2>{confirm.kind==='finish'?'Finish and score this attempt?':'Clear this attempt?'}</h2><p>{confirm.kind==='finish'?`Any open position closes at candle ${state.index+1}’s close. An unfilled bracket is canceled. Hidden candles are not scored.`:'Current orders and points will be cleared. This cannot be undone.'}</p><button className="primary-button" autoFocus onClick={confirmAction}>{confirm.kind==='finish'?'Finish & score':'Clear & continue'}</button><button className="quiet-button" onClick={()=>setConfirm(null)}>Keep practicing</button></section>}
    <div className="simulator-workspace">
      <section className="simulator-chart-panel" aria-label="Replay chart">
        <div className="simulator-chart-heading"><div><span className={`sim-status ${state.position?'is-open':''}`}>{loading?'Loading chart…':state.ended?'SESSION COMPLETE':state.position?`${state.position.side==='buy'?'LONG':'SHORT'} OPEN`:state.pending?'BRACKET WAITING':'NO ACTIVE ORDER'}</span><p>{chart?.title||'Historical chart sessions'}</p></div><div className="simulator-candle-count">Candle <strong>{chart?state.index+1:'—'}</strong> / {chart?.current.length||'—'}<small>Only revealed candles are scored</small></div></div>
        <div className="simulator-chart" ref={host}>
          {chart&&displayedView&&<svg ref={svg} viewBox={`0 0 ${displayedView.width} ${displayedView.height}`} role="group" aria-label="Candle chart with draggable entry, stop and target lines" onPointerMove={moveDrag} onPointerUp={e=>endDrag(e)} onPointerCancel={e=>endDrag(e,true)} onLostPointerCapture={e=>{if(drag.current)endDrag(e,true);}}>
            <defs><clipPath id="simulator-plot"><rect x={displayedView.left} y={displayedView.top} width={displayedView.width-displayedView.left-displayedView.right} height={displayedView.height-displayedView.top-displayedView.bottom}/></clipPath></defs>
            {Array.from({length:6},(_,i)=>{const price=displayedView.lo+(displayedView.hi-displayedView.lo)*i/5,y=replayPoint(0,price,displayedView).y;return <g key={i}><line x1={displayedView.left} x2={displayedView.width-displayedView.right} y1={y} y2={y} stroke="#203248"/><text x={displayedView.width-7} y={y+4} textAnchor="end" fill="#8ea8be" fontSize="11">{format(price)}</text></g>;})}
            <g clipPath="url(#simulator-plot)" data-layer="visible-candles">{chart.current.slice(displayedView.start,state.index+1).map((c,offset)=>{const index=displayedView.start+offset,o=replayPoint(index,c.o,displayedView),h=replayPoint(index,c.h,displayedView),l=replayPoint(index,c.l,displayedView),close=replayPoint(index,c.c,displayedView),color=c.c>=c.o?'#8dd6b3':'#f09b9b',w=Math.max(2,(displayedView.width-displayedView.left-displayedView.right)/displayedView.count*.62);return <g key={index}><line x1={h.x} x2={h.x} y1={h.y} y2={l.y} stroke={color}/><rect x={o.x-w/2} y={Math.min(o.y,close.y)} width={w} height={Math.max(1.5,Math.abs(o.y-close.y))} fill={color}/><title>{`Candle ${index+1} · ${c.t} · O ${c.o} H ${c.h} L ${c.l} C ${c.c}`}</title></g>;})}
              {showEma&&state.index>displayedView.start&&<path data-indicator="ema20" d={ema.slice(displayedView.start,state.index+1).map((value,index)=>{const p=replayPoint(displayedView.start+index,value,displayedView);return `${index?'L':'M'} ${p.x} ${p.y}`;}).join(' ')} fill="none" stroke="#f6c760" strokeWidth="2" pointerEvents="none"/>}
              {showEma&&state.index===displayedView.start&&<circle data-indicator="ema20" cx={replayPoint(state.index,ema[state.index],displayedView).x} cy={replayPoint(state.index,ema[state.index],displayedView).y} r="3" fill="#f6c760" pointerEvents="none"/>}
              {state.trades.flatMap(t=>[{key:`${t.id}-in`,index:t.entryIndex,price:t.entryPrice,color:'#8ac7ff',text:'Entry'},{key:`${t.id}-out`,index:t.exitIndex,price:t.exitPrice,color:t.points>=0?'#9ee5bc':'#ff9aa9',text:'Exit'}]).filter(p=>p.index>=displayedView.start).map(p=>{const point=replayPoint(p.index,p.price,displayedView);return <circle key={p.key} cx={point.x} cy={point.y} r="4" fill={p.color} stroke="#0b1421"><title>{`${p.text} · ${format(p.price)}`}</title></circle>;})}
            </g>
            {[displayedView.start,state.index].filter((n,i,a)=>a.indexOf(n)===i).map(index=><text key={index} x={replayPoint(index,0,displayedView).x} y={displayedView.height-12} fill="#8ea8be" fontSize="11" textAnchor="middle">{index+1} · {chart.current[index].t.slice(-5)}</text>)}
            {!state.ended&&KEYS.filter(k=>Number.isFinite(parsed[k])).map(key=>{const y=replayPoint(0,parsed[key],displayedView).y;return <g key={key}><line x1={displayedView.left} x2={displayedView.width-displayedView.right} y1={y} y2={y} stroke={COLORS[key]} strokeDasharray={!active||edited?'5 5':undefined} opacity=".8" pointerEvents="none"/><line className="sim-order-line-hit" x1={displayedView.left} x2={displayedView.width-displayedView.right} y1={y} y2={y} stroke="transparent" strokeWidth="18" onPointerDown={e=>startDrag(e,key)} /></g>;})}
            {!state.ended&&KEYS.filter(k=>Number.isFinite(parsed[k])).map(key=>{const y=replayPoint(0,parsed[key],displayedView).y,handle=orderHandle(key,y,displayedView),locked=key==='entry'&&!!state.position;return <g key={key} className={`sim-order-handle ${locked?'locked':''}`} role="slider" tabIndex={blocked||locked?-1:0} aria-label={`${LABELS[key]} price${locked?' (locked after fill)':''}`} aria-valuemin={.25} aria-valuemax={1e9} aria-valuenow={parsed[key]} aria-valuetext={`${format(parsed[key])}${locked?', locked':''}`} aria-disabled={blocked||locked} onPointerDown={e=>startDrag(e,key)} onKeyDown={e=>keyMove(e,key)}><rect {...handle} rx="7" fill="#122439" stroke={COLORS[key]}/><text x={handle.x+8} y={handle.y+17} fill={COLORS[key]} fontSize="10" fontWeight="700" pointerEvents="none">{locked?'LOCKED LIMIT':`${LABELS[key].toUpperCase()} ↕`}</text><text x={handle.x+8} y={handle.y+33} fill="#f1f6fc" fontSize="12" pointerEvents="none">{format(parsed[key])}</text></g>;})}
          </svg>}
        </div>
        <label className="simulator-ema"><input type="checkbox" checked={showEma} onChange={e=>setShowEma(e.target.checked)} /> EMA20</label><p className="simulator-chart-hint">Drag the labeled handles, use ↑ / ↓, or type prices. Dotted lines are a draft—not active orders.</p>
        <div className="simulator-replay"><button className="primary-button" disabled={blocked||edited||dragging} onClick={()=>setPlaying(v=>!v)}>{playing?'Pause':'▶ Play'}</button><button className="quiet-button" disabled={blocked||edited||playing||dragging} onClick={nextCandle}>Next candle →</button><label>Speed<select value={speed} disabled={!!confirm} onChange={e=>setSpeed(Number(e.target.value))}><option value={1800}>Slow</option><option value={1000}>Normal</option><option value={450}>Fast</option></select></label><button className="quiet-button" disabled={loading||!chart||!!confirm} onClick={()=>requestAction('reset')}>Replay</button><button className="quiet-button" disabled={blocked} onClick={()=>requestAction('finish')}>Finish & score now</button></div>
        <p className="simulator-replay-note">Auto-play pauses on an entry or exit. Replay clears all orders and results.</p>
      </section>
      <aside className="simulator-ticket" aria-label="Bracket order controls"><p className="eyebrow">ONE BRACKET AT A TIME</p><h2>{state.position?'Manage your exits':'Build your bracket'}</h2><div className="simulator-side"><button className={draft.side==='buy'?'selected buy':''} disabled={blocked||!!active} onClick={()=>changeSide('buy')}>Buy limit</button><button className={draft.side==='sell'?'selected sell':''} disabled={blocked||!!active} onClick={()=>changeSide('sell')}>Sell limit</button></div>
        <div className="simulator-prices">{KEYS.map(key=><label key={key} style={{color:COLORS[key]}}>{key==='entry'&&state.position?'Planned entry · locked':LABELS[key]}<input type="number" inputMode="decimal" min="0.25" step="0.25" value={draft[key]} disabled={blocked||key==='entry'&&!!state.position} onChange={e=>changeDraft(key,e.target.value)}/></label>)}</div>
        <div className="simulator-risk"><p className="eyebrow">PLANNED BRACKET</p>{metrics?<><div><span>Risk <strong>{format(metrics.risk)} pts</strong></span><span>Reward <strong>{format(metrics.reward)} pts</strong></span></div><p className="simulator-profitable">Profitable above {metrics.requiredWinRate.toFixed(1)}% win rate.</p></>:<p className="simulator-validation" role="status">{validation.error}</p>}<small>Calculated from the chosen limit, stop and target. Prices snap to 0.25.</small></div>
        {state.position&&<p className="simulator-fill">Actual entry <strong>{format(state.position.entryPrice)}</strong><br/>Open points <strong className={unrealized<0?'negative':'positive'}>{signed(unrealized)}</strong></p>}
        {edited&&<p className="simulator-draft-warning" role="status">Unapplied changes. Apply or discard before replay continues.</p>}
        <button className="primary-button simulator-apply" disabled={blocked||!validation.valid||!!active&&!edited} onClick={applyBracket}>{active?'Apply bracket changes':'Place entry + stop + target'}</button>
        <div className="simulator-ticket-actions">{edited&&<button className="quiet-button" disabled={blocked} onClick={discard}>Discard changes</button>}{state.pending&&<button className="quiet-button" disabled={blocked} onClick={()=>{setPlaying(false);commit(cancelPending(current.current));setEdited(false);setNotice('Unfilled bracket canceled.');}}>Cancel bracket</button>}</div>
        <p className="simulator-ticket-help">{state.ended?'Replay or load another chart to start again.':state.pending?`Waiting for a touch from candle ${state.pending.eligibleIndex+1}. The bracket stays active until it fills or you cancel it.`:state.position?'Entry is fixed. Apply stop and target changes together for the next candle.':'Place all three orders together. Nothing can fill on a candle you have already seen.'}</p>
        <p className="simulator-notice" role="status" aria-live="polite">{notice}</p>
      </aside>
    </div>
    <section className="simulator-results" aria-labelledby="sim-results"><div className="simulator-results-heading"><h2 id="sim-results">{state.ended?'Your points breakdown':'Points so far'}</h2><span>{state.ended?'FINAL':'CLOSED POSITIONS ONLY'}</span></div><div className="simulator-stats"><div><span>Net points</span><strong className={totals.netPoints<0?'negative':'positive'}>{signed(totals.netPoints)}</strong></div><div><span>Wins / losses / flat</span><strong>{totals.wins} / {totals.losses} / {totals.flats}</strong></div><div><span>Win rate</span><strong>{totals.trades?`${totals.winRate.toFixed(1)}%`:'—'}</strong></div><div><span>Won / lost points</span><strong>{format(totals.grossProfit)} / {format(totals.grossLoss)}</strong></div></div>
      <div className="simulator-ledger" tabIndex={0} aria-label="Scrollable trade ledger"><table><thead><tr><th>Trade</th><th>Entry</th><th>Exit</th><th>Reason</th><th>Result</th><th>Points</th></tr></thead><tbody>{state.trades.map((t,index)=><tr key={t.id}><td>{index+1} · {t.side==='buy'?'Long':'Short'}</td><td>{format(t.entryPrice)}<small>Candle {t.entryIndex+1} · {t.entryTime.slice(-5)}</small></td><td>{format(t.exitPrice)}<small>Candle {t.exitIndex+1} · {t.exitTime.slice(-5)}</small></td><td>{EXIT_LABELS[t.reason as keyof typeof EXIT_LABELS]||t.reason}{t.ambiguous&&<small>Both levels touched · stop first</small>}</td><td>{t.outcome==='win'?'Win':t.outcome==='loss'?'Loss':'Flat'}</td><td className={t.points<0?'negative':'positive'}>{signed(t.points)}</td></tr>)}</tbody></table>{!state.trades.length&&<p>No closed positions yet. Your entries and exits will appear here.</p>}</div>
      {state.position&&<p>One position is still open; {signed(unrealized)} open points are not included in the closed total.</p>}{state.ended&&<p>Open positions were marked at the last revealed close; unfilled orders were canceled. Win rate includes flat results in the total.</p>}
    </section>
    <details className="simulator-rules"><summary>How candle fills and points work</summary><ul><li>This is a simplified historical points simulation—not live trading or an execution guarantee. One bracket or position is allowed at a time.</li><li>A placed or updated bracket becomes eligible on the next candle. Previously visible candles never fill it. An unfilled bracket remains active until filled, moved, canceled or the session ends.</li><li>Buy limits fill when the next eligible candle opens at or below the limit, or its low touches it. Sell limits are the reverse. A favorable opening gap uses the opening price; otherwise entry is at the limit.</li><li>The stop and target activate only after entry. A gap past an active stop exits at the opening price. A gap past an active target exits at the opening price too. If an entry gaps past its own stop, entry and stop both fill at that open, for zero points.</li><li>Candles reveal open, high, low and close—not the exact path between them. When both exits are reachable after an opening between them, the stop wins. An already-triggered opening exit happens before later wicks.</li><li>On an intrabar entry candle, a target wick alone is not credited: it could have happened before entry. A target is credited that candle only if the close proves a crossing after entry, and the stop was not reached. A fill at the open can use that candle’s target touch.</li><li>Apply commits the entry, stop and target together. Dragging or typing pauses replay until you apply or discard the draft. An open entry cannot be moved. Each completed exit cancels its paired order.</li><li>The planned percentage uses risk ÷ (risk + reward). Actual points use the entry and exit fill prices. A long earns exit minus entry; a short earns entry minus exit. Final open positions close at the last revealed close, explicitly labeled Session end.</li><li>No account is required, no broker is connected, and refreshing or leaving this page clears this attempt.</li></ul></details>
  </main>;
}
