'use client';

import { useEffect, useMemo, useRef, useState, type PointerEvent, type KeyboardEvent } from 'react';
import { initialState, placeBracket, editBracket, cancelPending, closeOpenPosition, advanceCandle, finishSession, statistics, validateBracket, bracketStats, snapPrice, type Bracket, type SimState } from '../lib/trade-simulator.mjs';
import { replayViewport, replayPoint, priceFromClient, orderHandle, entryCloseHandle, defaultBracket, initialView, dragView, zoomTime, panTime, resetViewAxis, type ViewNavigation, EXIT_LABELS } from '../lib/trade-simulator-view.mjs';
import Model from '../lib/portal/lesson-model.cjs';
import { loadSimulatorCatalog, loadSimulatorChart } from './trade-simulator-data.mjs';

type Candle = {t:string;o:number;h:number;l:number;c:number};
type Chart = {id:string;title:string;current:Candle[];prior?:Candle[]};
type Reference = {id:string;title:string;url:string;sha256:string};
type Key = 'entry'|'stop'|'target';
type Draft = {side:'buy'|'sell';entry:string;stop:string;target:string};
type View = ReturnType<typeof replayViewport>;
const KEYS:Key[]=['entry','stop','target'];
const COLORS={entry:'#8ac7ff',stop:'#ff9aa9',target:'#9ee5bc'};
const LABELS={entry:'Entry',stop:'Stop',target:'Target'};
const format=(value:number)=>Number.isFinite(value)?value.toFixed(2):'—';
const signed=(value:number)=>`${value>0?'+':''}${format(value)}`;
const draftOf=(b:Bracket):Draft=>({side:b.side,entry:String(b.entry),stop:String(b.stop),target:String(b.target)});
const bracketOf=(d:Draft):Bracket=>({side:d.side,entry:d.entry.trim()?Number(d.entry):NaN,stop:d.stop.trim()?Number(d.stop):NaN,target:d.target.trim()?Number(d.target):NaN});

export default function TradeSimulator() {
  const [catalog,setCatalog]=useState<Reference[]>([]),[choice,setChoice]=useState(''),[sessionId,setSessionId]=useState('');
  const [chart,setChart]=useState<Chart|null>(null),[loading,setLoading]=useState(true),[error,setError]=useState(''),[retry,setRetry]=useState(0);
  const [state,setState]=useState<SimState>(()=>initialState()),[draft,setDraft]=useState<Draft>({side:'buy',entry:'',stop:'',target:''}),[edited,setEdited]=useState(false);
  const [playing,setPlaying]=useState(false),[speed,setSpeed]=useState(1000),[notice,setNotice]=useState(''),[width,setWidth]=useState(900);
  const [confirm,setConfirm]=useState<{kind:'reset'|'session'|'finish';id?:string}|null>(null);
  const host=useRef<HTMLDivElement>(null),svg=useRef<SVGSVGElement>(null),current=useRef(state);
  const drag=useRef<{key:Key;pointerId:number;view:View;before:Draft;beforeEdited:boolean;candidate:Bracket;orderId:number;offset:number}|null>(null);
  const [dragging,setDragging]=useState(false),[showEma,setShowEma]=useState(true);
  const [mode,setMode]=useState<'idle'|'armed'|'draft'>('idle'),[navigation,setNavigation]=useState<ViewNavigation>(initialView),[height,setHeight]=useState(440);
  const placement=useRef<'idle'|'armed'|'draft'>('idle'),paused=useRef(true),timerRef=useRef<ReturnType<typeof setTimeout>|null>(null);
  const gesture=useRef<{pointerId:number;x:number;y:number;view:View;nav:ViewNavigation;scaleX:number;scaleY:number;mode:'plot'|'price'|'time'|'place';moved:boolean}|null>(null);
  const closePress=useRef<{pointerId:number;orderId:number;generation:number;x:number;y:number;left:number;right:number;top:number;bottom:number}|null>(null);
  const runGeneration=useRef(0);
  const active=state.position||state.pending;
  const showOrders=!!active;
  const parsed=bracketOf(draft),validation=validateBracket(parsed),metrics=bracketStats(parsed);
  const blocked=loading||!!error||!!confirm||!chart||state.ended;
  const totals=statistics(state);
  const indicators=useMemo(()=>chart?Model.chartIndicators(chart,state.index):{ema:[],priorEma:[]},[chart,state.index]);
  const levels=showOrders?KEYS.map(k=>parsed[k]).filter(Number.isFinite):[];
  const viewport=useMemo(()=>chart?replayViewport(chart,state.index,levels,width,height,navigation,indicators):null,[chart,state.index,width,height,parsed.entry,parsed.stop,parsed.target,showOrders,navigation,indicators]);
  const displayedView=drag.current?.view||viewport;
  const unrealized=state.position&&chart?(chart.current[state.index].c-state.position.entryPrice)*(state.position.side==='buy'?1:-1):0;

  function commit(next:SimState) { current.current=next;setState(next); }
  function pause() { paused.current=true; if(timerRef.current!==null)clearTimeout(timerRef.current);timerRef.current=null;setPlaying(false); }
  function placeMode(value:'idle'|'armed'|'draft') {placement.current=value;setMode(value);}
  function clearDraft() {placeMode('idle');setDraft({side:'buy',entry:'',stop:'',target:''});setEdited(false);}
  function resetRun(source:Chart) { pause();runGeneration.current+=1;commit(initialState(0,source.current[0]));clearDraft();setNavigation(initialView());setNotice('Choose Buy or Sell, then tap the chart to set your entry.');drag.current=null;gesture.current=null;closePress.current=null;setDragging(false); }
  useEffect(()=>{
    const controller=new AbortController();setLoading(true);setError('');
    loadSimulatorCatalog({signal:controller.signal}).then(items=>{if(controller.signal.aborted)return;setCatalog(items);setChoice(items[0].id);setSessionId(items[0].id);}).catch(e=>{if(!controller.signal.aborted){setError(e.message);setLoading(false);}});
    return()=>controller.abort();
  },[retry]);
  useEffect(()=>{
    const reference=catalog.find(s=>s.id===sessionId);if(!reference)return;
    const controller=new AbortController();pause();setLoading(true);setError('');
    loadSimulatorChart(reference,{signal:controller.signal}).then(source=>{if(controller.signal.aborted)return;setChart(source);resetRun(source);setLoading(false);}).catch(e=>{if(!controller.signal.aborted){setError(e.message);setLoading(false);}});
    return()=>controller.abort();
  },[sessionId,catalog]);
  useEffect(()=>{
    const element=host.current;if(!element)return;
    const resize=new ResizeObserver(entries=>{setWidth(Math.max(280,Math.round(entries[0].contentRect.width)));setHeight(Math.max(220,Math.round(entries[0].contentRect.height)));});resize.observe(element);return()=>resize.disconnect();
  },[]);
  useEffect(()=>{
    if(typeof window==='undefined'||!host.current)return;
    const fit=()=>{const element=host.current,panel=element?.closest('.simulator-chart-panel');if(!element||!panel)return;const box=element.getBoundingClientRect(),outer=panel.getBoundingClientRect(),tail=Math.max(0,outer.bottom-box.bottom),available=Math.max(260,Math.min(850,window.innerHeight-(box.top+window.scrollY)-tail-10));if(Math.abs(box.height-available)>1)element.style.height=`${Math.round(available)}px`;};
    const frame=window.requestAnimationFrame(fit);window.addEventListener('resize',fit);return()=>{window.cancelAnimationFrame(frame);window.removeEventListener('resize',fit);};
  },[width,loading,mode]);
  useEffect(()=>{const onVisibility=()=>{if(document.hidden)pause();};document.addEventListener('visibilitychange',onVisibility);return()=>{pause();document.removeEventListener('visibilitychange',onVisibility);};},[]);
  useEffect(()=>{
    if(!playing||blocked||edited||dragging||mode!=='idle')return;
    timerRef.current=setTimeout(()=>{timerRef.current=null;nextCandle(true);},speed);
    return()=>{if(timerRef.current!==null)clearTimeout(timerRef.current);timerRef.current=null;};
  },[playing,speed,state.index,blocked,edited,dragging,mode]);
  function togglePlay() {if(blocked||edited||placement.current!=='idle'||drag.current||gesture.current||closePress.current)return;if(!paused.current){pause();return;}paused.current=false;setPlaying(true);}

  function nextCandle(automatic=false) {
    if(automatic&&paused.current||blocked||edited||placement.current!=='idle'||drag.current||gesture.current||closePress.current||!chart)return;
    const before=current.current,index=before.index+1;if(index>=chart.current.length)return;
    let next=advanceCandle(before,chart.current[index],index);
    if(index===chart.current.length-1)next=finishSession(next,chart.current[index]);
    commit(next);
    if(next.ended||next.trades.length!==before.trades.length||(!before.position&&next.position)){pause();if(!next.pending&&!next.position)clearDraft();setNotice(next.ended?'Session complete. Your points breakdown is below.':next.trades.length!==before.trades.length?'Position closed. Review the result or place another bracket.':'Limit filled. Stop and target are now active.');}
  }
  function changeSide(side:'buy'|'sell') {
    if(blocked||current.current.pending||current.current.position||drag.current||gesture.current||closePress.current||!chart)return;pause();placeMode('armed');setEdited(false);setDraft(draftOf(defaultBracket(chart.current[state.index],side) as Bracket));setNotice('Tap the chart to place your entry, stop and target. Then slide any line.');
  }
  function commitBracket(proposal:Bracket,expectedId:number|null) {
    pause();const existing=current.current.position||current.current.pending;
    if(blocked||expectedId!==null&&existing?.id!==expectedId||expectedId===null&&existing)return false;
    const check=validateBracket(proposal);
    if(!check.valid||!check.bracket){setNotice(`${check.error} The previous bracket is unchanged.`);return false;}
    try {const next=existing?editBracket(current.current,check.bracket):placeBracket(current.current,check.bracket);commit(next);setDraft(draftOf(check.bracket));setEdited(false);placeMode('idle');setNotice(`Bracket ${existing?'updated':'placed'}. Eligible from candle ${next.index+2}. Press Play or Next candle to continue.`);return true;}
    catch(error){setNotice(error instanceof Error?error.message:'The bracket could not be updated.');return false;}
  }
  function cancelPlacement() {pause();const pointerId=gesture.current?.pointerId;gesture.current=null;if(pointerId!==undefined&&svg.current?.hasPointerCapture(pointerId))svg.current.releasePointerCapture(pointerId);clearDraft();setNotice('Placement canceled. No order was created.');}
  function closeEntry(orderId:number,generation:number) {
    pause();const existing=current.current.position||current.current.pending;
    if(generation!==runGeneration.current||blocked||!existing||existing.id!==orderId||current.current.ended||drag.current||gesture.current||closePress.current)return;
    const open=!!current.current.position;
    try {commit(open?closeOpenPosition(current.current):cancelPending(current.current));clearDraft();setNotice(open?'Position closed at the latest revealed close. Both exits were removed.':'Unfilled bracket canceled. Both linked exits were removed.');}
    catch(error){setNotice(error instanceof Error?error.message:'The position could not be closed.');}
  }
  function closeDown(event:PointerEvent<SVGGElement>,orderId:number,generation:number) {
    event.preventDefault();event.stopPropagation();
    if(event.button!==0)return;pause();
    if(generation!==runGeneration.current||blocked||drag.current||gesture.current||closePress.current||!displayedView||!svg.current)return;
    const rect=entryCloseHandle(replayPoint(0,parsed.entry,displayedView).y,displayedView),box=svg.current.getBoundingClientRect();
    closePress.current={pointerId:event.pointerId,orderId,generation,x:event.clientX,y:event.clientY,left:box.left+rect.x*box.width/displayedView.width,right:box.left+(rect.x+rect.width)*box.width/displayedView.width,top:box.top+rect.y*box.height/displayedView.height,bottom:box.top+(rect.y+rect.height)*box.height/displayedView.height};
    svg.current.setPointerCapture(event.pointerId);
  }
  function requestAction(kind:'reset'|'session'|'finish',id?:string) {pause();runGeneration.current+=1;closePress.current=null;setConfirm({kind,id});}
  function confirmAction() {
    if(!confirm||!chart)return;
    if(confirm.kind==='session'){setSessionId(confirm.id!);setLoading(true);}
    else if(confirm.kind==='reset')resetRun(chart);
    else{commit(finishSession(current.current,chart.current[state.index]));clearDraft();setNotice('Session finished at the last visible close. No hidden candle was used.');}
    setConfirm(null);
  }
  function startDrag(event:PointerEvent<SVGElement>,key:Key) {
    if(blocked||!showOrders||gesture.current||drag.current||closePress.current||event.button!==0||!displayedView||key==='entry'&&!!state.position)return;
    event.preventDefault();event.stopPropagation();pause();setNotice('');
    const existing=current.current.position||current.current.pending;if(!existing)return;
    const price=svg.current?priceFromClient(event.clientY,svg.current.getBoundingClientRect(),displayedView):null;
    drag.current={key,pointerId:event.pointerId,view:displayedView,before:draft,beforeEdited:edited,candidate:bracketOf(draft),orderId:existing.id,offset:Number.isFinite(price)?Number(price)-parsed[key]:0};setDragging(true);
    svg.current?.setPointerCapture(event.pointerId);
  }
  function moveDrag(event:PointerEvent<SVGSVGElement>) {
    const move=drag.current;if(!move||move.pointerId!==event.pointerId||!svg.current||!Number.isFinite(event.clientY))return;
    const price=priceFromClient(event.clientY,svg.current.getBoundingClientRect(),move.view);
    if(price!==null){move.candidate={...move.candidate,[move.key]:snapPrice(Math.max(.25,price-move.offset))};setEdited(true);setDraft(draftOf(move.candidate));}
  }
  function endDrag(event:PointerEvent<SVGSVGElement>,cancel=false) {
    const move=drag.current;if(!move||event.pointerId!==move.pointerId)return;
    if(!cancel)moveDrag(event); // The release position wins, even without a final pointermove/render.
    drag.current=null;setDragging(false);
    const before=bracketOf(move.before),changed=KEYS.some(key=>move.candidate[key]!==before[key]);
    if(cancel||!changed){setDraft(move.before);setEdited(move.beforeEdited);if(cancel)setNotice('Line move canceled. The bracket is unchanged.');}
    else if(!commitBracket(move.candidate,move.orderId)){setDraft(move.before);setEdited(move.beforeEdited);}
    if(svg.current?.hasPointerCapture(event.pointerId))svg.current.releasePointerCapture(event.pointerId);
  }
  function keyMove(event:KeyboardEvent<SVGGElement>,key:Key) {
    if(blocked||drag.current||gesture.current||closePress.current||key==='entry'&&!!state.position||!['ArrowUp','ArrowDown'].includes(event.key))return;
    event.preventDefault();event.stopPropagation();pause();
    const existing=current.current.position||current.current.pending;if(!existing)return;
    commitBracket({...existing,[key]:snapPrice(existing[key]+(event.key==='ArrowUp'?1:-1)*(event.shiftKey?1:.25))},existing.id);
  }

  function navigate(action:'left'|'right'|'in'|'out'|'fit'|'follow'|'priceIn'|'priceOut') {
    if(!viewport||loading||confirm||drag.current||gesture.current||closePress.current)return;pause();
    setNavigation(nav=>action==='left'||action==='right'?panTime(nav,action,viewport):action==='in'||action==='out'?zoomTime(nav,action==='in'?1.3:1/1.3,viewport):action==='priceIn'||action==='priceOut'?dragView(nav,'price',0,action==='priceIn'?-35:35,viewport):resetViewAxis(nav,action));
  }
  function chartDown(event:PointerEvent<SVGSVGElement>) {
    if(loading||!!error||!!confirm||!chart||drag.current||gesture.current||closePress.current||event.button!==0||!viewport||!svg.current)return;
    pause();const r=svg.current.getBoundingClientRect(),x=(event.clientX-r.left)*viewport.width/r.width,y=(event.clientY-r.top)*viewport.height/r.height;
    const area=x>=viewport.width-viewport.right?'price':y>=viewport.height-viewport.bottom?'time':'plot';
    if(x<viewport.left||y<viewport.top&&area==='plot')return;
    gesture.current={pointerId:event.pointerId,x:event.clientX,y:event.clientY,view:viewport,nav:navigation,scaleX:viewport.width/r.width,scaleY:viewport.height/r.height,mode:placement.current==='armed'&&area==='plot'?'place':area,moved:false};
    event.preventDefault();svg.current.setPointerCapture(event.pointerId);
  }
  function chartMove(event:PointerEvent<SVGSVGElement>) {
    if(closePress.current)return;
    if(drag.current){moveDrag(event);return;}
    const g=gesture.current;if(!g||g.pointerId!==event.pointerId)return;
    const dx=event.clientX-g.x,dy=event.clientY-g.y;if(!g.moved&&Math.hypot(dx,dy)<4)return;g.moved=true;
    if(g.mode!=='place')setNavigation(dragView(g.nav,g.mode,dx*g.scaleX,dy*g.scaleY,g.view));
  }
  function chartUp(event:PointerEvent<SVGSVGElement>,cancel=false) {
    const close=closePress.current;
    if(close){event.preventDefault();event.stopPropagation();if(close.pointerId!==event.pointerId)return;closePress.current=null;const inside=event.clientX>=close.left&&event.clientX<=close.right&&event.clientY>=close.top&&event.clientY<=close.bottom;if(!cancel&&inside&&Math.hypot(event.clientX-close.x,event.clientY-close.y)<8)closeEntry(close.orderId,close.generation);if(svg.current?.hasPointerCapture(event.pointerId))svg.current.releasePointerCapture(event.pointerId);return;}
    if(drag.current){endDrag(event,cancel);return;}
    const g=gesture.current;if(!g||g.pointerId!==event.pointerId)return;
    const moved=g.moved||Math.hypot(event.clientX-g.x,event.clientY-g.y)>=4;
    gesture.current=null;
    if(cancel)setNavigation(g.nav);
    else if(g.mode==='place'&&!moved&&svg.current&&chart){
      const bounds=svg.current.getBoundingClientRect(),x=(event.clientX-bounds.left)*g.view.width/bounds.width,y=(event.clientY-bounds.top)*g.view.height/bounds.height;
      if(x>=g.view.left&&x<=g.view.width-g.view.right&&y>=g.view.top&&y<=g.view.height-g.view.bottom){
        const price=priceFromClient(event.clientY,bounds,g.view);
        if(price!==null){const base=defaultBracket(chart.current[state.index],draft.side) as Bracket,entry=snapPrice(Math.max(.25,price)),delta=entry-base.entry;commitBracket({...base,entry,stop:snapPrice(base.stop+delta),target:snapPrice(base.target+delta)},null);}
      }
    }
    if(svg.current?.hasPointerCapture(event.pointerId))svg.current.releasePointerCapture(event.pointerId);
  }
  function chartKeys(event:KeyboardEvent<SVGSVGElement>) {
    if(event.target!==event.currentTarget)return;
    const action=event.key==='ArrowLeft'?'left':event.key==='ArrowRight'?'right':event.key==='+'||event.key==='='?'in':event.key==='-'?'out':event.key==='Home'?'fit':null;
    if(action){event.preventDefault();navigate(action);}
  }

  return <main className="simulator-shell">
    <header className="simulator-header"><div><a className="simulator-back" href="/">← Training Center</a><p className="eyebrow">CANDLE REPLAY · POINTS PRACTICE</p><h1>Trade Simulator</h1></div><a className="quiet-button" href="/market-direction">Market Direction Bias ↗</a></header>
    <div className="simulator-session"><label>Chart session<select value={choice} disabled={loading||!!confirm} onChange={e=>setChoice(e.target.value)}>{catalog.map(s=><option key={s.id} value={s.id}>{s.title}</option>)}</select></label><button className="quiet-button" disabled={!choice||choice===sessionId||loading||!!confirm} onClick={()=>requestAction('session',choice)}>Load session</button><p>Changing sessions clears this attempt. Results stay on this page only.</p></div>
    {error&&<div className="notice error" role="alert">{error} <button className="quiet-button" onClick={()=>setRetry(v=>v+1)}>Try again</button></div>}
    {confirm&&<section className="simulator-confirm" aria-label="Confirm session action"><h2>{confirm.kind==='finish'?'Finish and score this attempt?':'Clear this attempt?'}</h2><p>{confirm.kind==='finish'?`Any open position closes at candle ${state.index+1}’s close. An unfilled bracket is canceled. Hidden candles are not scored.`:'Current orders and points will be cleared. This cannot be undone.'}</p><button className="primary-button" autoFocus onClick={confirmAction}>{confirm.kind==='finish'?'Finish & score':'Clear & continue'}</button><button className="quiet-button" onClick={()=>setConfirm(null)}>Keep practicing</button></section>}
    <div className="simulator-workspace">
      <section className="simulator-chart-panel" aria-label="Replay chart">
        <div className="simulator-chart-heading"><div><span className={`sim-status ${state.position?'is-open':''}`}>{loading?'Loading chart…':state.ended?'SESSION COMPLETE':state.position?`${state.position.side==='buy'?'LONG':'SHORT'} OPEN`:state.pending?'BRACKET WAITING':'NO ACTIVE ORDER'}</span><p>{chart?.title||'Historical chart sessions'}</p></div><div className="simulator-candle-count">Candle <strong>{chart?state.index+1:'—'}</strong> / {chart?.current.length||'—'}<small>Only revealed candles are scored</small></div></div>
        <div className="simulator-trade-bar"><button className="sim-buy" aria-pressed={mode!=='idle'&&draft.side==='buy'} disabled={blocked||!!active} onClick={()=>changeSide('buy')}>Buy limit</button><button className="sim-sell" aria-pressed={mode!=='idle'&&draft.side==='sell'} disabled={blocked||!!active} onClick={()=>changeSide('sell')}>Sell limit</button><span role="status">{mode==='armed'?'Tap the chart to set your entry':active?'Slide a line to update · × cancels or closes':'Choose Buy or Sell, then tap the chart'}</span>{mode==='armed'&&<button className="quiet-button" onClick={cancelPlacement}>Cancel placement</button>}</div>
        <div className={`simulator-chart ${mode==='armed'?'is-placing':''}`} ref={host}>
          {chart&&displayedView&&<svg ref={svg} viewBox={`0 0 ${displayedView.width} ${displayedView.height}`} role="group" aria-label="Candle chart with draggable entry, stop and target lines" tabIndex={0} onKeyDown={chartKeys} onPointerDown={chartDown} onPointerMove={chartMove} onPointerUp={e=>chartUp(e)} onPointerCancel={e=>chartUp(e,true)} onLostPointerCapture={e=>chartUp(e,true)}>
            <defs><clipPath id="simulator-plot"><rect x={displayedView.left} y={displayedView.top} width={displayedView.width-displayedView.left-displayedView.right} height={displayedView.height-displayedView.top-displayedView.bottom}/></clipPath></defs>
            {Array.from({length:6},(_,i)=>{const price=displayedView.lo+(displayedView.hi-displayedView.lo)*i/5,y=replayPoint(0,price,displayedView).y;return <g key={i}><line x1={displayedView.left} x2={displayedView.width-displayedView.right} y1={y} y2={y} stroke="#203248"/><text x={displayedView.width-7} y={y+4} textAnchor="end" fill="#8ea8be" fontSize="11">{format(price)}</text></g>;})}
            <g clipPath="url(#simulator-plot)" data-layer="visible-candles">{displayedView.visible.map(c=>{const o=replayPoint(c.slot,c.o,displayedView),h=replayPoint(c.slot,c.h,displayedView),l=replayPoint(c.slot,c.l,displayedView),close=replayPoint(c.slot,c.c,displayedView),color=c.c>=c.o?'#67dfb3':'#f18da6',w=Math.max(.7,displayedView.step*.56);return <g key={c.slot} opacity={c.prior ? .4 : 1} data-prior={c.prior}><rect x={o.x-displayedView.step/2} y={displayedView.top} width={displayedView.step} height={displayedView.height-displayedView.top-displayedView.bottom} fill={c.prior?'#23304066':'transparent'}/><line x1={h.x} x2={h.x} y1={h.y} y2={l.y} stroke={color} strokeWidth={Math.min(1.4,Math.max(.6,displayedView.step*.3))}/><rect x={o.x-w/2} y={Math.min(o.y,close.y)} width={w} height={Math.max(1,Math.abs(o.y-close.y))} fill={color}/><title>{`${c.prior?'Prior context':'Candle '+(c.index+1)} · ${c.t} · O ${c.o} H ${c.h} L ${c.l} C ${c.c}`}</title>{!c.prior&&<text x={o.x} y={Math.max(displayedView.top+10,h.y-7)} textAnchor="middle" fontSize={Math.max(7,Math.min(10,displayedView.step/1.35))} fill="#a2b0c1">{c.index+1}</text>}</g>;})}
              {showEma&&displayedView.visibleEma.length>1&&<path data-indicator="ema20" d={displayedView.visibleEma.map((point,index)=>{const p=replayPoint(point.slot,point.value,displayedView);return `${index?'L':'M'} ${p.x} ${p.y}`;}).join(' ')} fill="none" stroke="#f6c760" strokeWidth="2" pointerEvents="none"/>}
              {showEma&&displayedView.visibleEma.length===1&&<circle data-indicator="ema20" cx={replayPoint(displayedView.visibleEma[0].slot,displayedView.visibleEma[0].value,displayedView).x} cy={replayPoint(displayedView.visibleEma[0].slot,displayedView.visibleEma[0].value,displayedView).y} r="3" fill="#f6c760"/>}
              {displayedView.priorClose!==null&&<g pointerEvents="none"><line x1={displayedView.left} x2={displayedView.width-displayedView.right} y1={replayPoint(0,displayedView.priorClose,displayedView).y} y2={replayPoint(0,displayedView.priorClose,displayedView).y} stroke="#d5b771" strokeDasharray="5 5"/><text x={displayedView.left+4} y={Math.max(displayedView.top+12,replayPoint(0,displayedView.priorClose,displayedView).y-5)} fill="#e4cc95" fontSize="10">Prior close {format(displayedView.priorClose)}</text></g>}
              {state.trades.flatMap(t=>[{key:`${t.id}-in`,index:t.entryIndex,price:t.entryPrice,color:'#8ac7ff',text:'Entry'},{key:`${t.id}-out`,index:t.exitIndex,price:t.exitPrice,color:t.points>=0?'#9ee5bc':'#ff9aa9',text:'Exit'}]).map(p=>{const point=replayPoint(displayedView.priorCount+p.index,p.price,displayedView);return <circle key={p.key} cx={point.x} cy={point.y} r="4" fill={p.color} stroke="#0b1421"><title>{`${p.text} · ${format(p.price)}`}</title></circle>;})}
            </g>
            {(()=>{const x=displayedView.left+(displayedView.priorCount-displayedView.start)*displayedView.step;return x>=displayedView.left&&x<displayedView.width-displayedView.right?<g pointerEvents="none"><line x1={x} x2={x} y1={displayedView.top} y2={displayedView.height-displayedView.bottom} stroke="#b6c8e0" strokeDasharray="4 4"/><text x={x+5} y={displayedView.top-9} fill="#c5d8f0" fontSize="11">Day open · 08:30</text>{x-displayedView.left>70&&<text x={displayedView.left} y={displayedView.top-9} fill="#91a0b3" fontSize="11">Prior RTH</text>}</g>:null;})()}
            {displayedView.visible.filter((c,i)=>i===0||!c.prior&&c.index%Math.max(6,Math.ceil(48/displayedView.step/6)*6)===0).map(c=><text key={c.slot} x={replayPoint(c.slot,0,displayedView).x} y={displayedView.height-17} fill={c.prior?'#758496':'#90a2b9'} fontSize="10" textAnchor="middle">{c.t?.slice(-5)}</text>)}
            {displayedView.visible.length<displayedView.count&&<text x={Math.min(displayedView.width-displayedView.right-75,displayedView.left+displayedView.visible.length*displayedView.step+10)} y={displayedView.top+24} fill="#7b8fa7" fontSize="11">{state.ended?'Session end':'Unrevealed'}</text>}
            {!state.ended&&showOrders&&KEYS.filter(k=>Number.isFinite(parsed[k])).map(key=>{const y=replayPoint(0,parsed[key],displayedView).y;return <g key={key}><line x1={displayedView.left} x2={displayedView.width-displayedView.right} y1={y} y2={y} stroke={COLORS[key]} strokeDasharray={!active||edited?'5 5':undefined} opacity=".8" pointerEvents="none"/><line className="sim-order-line-hit" x1={displayedView.left} x2={displayedView.width-displayedView.right} y1={y} y2={y} stroke="transparent" strokeWidth="18" onPointerDown={e=>startDrag(e,key)} /></g>;})}
            {!state.ended&&showOrders&&KEYS.filter(k=>Number.isFinite(parsed[k])).map(key=>{const y=replayPoint(0,parsed[key],displayedView).y,handle=orderHandle(key,y,displayedView),locked=key==='entry'&&!!state.position;return <g key={key} className={`sim-order-handle ${locked?'locked':''}`} role="slider" tabIndex={blocked||locked?-1:0} aria-label={`${LABELS[key]} price${locked?' (locked after fill)':''}`} aria-valuemin={.25} aria-valuemax={1e9} aria-valuenow={parsed[key]} aria-valuetext={`${format(parsed[key])}${locked?', locked':''}`} aria-disabled={blocked||locked} onPointerDown={e=>startDrag(e,key)} onKeyDown={e=>keyMove(e,key)}><rect {...handle} rx="7" fill="#122439" stroke={COLORS[key]}/><text x={handle.x+8} y={handle.y+17} fill={COLORS[key]} fontSize="10" fontWeight="700" pointerEvents="none">{locked?'LOCKED LIMIT':`${LABELS[key].toUpperCase()} ↕`}</text><text x={handle.x+8} y={handle.y+33} fill="#f1f6fc" fontSize="12" pointerEvents="none">{format(parsed[key])}</text></g>;})}
            {!state.ended&&active&&Number.isFinite(parsed.entry)&&(()=>{const box=entryCloseHandle(replayPoint(0,parsed.entry,displayedView).y,displayedView),label=state.position?'Close simulated position at latest revealed close':'Cancel pending bracket',id=active.id,generation=runGeneration.current;return <g className="sim-entry-close" role="button" tabIndex={blocked?-1:0} aria-label={label} aria-disabled={blocked} onPointerDown={event=>closeDown(event,id,generation)} onClick={event=>{event.preventDefault();event.stopPropagation();if(event.detail===0)closeEntry(id,generation);}} onKeyDown={event=>{event.stopPropagation();if(event.key==='Enter'||event.key===' '){event.preventDefault();closeEntry(id,generation);}}}><rect {...box} rx="7" fill="#14283c" stroke="#8ac7ff"/><text x={box.x+22} y={box.y+29} textAnchor="middle" fill="#eaf5ff" fontSize="27" pointerEvents="none">×</text><title>{label}</title></g>;})()}

          </svg>}
        </div>
        <label className="simulator-ema"><input type="checkbox" checked={showEma} onChange={e=>setShowEma(e.target.checked)} /> EMA20</label><p className="simulator-chart-hint">Drag the chart to pan; drag the bottom or right axis to zoom. Release a valid line move to update it. The entry × cancels or closes.</p>
        <div className="simulator-replay"><button className="primary-button" disabled={blocked||edited||dragging||mode!=='idle'} onClick={togglePlay}>{playing?'Pause':'▶ Play'}</button><button className="quiet-button" disabled={blocked||edited||playing||dragging||mode!=='idle'} onClick={()=>nextCandle()}>Next candle →</button><label>Speed<select value={speed} disabled={!!confirm} onChange={e=>setSpeed(Number(e.target.value))}><option value={1800}>Slow</option><option value={1000}>Normal</option><option value={450}>Fast</option></select></label><button className="quiet-button" disabled={loading||!chart||!!confirm} onClick={()=>requestAction('reset')}>Replay</button><button className="quiet-button" disabled={blocked} onClick={()=>requestAction('finish')}>Finish & score now</button></div>
        <div className="simulator-view-controls" aria-label="Chart view controls"><button onClick={()=>navigate('left')} aria-label="Pan to earlier candles">←</button><button onClick={()=>navigate('right')} aria-label="Pan to later candles">→</button><button onClick={()=>navigate('out')} aria-label="Show more candles">−</button><button onClick={()=>navigate('in')} aria-label="Larger candles">+</button><button onClick={()=>navigate('fit')}>Fit</button><button onClick={()=>navigate('follow')}>Latest</button><button onClick={()=>navigate('priceOut')} aria-label="Expand price range">Price −</button><button onClick={()=>navigate('priceIn')} aria-label="Tighten price range">Price +</button></div>
        <p className="simulator-replay-note">Auto-play pauses on an entry or exit. Replay clears all orders and results.</p>
      </section>
      {active&&<aside className="simulator-ticket simulator-lines-only" aria-label="Bracket summary"><p className="eyebrow">ONE BRACKET AT A TIME</p><h2>{state.position?'Open position':'Working bracket'}</h2>
        <div className="simulator-risk"><p className="eyebrow">PLANNED BRACKET</p>{metrics?<><div><span>Risk <strong>{format(metrics.risk)} pts</strong></span><span>Reward <strong>{format(metrics.reward)} pts</strong></span></div><p className="simulator-profitable">Profitable above {metrics.requiredWinRate.toFixed(1)}% win rate.</p></>:<p className="simulator-validation" role="status">{validation.error}</p>}<small>Calculated from the chosen limit, stop and target. Prices snap to 0.25.</small></div>
        {state.position&&<p className="simulator-fill">Actual entry <strong>{format(state.position.entryPrice)}</strong><br/>Open points <strong className={unrealized<0?'negative':'positive'}>{signed(unrealized)}</strong></p>}
        <p className="simulator-ticket-help">{state.pending?`Waiting for a touch from candle ${state.pending.eligibleIndex+1}. Slide a line to change it; × cancels the bracket.`:'Entry is fixed. Slide the stop or target to update it; × closes at the latest revealed close.'} Valid releases apply immediately for the next candle. Replay stays paused.</p>
      </aside>}
      <p className="simulator-notice simulator-order-notice" role="status" aria-live="polite">{notice}</p>
    </div>
    <section className="simulator-results" aria-labelledby="sim-results"><div className="simulator-results-heading"><h2 id="sim-results">{state.ended?'Your points breakdown':'Points so far'}</h2><span>{state.ended?'FINAL':'CLOSED POSITIONS ONLY'}</span></div><div className="simulator-stats"><div><span>Net points</span><strong className={totals.netPoints<0?'negative':'positive'}>{signed(totals.netPoints)}</strong></div><div><span>Wins / losses / flat</span><strong>{totals.wins} / {totals.losses} / {totals.flats}</strong></div><div><span>Win rate</span><strong>{totals.trades?`${totals.winRate.toFixed(1)}%`:'—'}</strong></div><div><span>Won / lost points</span><strong>{format(totals.grossProfit)} / {format(totals.grossLoss)}</strong></div></div>
      <div className="simulator-ledger" tabIndex={0} aria-label="Scrollable trade ledger"><table><thead><tr><th>Trade</th><th>Entry</th><th>Exit</th><th>Reason</th><th>Result</th><th>Points</th></tr></thead><tbody>{state.trades.map((t,index)=><tr key={t.id}><td>{index+1} · {t.side==='buy'?'Long':'Short'}</td><td>{format(t.entryPrice)}<small>Candle {t.entryIndex+1} · {t.entryTime.slice(-5)}</small></td><td>{format(t.exitPrice)}<small>Candle {t.exitIndex+1} · {t.exitTime.slice(-5)}</small></td><td>{EXIT_LABELS[t.reason as keyof typeof EXIT_LABELS]||t.reason}{t.ambiguous&&<small>Both levels touched · stop first</small>}</td><td>{t.outcome==='win'?'Win':t.outcome==='loss'?'Loss':'Flat'}</td><td className={t.points<0?'negative':'positive'}>{signed(t.points)}</td></tr>)}</tbody></table>{!state.trades.length&&<p>No closed positions yet. Your entries and exits will appear here.</p>}</div>
      {state.position&&<p>One position is still open; {signed(unrealized)} open points are not included in the closed total.</p>}{state.ended&&<p>Open positions were marked at the last revealed close; unfilled orders were canceled. Win rate includes flat results in the total.</p>}
    </section>
    <details className="simulator-rules"><summary>How candle fills and points work</summary><ul><li>This is a simplified historical points simulation—not live trading or an execution guarantee. One bracket or position is allowed at a time.</li><li>Choose Buy or Sell, then tap the chart to place the entry, stop and target together. A valid line release updates the complete bracket immediately. New or changed orders are eligible on the next candle. Previously visible candles never fill it. An unfilled bracket remains active until filled, moved, canceled or the session ends.</li><li>Buy limits fill when the next eligible candle opens at or below the limit, or its low touches it. Sell limits are the reverse. A favorable opening gap uses the opening price; otherwise entry is at the limit.</li><li>The stop and target activate only after entry. A gap past an active stop exits at the opening price. A gap past an active target exits at the opening price too. If an entry gaps past its own stop, entry and stop both fill at that open, for zero points.</li><li>Candles reveal open, high, low and close—not the exact path between them. When both exits are reachable after an opening between them, the stop wins. An already-triggered opening exit happens before later wicks.</li><li>On an intrabar entry candle, a target wick alone is not credited: it could have happened before entry. A target is credited that candle only if the close proves a crossing after entry, and the stop was not reached. A fill at the open can use that candle’s target touch.</li><li>Arming, tapping, dragging, keyboard line adjustments and chart navigation pause replay immediately. Valid line releases apply without a confirmation. Invalid or canceled moves restore the last valid bracket. Press Play explicitly to resume. An open entry cannot be moved. Each completed exit cancels its paired order. The × beside the entry cancels an unfilled bracket or closes an open simulated position at the latest revealed close—not a panned historical candle—and removes both exits.</li><li>The planned percentage uses risk ÷ (risk + reward). Actual points use the entry and exit fill prices. A long earns exit minus entry; a short earns entry minus exit. Final open positions close at the last revealed close, explicitly labeled Session end.</li><li>The opening view matches Market Direction: dim prior-session context, a day-open divider and the revealed current-day candles. Empty slots are unrevealed, not future prices. Pan/zoom only changes the view, never the replay or score.</li><li>No account is required, no broker is connected, and refreshing or leaving this page clears this attempt.</li></ul></details>
  </main>;
}
