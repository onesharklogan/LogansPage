"use client";

import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState, type FormEvent } from 'react';

type Role = 'admin' | 'author';
export type Member = { email: string; role: Role; active: boolean; createdAt?: string | number; updatedAt?: string | number; bound: boolean; passwordSet?: boolean };
export type MembershipAction = { kind: 'add' | 'role'; email: string; role: Role } | { kind: 'remove'; email: string };
type Props = { csrfToken: string; currentEmail?: string | null; onMembershipChange: () => Promise<void> };
type Notice = { kind: 'success' | 'error' | 'info'; text: string };

export class MemberRequestError extends Error {
  constructor(message: string, public status: number) { super(message); }
}

export async function memberRequest<T>(path: string, init?: RequestInit): Promise<T> {
  let response: Response;
  try { response = await fetch(path, { ...init, credentials: 'same-origin', cache: 'no-store' }); }
  catch (error) {
    if (init?.signal?.aborted) throw error;
    throw new MemberRequestError(init?.method ? 'The change could not be confirmed. Refresh the author list before trying again.' : 'The author list could not be loaded. Please try Refresh.', 0);
  }
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const fallback = response.status === 409 ? 'This change is not allowed. At least one active administrator must remain. Refresh the author list and review the current roles.' : response.status === 401 || response.status === 403 ? 'Your account no longer has access to manage authors.' : 'The author change could not be completed.';
    throw new MemberRequestError(response.status >= 500 && init?.method ? 'The server could not confirm this change. Refresh the author list before trying again.' : typeof data?.error === 'string' ? data.error : fallback, response.status);
  }
  return data as T;
}

export function membershipConfirmation(action: MembershipAction, currentEmail?: string | null) {
  const self = !!currentEmail && action.email.toLowerCase() === currentEmail.toLowerCase();
  if (action.kind === 'remove') return `Remove author access for ${action.email}? ${self ? 'This is your account. You will be signed out and lose access to create slides and manage authors.' : 'Their current author sessions will be revoked immediately.'} Saved slides will not be deleted.`;
  if (action.role === 'admin') return `Grant administrator access to ${action.email}? Administrators can create and edit slides, add or remove authors, and grant administrator access to others. No invitation will be sent.`;
  if (action.kind === 'role' && self) return `Change your account (${action.email}) to author? You can still create and edit slides, but will lose access to Manage Authors.`;
  return null;
}

/** Explicit confirmations run before any state-changing request; cancel performs no mutation. */
export async function performMembershipAction(action: MembershipAction, csrfToken: string, currentEmail: string | null | undefined, confirm: (message: string) => boolean, request: typeof memberRequest = memberRequest) {
  const confirmation = membershipConfirmation(action, currentEmail);
  if (confirmation && !confirm(confirmation)) return false;
  if (!csrfToken) throw new MemberRequestError('Sign in again before changing author access.', 401);
  const base = '/api/author/members';
  const path = action.kind === 'add' ? base : `${base}/${encodeURIComponent(action.email)}${action.kind === 'remove' ? '/remove' : ''}`;
  await request(path, { method: action.kind === 'role' ? 'PATCH' : 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken }, body: JSON.stringify(action.kind === 'remove' ? {} : action.kind === 'add' ? { email: action.email, role: action.role } : { role: action.role }) });
  return true;
}


export async function createEnrollmentLink(email: string, csrfToken: string, currentEmail: string | null | undefined, confirm: (message: string) => boolean, origin: string, request: typeof memberRequest = memberRequest) {
  const self = email.toLowerCase() === currentEmail?.toLowerCase();
  if (!confirm(`Create a private setup/reset link for ${email}? Anyone holding it can set this account's password. ${self ? 'This is your account. ' : ''}Using it will revoke previous sessions. Existing setup/reset links will stop working. No email will be sent.`)) return null;
  if (!csrfToken) throw new MemberRequestError('Sign in again before creating a setup/reset link.', 401);
  const result = await request<{ enrollmentUrl: string; expiresAt: string }>(`/api/author/members/${encodeURIComponent(email)}/enrollment`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken }, body: '{}' });
  let url: URL;
  try { url = new URL(result.enrollmentUrl, origin); } catch { throw new Error('The setup/reset link response was invalid.'); }
  if (url.origin !== origin || url.pathname !== '/activate' || url.search || !/^#token=[a-f0-9]{64}$/i.test(url.hash) || !Number.isFinite(Date.parse(result.expiresAt))) throw new Error('The setup/reset link response was invalid.');
  return { enrollmentUrl: url.href, expiresAt: result.expiresAt };
}

export default function ManageAuthors({ csrfToken, currentEmail, onMembershipChange }: Props) {
  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<Notice | null>(null);
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<Role>('author');
  const [enrollment, setEnrollment] = useState<{ email: string; enrollmentUrl: string; expiresAt: string } | null>(null);
  const mounted = useRef(false);
  const loadGeneration = useRef(0);
  const loadRequest = useRef<AbortController | null>(null);
  const mutationInFlight = useRef(false);
  const enrollmentGeneration = useRef(0);
  const actor = useMemo(() => ({ csrfToken, currentEmail }), [csrfToken, currentEmail]);
  const committedActor = useRef<typeof actor | null>(null);
  const allowed = () => mounted.current && committedActor.current === actor;
  const renderedEnrollmentGeneration = enrollmentGeneration.current;
  useLayoutEffect(() => {
    committedActor.current = actor;
    loadGeneration.current++; loadRequest.current?.abort(); enrollmentGeneration.current++;
    setMembers([]); setEnrollment(null); setNotice(null);
    return () => { if (committedActor.current === actor) committedActor.current = null; };
  }, [actor]);
  const confirmCurrent = (message: string) => allowed() && window.confirm(message) && allowed();
  async function requestCurrent<T>(path: string, init?: RequestInit): Promise<T> {
    if (!allowed()) throw new MemberRequestError('The administrator account changed. Check access again.', 0);
    return memberRequest<T>(path, init);
  }

  const reloadMembers = useCallback(async () => {
    if (!mounted.current || committedActor.current !== actor) return;
    const generation = ++loadGeneration.current;
    loadRequest.current?.abort();
    const controller = new AbortController(); loadRequest.current = controller;
    const active = () => mounted.current && committedActor.current === actor && !controller.signal.aborted && loadGeneration.current === generation;
    if (active()) setLoading(true);
    try {
      const result = await memberRequest<{ members: Member[] }>('/api/author/members', { signal: controller.signal });
      if (!active()) return;
      if (!Array.isArray(result.members) || result.members.length > 1000 || result.members.some(member => typeof member.email !== 'string' || !['author', 'admin'].includes(member.role) || typeof member.active !== 'boolean')) throw new Error('The author list returned an invalid response.');
      setMembers(result.members);
    } catch (error) {
      if (!active()) return;
      if (allowed() && error instanceof MemberRequestError && (error.status === 401 || error.status === 403)) setMembers([]);
      throw error;
    } finally { if (active()) { setLoading(false); loadRequest.current = null; } }
  }, [actor]);

  useEffect(() => {
    mounted.current = true;
    reloadMembers().catch(error => { if (allowed()) setNotice({ kind: 'error', text: error.message }); });
    return () => { mounted.current = false; loadGeneration.current += 1; loadRequest.current?.abort(); };
  }, [reloadMembers]);

  async function applyAction(action: MembershipAction) {
    if (!allowed() || mutationInFlight.current) return;
    mutationInFlight.current = true; setBusy(true); setNotice(null); setEnrollment(null);
    let committed = false;
    try {
      const changed = await performMembershipAction(action, csrfToken, currentEmail, confirmCurrent, requestCurrent);
      if (!changed) return;
      committed = true;
      if (!allowed()) return;
      // Invalidate earlier reads before the mandatory server refresh.
      loadGeneration.current += 1; loadRequest.current?.abort();
      if (action.kind === 'add') { setEmail(''); setRole('author'); }
      try { await reloadMembers(); }
      finally { if (allowed()) await onMembershipChange(); }
      if (allowed()) setNotice({ kind: 'success', text: action.kind === 'remove' ? 'Author access removed. Saved slides are unchanged.' : action.kind === 'add' ? 'Author access saved. No invitation was sent.' : 'Author role updated.' });
    } catch (error) {
      if (allowed()) setNotice({ kind: committed ? 'info' : 'error', text: committed ? 'The change was saved, but the refreshed author list could not be shown. Refresh to check current access.' : error instanceof Error ? error.message : 'The author change could not be completed.' });
      // A revoked/expired administrator must not keep an old privileged screen.
      if (allowed() && !committed && error instanceof MemberRequestError && (error.status === 401 || error.status === 403)) {
        if (allowed()) setMembers([]);
        await onMembershipChange().catch(() => {});
      }
    } finally { mutationInFlight.current = false; if (mounted.current) setBusy(false); }
  }


  async function issueEnrollment(email: string) {
    if (!allowed() || mutationInFlight.current) return;
    const generation = ++enrollmentGeneration.current;
    mutationInFlight.current = true; setBusy(true); setNotice(null); setEnrollment(null);
    try {
      const result = await createEnrollmentLink(email, csrfToken, currentEmail, confirmCurrent, window.location.origin, requestCurrent);
      if (allowed() && generation === enrollmentGeneration.current && result) setEnrollment({ email, ...result });
    } catch (error) {
      if (allowed()) setNotice({ kind: 'error', text: error instanceof Error ? error.message : 'The setup/reset link could not be created.' });
      if (allowed() && error instanceof MemberRequestError && (error.status === 401 || error.status === 403)) { if (allowed()) setMembers([]); await onMembershipChange().catch(() => {}); }
    } finally { mutationInFlight.current = false; if (mounted.current) setBusy(false); }
  }

  async function copyEnrollment() {
    if (!allowed() || renderedEnrollmentGeneration !== enrollmentGeneration.current || !enrollment) return;
    try { await navigator.clipboard.writeText(enrollment.enrollmentUrl); if (allowed() && renderedEnrollmentGeneration === enrollmentGeneration.current) setNotice({ kind: 'info', text: 'Private link copied. Share it only with the intended account owner through a trusted private channel.' }); }
    catch { if (allowed() && renderedEnrollmentGeneration === enrollmentGeneration.current) setNotice({ kind: 'error', text: 'Copy was unavailable. Select the private link below and copy it manually.' }); }
  }

  function addAuthor(event: FormEvent) {
    event.preventDefault();
    if (!allowed() || mutationInFlight.current) return;
    const exactEmail = email.trim().toLowerCase();
    if (exactEmail.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(exactEmail)) { setNotice({ kind: 'error', text: 'Enter the exact email address for their author account.' }); return; }
    void applyAction({ kind: 'add', email: exactEmail, role });
  }

  return <details className="panel import-panel" style={{ marginTop: 24 }} onToggle={event => { if (!allowed()) return; if (!event.currentTarget.open) { enrollmentGeneration.current++; setEnrollment(null); } }}>
    <summary>Manage access <span>Administrators only</span></summary>
    <p className="muted">Authors can create and edit slides. Administrators can also manage author access.</p>
    <p className="field-help">No email is sent automatically. Add an approved account, then explicitly create a private one-use setup link. Only its intended owner should receive it.</p>
    {enrollment && <section className="notice info" aria-label="Private setup/reset link" style={{ display: 'grid', gap: 10 }}><strong>Private link for {enrollment.email}</strong><p>Anyone holding this link can set this account's password. It expires {new Date(enrollment.expiresAt).toLocaleString()}. This link is shown only here and is not emailed.</p><label htmlFor="private-enrollment-link">One-use setup/reset link<textarea id="private-enrollment-link" readOnly autoComplete="off" value={enrollment.enrollmentUrl} rows={3} style={{ width: '100%', overflowWrap: 'anywhere' }} /></label><div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}><button className="quiet-button" type="button" onClick={() => void copyEnrollment()}>Copy private link</button><button className="quiet-button" type="button" onClick={() => { if (!allowed() || renderedEnrollmentGeneration !== enrollmentGeneration.current) return; enrollmentGeneration.current++; setEnrollment(null); }}>Dismiss link</button></div></section>}
    {notice && <div className={`notice ${notice.kind}`} role={notice.kind === 'error' ? 'alert' : 'status'}><span>{notice.text}</span></div>}
    <form onSubmit={addAuthor} style={{ display: 'grid', gap: 12, marginTop: 18 }}>
      <label htmlFor="new-author-email">Account email<input id="new-author-email" type="email" autoComplete="off" required maxLength={254} value={email} onChange={event => { if (allowed() && !mutationInFlight.current) setEmail(event.target.value); }} disabled={busy} placeholder="Exact account email" /></label>
      <label htmlFor="new-author-role">Access level<select id="new-author-role" aria-describedby="new-author-role-help" value={role} onChange={event => { if (allowed() && !mutationInFlight.current) setRole(event.target.value as Role); }} disabled={busy}><option value="author">Author</option><option value="admin">Administrator</option></select></label>
      <p id="new-author-role-help" className="field-help admin-role-help">Authors can create and edit slides. Administrators can also manage author access.</p>
      <div><button className="quiet-button" type="submit" disabled={busy || !email.trim()}>{busy ? 'Saving access…' : 'Add or reactivate author'}</button></div>
    </form>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12, margin: '24px 0 12px' }}><h3 style={{ fontSize: 16 }}>Author access</h3><button className="quiet-button" type="button" disabled={busy || loading} onClick={() => { if (!allowed() || mutationInFlight.current) return; enrollmentGeneration.current++; setNotice(null); setEnrollment(null); reloadMembers().catch(error => { if (allowed()) setNotice({ kind: 'error', text: error.message }); }); }}>{loading ? 'Loading…' : 'Refresh'}</button></div>
    <div aria-busy={loading}>
      {members.map(member => <article key={member.email} style={{ borderTop: '1px solid #2b4055', padding: '14px 0', display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 14 }}>
        <div style={{ flex: '1 1 220px', minWidth: 0 }}><strong style={{ display: 'block', overflowWrap: 'anywhere', fontSize: 13 }}>{member.email}{member.email.toLowerCase() === currentEmail?.toLowerCase() ? ' (you)' : ''}</strong><p className="field-help" style={{ margin: '5px 0 0' }}>{member.active ? member.passwordSet ? 'Active · password set' : 'Active · approved account' : 'Removed · cannot create or edit'} · {member.role === 'admin' ? 'Administrator' : 'Author'}</p></div>
        {member.active ? <><button className="quiet-button" type="button" disabled={busy || loading} onClick={() => { void issueEnrollment(member.email); }}>Legacy password setup</button><label className="sr-only" htmlFor={`member-role-${member.email}`}>Role for {member.email}</label><select id={`member-role-${member.email}`} aria-label={`Role for ${member.email}`} value={member.role} onChange={event => { void applyAction({ kind: 'role', email: member.email, role: event.target.value as Role }); }} disabled={busy || loading} style={{ width: 155 }}><option value="author">Author</option><option value="admin">Administrator</option></select><button className="quiet-button" type="button" disabled={busy || loading} onClick={() => { void applyAction({ kind: 'remove', email: member.email }); }}>Remove</button></> : <button className="quiet-button" type="button" disabled={busy || loading} onClick={() => { void applyAction({ kind: 'add', email: member.email, role: member.role }); }}>Reactivate</button>}
      </article>)}
      {!loading && !members.length && <p className="field-help">No author records are available to display. Refresh to check current access.</p>}
    </div>
    <p className="field-help">Removing an author revokes their current sessions. At least one active administrator must remain; the server checks this before accepting a change.</p>
  </details>;
}
