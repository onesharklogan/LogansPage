"use client";
import { useCallback, useEffect, useRef, useState } from 'react';
import AppHeader from './app-navigation';
import PasswordSignIn from './password-sign-in';
import ManageAuthors from './manage-authors';

type AdminStatus = { author: boolean; csrfToken: string | null; passwordConfigured: boolean; authorEmail: string | null; authorRole: 'admin' | 'author' | null; storageReady: boolean };
export default function AdminArea() {
  const [status, setStatus] = useState<AdminStatus | null>(null), [loading, setLoading] = useState(true), [busy, setBusy] = useState(false), [error, setError] = useState('');
  const logoutInFlight = useRef(false);
  const mounted = useRef(false), generation = useRef(0), currentRequest = useRef<AbortController | null>(null);
  const refresh = useCallback(async () => {
    const request = new AbortController(), requestGeneration = ++generation.current;
    currentRequest.current?.abort(); currentRequest.current = request;
    setLoading(true); setError('');
    try {
      const response = await fetch('/api/status', { credentials: 'same-origin', cache: 'no-store', signal: request.signal });
      if (!response.ok) throw new Error('Author access could not be checked. Please try again.');
      const next = await response.json();
      if (typeof next.author !== 'boolean' || typeof next.passwordConfigured !== 'boolean') throw new Error('The author access response was invalid.');
      if (mounted.current && !request.signal.aborted && requestGeneration === generation.current) setStatus(next);
    } catch (problem) {
      if (mounted.current && !request.signal.aborted && requestGeneration === generation.current) { setStatus(null); setError(problem instanceof Error ? problem.message : 'Author access could not be checked.'); }
    } finally { if (mounted.current && requestGeneration === generation.current) setLoading(false); }
  }, []);
  useEffect(() => { mounted.current = true; void refresh(); return () => { mounted.current = false; generation.current++; currentRequest.current?.abort(); }; }, [refresh]);
  async function logout() {
    if (logoutInFlight.current || !status?.csrfToken) return;
    logoutInFlight.current = true; setBusy(true); setError('');
    try {
      const response = await fetch('/api/auth/logout', { method: 'POST', credentials: 'same-origin', cache: 'no-store', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': status.csrfToken }, body: '{}' });
      if (!response.ok) throw new Error('Sign-out could not be confirmed. Refresh to check your current access.');
      await refresh();
    } catch (problem) { if (mounted.current) setError(problem instanceof Error ? problem.message : 'Sign-out could not be confirmed.'); }
    finally { logoutInFlight.current = false; if (mounted.current) setBusy(false); }
  }
  return <div className="training-center"><AppHeader section="ADMIN" current="/admin">{status?.author ? <><span className="app-account-name" title={status.authorEmail || 'Approved author'}>{status.authorEmail || 'Author'}</span><button className="quiet-button" disabled={busy} onClick={logout}>{busy ? 'Signing out…' : 'Sign out'}</button></> : <span className="app-account-name">Author sign in</span>}</AppHeader><main className="admin-main"><p className="eyebrow">ADMIN AREA</p><h1>Admin Login</h1><p className="admin-intro">Sign in with your email and password to access your approved author account. Administrators can manage who has access.</p>{error && <div className="notice error" role="alert"><span>{error}</span><button className="quiet-button" disabled={loading} onClick={() => void refresh()}>Check access again</button></div>}{loading ? <section className="panel admin-login-panel" aria-busy="true"><p role="status">Checking author access…</p></section> : !status ? <section className="panel admin-login-panel"><h2>Author access could not be checked</h2><p>Use “Check access again” above. The public training module remains available without sign-in.</p></section> : status.author ? <><section className="panel admin-session"><div><p className="eyebrow">SIGNED IN</p><h2>{status.authorRole === 'admin' ? 'Administrator access' : 'Author access'}</h2>{status.authorEmail && <p className="admin-account">{status.authorEmail}</p>}<p className="field-help">{status.authorRole === 'admin' ? 'You can add, remove and manage author access below.' : 'Your account is approved. Only administrators can manage author access.'}</p></div><button className="quiet-button" disabled={busy} onClick={logout}>{busy ? 'Signing out…' : 'Sign out'}</button></section>{status.authorRole === 'admin' && status.csrfToken && <ManageAuthors csrfToken={status.csrfToken} currentEmail={status.authorEmail} onMembershipChange={refresh} />}</> : status?.passwordConfigured && status.storageReady ? <section className="panel admin-login-panel"><h2>Sign in to your account</h2><PasswordSignIn onSignedIn={refresh} /></section> : <section className="panel admin-login-panel"><h2>Password sign-in is not available yet</h2><p>The administrator sign-in configuration is not ready. The public training module does not require sign-in.</p><button className="quiet-button" disabled>Password sign-in unavailable</button></section>}</main><footer className="training-footer"><span>Price Action Center</span><a href="/market-direction">Market Direction Simulator</a></footer></div>;
}
