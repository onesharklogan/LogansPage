'use client';
import LoadingIndicator from './loading-indicator';
import {useEffect, useRef, useState} from 'react';
import {LessonCover} from './lesson-cover';
import {parseLessonList, type WorkspaceLesson} from './teacher-workspace-api';
import styles from './home-gallery.module.css';

const lessonHref = (lesson: WorkspaceLesson) => '/library?' + new URLSearchParams({
  [lesson.kind === 'sequence' ? 'sequenceId' : 'folderId']: lesson.key.slice(lesson.key.indexOf(':') + 1),
});

/** Same published, read-only Lesson projection as /library; no author data or mutations. */
export default function HomeLessons() {
  const [lessons, setLessons] = useState<WorkspaceLesson[]>([]);
  const [cursor, setCursor] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const request = useRef<AbortController | null>(null);
  const generation = useRef(0);
  const live = useRef(false);
  const rows = useRef<WorkspaceLesson[]>([]);
  const more = useRef<string | null>(null);

  async function load(next: string | null = null) {
    if (!live.current || next !== null && (request.current !== null || next !== more.current)) return;
    request.current?.abort();
    const controller = new AbortController(), current = ++generation.current;
    request.current = controller;
    setLoading(true); setError('');
    const valid = () => live.current && !controller.signal.aborted && current === generation.current;
    try {
      const response = await fetch('/api/public/workspace/lessons' + (next ? '?cursor=' + encodeURIComponent(next) : ''), {
        method: 'GET', credentials: 'omit', cache: 'no-store', signal: controller.signal,
      });
      if (!response.ok) throw Error('Lessons could not be loaded. Please try again.');
      const page = parseLessonList(await response.json());
      if (!valid()) return;
      if (page.items.some(item => item.trashed || next && rows.current.some(old => old.key === item.key))) {
        throw Error('The published Lesson list changed. Refresh Lessons to continue.');
      }
      rows.current = next ? [...rows.current, ...page.items] : page.items;
      more.current = page.nextCursor;
      setLessons(rows.current); setCursor(page.nextCursor);
    } catch (failure) {
      if (valid()) setError((failure as Error).message);
    } finally {
      if (valid()) { request.current = null; setLoading(false); }
    }
  }

  useEffect(() => {
    live.current = true;
    void load();
    return () => { live.current = false; generation.current++; request.current?.abort(); request.current = null; };
  }, []);

  return <section className={styles.lessons} aria-labelledby="home-lessons-title">
    <div className={styles.lessonHeading}><div><p className="eyebrow">LEARN AT YOUR PACE</p><h2 id="home-lessons-title">Lessons</h2></div><a href="/library">Browse all Lessons <svg viewBox="0 0 20 20" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true" focusable="false"><path d="M5 15 15 5M5 5h10v10" strokeLinecap="round" strokeLinejoin="round"/></svg></a></div>
    {lessons.length > 0 && <><p id="home-lessons-hint" className={styles.scrollHint}>Choose a Lesson. Scroll sideways to explore, or use the arrow keys when the gallery is focused.</p><div className={styles.lessonScroller} role="region" aria-labelledby="home-lessons-title" aria-describedby="home-lessons-hint" tabIndex={0}><ul className={styles.lessonRow}>{lessons.map(lesson => <li key={lesson.key}><a className={styles.lessonCard} href={lessonHref(lesson)}><LessonCover value={lesson.coverArtwork}/><div><h3>{lesson.title}</h3><p>{lesson.slideCount} {lesson.slideCount === 1 ? 'Slide' : 'Slides'}</p><span>Open Lesson <svg viewBox="0 0 20 20" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true" focusable="false"><path d="M5 15 15 5M5 5h10v10" strokeLinecap="round" strokeLinejoin="round"/></svg></span></div></a></li>)}</ul></div></>}
    {loading && <p className={styles.message} role="status"><LoadingIndicator label="Loading Lessons…" /></p>}
    {error && <div className={styles.message}><p role="alert">{error}</p><button disabled={loading} onClick={() => void load()}>Refresh Lessons</button></div>}
    {!loading && !error && !lessons.length && <p className={styles.message}>No published Lessons yet. Check back soon.</p>}
    {cursor && !error && <button className={styles.loadMore} disabled={loading} onClick={() => void load(cursor)}>Load more Lessons</button>}
  </section>;
}
