'use client';
import LoadingIndicator from './loading-indicator';
import {useEffect,useRef,useState} from 'react';
import {learnerClient,safeGoogleAvatarUrl} from '../lib/learner/client.mjs';
import {createAccountTradeAdapter} from '../lib/learner/trade-adapter.mjs';
import LearnerAccountControl from './learner-account-control';
import TradeSimulator from './trade-simulator';
import type {SimulatorProfileAccess} from './simulator-profile-gate';

function OwnedTrade({capture,profile,headerReady,avatarUrl,panelOpen,suspend,navigation}:{capture:any;profile:{key:string;name:string;learnerId:string};headerReady:boolean;avatarUrl:string|null;panelOpen:React.RefObject<boolean>;suspend:React.RefObject<(()=>void)|null>;navigation:React.RefObject<(()=>boolean)|null>}){
 const [store]=useState(()=>createAccountTradeAdapter({client:learnerClient,capture,profile,replayId:typeof window==='undefined'?null:new URLSearchParams(window.location.search).get('replay')})),[ready,setReady]=useState(false),[error,setError]=useState(''),[retry,setRetry]=useState(0);
 const mounted=useRef(false);
 useEffect(()=>{mounted.current=true;const controller=new AbortController();setError('');void Promise.resolve().then(()=>{if(!controller.signal.aborted)return store.loadRemote({signal:controller.signal});}).then(()=>{if(!controller.signal.aborted)setReady(true);}).catch((error:Error)=>{if(!controller.signal.aborted)setError(error.message);});return()=>{mounted.current=false;controller.abort();};},[store,retry]);
 const access:SimulatorProfileAccess={profile,mode:capture.mode,accountHeader:{ready:headerReady,avatarUrl:headerReady&&capture.mode==='account'?safeGoogleAvatarUrl(avatarUrl):null,isCurrent:()=>mounted.current&&learnerClient.guard(capture)},store,guard:()=>mounted.current&&ready&&!panelOpen.current&&learnerClient.guard(capture),choose:()=>learnerClient.requestPanel(),registerSuspend:fn=>{suspend.current=fn;},registerNavigationGuard:fn=>{navigation.current=fn;}};
 if(!ready)return <main className="training-main"><p role="status">{error||<LoadingIndicator label="Loading your account history…" />}</p>{error&&<button className="quiet-button" onClick={()=>setRetry(v=>v+1)}>Retry account history</button>}</main>;
 return <TradeSimulator profileAccess={access}/>;
}
/** Online mode is only mounted by the server readiness gate. Local mode never enters here. */
export default function AccountTradeSimulator(){
 const [snapshot,setSnapshot]=useState(learnerClient.getSnapshot),panelOpen=useRef(false),suspend=useRef<(()=>void)|null>(null),navigation=useRef<(()=>boolean)|null>(null),owner=useRef<{capture:any;profile:{key:string;name:string;learnerId:string}}|null>(null);
 useEffect(()=>{const unsubscribe=learnerClient.subscribe((next:ReturnType<typeof learnerClient.getSnapshot>)=>{if(!learnerClient.guard(learnerClient.captureContext()))suspend.current?.();setSnapshot(next);});void learnerClient.refresh();return()=>{unsubscribe();};},[]);
 const capture=learnerClient.captureContext(),profile=snapshot.profile?{key:'account:'+snapshot.profile.id,name:snapshot.profile.name,learnerId:snapshot.profile.id}:{key:'guest',name:'Guest',learnerId:'00000000-0000-4000-8000-000000000001'};
 if(capture&&snapshot.authConfigured)owner.current={capture,profile};if(owner.current&&!learnerClient.ownsCapture(owner.current.capture))owner.current=null;
 const verified=!!capture&&snapshot.authConfigured,verifying=!verified&&!snapshot.signOutNeeded&&(snapshot.revalidating||!snapshot.ready&&!snapshot.reconcileRequired&&!snapshot.error&&!snapshot.busy);
 return <><LearnerAccountControl hideTrigger={verified||verifying} onOpenChange={open=>{panelOpen.current=open;if(open)suspend.current?.();else setTimeout(()=>document.querySelector<HTMLButtonElement>('[data-learner-profile-control]')?.focus(),0);}} onBeforeNavigate={()=>navigation.current?.()!==false}/>{owner.current&&<div hidden={!verified} inert={!verified} style={!verified?{display:'none'}:undefined}><OwnedTrade key={owner.current.capture.epoch} capture={owner.current.capture} profile={owner.current.profile} headerReady={verified} avatarUrl={verified?snapshot.avatarUrl:null} panelOpen={panelOpen} suspend={suspend} navigation={navigation}/></div>}{!verified&&<main className="training-main"><p role="status">{verifying?<LoadingIndicator label="Verifying profile…" />:snapshot.error||(snapshot.busy?<LoadingIndicator label={snapshot.busy} />:'Profile verification is unavailable. Retry to continue.')}</p>{!verifying&&<button className="quiet-button" disabled={snapshot.revalidating} onClick={()=>void learnerClient.revalidate()}>Retry account check</button>}</main>}</>;
}
