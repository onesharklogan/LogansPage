'use client';

import {useEffect,useMemo,useRef,useState} from 'react';
import AppHeader from './app-navigation';
import {loadSimulatorCatalog,loadSimulatorChart} from './trade-simulator-data.mjs';
import {DAY_TYPE_FILTERS,DAY_TYPE_CATALOG,DAY_TYPES,dayTypeLabel,matchesDayType} from '../lib/day-types.mjs';
import {dayTypeChartGeometry,validateDayTypeChart} from '../lib/day-type-search-view.mjs';
import styles from './day-type-search.module.css';

type Bar={t:string;o:number;h:number;l:number;c:number};
type Chart={id:string;current:Bar[]};
type Day={id:string;date:string;sourceSha256:string;primaryType:string;tags:string[];rationale:string[];boxes:{startBar:number;endBar:number;low:number;high:number;label:string;kind:string}[]};
const days=DAY_TYPES as Day[];
const PAGE_SIZE=24;
const boxColors=['#f0c57b','#8ad6c0','#9ec9ff','#e5a9d2'];

/** Full-session study only: never creates an attempt or writes account, profile or lesson state. */
export default function DayTypeSearch(){
  const [filter,setFilter]=useState('all'),[query,setQuery]=useState(''),[page,setPage]=useState(0),[selectedId,setSelectedId]=useState(''),[boxes,setBoxes]=useState(true),[retry,setRetry]=useState(0);
  const [loaded,setLoaded]=useState<{id:string;chart:Chart|null;error:string}>({id:'',chart:null,error:''});
  const generation=useRef(0),chartHeading=useRef<HTMLHeadingElement>(null);
  const filtered=useMemo(()=>days.filter(day=>matchesDayType(day.date,filter)&&day.date.includes(query.trim())).sort((a,b)=>b.date.localeCompare(a.date)),[filter,query]);
  const counts=useMemo(()=>Object.fromEntries(DAY_TYPE_FILTERS.map(({id}:{id:string})=>[id,days.filter(day=>matchesDayType(day.date,id)).length])),[]);
  const selected=filtered.find(day=>day.id===selectedId)||null;
  const pages=Math.max(1,Math.ceil(filtered.length/PAGE_SIZE)),currentPage=Math.min(page,pages-1),visible=filtered.slice(currentPage*PAGE_SIZE,(currentPage+1)*PAGE_SIZE);
  const chart=selected&&loaded.id===selected.id?loaded.chart:null,error=selected&&loaded.id===selected.id?loaded.error:'';
  const geometry=useMemo(()=>chart?dayTypeChartGeometry(chart.current):null,[chart]);
  useEffect(()=>{if(selected)chartHeading.current?.focus()},[selected?.id]);
  useEffect(()=>{
    if(!selected)return;
    const id=selected.id,epoch=++generation.current,controller=new AbortController();
    setLoaded({id,chart:null,error:''});
    const timeout=setTimeout(()=>{controller.abort();if(generation.current===epoch)setLoaded({id,chart:null,error:'Chart loading timed out. Please retry.'})},12000);
    (async()=>{try{
      const catalog=await loadSimulatorCatalog({signal:controller.signal}),reference=catalog.find((entry:{id:string})=>entry.id===id);
      if(!reference)throw Error('The chart is no longer in the source catalog.');
      const data=validateDayTypeChart(await loadSimulatorChart(reference,{signal:controller.signal}),selected,reference);
      if(!controller.signal.aborted&&generation.current===epoch)setLoaded({id,chart:data,error:''});
    }catch{if(!controller.signal.aborted&&generation.current===epoch)setLoaded({id,chart:null,error:'This chart could not be verified against its classification. Retry, or choose another day.'})}finally{clearTimeout(timeout)}})();
    return()=>{generation.current++;controller.abort();clearTimeout(timeout)};
  },[selected?.id,retry]);
  function changeFilter(value:string){setFilter(value);setPage(0);setSelectedId('')}
  return <div className={styles.root}><AppHeader section="DAY TYPE SEARCH" current="/day-type-search"/><main className={styles.main}>
    <header className={styles.intro}><p className={styles.eyebrow}>HISTORICAL CHART STUDY</p><h1>Day Type Search</h1><p>Find examples across all {days.length} chart days. Open a day to see its complete price chart, structure boxes and classification rationale.</p></header>
    <aside className={styles.notice}><strong>Full-day hindsight, not a forecast.</strong> Labels and boxes are rule-based study suggestions, not expert-verified answers. Mixed / unclear is a valid result. This page intentionally reveals the entire session; it does not start or change practice.</aside>
    <section className={styles.panel} aria-label="Find chart days"><h2>Choose a day type</h2><div className={styles.filters}>{DAY_TYPE_FILTERS.filter(({id}:{id:string})=>id!=='unknown').map(({id,label}:{id:string;label:string})=><button type="button" key={id} aria-pressed={filter===id} onClick={()=>changeFilter(id)}>{label} <span>{counts[id]}</span></button>)}</div><p className={styles.note}>Primary day types are exclusive. Upper / lower ranges is a structural tag within trending trading ranges, so those filter counts overlap.</p><label className={styles.search}>Find a date <input type="search" placeholder="YYYY-MM-DD or YYYY-MM" value={query} onChange={event=>{setQuery(event.target.value);setPage(0);setSelectedId('')}} autoComplete="off"/></label>
      <p role="status">{filtered.length} matching {filtered.length===1?'day':'days'}</p>
      <div className={styles.days}>{visible.map(day=><button type="button" key={day.id} className={styles.day} aria-pressed={selected?.id===day.id} onClick={()=>setSelectedId(day.id)}><strong>{day.date}</strong><span>{dayTypeLabel(day.date)}</span>{day.tags.includes('upper-lower-ranges')&&<small>Upper / lower ranges</small>}<small>View full chart →</small></button>)}</div>
      {!filtered.length&&<p>No days match. Try another type or clear the date search.</p>}
      {pages>1&&<nav className={styles.pagination} aria-label="Chart day pages"><button type="button" disabled={currentPage===0} onClick={()=>setPage(p=>Math.max(0,p-1))}>Previous</button><span>Page {currentPage+1} of {pages}</span><button type="button" disabled={currentPage===pages-1} onClick={()=>setPage(p=>Math.min(pages-1,p+1))}>Next</button></nav>}
    </section>
    {selected?<section className={styles.panel} aria-label="Selected day chart"><div className={styles.chartHeading}><div><p className={styles.eyebrow}>FULL-SESSION STUDY · MES · 5 MIN</p><h2 ref={chartHeading} tabIndex={-1}>{selected.date} · {dayTypeLabel(selected.date)}</h2></div><button type="button" onClick={()=>setSelectedId('')}>Close chart</button></div><p className={styles.note}>81 bars · Chicago time · first bar opens 08:30, last bar opens 15:10 and ends 15:15.</p>
      {error?<div role="alert"><p>{error}</p><button type="button" onClick={()=>setRetry(value=>value+1)}>Retry chart</button></div>:!chart?<p role="status">Loading and verifying chart…</p>:geometry&&<><div className={styles.chartActions}><button type="button" aria-pressed={boxes} onClick={()=>setBoxes(value=>!value)}>{boxes?'Hide boxes':'Show boxes'}</button><span>Scroll the chart horizontally on smaller screens.</span></div><div className={styles.chartScroll} tabIndex={0} role="region" aria-label={`${selected.date} full price chart; scroll horizontally to inspect all 81 bars`}><svg viewBox={`0 0 ${geometry.width} ${geometry.height}`} role="img" aria-label={`Full-session candlestick chart for ${selected.date}. ${selected.boxes.length} annotated structural regions.`}><rect width={geometry.width} height={geometry.height} fill="#0b1824"/>{geometry.ticks.map((price:number)=><g key={price}><line x1={geometry.left} x2={geometry.width-geometry.right} y1={geometry.y(price)} y2={geometry.y(price)} stroke="#263a4d"/><text x={geometry.width-geometry.right+8} y={geometry.y(price)+4} fill="#b9cbda" fontSize="12">{price.toFixed(2)}</text></g>)}
        {boxes&&selected.boxes.map((box,index)=><rect key={index} x={geometry.x(box.startBar-1)-geometry.step*.48} y={geometry.y(box.high)} width={(box.endBar-box.startBar+1)*geometry.step-geometry.step*.04} height={Math.max(1,geometry.y(box.low)-geometry.y(box.high))} fill={boxColors[index%boxColors.length]} fillOpacity=".07" stroke={boxColors[index%boxColors.length]} strokeWidth="1.5"><title>{`${index+1}. ${box.label}: bars ${box.startBar}–${box.endBar}, ${box.low.toFixed(2)}–${box.high.toFixed(2)}`}</title></rect>)}
        {chart.current.map((bar,index)=>{const x=geometry.x(index),up=bar.c>=bar.o,color=up?'#87cdb4':'#e39a9b';return <g key={bar.t}><title>{`Bar ${index+1} · ${bar.t} · O ${bar.o} H ${bar.h} L ${bar.l} C ${bar.c}`}</title><line x1={x} x2={x} y1={geometry.y(bar.h)} y2={geometry.y(bar.l)} stroke={color}/><rect x={x-geometry.step*.29} y={geometry.y(Math.max(bar.o,bar.c))} width={geometry.step*.58} height={Math.max(1,Math.abs(geometry.y(bar.o)-geometry.y(bar.c)))} fill={up?'#0b1824':color} stroke={color}/>{(index===0||(index+1)%10===0||index===80)&&<text x={x} y={geometry.height-17} textAnchor="middle" fill="#b9cbda" fontSize="11">{index+1}</text>}</g>})}
        {boxes&&selected.boxes.map((box,index)=><g key={`label-${index}`}><rect x={geometry.x(box.startBar-1)-3} y={geometry.y(box.high)-14} width="17" height="15" rx="3" fill={boxColors[index%boxColors.length]}/><text x={geometry.x(box.startBar-1)+5.5} y={geometry.y(box.high)-3} textAnchor="middle" fill="#10202f" fontSize="11" fontWeight="bold">{index+1}</text></g>)}<text x="18" y="440" fill="#b9cbda" fontSize="11">Bar number</text></svg></div>
      <h3>Why this label?</h3><ul>{selected.rationale.map((reason,index)=><li key={index}>{reason}</li>)}</ul><h3>Structure boxes</h3>{selected.boxes.length?<ol className={styles.legend}>{selected.boxes.map((box,index)=><li key={index}><span style={{color:boxColors[index%boxColors.length]}}>{box.label}</span> · bars {box.startBar}–{box.endBar} · {box.low.toFixed(2)}–{box.high.toFixed(2)}</li>)}</ol>:<p>No sufficiently clear structure was boxed.</p>}</>}
      <p className={styles.note}>Classification version: {DAY_TYPE_CATALOG.algorithmVersion}. The label describes this full chart, not what was knowable at an earlier bar.</p>
    </section>:<p className={styles.empty}>Choose a day above to inspect its full chart and boxes.</p>}
    <details className={styles.panel}><summary>How to use these labels</summary><p>Use these examples as starting points for study. Trend labels require directional structure, not just a green or red close. Trading ranges show two-sided movement; trending trading ranges connect multiple ranges through breakouts. Reversal days change direction; mixed / unclear days do not fit a strong pattern.</p><p>Upper / lower ranges is a secondary structural tag, not an additional exclusive day type. The same day can appear in that filter and Trending trading range. Labels are deterministic heuristic judgments, not accuracy claims or trading advice.</p><p>The same versioned date labels are available for completed trading-history review. Repeated attempts are not independent days, and small samples cannot establish a durable strength or weakness.</p></details>
  </main></div>;
}
