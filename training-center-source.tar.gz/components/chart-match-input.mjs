/** Local image decode only. Never sends the supplied bytes to a server. */
export async function readLocalChartImage(file,{signal}={}){
  if(!file||!['image/png','image/jpeg','image/webp'].includes(file.type)||!Number.isFinite(file.size)||file.size<1||file.size>20*1024*1024)throw Error('Choose a PNG, JPEG or WebP screenshot up to 20 MB.');
  const aborted=()=>{if(signal?.aborted)throw new DOMException('Image loading canceled.','AbortError');};aborted();
  const url=URL.createObjectURL(file);let bitmap=null;
  try{
    if(typeof createImageBitmap==='function')bitmap=await createImageBitmap(file);
    else bitmap=await new Promise((resolve,reject)=>{const image=new Image();image.onload=()=>resolve(image);image.onerror=()=>reject(Error('This image could not be decoded.'));image.src=url;});
    aborted();const width=bitmap.width,height=bitmap.height;
    if(!Number.isInteger(width)||!Number.isInteger(height)||width<240||height<160||width*height>12000000||width>8000||height>8000)throw Error('Use a clear screenshot between 240 × 160 and 12 million pixels, with neither side over 8,000 pixels.');
    const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;const context=canvas.getContext('2d',{willReadFrequently:true});if(!context)throw Error('Local image reading is unavailable in this browser.');context.drawImage(bitmap,0,0);const pixels=context.getImageData(0,0,width,height);aborted();
    bitmap.close?.();bitmap=null;let disposed=false;return{width,height,data:pixels.data,url,dispose(){if(!disposed){disposed=true;URL.revokeObjectURL(url);}}};
  }catch(error){bitmap?.close?.();URL.revokeObjectURL(url);throw error;}
}
/** CSS-scaled pointer coordinates map to the actual bitmap, with no assumed display size. */
export function imagePoint(clientX,clientY,rect,width,height){
  if(![clientX,clientY,rect?.left,rect?.top,rect?.width,rect?.height,width,height].every(Number.isFinite)||rect.width<=0||rect.height<=0||width<=0||height<=0)return null;
  if(clientX<rect.left||clientY<rect.top||clientX>=rect.left+rect.width||clientY>=rect.top+rect.height)return null;
  const x=(clientX-rect.left)*width/rect.width,y=(clientY-rect.top)*height/rect.height;
  return x<0||y<0||x>=width||y>=height?null:{x:Math.min(width-1,Math.round(x)),y:Math.min(height-1,Math.round(y))};
}
