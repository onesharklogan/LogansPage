'use client';
import {useEffect,useState} from 'react';
import AppHeader from './app-navigation';
import {readLocalHistory} from '../lib/learner/local-history-reader.mjs';
export default function LearnerLocalHistory(){
 const [rows,setRows]=useState<ReturnType<typeof readLocalHistory>>([]),[error,setError]=useState(''),[ready,setReady]=useState(false);
 function refresh(){try{setRows(readLocalHistory(window.localStorage));setError('');}catch(error){setRows([]);setError(error instanceof Error?error.message:'Browser-local history is unavailable.');}setReady(true);}
 useEffect(()=>{refresh();window.addEventListener('storage',refresh);return()=>window.removeEventListener('storage',refresh);},[]);
 return <><AppHeader section="BROWSER-LOCAL HISTORY" current="/learner/local-history"/><main className="training-main"><h1>Older browser-local history</h1><p>Read-only. These profiles belong to this browser, not your Google account. Nothing is uploaded, migrated, selected, reset or deleted here.</p>{!ready&&<p role="status">Reading local history…</p>}{error&&<p role="alert">{error}</p>}<button className="quiet-button" onClick={refresh}>Refresh read-only history</button>{ready&&!error&&!rows.length&&<p>No older profiles were found in this browser.</p>}{rows.map(({profile,direction,trade}:any)=><section key={profile.key} style={{marginTop:24}}><h2>{profile.name}</h2><h3>Market Direction · first completed results</h3><ul>{direction.map((row:any,index:number)=><li key={index}>{row.session} · {row.points.toFixed(2)} points{row.completedAt?' · '+row.completedAt.slice(0,10):''}</li>)}</ul>{!direction.length&&<p>No recorded Market Direction results.</p>}<h3>Trade Simulator · completed attempts</h3><ul>{trade.map((row:any)=><li key={row.id}>{row.session} · {row.points.toFixed(2)} points{row.completedAt?' · '+row.completedAt.slice(0,10):''}</li>)}</ul>{!trade.length&&<p>No recorded Trade results.</p>}</section>)}</main></>;
}
