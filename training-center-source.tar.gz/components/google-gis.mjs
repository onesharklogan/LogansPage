const SCRIPT_URL = 'https://accounts.google.com/gsi/client';
let scriptPromise;

export function loadGoogleIdentity() {
  if (window.google?.accounts?.id) return Promise.resolve(window.google.accounts.id);
  if (scriptPromise) return scriptPromise;
  scriptPromise = new Promise((resolve, reject) => {
    const existing = document.querySelector('script[data-priceaction-google]');
    const script = existing || document.createElement('script');
    const cleanup = () => { clearTimeout(timeout); script.removeEventListener('load', loaded); script.removeEventListener('error', failed); };
    const loaded = () => { cleanup(); window.google?.accounts?.id ? resolve(window.google.accounts.id) : failed(); };
    const failed = () => { cleanup(); scriptPromise = undefined; if (script.dataset.priceactionGoogle === 'true') script.remove(); reject(new Error('Google sign-in could not load. Check your connection and try again.')); };
    const timeout = setTimeout(failed, 20000);
    script.addEventListener('load', loaded, { once: true }); script.addEventListener('error', failed, { once: true });
    if (!existing) { script.src = SCRIPT_URL; script.async = true; script.defer = true; script.dataset.priceactionGoogle = 'true'; document.head.appendChild(script); }
  });
  return scriptPromise;
}

function failureMessage(status) {
  if (status === 403) return 'This Google account is not approved for author access, or the sign-in check expired. Use an approved account and try again.';
  if (status === 400 || status === 401) return 'The Google sign-in check expired or was invalid. Please start again.';
  if (status === 429) return 'Too many sign-in attempts. Please wait before trying again.';
  return 'Google sign-in could not be confirmed. Refresh the page to check your access before trying again.';
}

/**
 * Mount one official GIS button with a server-issued nonce. JWTs stay transient in this callback.
 * @param {{clientId:string,element:any,onState:(stage:string,message?:string)=>void,onSuccess:()=>Promise<void>,fetcher?:typeof fetch,loadIdentity?:()=>Promise<any>}} options
 */
export function mountGoogleButton({ clientId, element, onState, onSuccess, fetcher = fetch, loadIdentity = loadGoogleIdentity }) {
  let active = true, verifying = false, attempted = false;
  const controller = new AbortController();
  const set = (stage, message = '') => { if (active) onState(stage, message); };
  set('loading');
  const ready = (async () => {
    try {
      if (typeof clientId !== 'string' || !clientId.endsWith('.apps.googleusercontent.com')) throw new Error('Google author sign-in is not configured yet.');
      const [identity, response] = await Promise.all([loadIdentity(), fetcher('/api/auth/csrf', { credentials: 'same-origin', cache: 'no-store', signal: controller.signal })]);
      const data = await response.json();
      if (!response.ok || typeof data.csrfToken !== 'string' || data.csrfToken.length < 16) throw new Error('Google author sign-in is temporarily unavailable. Please try again.');
      if (!active) return;
      identity.initialize({ client_id: clientId, nonce: data.csrfToken, auto_select: false, ux_mode: 'popup',
        callback: async result => {
          if (!active || verifying || attempted) return;
          if (typeof result?.credential !== 'string' || !result.credential) { set('error', 'Google did not return a sign-in credential. Please try again.'); return; }
          attempted = true; verifying = true; set('verifying');
          try {
            const login = await fetcher('/api/auth/google', { method: 'POST', credentials: 'same-origin', cache: 'no-store', signal: controller.signal, headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': data.csrfToken }, body: JSON.stringify({ credential: result.credential }) });
            if (!login.ok) throw new Error(failureMessage(login.status));
            if (!active) return;
            set('success');
            await onSuccess();
          } catch (error) { if (active) set('error', error instanceof Error ? error.message : 'Sign-in could not be confirmed. Refresh to check your access.'); }
          finally { verifying = false; }
        },
      });
      element.replaceChildren();
      identity.renderButton(element, { type: 'standard', theme: 'outline', size: 'large', text: 'signin_with', shape: 'rectangular', width: 260 });
      set('ready');
    } catch (error) { if (active) set('error', error instanceof Error ? error.message : 'Google sign-in is unavailable.'); }
  })();
  return { ready, dispose() { active = false; controller.abort(); element.replaceChildren(); } };
}
