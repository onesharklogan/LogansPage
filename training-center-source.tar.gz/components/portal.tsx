"use client";

import AppHeader, { CandleMark } from "./app-navigation";
import type {MouseEvent} from "react";
import TeacherWorkspace from "./teacher-workspace";

export type PortalStatus = { workspace?: {version:1;schemaVersion:6;visibilityVersion:1;ready:boolean;writeEnabled:boolean;permanentDeleteEnabled?:boolean;lessonCoversEnabled?:boolean}; setupComplete: boolean; passwordConfigured?: boolean; authorEmail?: string | null; authorRole?: "admin" | "author" | null; author: boolean; csrfToken: string | null; owner: boolean; setupAvailable: boolean; storageReady: boolean; publicReady?: boolean };
export type Folder = { id: string; name: string; revision: number; trashed?: boolean; slideCount?: number; activeSlideCount?: number; trashedSlideCount?: number; versionCount?: number; sequenceCount?:number; sequenceSlideCount?:number; sequenceVersionCount?:number };
export type Lesson = { id: string; folderId: string; title: string; purpose?: string; coverArtwork?: string; revision: number; pack?: { sha256: string; bytes: number; contentType?: string }; updatedAt?: string | number; versionId: string; manifestUrl?: string; packUrl?: string; trashed?: boolean | number; trashedAt?: string | number | null };
type Notice = { kind: "success" | "error" | "info"; text: string };
type DialogState = { kind: "delete-module"; folder: Folder } | { kind: "create" } | { kind: "rename"; folder: Folder } | { kind: "trash"; lesson: Lesson } | { kind: "review"; lesson: Lesson; sequence: Lesson[] } | null;

export class ApiError extends Error {
  constructor(message: string, public status: number, public code?: string) { super(message); }
}

export async function api<T>(path: string, init?: RequestInit): Promise<T> {
  let response: Response;
  try { response = await fetch(path, { ...init, cache: "no-store", credentials: "same-origin" }); }
  catch (error) { if (init?.signal?.aborted) throw error; throw new ApiError(init?.method ? "The server could not be reached. The change may or may not have saved; refresh the Lessons before trying again." : "The Lessons could not be reached. Check your connection and try Refresh.", 0); }
  const parsed: unknown = await response.json().catch(() => ({}));
  const data = parsed && typeof parsed === "object" ? parsed as Record<string, unknown> : {};
  if (!response.ok) {
    const fallback = response.status === 409 ? "Someone changed this item. Refresh the Lessons and review the newest revision before trying again." : response.status === 401 ? "Your author session has ended. Sign in again to make changes." : response.status === 429 ? "Too many attempts. Please wait before trying again." : "The request could not be completed.";
    throw new ApiError(init?.method && response.status >= 500 ? "The server response could not confirm whether this change saved. Refresh the Lessons before trying again." : response.status === 409 ? fallback : typeof data.error === "string" ? data.error : fallback, response.status, typeof data.code === "string" ? data.code : undefined);
  }
  return data as T;
}

export function safeAssetUrl(value: string | undefined): string | undefined {
  if (!value || typeof window === "undefined") return undefined;
  try { const url = new URL(value, window.location.origin); return url.origin === window.location.origin && /^\/api\/(public|author)\/lessons\//.test(url.pathname) ? url.pathname + url.search : undefined; }
  catch { return undefined; }
}

function dateLabel(value?: string | number) {
  if (!value) return "Just saved";
  const date = new Date(typeof value === "number" && value < 1e12 ? value * 1000 : value);
  return Number.isNaN(date.getTime()) ? "Saved online" : date.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
}
function isTrashed(lesson: Lesson) { return Boolean(lesson.trashed || lesson.trashedAt); }
export function studioHref(folderId = "", lessonId = "") {
  const params = new URLSearchParams(); if (folderId) params.set("folderId", folderId); if (lessonId) params.set("lessonId", lessonId);
  return `/studio${params.size ? `?${params}` : ""}`;
}

export function Icon({ name }: { name: "folder" | "upload" | "arrow" | "lock" | "slide" | "check" | "trash" | "refresh" | "plus" }) {
  const paths = { folder: <path d="M3 7a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v10H3Z" />, upload: <path d="M12 16V3m-5 5 5-5 5 5M4 15v6h16v-6" />, arrow: <path d="m9 5-7 7 7 7M2 12h20" />, lock: <><rect x="5" y="10" width="14" height="11" rx="2" /><path d="M8 10V7a4 4 0 0 1 8 0v3m-4 5v2" /></>, slide: <><rect x="3" y="4" width="18" height="15" rx="2" /><path d="m6 15 4-4 4 2 4-6M9 22h6" /></>, check: <path d="m5 12 4 4L19 6" />, trash: <path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7m4-7v7" />, refresh: <path d="M20 8a8 8 0 1 0 0 8M20 3v5h-5" />, plus: <path d="M12 5v14M5 12h14" /> };
  return <svg className="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>;
}

export function Brand({ onClick }: { onClick?: (event: MouseEvent<HTMLAnchorElement>) => void } = {}) { return <a className="app-brand" href="/" onClick={onClick} aria-label="Home" title="Home"><CandleMark /><span className="app-brand-text"><strong>Price Action Center</strong><small>TEACHER STUDIO</small></span></a>; }

export default function Portal(){return <TeacherWorkspace current="/admin/modules"/>;}
