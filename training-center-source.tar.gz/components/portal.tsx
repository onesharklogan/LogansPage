"use client";

import AppHeader, { CandleMark } from "./app-navigation";
import SavedLessonReview from "./lesson-review";
import SequenceShelf from "./lesson-sequence-shelf";
import SequenceAuthor from "./lesson-sequence-author";
import LessonModel from "../lib/portal/lesson-model.cjs";
import { useCallback, useEffect, useRef, useState, type FormEvent, type ReactNode, type MouseEvent } from "react";

export type PortalStatus = { setupComplete: boolean; passwordConfigured?: boolean; authorEmail?: string | null; authorRole?: "admin" | "author" | null; author: boolean; csrfToken: string | null; owner: boolean; setupAvailable: boolean; storageReady: boolean; publicReady?: boolean };
export type Folder = { id: string; name: string; revision: number; trashed?: boolean; slideCount?: number; activeSlideCount?: number; trashedSlideCount?: number; versionCount?: number; sequenceCount?:number; sequenceSlideCount?:number; sequenceVersionCount?:number };
export type Lesson = { id: string; folderId: string; title: string; purpose?: string; coverArtwork?: string; revision: number; pack?: { sha256: string; bytes: number; contentType?: string }; updatedAt?: string | number; versionId: string; manifestUrl?: string; packUrl?: string; trashed?: boolean | number; trashedAt?: string | number | null };
type Notice = { kind: "success" | "error" | "info"; text: string };
type DialogState = { kind: "delete-module"; folder: Folder } | { kind: "create" } | { kind: "rename"; folder: Folder } | { kind: "trash"; lesson: Lesson } | { kind: "review"; lesson: Lesson; sequence: Lesson[] } | null;

export class ApiError extends Error {
  constructor(message: string, public status: number, public code?: string) { super(message); }
}

export async function api<T>(path: string, init?: RequestInit): Promise<T> {
  let response: Response;
  try { response = await fetch(path, { ...init, cache: "no-store", credentials: "same-origin" }); }
  catch (error) { if (init?.signal?.aborted) throw error; throw new ApiError(init?.method ? "The server could not be reached. The change may or may not have saved; refresh the Lessons before trying again." : "The Lessons could not be reached. Check your connection and try Refresh.", 0); }
  const parsed: unknown = await response.json().catch(() => ({}));
  const data = parsed && typeof parsed === "object" ? parsed as Record<string, unknown> : {};
  if (!response.ok) {
    const fallback = response.status === 409 ? "Someone changed this item. Refresh the Lessons and review the newest revision before trying again." : response.status === 401 ? "Your author session has ended. Sign in again to make changes." : response.status === 429 ? "Too many attempts. Please wait before trying again." : "The request could not be completed.";
    throw new ApiError(init?.method && response.status >= 500 ? "The server response could not confirm whether this change saved. Refresh the Lessons before trying again." : response.status === 409 ? fallback : typeof data.error === "string" ? data.error : fallback, response.status, typeof data.code === "string" ? data.code : undefined);
  }
  return data as T;
}

export function safeAssetUrl(value: string | undefined): string | undefined {
  if (!value || typeof window === "undefined") return undefined;
  try { const url = new URL(value, window.location.origin); return url.origin === window.location.origin && /^\/api\/(public|author)\/lessons\//.test(url.pathname) ? url.pathname + url.search : undefined; }
  catch { return undefined; }
}

function dateLabel(value?: string | number) {
  if (!value) return "Just saved";
  const date = new Date(typeof value === "number" && value < 1e12 ? value * 1000 : value);
  return Number.isNaN(date.getTime()) ? "Saved online" : date.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
}
function isTrashed(lesson: Lesson) { return Boolean(lesson.trashed || lesson.trashedAt); }
export function studioHref(folderId = "", lessonId = "") {
  const params = new URLSearchParams(); if (folderId) params.set("folderId", folderId); if (lessonId) params.set("lessonId", lessonId);
  return `/studio${params.size ? `?${params}` : ""}`;
}

export function Icon({ name }: { name: "folder" | "upload" | "arrow" | "lock" | "slide" | "check" | "trash" | "refresh" | "plus" }) {
  const paths = { folder: <path d="M3 7a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v10H3Z" />, upload: <path d="M12 16V3m-5 5 5-5 5 5M4 15v6h16v-6" />, arrow: <path d="m9 5-7 7 7 7M2 12h20" />, lock: <><rect x="5" y="10" width="14" height="11" rx="2" /><path d="M8 10V7a4 4 0 0 1 8 0v3m-4 5v2" /></>, slide: <><rect x="3" y="4" width="18" height="15" rx="2" /><path d="m6 15 4-4 4 2 4-6M9 22h6" /></>, check: <path d="m5 12 4 4L19 6" />, trash: <path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7m4-7v7" />, refresh: <path d="M20 8a8 8 0 1 0 0 8M20 3v5h-5" />, plus: <path d="M12 5v14M5 12h14" /> };
  return <svg className="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>;
}

export function Brand({ onClick }: { onClick?: (event: MouseEvent<HTMLAnchorElement>) => void } = {}) { return <a className="app-brand" href="/" onClick={onClick} aria-label="Home" title="Home"><CandleMark /><span className="app-brand-text"><strong>Price Action Center</strong><small>TEACHER STUDIO</small></span></a>; }

function Modal({ title, children, onClose, lesson = false, contentKey }: { title: string; children: ReactNode; onClose: () => void; lesson?: boolean; contentKey?: string }) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => { const dialog = ref.current; dialog?.showModal(); return () => { dialog?.close(); }; }, []);
  useEffect(() => { ref.current?.querySelector<HTMLElement>('.lesson-modal-body')?.scrollTo({ top: 0, left: 0 }); }, [contentKey]);
  return <dialog ref={ref} className={lesson ? "modal lesson-modal" : "modal"} onCancel={event => { event.preventDefault(); onClose(); }} aria-labelledby="modal-title"><div className="modal-head"><h2 id="modal-title">{title}</h2><button className="icon-button" onClick={onClose} aria-label="Close dialog">×</button></div>{lesson ? <div className="lesson-modal-body">{children}</div> : children}</dialog>;
}

export default function Portal() {
  const [status, setStatus] = useState<PortalStatus | null>(null);
  const [folders, setFolders] = useState<Folder[]>([]);
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [folderId, setFolderIdState] = useState("");
  const [search, setSearch] = useState("");
  const [trashView, setTrashViewState] = useState(false);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<Notice | null>(null);
  const [lastLoaded, setLastLoaded] = useState<Date | null>(null);
  const [loginOpen, setLoginOpen] = useState(false);
  const [uploadFolder, setUploadFolder] = useState("");
  const [pack, setPack] = useState<File | null>(null);
  const [fileKey, setFileKey] = useState(0);
  const [dragging, setDragging] = useState(false);
  const [dialog, setDialogState] = useState<DialogState>(null);
  const [folderName, setFolderName] = useState("");
  const [moduleTrashView, setModuleTrashView] = useState(false);
  const moduleTrashCurrent = useRef(false), moduleMutating = useRef(false), moduleAction = useRef<Folder | null>(null);
  moduleTrashCurrent.current = moduleTrashView;
  const loadGeneration = useRef(0);
  const importAttempt = useRef<{ pack: File; folderId: string; requestId: string; body: string } | null>(null);
  const [importUncertain, setImportUncertain] = useState(false);
  const importSubmitting = useRef(false);
  const mounted = useRef(false);
  const reviewGeneration = useRef(0);
  const reviewRequest = useRef<AbortController | null>(null);
  const cancelReview = useCallback(() => {
    reviewGeneration.current += 1;
    reviewRequest.current?.abort();
    reviewRequest.current = null;
  }, []);
  const setDialog = useCallback((next: DialogState) => { cancelReview(); moduleAction.current = next?.kind === "delete-module" ? next.folder : null; setDialogState(next); }, [cancelReview]);
  const setFolderId = useCallback((next: string) => {
    cancelReview(); setDialogState(current => current?.kind === "review" ? null : current); setFolderIdState(next);
  }, [cancelReview]);
  const setTrashView = useCallback((next: boolean) => {
    cancelReview(); setDialogState(current => current?.kind === "review" ? null : current); setTrashViewState(next);
  }, [cancelReview]);

  useEffect(() => {
    mounted.current = true;
    return () => { mounted.current = false; loadGeneration.current += 1; cancelReview(); };
  }, [cancelReview]);

  const reload = useCallback(async (nextTrash?: boolean, nextModuleTrash?: boolean) => {
    const generation = ++loadGeneration.current;
    const inTrash = nextTrash ?? trashView, inModuleTrash = nextModuleTrash ?? moduleTrashView;
    setLoading(true);
    try {
      const nextStatus = await api<PortalStatus>("/api/status");
      if (generation !== loadGeneration.current) return;
      setStatus(nextStatus);
      if (!nextStatus.author) { setTrashView(false); setModuleTrashView(false); setDialog(null); setLessons([]); setFolders([]); setLastLoaded(null); return; }
      const prefix = "/api/author";
      const [folderData, lessonData] = await Promise.all([
        api<{ folders: Folder[] }>(`${prefix}/folders${inModuleTrash ? "?trashed=true" : ""}`),
        inModuleTrash ? Promise.resolve({lessons:[] as Lesson[]}) : api<{ lessons: Lesson[] }>(`${prefix}/lessons${inTrash ? "?trashed=true" : ""}`),
      ]);
      if (generation !== loadGeneration.current) return;
      setFolders(folderData.folders || []); setLessons(lessonData.lessons || []); setLastLoaded(new Date());
    } catch (error) {
      if (mounted.current && generation === loadGeneration.current) throw error;
    } finally { if (mounted.current && generation === loadGeneration.current) setLoading(false); }
  }, [trashView, moduleTrashView, setTrashView, setDialog]);

  useEffect(() => { reload().catch(showError); }, [reload]);
  useEffect(() => { if (new URLSearchParams(window.location.search).get("signin") === "1") setLoginOpen(true); }, []);

  function showError(error: unknown) {
    setNotice({ kind: "error", text: error instanceof Error ? error.message : "The request could not be completed." });
    if (error instanceof ApiError && error.status === 401) { setFolders([]); setLessons([]); setDialog(null); setStatus(previous => previous ? { ...previous, author: false, csrfToken: null } : previous); setLoginOpen(true); }
  }
  function mutationHeaders(json = true) {
    if (!status?.author || !status.csrfToken) throw new ApiError("Sign in again before saving changes.", 401);
    return { "X-CSRF-Token": status.csrfToken, ...(json ? { "Content-Type": "application/json" } : {}) };
  }
  async function logout() {
    setBusy(true); setNotice(null);
    try {
      await api("/api/auth/logout", { method: "POST", headers: mutationHeaders(), body: "{}" });
      setTrashView(false); setDialog(null); await reload(false);
      setNotice({ kind: "info", text: "Signed out of author mode. Saved slides are unchanged." });
    } catch (error) { showError(error); }
    finally { setBusy(false); }
  }
  async function saveFolder(event: FormEvent) {
    event.preventDefault(); if (!dialog || !["create", "rename"].includes(dialog.kind)) return;
    setBusy(true); setNotice(null);
    try {
      const rename = dialog.kind === "rename" ? dialog.folder : null;
      await api(rename ? `/api/author/folders/${encodeURIComponent(rename.id)}` : "/api/author/folders", { method: rename ? "PATCH" : "POST", headers: mutationHeaders(), body: JSON.stringify({ name: folderName.trim(), ...(rename ? { expectedRevision: rename.revision } : {}) }) });
      setDialog(null); await reload(); setNotice({ kind: "success", text: rename ? "Lesson renamed online." : "Lesson created online. It is ready for slides." });
    } catch (error) { showError(error); }
    finally { setBusy(false); }
  }
  function selectFiles(files: FileList | File[]) {
    const selected = Array.from(files);
    if (selected.length !== 1 || !/\.json$/i.test(selected[0].name) || selected[0].size > 3 * 1024 * 1024) {
      setNotice({ kind: "error", text: "Choose one editable slide pack (.json, up to 3 MB). No image is needed or stored." }); return;
    }
    setPack(selected[0]);
  }
  async function upload(event: FormEvent) {
    event.preventDefault();
    if (importSubmitting.current) return;
    if (!pack || !uploadFolder) { setNotice({ kind: "error", text: "Choose a Lesson and one editable slide pack (.json)." }); return; }
    importSubmitting.current = true;
    let committed = false;
    setBusy(true); setNotice(null);
    try {
      if (!importAttempt.current || importAttempt.current.pack !== pack || importAttempt.current.folderId !== uploadFolder) {
        const requestId = crypto.randomUUID();
        importAttempt.current = { pack, folderId: uploadFolder, requestId, body: JSON.stringify({ pack: await pack.text(), folderId: uploadFolder, requestId }) };
      }
      await api("/api/author/lessons", { method: "POST", headers: mutationHeaders(), body: importAttempt.current.body });
      committed = true;
      setPack(null); setFileKey(key => key + 1); setTrashView(false); setFolderId(uploadFolder); importAttempt.current = null; setImportUncertain(false); await reload(false);
      setNotice({ kind: "success", text: "Imported and saved online. The Lessons has been reloaded from the server." });
    } catch (error) { if (!committed && error instanceof ApiError && (error.status === 0 || error.status >= 500)) setImportUncertain(true); showError(error); }
    finally { importSubmitting.current = false; setBusy(false); }
  }
  async function checkImportStatus() {
    if (!importAttempt.current) return;
    setBusy(true); setNotice(null);
    try {
      const result = await api<{ state: string; lesson?: Lesson }>(`/api/author/save-status?requestId=${encodeURIComponent(importAttempt.current.requestId)}`);
      if (result.state === "committed") {
        setPack(null); setFileKey(key => key + 1); importAttempt.current = null; setImportUncertain(false);
        await reload(); setNotice({ kind: "success", text: "The server confirms your import was saved. The Lessons has been refreshed." });
      } else setNotice({ kind: "info", text: "The import is still unconfirmed. This does not prove it failed. Keep this file unchanged and check again, or retry the same import." });
    } catch (error) {
      if (error instanceof ApiError && error.status === 404) setNotice({ kind: "info", text: "The import is still unconfirmed. It may still be saving. Keep this file unchanged and check again, or retry the same import." });
      else showError(error);
    } finally { setBusy(false); }
  }
  async function trashOrRestore(lesson: Lesson, restore: boolean) {
    setBusy(true); setNotice(null);
    try {
      await api(`/api/author/lessons/${encodeURIComponent(lesson.id)}/${restore ? "restore" : "trash"}`, { method: "POST", headers: mutationHeaders(), body: JSON.stringify({ expectedRevision: lesson.revision }) });
      setDialog(null); await reload(); setNotice({ kind: "success", text: restore ? "Slide restored to the Lessons." : "Slide moved to Trash and removed from public viewing. Authors can restore it." });
    } catch (error) { showError(error); }
    finally { setBusy(false); }
  }
  async function changeModuleTrash(folder: Folder, restore: boolean) {
    if (moduleMutating.current || loading || !mounted.current || !status?.author || !status.csrfToken) return;
    if (restore ? !moduleTrashCurrent.current : moduleAction.current?.id !== folder.id || moduleAction.current?.revision !== folder.revision) return;
    moduleMutating.current = true; setBusy(true); setNotice(null);
    try {
      await api(`/api/author/folders/${encodeURIComponent(folder.id)}/${restore ? "restore" : "trash"}`, { method: "POST", headers: mutationHeaders(), body: JSON.stringify({expectedRevision:folder.revision}) });
      if (!mounted.current) return;
      setDialog(null); setFolderId(""); await reload(false, restore ? true : false);
      setNotice({kind:"success",text:restore ? "Lesson restored. Slides already in Slide Trash stay there." : "Lesson moved to Lesson Trash. Its slides and versions are preserved and hidden from learners."});
    } catch(error) { if(mounted.current) showError(error); }
    finally { moduleMutating.current = false; if(mounted.current)setBusy(false); }
  }

  async function review(lesson: Lesson, sequence: Lesson[] = [lesson]) {
    cancelReview();
    const generation = reviewGeneration.current;
    const order = sequence.filter(item => !isTrashed(item)).map(item => ({ ...item }));
    const request = new AbortController();
    reviewRequest.current = request;
    setNotice(null);
    try {
      const url = safeAssetUrl(lesson.manifestUrl);
      const manifest = url ? await api<{ lesson?: Lesson } & Partial<Lesson>>(url, { signal: request.signal }) : {};
      if (!mounted.current || request.signal.aborted || generation !== reviewGeneration.current) return;
      setDialogState({ kind: "review", lesson: { ...lesson, ...(manifest.lesson || manifest) }, sequence: order });
    } catch (error) {
      if (mounted.current && !request.signal.aborted && generation === reviewGeneration.current) showError(error);
    } finally {
      if (generation === reviewGeneration.current) reviewRequest.current = null;
    }
  }

  const currentFolder = folders.find(folder => folder.id === folderId);
  const filtered = lessons.filter(lesson => (!folderId || lesson.folderId === folderId) && lesson.title.toLocaleLowerCase().includes(search.toLocaleLowerCase()) && (trashView || !isTrashed(lesson)));
  const reviewIndex = dialog?.kind === "review" ? dialog.sequence.findIndex(item => item.id === dialog.lesson.id) : -1;
  const followingLesson = dialog?.kind === "review" && reviewIndex >= 0 ? dialog.sequence[reviewIndex + 1] : undefined;
  const activeCount = lessons.filter(lesson => !isTrashed(lesson)).length;
  const locked = !status?.author || !status.storageReady;
  const passwordAvailable = !!status?.passwordConfigured && !!status.storageReady && !loading && !busy;

  if (!status?.author) return <div className="studio-shell"><AppHeader section="ADMIN" current="/admin/modules"/><main className="editor-gate panel"><h1>{loading ? "Checking teacher access…" : "Teacher workspace"}</h1>{notice&&<p role="alert" className="notice error">{notice.text}</p>}<p>{loading ? "Your author session is checked before loading Lessons or editing tools." : "Sign in through Admin with an approved author account to manage Lessons and slides."}</p>{!loading&&<><a className="primary-button" href="/admin">Open Admin</a><a className="quiet-button" href="/library">View public Lessons</a></>}</main></div>;

  return <div className="studio-shell">
    <a className="skip-link" href="#library">Skip to slides</a>
    <AppHeader teacher section="TEACHER WORKSPACE" current="/admin/modules">{status?.author ? <><span className="app-account-name" title={status.authorEmail || 'Approved author'}>{status.authorEmail || 'Author'}</span><button className="quiet-button" disabled={busy} onClick={logout}>Sign out</button></> : <button className="quiet-button" disabled={!passwordAvailable} onClick={() => setLoginOpen(!loginOpen)} aria-expanded={loginOpen}><Icon name="lock" />{loading ? "Checking sign-in…" : passwordAvailable ? "Author sign in" : "Sign-in unavailable"}</button>}</AppHeader>
    <main className="studio-main">
      <section className="hero"><div><p className="eyebrow">TEACHER WORKSPACE</p><h1>Teacher Lessons<br /><span>Create together.</span></h1><p className="hero-description">Build a slide, save it to a Lesson, and review it here. Only your chart reference, lines, labels and notes are saved—tiny editable text, not images.</p></div><div className="hero-summary"><div className={`mode-badge ${status?.author ? "author" : ""}`}><span className="status-dot" />{status?.author ? "Author mode" : "Review mode"}</div><p>{status?.author ? "Author access · online saves" : "View slides · sign in to create"}</p><div className="summary-rule" /><strong>Lessons<span>Teach with Slides</span></strong></div></section>
      {notice && <div className={`notice ${notice.kind}`} role={notice.kind === "error" ? "alert" : "status"}><span>{notice.text}</span><button className="icon-button" aria-label="Dismiss message" onClick={() => setNotice(null)}>×</button></div>}
      {status && !status.storageReady && <div className="notice error" role="alert">Online storage is not ready. Saving is disabled; this browser is not a substitute for online storage.</div>}
      {status && !status.passwordConfigured && <div className="notice info"><span>Author password sign-in is not available yet. You can still review the saved public slides.</span></div>}
      
      {loginOpen && !status?.author && <section className="signin-panel panel" aria-labelledby="signin-title"><div><p className="eyebrow">AUTHOR ACCESS</p><h2 id="signin-title">Sign in to your account</h2><p className="muted">Only accounts approved by an administrator can create or change slides.</p></div><div className="signin-form">{passwordAvailable ? <a className="primary-button" href="/admin">Open Admin Login →</a> : <button className="primary-button" disabled>Password sign-in unavailable</button>}<p className="field-help">Public slide viewing does not require sign-in.</p></div></section>}
      <div>
        <section className="library-content" id="library" aria-labelledby="library-title">
          <div className="library-toolbar"><div><p className="eyebrow">LESSONS → SLIDES</p><h2 id="library-title">{moduleTrashView?'Lesson Trash':trashView?'Slide Trash':currentFolder?.name||'Lessons'}</h2></div><div className="toolbar-actions"><button disabled={busy} onClick={()=>{setDialog(null);setFolderId('');setTrashView(false);setModuleTrashView(false);}}>All Lessons</button><button disabled={busy} onClick={()=>{setDialog(null);setFolderId('');setTrashView(false);setModuleTrashView(true);}}>Lesson Trash</button><button disabled={busy} onClick={()=>{setDialog(null);setFolderId('');setModuleTrashView(false);setTrashView(true);}}>Slide Trash</button>{currentFolder&&!trashView&&!moduleTrashView&&<><button disabled={busy} onClick={()=>{setFolderName(currentFolder.name);setDialog({kind:'rename',folder:currentFolder});}}>Rename Lesson</button><button disabled={busy} onClick={()=>setDialog({kind:'delete-module',folder:currentFolder})}>Move Lesson to Trash</button><a className="primary-button" href={studioHref(currentFolder.id)}>Add Slide</a></>}</div></div>
          <div className="filter-row"><label className="search-field"><span className="sr-only">Search Lessons or slide titles</span><span aria-hidden="true">⌕</span><input type="search" placeholder="Find a Lesson or slide…" value={search} onChange={event => { cancelReview(); setSearch(event.target.value); }} /></label><button className="refresh-button" disabled={loading || busy} onClick={() => { cancelReview(); setNotice(null); reload().catch(showError); }}><Icon name="refresh" /> {loading ? "Loading…" : "Refresh"}</button></div>
          {trashView && <p className="trash-explainer">Trashed slides are hidden from public viewing. Restore a slide to return it to its Lesson. Nothing is permanently deleted here.</p>}
          {!folderId&&!trashView&&<SequenceShelf key={moduleTrashView?'trash':'active'} renderAuthor={props=><SequenceAuthor {...props}/>} author trash={moduleTrashView} search={search} csrfToken={status.csrfToken||''} onChanged={()=>{void reload().catch(showError);}} legacyLessons={folders} renderLegacy={folder=><article className="lesson-card"><div className="lesson-card-body"><h3>{folder.name}</h3><p>{folder.slideCount??lessons.filter(slide=>slide.folderId===folder.id).length} slides · existing Lesson</p>{moduleTrashView?<button disabled={busy} onClick={()=>changeModuleTrash(folder,true)}>Restore Lesson</button>:<button disabled={busy} onClick={()=>{setFolderId(folder.id);setUploadFolder(folder.id);setSearch('');}}>Open Lesson</button>}</div></article>}/>}
          <div className="lesson-grid" hidden={moduleTrashView||!folderId&&!trashView} aria-busy={loading}>{filtered.map(lesson => <article className={`lesson-card ${trashView ? "trashed" : ""}`} key={lesson.id}><button className="lesson-preview" onClick={() => review(lesson, filtered)} aria-label={`Practice ${lesson.title}`}><img className="lesson-cover-art" src={`/artwork/${LessonModel.coverArtworkId(lesson.coverArtwork)}.svg`} alt="" width="800" height="450" loading="lazy" /><div className="lesson-cover-copy"><span className="lesson-cover-kicker">SLIDE PRACTICE</span><strong>{lesson.purpose || "Chart slide"}</strong><span className="lesson-cover-action">Explore the chart <span aria-hidden="true">↗</span></span></div><span className="revision-badge">v{lesson.revision}</span></button><div className="lesson-card-body"><div className="lesson-folder"><Icon name="folder" />{folders.find(folder => folder.id === lesson.folderId)?.name || "Lesson"}</div><h3><button onClick={() => review(lesson, filtered)}>{lesson.title}</button></h3><p className="lesson-date">Saved {dateLabel(lesson.updatedAt)}</p><div className="card-actions"><button className="text-button" onClick={() => review(lesson, filtered)}>Practice Slide <span aria-hidden="true">↗</span></button>{status?.author && (trashView ? <button className="text-button" disabled={busy} onClick={() => trashOrRestore(lesson, true)}>Restore</button> : <><a className="text-button" href={studioHref(lesson.folderId, lesson.id)}>Edit</a><button className="icon-button danger" disabled={busy} onClick={() => setDialog({ kind: "trash", lesson })} aria-label={`Move ${lesson.title} to Trash`}><Icon name="trash" /></button></>)}</div></div></article>)}</div>
          {!moduleTrashView && (!!folderId||trashView) && !filtered.length && <div className="empty-state"><span className="empty-icon"><Icon name={trashView ? "trash" : "folder"} /></span><h3>{loading ? "Loading your Lessons…" : search ? "No matching slides" : trashView ? "Trash is empty" : !status?.author && status?.publicReady === false ? "Private setup is in progress" : "A place for your next slide"}</h3><p>{loading ? "Fetching saved Lessons and slides from the server." : search ? "Try another title or choose a different Lesson." : trashView ? "Slides moved to Trash will appear here so an author can restore them." : status?.author ? "Add a slide right here in Teacher Studio, then save it to a Lesson." : status?.publicReady === false ? "The public Lessons is temporarily unavailable. Please refresh in a moment." : "Saved slides will appear here. An author can sign in to create the first one."}</p>{status?.author && !loading && !trashView && !search && <a className="primary-button" href={studioHref(folderId)}>Add Your First Slide</a>}</div>}
          <p className="sync-note" aria-live="polite">{lastLoaded ? <><span className="status-dot" />Loaded from online storage · {lastLoaded.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })}</> : "No Lessons loaded yet."}</p>
          {status?.author && !!currentFolder && !trashView && !moduleTrashView && <details className="import-panel panel"><summary>Import a Slide Backup <span>Optional · JSON only</span></summary><p className="muted">Normal slide creation and saving happen inside the editor. Use this only to bring in an existing exported slide pack.</p>{importUncertain && <div className="notice info"><span>The previous save is unconfirmed. Check its server status first. Retrying this unchanged file uses the same request ID to avoid a duplicate.</span><button className="quiet-button" disabled={busy} type="button" onClick={checkImportStatus}>Check save status</button></div>}<form onSubmit={upload}><label htmlFor="upload-folder">Destination Lesson</label><select id="upload-folder" value={uploadFolder} onChange={event => setUploadFolder(event.target.value)} required disabled={busy || importUncertain}><option value="">Choose a Lesson</option>{folders.map(folder => <option key={folder.id} value={folder.id}>{folder.name}</option>)}</select>{!folders.length && <p className="field-help">Create a Lesson first.</p>}<div className={`dropzone ${dragging ? "dragging" : ""}`} onDragOver={event => { event.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={event => { event.preventDefault(); setDragging(false); if (!busy && !importUncertain) selectFiles(event.dataTransfer.files); }}><Icon name="upload" /><strong>Drop one editable slide pack here</strong><span>JSON up to 3 MB · no image needed</span></div><div className="file-fields" key={fileKey}><label className="file-field">Editable slide pack <span>.json</span><input type="file" accept=".json,application/json" disabled={busy || importUncertain} onChange={event => { if (event.target.files) selectFiles(event.target.files); }} /><small>{pack?.name || "No pack selected"}</small></label></div><div className="upload-footer"><p className="field-help">Slides are intended for public viewing. Don’t include private information. The server validates the editable slide and its chart reference before saving.</p><button className="quiet-button" disabled={busy || !pack || !uploadFolder || locked} type="submit"><Icon name="upload" />{busy ? "Saving online…" : importUncertain ? "Retry same import" : "Import & save online"}</button></div></form></details>}
        </section>
      </div>
    </main>
    <footer className="site-footer"><span>Price Action Center · Teacher Studio</span><span>Create, save, and review—all in one place.</span></footer>
    {dialog?.kind === "create" || dialog?.kind === "rename" ? <Modal title={dialog.kind === "rename" ? "Rename Lesson" : "Create Lesson"} onClose={() => !busy && setDialog(null)}>{notice?.kind === "error" && <p className="notice error" role="alert">{notice.text}</p>}<form onSubmit={saveFolder}><label htmlFor="folder-name">Lesson name</label><input id="folder-name" autoFocus required maxLength={100} value={folderName} onChange={event => setFolderName(event.target.value)} disabled={busy} placeholder="e.g. Trendlines" /><p className="field-help">A short, recognizable name for your shared collection.</p><div className="dialog-actions"><button type="button" className="quiet-button" disabled={busy} onClick={() => setDialog(null)}>Cancel</button><button className="primary-button" disabled={busy || !folderName.trim()} type="submit">{busy ? "Saving…" : dialog.kind === "rename" ? "Save name" : "Create Lesson"}</button></div></form></Modal> : null}
    {dialog?.kind === "delete-module" && <Modal title="Move Lesson to Trash?" onClose={()=>!busy&&setDialog(null)}>{notice?.kind==="error"&&<p className="notice error" role="alert">{notice.text}</p>}<p><strong>{dialog.folder.name}</strong> will move to Lesson Trash and disappear from the public library.</p><p>{dialog.folder.slideCount ?? 0} existing slides and {dialog.folder.versionCount ?? 0} saved versions, plus {dialog.folder.sequenceCount ?? 0} ordered lessons containing {dialog.folder.sequenceSlideCount ?? 0} current slides and {dialog.folder.sequenceVersionCount ?? 0} saved lesson versions, will remain recoverable. No slide or version is permanently deleted. Restore the Lesson from Lesson Trash; slides already in Slide Trash stay there.</p><div className="dialog-actions"><button className="quiet-button" disabled={busy} onClick={()=>setDialog(null)}>Keep Lesson</button><button className="danger-button" disabled={busy} onClick={()=>dialog.kind==="delete-module"&&changeModuleTrash(dialog.folder,false)}>{busy?"Moving…":"Move Lesson to Trash"}</button></div></Modal>}
    {dialog?.kind === "trash" && <Modal title="Move slide to Trash?" onClose={() => !busy && setDialog(null)}>{notice?.kind === "error" && <p className="notice error" role="alert">{notice.text}</p>}<p><strong>{dialog.lesson.title}</strong> will be removed from public viewing. Its saved text and versions will remain recoverable.</p><p className="muted">You or Travis can restore it from Trash while signed in.</p><div className="dialog-actions"><button className="quiet-button" disabled={busy} onClick={() => setDialog(null)}>Keep Slide</button><button className="danger-button" disabled={busy} onClick={() => dialog.kind === "trash" && trashOrRestore(dialog.lesson, false)}>{busy ? "Moving…" : "Move to Trash"}</button></div></Modal>}
    {dialog?.kind === "review" && <Modal lesson contentKey={`${dialog.lesson.id}:${dialog.lesson.versionId}`} title={dialog.lesson.title} onClose={() => setDialog(null)}>{notice?.kind === "error" && <p className="notice error" role="alert">{notice.text}</p>}<p className="review-meta">Revision {dialog.lesson.revision} · Saved {dateLabel(dialog.lesson.updatedAt)}</p><SavedLessonReview lesson={dialog.lesson} hasNext={!!followingLesson} onNext={followingLesson ? () => review(followingLesson, dialog.sequence) : undefined} /><div className="review-downloads">{status?.author && safeAssetUrl(dialog.lesson.packUrl) && <a className="quiet-button" href={safeAssetUrl(dialog.lesson.packUrl)} download>Download editable pack</a>}</div><p className="field-help">This chart is recreated from the saved text and original chart data. PNG export remains optional in the editor; no image is stored.</p>{status?.author && !trashView && !moduleTrashView && <div className="dialog-actions"><a className="primary-button" href={studioHref(dialog.lesson.folderId, dialog.lesson.id)}>Edit Slide in Teacher Studio →</a></div>}</Modal>}
  </div>;
}
