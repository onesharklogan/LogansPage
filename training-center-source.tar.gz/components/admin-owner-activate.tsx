'use client';
import {useEffect,useLayoutEffect,useRef,useState} from 'react';
import AppHeader from './app-navigation';
import TeacherGoogleSignIn from './teacher-google-sign-in';
import {memberRequest,MemberRequestError} from './manage-authors';
type Approval={email:string;role:'admin';expiresAt:string;csrfToken:string};
export default function AdminOwnerActivate(){
 const alive=useRef(false),epoch=useRef(0),pending=useRef(false),request=useRef<AbortController|null>(null),consent=useRef({accepted:false}),display=useRef<object|null>(null);
 const renderedEpoch=epoch.current,renderedConsent=consent.current,view={};
 useLayoutEffect(()=>{display.current=view;return()=>{if(display.current===view)display.current=null;};},[view]);
 const allowed=()=>alive.current&&display.current===view&&renderedEpoch===epoch.current;
 const [approval,setApproval]=useState<Approval|null>(null),[loading,setLoading]=useState(true),[busy,setBusy]=useState(false),[error,setError]=useState(''),[signIn,setSignIn]=useState(false),[accepted,setAccepted]=useState(false),[checked,setChecked]=useState(false);
 async function refresh(){
  if(!alive.current)return;const ticket=++epoch.current;request.current?.abort();const controller=new AbortController();request.current=controller;consent.current={accepted:false};setChecked(false);setApproval(null);setError('');setAccepted(false);setLoading(true);setSignIn(false);
  const current=()=>alive.current&&ticket===epoch.current&&!controller.signal.aborted;
  try{const next=await memberRequest<Approval>('/api/admin-owner/session',{signal:controller.signal});if(!current())return;if(typeof next.email!=='string'||!next.email||next.role!=='admin'||typeof next.csrfToken!=='string'||!next.csrfToken||!Number.isFinite(Date.parse(next.expiresAt)))throw Error('Owner approval could not be confirmed.');setApproval(next);}
  catch(problem){if(current()){setError(problem instanceof Error?problem.message:'Owner approval could not be checked.');setSignIn(problem instanceof MemberRequestError&&problem.status===401);}}
  finally{if(current())setLoading(false);}
 }
 useEffect(()=>{alive.current=true;void refresh();const hide=()=>{epoch.current++;request.current?.abort();consent.current={accepted:false};setChecked(false);setApproval(null);};const resume=()=>{if(alive.current)void refresh();};window.addEventListener('pagehide',hide);window.addEventListener('focus',resume);window.addEventListener('pageshow',resume);return()=>{alive.current=false;epoch.current++;request.current?.abort();consent.current={accepted:false};window.removeEventListener('pagehide',hide);window.removeEventListener('focus',resume);window.removeEventListener('pageshow',resume);};},[]);
 async function accept(){
  if(!allowed()||pending.current||consent.current!==renderedConsent||!renderedConsent.accepted||!checked||!approval)return;
  const ticket=++epoch.current;request.current?.abort();const controller=new AbortController();request.current=controller;pending.current=true;consent.current={accepted:false};setChecked(false);setBusy(true);setError('');
  const current=()=>alive.current&&ticket===epoch.current&&!controller.signal.aborted;
  try{const result=await memberRequest<{accepted:boolean;email:string;role:string}>('/api/admin-owner/accept',{method:'POST',signal:controller.signal,headers:{'Content-Type':'application/json','X-CSRF-Token':approval.csrfToken},body:JSON.stringify({confirmation:'LINK MY GOOGLE ADMIN'})});if(!current())return;if(result.accepted!==true||result.email!==approval.email||result.role!=='admin')throw Error('Administrator access could not be confirmed. Check access before retrying.');setAccepted(true);setApproval(null);}
  catch(problem){if(current())setError(problem instanceof Error?problem.message:'Activation could not be confirmed. Check access before retrying.');}
  finally{pending.current=false;if(alive.current)setBusy(false);}
 }
 return <div className="training-center"><AppHeader section="ADMIN ACTIVATION" current="/admin"/><main className="admin-main"><h1>Link Google admin access</h1>{loading?<p role="status">Verifying Google account…</p>:accepted?<section className="panel"><h2>Administrator access confirmed</h2><a className="primary-button" href="/admin">Open Admin</a></section>:<section className="panel">{error&&<p role="alert">{error}</p>}{signIn&&<><p>Sign in with the approved Google account, then reopen this activation page.</p><TeacherGoogleSignIn onReturn={()=>void refresh()}/></>}{approval&&<><h2>{approval.email}</h2><p>Full administrator access: create and change Lessons, invite administrators and manage access.</p><p>This one-time approval expires at {new Date(approval.expiresAt).toLocaleString()}.</p><label><input type="checkbox" checked={checked} disabled={busy} onChange={event=>{if(allowed()&&!pending.current&&consent.current===renderedConsent&&event.target.checked!==checked){consent.current={accepted:event.target.checked};setChecked(event.target.checked);}}}/>Link this verified Google account to my approved administrator access.</label><div className="toolbar-actions"><a className="quiet-button" href="/admin" onClick={event=>{if(!allowed()){event.preventDefault();return;}epoch.current++;request.current?.abort();consent.current={accepted:false};}}>Cancel</a><button className="primary-button" type="button" disabled={busy||!checked} onClick={()=>void accept()}>Link my Google admin access</button></div></>}<button className="quiet-button" type="button" disabled={busy||loading} onClick={()=>{if(allowed()&&!pending.current)void refresh();}}>Check access again</button><a className="quiet-button" href="/">Open profile to sign out or switch accounts</a></section>}</main></div>;
}
