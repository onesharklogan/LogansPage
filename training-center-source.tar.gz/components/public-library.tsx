'use client';
import WorkspaceLibrary from './teacher-workspace-library';
/** Learner-only unified read projection; no author authentication or mutation path. */
export default function PublicLibrary(){return <WorkspaceLibrary/>;}
