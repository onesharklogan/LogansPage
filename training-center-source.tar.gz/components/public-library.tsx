'use client';

import {useCallback,useEffect,useRef,useState} from 'react';
import AppHeader from './app-navigation';
import SavedLessonReview from './lesson-review';
import LessonModel from '../lib/portal/lesson-model.cjs';

type Folder={id:string;name:string;revision:number};
type Lesson={id:string;folderId:string;title:string;purpose?:string;coverArtwork?:string;revision:number;versionId:string;updatedAt?:string|number;pack?:{sha256:string;bytes:number;contentType?:string};packUrl?:string};
type Review={lesson:Lesson;sequence:Lesson[]};
const identifier=(v:unknown):v is string=>typeof v==='string'&&/^[A-Za-z0-9_-]{1,90}$/.test(v);
function lessonValue(value:unknown,manifest=false):Lesson {
  const v=value as Record<string,unknown>;
  if(!v||!identifier(v.id)||!identifier(v.folderId)||!identifier(v.versionId)||typeof v.title!=='string'||!v.title||v.title.length>120||!Number.isSafeInteger(v.revision)||(v.revision as number)<1||v.trashed)throw Error('Published slide metadata is invalid. Please refresh.');
  const result:Lesson={id:v.id,folderId:v.folderId,versionId:v.versionId,title:v.title,revision:v.revision as number};
  if(typeof v.purpose==='string')result.purpose=v.purpose;
  if(typeof v.coverArtwork==='string')result.coverArtwork=v.coverArtwork;
  if(typeof v.updatedAt==='string'||typeof v.updatedAt==='number')result.updatedAt=v.updatedAt;
  if(manifest){const pack=v.pack as Record<string,unknown>;const url=`/api/public/lessons/${v.id}/versions/${v.versionId}/pack`;if(v.packUrl!==url||!pack||typeof pack.sha256!=='string'||!/^[a-f0-9]{64}$/.test(pack.sha256)||!Number.isSafeInteger(pack.bytes)||(pack.bytes as number)<1||(pack.bytes as number)>LessonModel.MAX_BYTES)throw Error('Published slide content is unavailable. Please refresh.');result.packUrl=url;result.pack={sha256:pack.sha256,bytes:pack.bytes as number,contentType:'application/json'};}
  return result;
}
async function publicGet(path:string,signal:AbortSignal) {
  if(!/^\/api\/public\/(?:folders|lessons(?:\/[A-Za-z0-9_-]{1,90}\/manifest)?)$/.test(path))throw Error('Invalid published library request.');
  const response=await fetch(path,{method:'GET',credentials:'omit',cache:'no-store',signal});
  if(!response.ok)throw Error(response.status===404?'This published slide is no longer available. Refresh the library.':'The published library is unavailable. Please try Refresh.');
  return response.json();
}
function PracticeDialog({review,onClose,onNext,error}:{review:Review;onClose:()=>void;onNext?:()=>Promise<void>;error:string}) {
  const dialog=useRef<HTMLDialogElement>(null);
  useEffect(()=>{dialog.current?.showModal();return()=>dialog.current?.close();},[]);
  useEffect(()=>{dialog.current?.querySelector('.lesson-modal-body')?.scrollTo({top:0,left:0});},[review.lesson.id,review.lesson.versionId]);
  return <dialog ref={dialog} className="modal lesson-modal" aria-labelledby="published-slide-title" onCancel={event=>{event.preventDefault();onClose();}}><div className="modal-head"><h2 id="published-slide-title">{review.lesson.title}</h2><button className="icon-button" aria-label="Close slide" onClick={onClose}>×</button></div><div className="lesson-modal-body">{error&&<p className="notice error" role="alert">{error}</p>}<SavedLessonReview lesson={review.lesson} hasNext={!!onNext} onNext={onNext}/></div></dialog>;
}
/** Learner-only surface. No auth status, author scope, editing controls or mutation APIs. */
export default function PublicLibrary() {
  const [folders,setFolders]=useState<Folder[]>([]),[lessons,setLessons]=useState<Lesson[]>([]),[folderId,setFolderId]=useState(''),[search,setSearch]=useState(''),[loading,setLoading]=useState(true),[error,setError]=useState(''),[review,setReview]=useState<Review|null>(null);
  const alive=useRef(false),loadEpoch=useRef(0),reviewEpoch=useRef(0),loadRequest=useRef<AbortController|null>(null),reviewRequest=useRef<AbortController|null>(null),reviewIdentity=useRef<Review|null>(null);
  const cancelReview=useCallback(()=>{reviewEpoch.current++;reviewRequest.current?.abort();reviewRequest.current=null;},[]);
  const closeReview=useCallback(()=>{cancelReview();reviewIdentity.current=null;setReview(null);},[cancelReview]);
  const reload=useCallback(async()=>{
    const epoch=++loadEpoch.current,request=new AbortController();loadRequest.current?.abort();loadRequest.current=request;closeReview();setLoading(true);setError('');
    try{const [modules,slides]=await Promise.all([publicGet('/api/public/folders',request.signal),publicGet('/api/public/lessons',request.signal)]);if(!alive.current||request.signal.aborted||epoch!==loadEpoch.current)return;if(!Array.isArray(modules.folders)||!Array.isArray(slides.lessons))throw Error('The published library response is invalid.');const nextFolders=modules.folders.map((v:Folder)=>{if(!v||!identifier(v.id)||typeof v.name!=='string'||!Number.isSafeInteger(v.revision))throw Error('Published module metadata is invalid.');return{id:v.id,name:v.name,revision:v.revision};});setFolders(nextFolders);setLessons(slides.lessons.map((value:unknown)=>lessonValue(value)));setFolderId(current=>nextFolders.some((v:Folder)=>v.id===current)?current:'');}
    catch(problem){if(alive.current&&!request.signal.aborted&&epoch===loadEpoch.current){setFolders([]);setLessons([]);setError(problem instanceof Error?problem.message:'The published library could not be loaded.');}}
    finally{if(alive.current&&epoch===loadEpoch.current)setLoading(false);}
  },[closeReview]);
  useEffect(()=>{alive.current=true;void reload();return()=>{alive.current=false;loadEpoch.current++;loadRequest.current?.abort();cancelReview();};},[reload,cancelReview]);
  async function openSlide(lesson:Lesson,sequence:Lesson[]) {
    cancelReview();const epoch=reviewEpoch.current,request=new AbortController();reviewRequest.current=request;setError('');
    try{const data=await publicGet(`/api/public/lessons/${lesson.id}/manifest`,request.signal);if(!alive.current||request.signal.aborted||epoch!==reviewEpoch.current)return;const selected=lessonValue(data.lesson||data,true);if(selected.id!==lesson.id)throw Error('The published slide changed. Refresh the library.');const opened={lesson:selected,sequence:sequence.map(value=>({...value}))};reviewIdentity.current=opened;setReview(opened);}
    catch(problem){if(alive.current&&!request.signal.aborted&&epoch===reviewEpoch.current)setError(problem instanceof Error?problem.message:'This published slide could not be opened.');}
    finally{if(epoch===reviewEpoch.current)reviewRequest.current=null;}
  }
  const filtered=lessons.filter(lesson=>(!folderId||lesson.folderId===folderId)&&lesson.title.toLocaleLowerCase().includes(search.toLocaleLowerCase())),folder=folders.find(value=>value.id===folderId),index=review?.sequence.findIndex(value=>value.id===review.lesson.id)??-1,next=review&&index>=0?review.sequence[index+1]:undefined;
  return <div className="studio-shell"><a className="skip-link" href="#library">Skip to slides</a><AppHeader section="MODULE LIBRARY" current="/library"/><main className="studio-main"><section className="hero"><div><p className="eyebrow">CHART PRACTICE</p><h1>Module Library</h1><p className="hero-description">Choose a module, practice a slide, and work through the collection at your pace.</p></div><div className="hero-summary"><strong>{loading?'—':lessons.length}<span>published slides</span></strong></div></section>{error&&!review&&<p className="notice error" role="alert">{error}</p>}<div className="library-layout"><aside className="folder-sidebar panel" aria-label="Modules"><div className="section-label"><h2>Modules</h2><span>{folders.length}</span></div><button className={`folder-button ${!folderId?'selected':''}`} onClick={()=>{closeReview();setFolderId('');}}>All Slides</button><div className="folder-list">{folders.map(value=><button key={value.id} className={`folder-button ${folderId===value.id?'selected':''}`} title={value.name} onClick={()=>{closeReview();setFolderId(value.id);}}>{value.name}</button>)}</div></aside><section className="library-content" id="library" aria-labelledby="library-title"><div className="library-toolbar"><div><p className="eyebrow">SLIDE COLLECTION</p><h2 id="library-title">{folder?.name||'All Slides'}</h2></div></div><div className="filter-row"><label className="search-field"><span className="sr-only">Search slide titles</span><input type="search" placeholder="Find a slide…" value={search} onChange={event=>{closeReview();setSearch(event.target.value);}}/></label><button className="refresh-button" disabled={loading} onClick={()=>void reload()}>{loading?'Loading…':'Refresh'}</button></div><div className="lesson-grid" aria-busy={loading}>{filtered.map(lesson=><article className="lesson-card" key={lesson.id}><button className="lesson-preview" aria-label={`Practice ${lesson.title}`} onClick={()=>void openSlide(lesson,filtered)}><img className="lesson-cover-art" src={`/artwork/${LessonModel.coverArtworkId(lesson.coverArtwork)}.svg`} alt="" width="800" height="450" loading="lazy"/><div className="lesson-cover-copy"><span className="lesson-cover-kicker">SLIDE PRACTICE</span><strong>{lesson.purpose||'Chart slide'}</strong><span className="lesson-cover-action">Explore the chart ↗</span></div></button><div className="lesson-card-body"><p className="lesson-folder">{folders.find(value=>value.id===lesson.folderId)?.name||'Module'}</p><h3><button onClick={()=>void openSlide(lesson,filtered)}>{lesson.title}</button></h3><div className="card-actions"><button className="text-button" onClick={()=>void openSlide(lesson,filtered)}>Practice Slide ↗</button></div></div></article>)}</div>{!filtered.length&&<div className="empty-state"><h3>{loading?'Loading published slides…':search?'No matching slides':'No published slides yet'}</h3><p>{loading?'Getting the current collection.':search?'Try another title or module.':'Check back later or use Refresh.'}</p></div>}</section></div></main><footer className="site-footer"><span>Price Action Center</span><span>Practice at your own pace.</span></footer>{review&&<PracticeDialog error={error} review={review} onClose={()=>{if(reviewIdentity.current===review)closeReview();}} onNext={next?()=>reviewIdentity.current===review?openSlide(next,review.sequence):Promise.resolve():undefined}/>}</div>;
}
