'use client';

import {useEffect,useRef,useState,type FormEvent,type KeyboardEvent,type MouseEvent} from 'react';
import {createLearnerClient,learnerClient} from '../lib/learner/client.mjs';
import styles from './learner-account.module.css';
import {googleAuthDriver} from '../lib/learner/google-driver.mjs';

export type LearnerAuthDriver={signIn:(input:{signal:AbortSignal})=>Promise<unknown>;signOut?:(input:{signal:AbortSignal})=>Promise<unknown>;};
type View='choose'|'details'|'reset';
const defaultClient=learnerClient;
/** This control does not read or migrate any browser-local learner profile. */
export default function LearnerAccountControl({client=defaultClient,authDriver=googleAuthDriver,promptOnEntry=false,hideTrigger=false,navigationWarning,onBeforeNavigate,onOpenChange}:{client?:ReturnType<typeof createLearnerClient>;authDriver?:LearnerAuthDriver;promptOnEntry?:boolean;hideTrigger?:boolean;navigationWarning?:string;onBeforeNavigate?:()=>boolean;onOpenChange?:(open:boolean)=>void}){
 const [snapshot,setSnapshot]=useState<ReturnType<typeof client.getSnapshot>>(client.getSnapshot),[opened,setOpened]=useState(false),[view,setView]=useState<View>('choose'),[confirmation,setConfirmation]=useState(''),[accepted,setAccepted]=useState(false),[localError,setLocalError]=useState('');
 const dialog=useRef<HTMLDialogElement>(null),trigger=useRef<HTMLButtonElement>(null),closeButton=useRef<HTMLButtonElement>(null),alive=useRef(false),panelVersion=useRef(0),openRef=useRef(false),lastIdentity=useRef<string|null>(null),lastPanelRequest=useRef(0),openChange=useRef(onOpenChange);openChange.current=onOpenChange;
 const renderCapture=client.captureContext();
 const prompted=useRef(false);
 const renderedPanel=panelVersion.current;
 const actionAllowed=()=>alive.current&&openRef.current&&renderedPanel===panelVersion.current&&client.guard(renderCapture);
 function navigateReplay(event:MouseEvent<HTMLAnchorElement>){if(!actionAllowed()||onBeforeNavigate&&!onBeforeNavigate()){event.preventDefault();setLocalError('Finish saving your current practice and refresh this account before replaying.');}}
 const identity=snapshot.profile?`${snapshot.profile.id}:${snapshot.profile.generation}`:null;
 async function downloadHistory(){if(!actionAllowed())return;const ticket=panelVersion.current;setLocalError('');try{const exported=await client.exportHistory();if(!alive.current||!openRef.current||ticket!==panelVersion.current||!client.guard(renderCapture))return;const blob=new Blob([JSON.stringify({version:exported.version,profile:exported.profile,attempts:exported.attempts},null,2)+'\n'],{type:'application/json'}),url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download='price-action-account-history.json';link.click();setTimeout(()=>URL.revokeObjectURL(url),0);}catch(error){if(alive.current&&openRef.current&&ticket===panelVersion.current)setLocalError(error instanceof Error?error.message:'History download could not be prepared.');}}
 function clearPrivateFields(){setConfirmation('');setAccepted(false);}
 function close(){if(!alive.current||!openRef.current||renderedPanel!==panelVersion.current)return;panelVersion.current++;openRef.current=false;setOpened(false);clearPrivateFields();setLocalError('');client.cancelAuthentication();openChange.current?.(false);}
 useEffect(()=>{alive.current=true;const unsubscribe=client.subscribe(setSnapshot);void client.refresh();const restore=()=>{void client.revalidate();};window.addEventListener('focus',restore);window.addEventListener('pageshow',restore);return()=>{alive.current=false;panelVersion.current++;client.cancelAuthentication();if(openRef.current)openChange.current?.(false);unsubscribe();window.removeEventListener('focus',restore);window.removeEventListener('pageshow',restore);};},[client]);
 useEffect(()=>{
  if(lastIdentity.current!==identity){lastIdentity.current=identity;clearPrivateFields();panelVersion.current++;if(openRef.current){setView(snapshot.profile?'details':'choose');if(snapshot.profile)void client.loadDetails();}}
 },[identity]);
 useEffect(()=>{const request=snapshot.panelRequest;if(request&&request.id!==lastPanelRequest.current){lastPanelRequest.current=request.id;open();}},[snapshot.panelRequest]);
 useEffect(()=>{if(promptOnEntry&&!prompted.current&&snapshot.ready&&snapshot.authConfigured&&!snapshot.profile){prompted.current=true;open();}},[promptOnEntry,snapshot.ready,snapshot.authConfigured,snapshot.profile]);
 useEffect(()=>{
  const node=dialog.current;if(!node)return;
  if(opened){if(!node.open)node.showModal();closeButton.current?.focus();}
  else if(node.open){node.close();trigger.current?.focus();}
 },[opened]);
 function open(){if(!alive.current||openRef.current)return;panelVersion.current++;openRef.current=true;openChange.current?.(true);setOpened(true);setView(snapshot.profile?'details':'choose');clearPrivateFields();setLocalError('');if(snapshot.profile)void client.loadDetails();}
 function changeView(next:View){panelVersion.current++;clearPrivateFields();setLocalError('');setView(next);}
 async function google(){
  if(!authDriver||snapshot.busy||!actionAllowed())return;
  const ticket=panelVersion.current;setLocalError('');
  try{await client.authenticate(authDriver,'signIn',{});}catch(error){if(alive.current&&openRef.current&&ticket===panelVersion.current)setLocalError(error instanceof Error?error.message:'Google sign-in could not be completed. Try again.');}
 }
 function continueGuest(){if(!actionAllowed())return;setLocalError('');try{client.continueAsGuest();close();}catch(error){setLocalError(error instanceof Error?error.message:'Wait for the account check before continuing.');}}
 async function logout(){if(!actionAllowed())return;if(onBeforeNavigate&&!onBeforeNavigate()){setLocalError('Finish saving your current practice before signing out.');return;}const ticket=panelVersion.current;setLocalError('');clearPrivateFields();try{await client.logout(authDriver);}catch(error){if(alive.current&&openRef.current&&ticket===panelVersion.current)setLocalError(error instanceof Error?error.message:'Sign-out could not be confirmed. Try again.');}}
 async function prepareReset(){if(!actionAllowed())return;if(onBeforeNavigate&&!onBeforeNavigate()){setLocalError('Finish saving your current practice before resetting history.');return;}setLocalError('');clearPrivateFields();const ticket=++panelVersion.current;try{await client.prepareReset();if(alive.current&&openRef.current&&ticket===panelVersion.current)setView('reset');}catch(error){if(alive.current&&openRef.current&&ticket===panelVersion.current)setLocalError(error instanceof Error?error.message:'Reset confirmation could not be prepared. Try again.');}}
 async function reset(event:FormEvent<HTMLFormElement>){event.preventDefault();if(!actionAllowed()||view!=='reset'||!accepted||confirmation!=='RESET MY HISTORY')return;setLocalError('');const ticket=panelVersion.current;try{await client.reset(confirmation);if(alive.current&&openRef.current&&ticket===panelVersion.current){clearPrivateFields();setView('details');}}catch(error){if(alive.current&&openRef.current&&ticket===panelVersion.current)setLocalError(error instanceof Error?error.message:'Reset could not be confirmed. Retry only after refreshing the account.');}}
 function keys(event:KeyboardEvent<HTMLDialogElement>){
  event.stopPropagation();if(!openRef.current||renderedPanel!==panelVersion.current)return;if(event.key==='Escape'){event.preventDefault();close();return;}if(event.key!=='Tab')return;
  const targets=Array.from(dialog.current?.querySelectorAll<HTMLElement>('button:not(:disabled),input:not(:disabled),a[href],[tabindex="0"]')||[]),first=targets[0],last=targets.at(-1),focused=document.activeElement;
  if(!first){event.preventDefault();dialog.current?.focus();}
  else if(event.shiftKey&&(focused===first||!dialog.current?.contains(focused))){event.preventDefault();last?.focus();}
  else if(!event.shiftKey&&(focused===last||!dialog.current?.contains(focused))){event.preventDefault();first.focus();}
 }
 const verified=snapshot.ready&&!snapshot.reconcileRequired&&!snapshot.revalidating&&!snapshot.signOutNeeded,signedIn=verified&&!!snapshot.profile,authReady=!!authDriver&&snapshot.authConfigured&&verified,warning='Guests will not be able to track their history + skill progress';
 return <><div className={styles.control} hidden={hideTrigger} style={hideTrigger?{display:'none'}:undefined}><button ref={trigger} className={styles.trigger} type="button" aria-haspopup="dialog" aria-expanded={opened} aria-controls="learner-account-dialog" onClick={open}>{signedIn?snapshot.profile!.name:verified?'Guest':'Checking…'}</button>{!signedIn&&<span className={styles.guestHelp}>{warning}</span>}</div>
 <dialog id="learner-account-dialog" ref={dialog} className={styles.dialog} aria-labelledby="learner-account-title" aria-describedby="learner-account-description" onCancel={event=>{event.preventDefault();close();}} onKeyDown={keys} onClick={event=>{if(event.target===event.currentTarget)close();}}>
  <section><div className={styles.heading}><div><p className={styles.eyebrow}>{signedIn?'LEARNER ACCOUNT':'PRACTICE YOUR WAY'}</p><h2 id="learner-account-title">{view==='reset'?'Reset saved practice':signedIn?snapshot.profile!.name:'Sign in or continue as Guest'}</h2></div><button ref={closeButton} className={styles.close} type="button" aria-label="Close learner account" onClick={close}>×</button></div>
  {navigationWarning?<p className={styles.warning}>{navigationWarning}</p>:null}
  <p id="learner-account-description">{signedIn?'Your saved practice belongs to this learner account—not a teacher account.':warning}</p>
  {(localError||snapshot.error)&&<p className={styles.error} role="alert">{localError||snapshot.error}</p>}
  {snapshot.busy&&<p className={styles.status} role="status">{snapshot.busy}</p>}{!verified&&<p className={styles.status} role="status">Checking your sign-in state. Guest and account tracking stay paused until this check finishes.</p>}{snapshot.signOutNeeded&&<button type="button" disabled={!!snapshot.busy||!authDriver} onClick={()=>void client.retrySignOut(authDriver).catch(()=>{})}>Retry sign-out</button>}{snapshot.reconcileRequired&&<button type="button" onClick={()=>void client.revalidate()} disabled={!!snapshot.busy}>Retry account check</button>}
  {!signedIn&&<>
   {!authReady&&<p className={styles.warning}>Account sign-in is not configured yet. Continue as Guest.</p>}
   <div className={styles.signInActions}><button className={`${styles.choiceButton} ${styles.googleButton}`} type="button" disabled={!authReady||!!snapshot.busy} onClick={()=>void google()}>Sign in with Google</button>
   <button type="button" className={`${styles.choiceButton} ${styles.guestButton}`} disabled={!verified||!!snapshot.busy} onClick={continueGuest}>Continue as Guest</button></div>
  </>}
  {signedIn&&view!=='reset'&&<>
   <dl className={styles.metrics}><div><dt>Completed attempts</dt><dd>{snapshot.progress?.completedAttempts??'—'}</dd></div><div><dt>Simulators practiced</dt><dd>{snapshot.progress?Object.values(snapshot.progress.byModule).filter((count:any)=>count>0).length:'—'}</dd></div></dl><p className={styles.muted}>No skill score available. These are practice counts, not a skill rating.</p>
   <p>Trade points: <strong>{snapshot.progress?.trade.netPoints??'—'}</strong> · Market Direction points (first completed per chart): <strong>{snapshot.progress?.direction.netAlignedPoints??'—'}</strong></p><h3>Recent account history</h3>{snapshot.attempts.length?<ul className={styles.history}>{snapshot.attempts.map((attempt:any)=><li key={attempt.id}><strong>{attempt.module==='trade-simulator'?'Trade Simulator':'Market Direction'} · {attempt.chartId}</strong><small>Completed · {new Date(attempt.completedAt).toLocaleDateString()}</small><a className={styles.action} href={`/${attempt.module}?replay=${encodeURIComponent(attempt.id)}`} onClick={navigateReplay} onAuxClick={navigateReplay} onContextMenu={navigateReplay}>Replay</a></li>)}</ul>:<p>No saved account attempts yet.</p>}
   <div className={styles.actions}><button type="button" disabled={!!snapshot.busy} onClick={()=>void client.loadDetails()}>Refresh history</button><button type="button" disabled={!!snapshot.busy} onClick={logout}>Sign out</button></div>
   <div className={styles.actions}><button type="button" disabled={!!snapshot.busy} onClick={downloadHistory}>Download account history</button><button className={styles.danger} type="button" disabled={!!snapshot.busy} onClick={prepareReset}>Reset saved practice</button></div><p className={styles.muted}>Reset only clears this account’s tracked history and progress. It does not delete your login, teacher access, or older browser-local profiles.</p>
  </>}
  {signedIn&&view==='reset'&&<form className={styles.form} onSubmit={reset}><p className={styles.warning}>This permanently clears all saved practice history and progress for <strong>{snapshot.profile!.name}</strong>. Other accounts and browser-local history are not changed. Your login remains.</p><label className={styles.check}><input type="checkbox" checked={accepted} onChange={event=>setAccepted(event.target.checked)} disabled={!!snapshot.busy}/>I understand this cannot be undone.</label><label htmlFor="learner-reset-confirmation">Type RESET MY HISTORY to confirm</label><input id="learner-reset-confirmation" value={confirmation} autoComplete="off" onChange={event=>setConfirmation(event.target.value)} disabled={!!snapshot.busy}/><div className={styles.actions}><button type="button" onClick={()=>changeView('details')}>Cancel reset</button><button className={styles.danger} type="submit" disabled={!!snapshot.busy||!accepted||confirmation!=='RESET MY HISTORY'}>Reset my saved practice</button></div></form>}
  </section>
 </dialog></>;
}
