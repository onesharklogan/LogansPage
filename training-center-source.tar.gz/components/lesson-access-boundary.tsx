'use client';
import {useEffect,useState,type ReactNode} from 'react';
/** Clear restored lesson UI before rechecking access on back/forward and tab return. */
export default function LessonAccessBoundary({children}:{children:ReactNode}) {
  const [allowed,setAllowed]=useState(true);
  useEffect(()=>{
    let live=true,epoch=0;let controller:AbortController|undefined;
    const verify=async()=>{
      const current=++epoch;controller?.abort();controller=new AbortController();setAllowed(false);
      try {
        const response=await fetch('/api/status',{credentials:'same-origin',cache:'no-store',signal:controller.signal});
        const status=response.ok?await response.json():null;
        if(!live||current!==epoch)return;
        if(status?.author===true&&status.storageReady===true&&['author','admin'].includes(status.authorRole))setAllowed(true);
        else window.location.replace('/admin');
      }catch{if(live&&current===epoch)window.location.replace('/admin');}
    };
    const hide=()=>{setAllowed(false);};
    const visible=()=>{if(document.visibilityState==='visible')void verify();else hide();};
    window.addEventListener('pageshow',verify);window.addEventListener('pagehide',hide);window.addEventListener('focus',verify);document.addEventListener('visibilitychange',visible);
    return()=>{live=false;epoch++;controller?.abort();window.removeEventListener('pageshow',verify);window.removeEventListener('pagehide',hide);window.removeEventListener('focus',verify);document.removeEventListener('visibilitychange',visible);};
  },[]);
  return allowed?children:null;
}
