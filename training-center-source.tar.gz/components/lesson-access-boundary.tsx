'use client';
import {Fragment,useEffect,useState,type ReactNode} from 'react';
/** Clear restored lesson UI before rechecking access on back/forward and tab return. */
export default function LessonAccessBoundary({children}:{children:ReactNode}) {
  const [allowed,setAllowed]=useState(false);
  const [generation,setGeneration]=useState(0);
  useEffect(()=>{
    let live=true,epoch=0;let controller:AbortController|undefined;
    const verify=async()=>{
      const current=++epoch;controller?.abort();controller=new AbortController();setAllowed(false);
      try {
        const response=await fetch('/api/status',{credentials:'same-origin',cache:'no-store',signal:controller.signal});
        const status=response.ok?await response.json():null;
        if(!live||current!==epoch)return;
        if(status?.lessonsAccess===true&&status.storageReady===true){setGeneration(value=>value+1);setAllowed(true);}
        else window.location.replace('/admin');
      }catch{if(live&&current===epoch)window.location.replace('/admin');}
    };
    const hide=()=>{epoch++;controller?.abort();setAllowed(false);};
    const visible=()=>{if(document.visibilityState==='visible')void verify();else hide();};
    void verify();
    window.addEventListener('pageshow',verify);window.addEventListener('pagehide',hide);window.addEventListener('focus',verify);document.addEventListener('visibilitychange',visible);
    return()=>{live=false;epoch++;controller?.abort();window.removeEventListener('pageshow',verify);window.removeEventListener('pagehide',hide);window.removeEventListener('focus',verify);document.removeEventListener('visibilitychange',visible);};
  },[]);
  return allowed?<Fragment key={generation}>{children}</Fragment>:null;
}
