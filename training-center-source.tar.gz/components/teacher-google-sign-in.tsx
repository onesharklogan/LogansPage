'use client';
import {useEffect,useLayoutEffect,useRef,useState} from 'react';
import {googleAuthDriver} from '../lib/learner/google-driver.mjs';
import styles from './learner-account.module.css';
export default function TeacherGoogleSignIn({onReturn}:{onReturn:()=>void}){
 const [busy,setBusy]=useState(false),[error,setError]=useState('');const alive=useRef(false),pending=useRef<AbortController|null>(null),display=useRef<object|null>(null);const view={};useLayoutEffect(()=>{display.current=view;return()=>{if(display.current===view)display.current=null;};},[view]);
 useEffect(()=>{alive.current=true;return()=>{alive.current=false;pending.current?.abort();};},[]);
 async function start(){if(!alive.current||display.current!==view||pending.current)return;const request=new AbortController();pending.current=request;setBusy(true);setError('');try{await googleAuthDriver.signIn({signal:request.signal});}catch(problem){if(alive.current&&pending.current===request){if(problem instanceof Error&&problem.name==='AbortError')onReturn();else setError('Google sign-in could not be completed. Try again.');}}finally{if(pending.current===request){pending.current=null;if(alive.current)setBusy(false);}}}
 return <><button type="button" className={`${styles.choiceButton} ${styles.googleButton}`} disabled={busy} onClick={()=>void start()}>{busy?'Opening Google…':'Sign in with Google'}</button>{error&&<p role="alert">{error}</p>}</>;
}
