'use client';

import {useEffect,useId,useMemo,useRef,useState,type KeyboardEvent} from 'react';
import {deriveTradeBuckets} from '../lib/trade-history-buckets.mjs';
import {formatHistoryPoints} from '../lib/trade-history-chart.mjs';
import type {Attempt} from '../lib/trade-simulator-history.mjs';

export type TradeHistoryBucketsProps={records:Attempt[];learnerId?:string};
type Bucket={id:string;label:string;startBar:number;endBar:number|null;points:number;sampleCount:number;resultCount:number;reachedCount:number};
type Model={buckets:Bucket[];reportCount:number;reportedPoints:number;attributedPoints:number;unallocatedPoints:number;unallocatedCount:number;missingScoreCount:number};
type Selection={model:Model|null;index:number};
const colors={positive:'#9ee5bc',negative:'#ff9aa9',zero:'#bacddd'};
const css=`
.trade-history-buckets{margin:16px 0;padding:12px;min-width:0;border:1px solid #355267;border-radius:12px;background:#0a1825;color:#e2edf7}.trade-history-buckets *{box-sizing:border-box}.trade-history-buckets h3{margin:0;font-size:17px}.trade-history-buckets p{margin:5px 0;font-size:13px;color:#b5c8d9}.trade-history-buckets .thb-heading{display:flex;flex-wrap:wrap;gap:6px 16px;align-items:baseline;justify-content:space-between}.trade-history-buckets svg{display:block;width:100%;height:auto;max-height:190px;min-height:130px;background:#091420;border-radius:8px}.trade-history-buckets .thb-selectors{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:5px;margin:6px 0}.trade-history-buckets button{min-width:44px;min-height:44px;margin:0;padding:5px 3px;border:1px solid #405c72;border-radius:7px;background:#142638;color:#e2edf7;font:inherit;font-size:12px;cursor:pointer;overflow-wrap:anywhere}.trade-history-buckets button[aria-pressed=true]{background:#26435e;border-color:#9fcfff}.trade-history-buckets button:focus-visible{outline:2px solid #ffcf7c;outline-offset:2px}.trade-history-buckets .thb-details{padding:8px 10px;border-radius:8px;background:#102436;overflow-wrap:anywhere}.trade-history-buckets .thb-details strong{display:block}.trade-history-buckets .thb-counts{display:flex;gap:6px 14px;flex-wrap:wrap;margin:5px 0}.trade-history-buckets .thb-counts div{font-size:12px}.trade-history-buckets .thb-counts dt,.trade-history-buckets .thb-counts dd{display:inline;margin:0}.trade-history-buckets .thb-counts dd{font-weight:750}.trade-history-buckets .thb-counts dt:after{content:': '}.trade-history-buckets details{margin-top:8px}.trade-history-buckets summary{min-height:44px;padding:12px 4px;cursor:pointer;font-size:13px}.trade-history-buckets summary:focus-visible{outline:2px solid #ffcf7c}.trade-history-buckets .thb-table-wrap{max-width:100%;overflow:auto;overscroll-behavior:contain}.trade-history-buckets table{width:100%;border-collapse:collapse;font-size:12px}.trade-history-buckets th,.trade-history-buckets td{padding:7px 4px;text-align:right;border-bottom:1px solid #2e465c;overflow-wrap:anywhere}.trade-history-buckets th:first-child{text-align:left}.trade-history-buckets .thb-error{color:#ffc4cc}.trade-history-buckets .thb-note{font-size:12px}.trade-history-buckets .thb-positive{color:#9ee5bc}.trade-history-buckets .thb-negative{color:#ff9aa9}
`;
const shortLabel=(bucket:Bucket)=>`${bucket.startBar}–${bucket.endBar??'end'}`;
const statusOf=(bucket:Bucket)=>!bucket.reachedCount?'No attempts reached this section.':!bucket.sampleCount?'Attempts reached this section, but no trades closed here.':bucket.points===0?'Closed trades netted zero points in this section.':`${formatHistoryPoints(bucket.points)} realized points in this section.`;
const pointLabel=(bucket:Bucket)=>bucket.reachedCount?formatHistoryPoints(bucket.points):'—';
const plotLabel=(bucket:Bucket)=>{const label=pointLabel(bucket);return label.length<=11?label:'≈'+(bucket.points>0?'+':'')+bucket.points.toExponential(1).replace('e+','e')};

/** Read-only view of committed local attempt summaries. No candles, storage or replay actions. */
export default function TradeHistoryBuckets({records,learnerId}:TradeHistoryBucketsProps){
  const parsed=useMemo(()=>{try{return {model:deriveTradeBuckets(records,learnerId) as Model,error:false}}catch{return {model:null,error:true}}},[records,learnerId]);
  const model=parsed.model,titleId=useId(),helpId=useId(),root=useRef<HTMLElement>(null),alive=useRef(true),latest=useRef(model),focusNext=useRef(false);latest.current=model;
  const [selection,setSelection]=useState<Selection>({model:null,index:0});
  const index=model?Math.max(0,Math.min(3,selection.model===model?selection.index:0)):0,selected=model?.buckets[index];
  const maximum=model?Math.max(1,...model.buckets.map(bucket=>Math.abs(bucket.points))):1;
  useEffect(()=>{alive.current=true;return()=>{alive.current=false}},[]);
  useEffect(()=>{if(focusNext.current){root.current?.querySelector<HTMLButtonElement>(`[data-trade-bucket-index="${index}"]`)?.focus({preventScroll:true});focusNext.current=false}},[model,index]);
  function choose(next:number,focus=false){if(!model||!alive.current||latest.current!==model||!model.reportCount)return;focusNext.current=focus;setSelection({model,index:Math.max(0,Math.min(3,next))})}
  function sectionKey(event:KeyboardEvent<HTMLButtonElement>,position:number){
    if(event.key==='Escape')return;event.stopPropagation();
    if(event.defaultPrevented||event.nativeEvent?.isComposing||event.nativeEvent?.keyCode===229||event.ctrlKey||event.metaKey||event.altKey||event.shiftKey)return;
    const key=event.key.toLowerCase(),moves:{[key:string]:number}={arrowleft:-1,a:-1,arrowup:-1,w:-1,arrowright:1,d:1,arrowdown:1,s:1};
    if(key==='enter'||key===' '){event.preventDefault();choose(position);return}
    if(key==='home'||key==='end'||Object.hasOwn(moves,key)){event.preventDefault();choose(key==='home'?0:key==='end'?3:position+moves[key],true)}
  }
  return <section ref={root} className="trade-history-buckets" aria-labelledby={titleId} onKeyDown={event=>{if(event.key!=='Escape')event.stopPropagation();}}>
    <style>{css}</style><div className="thb-heading"><h3 id={titleId}>Points by closing bar</h3>{model&&model.reportCount>0&&<strong data-trade-bucket-total={model.attributedPoints}>{formatHistoryPoints(model.attributedPoints)} allocated points</strong>}</div>
    <p id={helpId}>Each trade’s full realized points go to the section where it closed—not where it opened. All saved completed attempts, including replays, count.</p>
    {parsed.error?<p className="thb-error" role="alert">This breakdown is unavailable because the saved attempts could not be verified. Your saved history and its existing totals have not been changed. Reload history to try again.</p>:!model?.reportCount?<p role="status">Complete a Limit Orders Simulator session to see points by closing bar. Active attempts and pending orders are not counted.</p>:<>
      <svg viewBox="0 0 440 170" role="img" aria-label="Realized points in four closing-bar sections. Above zero is positive; below zero is negative." aria-describedby={helpId}>
        <line data-trade-bucket-zero="true" x1={22} x2={432} y1={84} y2={84} stroke="#8198ab" strokeDasharray="4 4"/><text x={5} y={88} fill="#bacddd" fontSize={10}>0</text>
        {model.buckets.map((bucket,i)=>{const h=Math.abs(bucket.points)/maximum*54,x=47+i*104,y=bucket.points>0?84-h:84,color=bucket.points>0?colors.positive:bucket.points<0?colors.negative:colors.zero;return <g key={bucket.id} data-trade-bucket-bar={bucket.id} data-points={bucket.points} data-samples={bucket.sampleCount}>
          <title>{bucket.label}: {pointLabel(bucket)} points. {statusOf(bucket)} {bucket.sampleCount} closed trades; {bucket.resultCount} attempts with a close; {bucket.reachedCount} attempts reached.</title>
          {bucket.points!==0?<rect x={x} y={y} width={42} height={h} rx={2} fill={color}/>:<line x1={x} x2={x+42} y1={84} y2={84} stroke={color} strokeWidth={bucket.reachedCount?3:1} strokeDasharray={bucket.reachedCount?undefined:'3 3'}/>}
          <text x={x+21} y={18} textAnchor="middle" fill={color} fontSize={12}>{plotLabel(bucket)}</text><text x={x+21} y={160} textAnchor="middle" fill="#b5c8d9" fontSize={12}>{shortLabel(bucket)}</text>
        </g>})}
      </svg>
      <div className="thb-selectors" role="group" aria-label="Inspect a closing-bar section">{model.buckets.map((bucket,i)=><button key={bucket.id} type="button" data-trade-bucket-index={i} aria-pressed={i===index} aria-label={`${bucket.label}. ${pointLabel(bucket)} points. ${bucket.sampleCount} closed trades. ${bucket.resultCount} attempts with a close. ${bucket.reachedCount} attempts reached.`} aria-keyshortcuts="ArrowLeft ArrowRight ArrowUp ArrowDown A D W S Home End" onClick={event=>{event.stopPropagation();choose(i)}} onKeyDown={event=>sectionKey(event,i)}>Bars {shortLabel(bucket)}</button>)}</div>
      <div className="thb-details" role="status" aria-live="polite" aria-atomic="true" data-trade-bucket-selected={selected!.id}><strong>{selected!.label} · <span className={selected!.points>0?'thb-positive':selected!.points<0?'thb-negative':''}>{pointLabel(selected!)} points</span></strong><p>{statusOf(selected!)}</p><dl className="thb-counts"><div><dt>Closed trades</dt><dd>{selected!.sampleCount}</dd></div><div><dt>Attempts with a close</dt><dd>{selected!.resultCount}</dd></div><div><dt>Attempts reaching section</dt><dd>{selected!.reachedCount}</dd></div></dl></div>
      <p className="thb-note">Reached means a completed attempt revealed at least the section’s first bar, even if no trade closed there. Bar numbers belong to the selected session; the last section stops at its actual end. Points, not cash.</p>
      {(model.unallocatedCount>0||model.missingScoreCount>0)&&<p className="thb-error" role="status">{model.unallocatedCount} saved attempts could not be allocated: {formatHistoryPoints(model.unallocatedPoints)} known points are excluded from these bars. {model.missingScoreCount>0?`${model.missingScoreCount} saved attempts have no verified point total.`:''}</p>}
      <details><summary>All four sections · points and counts</summary><div className="thb-table-wrap"><table><caption>Realized points by closing bar · all completed attempts and replays</caption><thead><tr><th scope="col">Bars</th><th scope="col">Points</th><th scope="col">Closed trades</th><th scope="col">Attempts with close</th><th scope="col">Attempts reached</th></tr></thead><tbody>{model.buckets.map(bucket=><tr key={bucket.id}><th scope="row">{shortLabel(bucket)}</th><td>{pointLabel(bucket)}</td><td>{bucket.sampleCount}</td><td>{bucket.resultCount}</td><td>{bucket.reachedCount}</td></tr>)}</tbody></table></div></details>
    </>}
  </section>;
}
