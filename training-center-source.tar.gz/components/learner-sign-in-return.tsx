'use client';
import LoadingIndicator from './loading-indicator';
import {useEffect,useState} from 'react';
import {browserGoogleDriver} from '../lib/learner/google-driver.mjs';
import {learnerClient} from '../lib/learner/client.mjs';
export default function LearnerSignInReturn(){
 const[status,setStatus]=useState('Confirming your Google sign-in…');
 useEffect(()=>{const controller=new AbortController();let live=true;void(async()=>{try{const driver=await browserGoogleDriver();if(!live)return;await driver.completeCallback({signal:controller.signal,url:window.location.href});if(!live)return;const result=await learnerClient.revalidate();if(!live)return;if(!result.ready||!result.profile||result!==learnerClient.getSnapshot()||!learnerClient.guard(learnerClient.captureContext()))throw Error();window.location.replace('/');}catch{if(live)setStatus('Sign-in was canceled or could not be confirmed. You can return and try again, or continue as Guest.');}})();return()=>{live=false;controller.abort();};},[]);
 return <main className="training-main"><h1>Learner sign-in</h1><p role="status">{status==='Confirming your Google sign-in…'?<LoadingIndicator label={status} />:status}</p><a href="/">Return to Price Action Center</a></main>;
}
