"use client";
import AppHeader from './app-navigation';
import { useEffect, useRef, useState, type FormEvent } from 'react';
import { passwordRequest } from './password-sign-in';

export function consumeEnrollmentFragment(location: Pick<Location, 'hash' | 'pathname' | 'search'>, history: Pick<History, 'replaceState'>) {
  const fragment = location.hash;
  history.replaceState(null, '', location.pathname + location.search);
  const match = /^#token=([a-f0-9]{64})$/i.exec(fragment);
  return match ? match[1] : '';
}

export default function ActivateAccount() {
  const [token, setToken] = useState<string | null>(null), [password, setPassword] = useState(''), [confirmation, setConfirmation] = useState(''), [busy, setBusy] = useState(false), [error, setError] = useState(''), [complete, setComplete] = useState(false);
  const mounted = useRef(false), initialized = useRef(false), inFlight = useRef(false), request = useRef<AbortController | null>(null);
  useEffect(() => {
    mounted.current = true;
    if (!initialized.current) { initialized.current = true; setToken(consumeEnrollmentFragment(window.location, window.history)); }
    return () => { mounted.current = false; request.current?.abort(); };
  }, []);
  async function submit(event: FormEvent) {
    event.preventDefault(); if (inFlight.current || !token) return;
    if (password.length < 14 || password.length > 128) { setError('Choose a password from 14 to 128 characters.'); return; }
    if (password !== confirmation) { setError('The passwords do not match.'); return; }
    const submittedPassword = password;
    inFlight.current = true; setBusy(true); setError(''); setPassword(''); setConfirmation('');
    const controller = new AbortController(); request.current = controller;
    try {
      await passwordRequest('/api/auth/enroll', { token, password: submittedPassword }, controller.signal);
      if (mounted.current && !controller.signal.aborted) { setToken(''); setComplete(true); }
    } catch (problem) { if (mounted.current && !controller.signal.aborted) setError(problem instanceof Error ? problem.message : 'Password setup could not be confirmed. Ask an administrator for a new link.'); }
    finally { inFlight.current = false; if (mounted.current) setBusy(false); }
  }
  return <div className="training-center"><AppHeader section="ACCOUNT SETUP" current="/activate" /><main className="admin-main"><p className="eyebrow">PRIVATE ACCOUNT SETUP</p><h1>Set your password</h1><section className="panel admin-login-panel">{complete ? <><h2>Password set</h2><p>Your one-use link has been consumed. Previous sessions have been revoked.</p><a className="primary-button" href="/admin">Go to Admin Login</a></> : token === null ? <p role="status">Opening your setup link…</p> : !token ? <><h2>A private setup/reset link is required</h2><p>Ask an administrator for a new link and open it directly. An email address alone cannot activate an account.</p><a href="/admin">Back to Admin Login</a></> : <><p>Choose a unique password of at least 14 characters. A password manager can create and save it for you. Do not share this link or password in chat.</p><form onSubmit={submit} style={{ display: 'grid', gap: 16, maxWidth: 480 }}><label htmlFor="new-account-password">New password<input id="new-account-password" type="password" autoComplete="new-password" required minLength={14} maxLength={128} value={password} onChange={event => setPassword(event.target.value)} disabled={busy} /></label><label htmlFor="confirm-account-password">Confirm password<input id="confirm-account-password" type="password" autoComplete="new-password" required minLength={14} maxLength={128} value={confirmation} onChange={event => setConfirmation(event.target.value)} disabled={busy} /></label>{error && <p className="notice error" role="alert">{error}</p>}<div><button className="primary-button" type="submit" disabled={busy || !password || !confirmation}>{busy ? 'Setting password…' : 'Set password'}</button></div><p className="field-help">This link can be used once. Setting a password signs out prior sessions for this account.</p></form></>}</section></main></div>;
}
