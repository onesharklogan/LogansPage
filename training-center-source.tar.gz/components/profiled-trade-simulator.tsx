'use client';
import SimulatorProfileGate from './simulator-profile-gate';
import TradeSimulator from './trade-simulator';
export default function ProfiledTradeSimulator(){return <SimulatorProfileGate section="TRADE SIMULATOR" current="/trade-simulator">{access=><TradeSimulator profileAccess={access}/>}</SimulatorProfileGate>;}
