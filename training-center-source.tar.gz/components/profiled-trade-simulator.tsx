'use client';
import SimulatorProfileGate from './simulator-profile-gate';
import AccountTradeSimulator from './account-trade-simulator';
import TradeSimulator from './trade-simulator';
export default function ProfiledTradeSimulator({accountsEnabled=false}:{accountsEnabled?:boolean}={}){if(accountsEnabled)return <AccountTradeSimulator/>;return <SimulatorProfileGate section="TRADE SIMULATOR" current="/trade-simulator">{access=><TradeSimulator profileAccess={access}/>}</SimulatorProfileGate>;}
