async function getJson(path, signal, fetcher, maxBytes) {
  const response = await fetcher(path, { signal, credentials:'same-origin' });
  if (!response.ok) throw new Error('Chart data could not be loaded. Try again.');
  const text = await response.text();
  if (new TextEncoder().encode(text).length > maxBytes) throw new Error('Chart data is too large.');
  return {data:JSON.parse(text),text};
}
/** @param {{signal?:AbortSignal,fetcher?:typeof fetch}} [options] */
export async function loadSimulatorCatalog({signal,fetcher=fetch}={}) {
  const {data}=await getJson('/charts/catalog.json',signal,fetcher,128*1024);
  if(data.version!==1||!Array.isArray(data.sessions)||!data.sessions.length||data.sessions.some(s=>!/^mes1-\d{4}-\d{2}-\d{2}-81$/.test(s.id)||s.url!==`/charts/${s.id}.json`||typeof s.title!=='string'||!/^[a-f0-9]{64}$/.test(s.sha256)))throw new Error('The chart catalog is invalid.');
  return data.sessions;
}
/** @param {{id:string,url:string,sha256:string}} reference @param {{signal?:AbortSignal,fetcher?:typeof fetch}} [options] */
export async function loadSimulatorChart(reference,{signal,fetcher=fetch}={}) {
  if(!/^mes1-\d{4}-\d{2}-\d{2}-81$/.test(reference.id)||reference.url!==`/charts/${reference.id}.json`)throw new Error('The chart reference is invalid.');
  const {data,text}=await getJson(reference.url,signal,fetcher,2*1024*1024);
  const hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text)))].map(x=>x.toString(16).padStart(2,'0')).join('');
  if(hash!==reference.sha256)throw new Error('The original chart integrity check failed.');
  if(data.id!==reference.id||!Array.isArray(data.current)||data.current.length<2||data.current.length>2000||data.current.some(c=>typeof c.t!=='string'||![c.o,c.h,c.l,c.c].every(Number.isFinite)||c.l>Math.min(c.o,c.c,c.h)||c.h<Math.max(c.o,c.c,c.l)))throw new Error('The original chart data is invalid.');
  return data;
}
