'use client';
import {useEffect,useRef,useState} from 'react';
import {learnerClient} from '../lib/learner/client.mjs';
import Profiles from '../public/modules/learner-profiles.js';
import {COMPLETION_EVENT,readCompletion,writeCompletion} from '../lib/learner/lesson-completion.mjs';
export type CompletionOwner={mode:'account'|'local'|'guest';id:string;capture?:any;profileKey?:string};
let loadingAccount:Promise<unknown>|null=null,checkingAccount:Promise<unknown>|null=null;
function restoreAccount(){if(checkingAccount)return;checkingAccount=learnerClient.revalidate().finally(()=>{checkingAccount=null;refreshMarks(true);});}
function refreshMarks(force=false){
 const capture=learnerClient.captureContext();if(capture?.mode!=='account'||!learnerClient.guard(capture)||loadingAccount)return;
 if(!force&&learnerClient.getSnapshot().completedLessons!==null)return;
 loadingAccount=learnerClient.loadLessonCompletions(capture).catch(()=>{}).finally(()=>{loadingAccount=null;const next=learnerClient.captureContext();if(next?.mode==='account'&&next.epoch!==capture.epoch)refreshMarks();});
}
export function useLessonCompletion(accountsEnabled=false){
 const [,render]=useState(0),live=useRef(false),[ready,setReady]=useState(false);
 function capture():CompletionOwner|null{
  if(typeof window==='undefined')return null;
  if(accountsEnabled){const value=learnerClient.captureContext();return value&&learnerClient.guard(value)?{mode:value.mode,id:value.context?.accountId||'guest',capture:value}:null;}
  try{const value=Profiles.read(window.localStorage);if(!value.ok)return null;return value.active&&Profiles.validLearnerId(value.active.learnerId)?{mode:'local',id:value.active.learnerId,profileKey:value.active.key}:{mode:'guest',id:'guest'};}catch{return null;}
 }
 function guard(owner:CompletionOwner){if(accountsEnabled)return !!owner.capture&&learnerClient.guard(owner.capture);const now=capture();return now?.mode===owner.mode&&now.id===owner.id&&now.profileKey===owner.profileKey;}
 useEffect(()=>{
  live.current=true;let triedFor='';
  const update=()=>{if(live.current){setReady(true);render(v=>v+1);const current=learnerClient.captureContext();const token=current?.mode==='account'?String(current.epoch):'';if(accountsEnabled&&token&&token!==triedFor){triedFor=token;refreshMarks();}}};
  const restore=()=>{update();if(accountsEnabled)restoreAccount();};
  const unsubscribe=accountsEnabled?learnerClient.subscribe(update):()=>{};
  window.addEventListener('storage',restore);window.addEventListener(COMPLETION_EVENT,restore);window.addEventListener('focus',restore);window.addEventListener('pageshow',restore);
  if(accountsEnabled&&!learnerClient.getSnapshot().ready&&!learnerClient.getSnapshot().revalidating)void learnerClient.refresh();update();
  return()=>{live.current=false;unsubscribe();window.removeEventListener('storage',restore);window.removeEventListener(COMPLETION_EVENT,restore);window.removeEventListener('focus',restore);window.removeEventListener('pageshow',restore);};
 },[accountsEnabled]);
 const owner=ready?capture():null;
 async function save(lessonKey:string,captured:CompletionOwner|null,completed=true){
  if(!live.current||!captured||!guard(captured))throw Error('Your learner profile changed or could not be verified. Reopen the Lesson after checking your profile.');
  if(captured.mode==='guest')return;
  if(captured.mode==='account'){
   await learnerClient.saveLessonCompletion(captured.capture,lessonKey,completed);
   if(!live.current||!guard(captured))throw Error('Your sign-in changed. Reopen the Lesson to check its saved status.');
   // Only a refresh hint, never account data. Account persistence does not depend on browser storage.
   try{window.localStorage.setItem('price-action-lesson-checkmarks-refresh',String(Date.now()));}catch{}
  }else writeCompletion({storage:window.localStorage,owner:captured,lessonKey,completed,guard,notify:()=>window.dispatchEvent(new Event(COMPLETION_EVENT))});
 }
 function completed(lessonKey:string){if(!owner||owner.mode==='guest')return false;if(owner.mode==='account')return learnerClient.getSnapshot().completedLessons?.includes(lessonKey)===true;try{return readCompletion(window.localStorage,owner,lessonKey);}catch{return false;}}
 const notice=owner?.mode==='account'?(learnerClient.getSnapshot().completedLessons===null&&learnerClient.getSnapshot().error?'Saved checkmarks could not be loaded. Finishing will retry saving this Lesson to your account.':'Lesson checkmarks are saved to your learner account.'):owner?.mode==='local'?'Lesson checkmarks are saved for this learner in this browser only.':owner?.mode==='guest'?'Guest completion is not saved. Sign in to keep checkmarks.':'Checking your learner profile…';
 return {capture,save,completed,ready,ownerKey:owner?owner.mode+':'+owner.id+(owner.capture?':'+owner.capture.epoch:''):null,notice};
}
export function LessonCompletionControl({lessonKey,accountsEnabled=false}:{lessonKey:string;accountsEnabled?:boolean}){
 const progress=useLessonCompletion(accountsEnabled),[busy,setBusy]=useState(false),[error,setError]=useState(''),pending=useRef(false),alive=useRef(false),scope=useRef('');
 scope.current=String(progress.ownerKey)+':'+lessonKey;const renderedScope=scope.current,renderedOwner=progress.capture();
 useEffect(()=>{alive.current=true;return()=>{alive.current=false;};},[]);
 const checked=progress.completed(lessonKey);
 useEffect(()=>{setError('');setBusy(false);pending.current=false;},[progress.ownerKey,lessonKey]);
 if(!checked&&!error)return null;
 return <div className="lesson-completion-control">{checked&&<button type="button" aria-label="Mark as new" aria-pressed={true} title="Completed. Mark as new." disabled={busy} style={{minWidth:44,minHeight:44}} onClick={async event=>{event.preventDefault();event.stopPropagation();if(pending.current||!alive.current||scope.current!==renderedScope)return;pending.current=true;const ticket=renderedScope;setBusy(true);setError('');try{await progress.save(lessonKey,renderedOwner,false);}catch(e){if(alive.current&&scope.current===ticket)setError((e as Error).message);}finally{if(alive.current&&scope.current===ticket){pending.current=false;setBusy(false);}}}}><span aria-hidden="true">✓</span> Completed<span className="sr-only"> — Mark as new</span></button>}{error&&<p role="alert">{error}</p>}</div>;
}
