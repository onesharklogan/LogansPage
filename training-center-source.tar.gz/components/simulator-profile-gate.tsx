'use client';

import {useEffect,useRef,useState,type ReactNode,type KeyboardEvent} from 'react';
import Profiles from '../public/modules/learner-profiles.js';
import AppHeader from './app-navigation';

type Profile={key:string;name:string};
type Snapshot={ok:boolean;profiles:Profile[];active:Profile|null;error:string|null;code?:string|null};
export type SimulatorProfileAccess={profile:Profile;guard:()=>boolean;choose:()=>void;registerSuspend:(fn:(()=>void)|null)=>void};
const empty:Snapshot={ok:false,profiles:[],active:null,error:null};

/** Shared local-profile entry boundary. No simulator is mounted before validation. */
export default function SimulatorProfileGate({children,section,current}:{children:(access:SimulatorProfileAccess)=>ReactNode;section:string;current:string}) {
  const [snapshot,setSnapshot]=useState<Snapshot>(empty),[profile,setProfile]=useState<Profile|null>(null),[open,setOpen]=useState(true),[ready,setReady]=useState(false),[busy,setBusy]=useState(false),[name,setName]=useState(''),[error,setError]=useState('');
  const owner=useRef<Profile|null>(null),opened=useRef(true),mounted=useRef(false),pending=useRef(false),generation=useRef(0),request=useRef(0),suspend=useRef<(()=>void)|null>(null),panel=useRef<HTMLDivElement>(null),input=useRef<HTMLInputElement>(null);
  const readCache=useRef<{storage:Storage;sourceKey:string|null;raw:string|null;snapshot:Snapshot}|null>(null);
  const read=():Snapshot=>{
    try {
      const storage=window.localStorage,primary=storage.getItem(Profiles.KEY);let sourceKey:string|null=primary===null?null:Profiles.KEY,raw=primary;
      if(primary===null)for(const key of Profiles.LEGACY_KEYS){const value=storage.getItem(key);if(value!==null){sourceKey=key;raw=value;break;}}
      const cached=readCache.current;if(cached&&cached.storage===storage&&cached.sourceKey===sourceKey&&cached.raw===raw)return cached.snapshot;
      // Validate the exact just-read bytes once. Unchanged pointer moves need no large JSON reparse.
      const snapshot=Profiles.read({getItem:(key:string)=>key===Profiles.KEY?primary:key===sourceKey?raw:null}) as Snapshot;
      readCache.current={storage,sourceKey,raw,snapshot};return snapshot;
    }catch{readCache.current=null;return{...empty,error:'Local profile storage is unavailable. Enable browser storage, then Retry.'};}
  };
  function invalidate(next:Snapshot) {suspend.current?.();generation.current+=1;owner.current=null;opened.current=true;setProfile(null);setOpen(true);setSnapshot(next);setError(next.error||'Choose a learner profile to continue.');}
  function refresh(initial=false) {
    const next=read();setReady(true);setSnapshot(next);
    if(!next.ok||!next.active){invalidate(next);return;}
    if(initial){owner.current=next.active;opened.current=false;setProfile(next.active);setOpen(false);setError('');return;}
    if(owner.current?.key!==next.active.key){invalidate(next);return;}
    setError('');
  }
  useEffect(()=>{
    mounted.current=true;refresh(true);
    const storage=(event:StorageEvent)=>{if(event.key===null||event.key===Profiles.KEY||['price-action-always-in-v3','price-action-always-in-v2','logans-always-in-v1'].includes(event.key)){suspend.current?.();refresh();}};
    const restore=()=>{suspend.current?.();refresh();};
    const visible=()=>{if(document.hidden)suspend.current?.();else restore();};
    window.addEventListener('storage',storage);window.addEventListener('pageshow',restore);window.addEventListener('focus',restore);window.addEventListener('pagehide',restore);document.addEventListener('visibilitychange',visible);
    return()=>{mounted.current=false;opened.current=true;request.current+=1;suspend.current?.();window.removeEventListener('storage',storage);window.removeEventListener('pageshow',restore);window.removeEventListener('focus',restore);window.removeEventListener('pagehide',restore);document.removeEventListener('visibilitychange',visible);};
  },[]);
  useEffect(()=>{if(open&&ready){if(snapshot.ok)input.current?.focus();else panel.current?.focus();}},[open,ready,snapshot.ok]);
  function choose() {suspend.current?.();opened.current=true;setOpen(true);setName('');setError('');setSnapshot(read());}
  function cancel() {
    if(pending.current||!owner.current)return;
    const next=read();setSnapshot(next);
    if(!next.ok||next.active?.key!==owner.current.key){invalidate(next);return;}
    opened.current=false;setOpen(false);setError('');request.current+=1;
    window.requestAnimationFrame(()=>document.querySelector<HTMLButtonElement>('[data-learner-profile-control]')?.focus());
  }
  async function mutate(kind:'create'|'select',value:string) {
    if(pending.current||!opened.current||!mounted.current)return;
    pending.current=true;setBusy(true);setError('');const ticket=++request.current;
    try {
      const options={storage:window.localStorage,locks:window.navigator.locks};
      const before=read();
      // Continuing the already-selected profile is read-only, even while MD holds its writer lock.
      const next=(kind==='select'&&before.ok&&before.active?.key===value?before:await(kind==='create'?Profiles.create(value,options):Profiles.select(value,options))) as Snapshot;
      if(!mounted.current||ticket!==request.current)return;
      if(!next.ok||!next.active){setSnapshot(read());setError(next.error||'The profile could not be selected. Try again.');return;}
      setSnapshot(next);
      const verified=read();if(!verified.ok||verified.active?.key!==next.active.key){invalidate(verified);return;}
      if(owner.current?.key!==verified.active.key)generation.current+=1;
      owner.current=verified.active;setProfile(verified.active);opened.current=false;setOpen(false);setError('');setName('');
    } catch {if(mounted.current&&ticket===request.current)setError('The profile could not be saved safely. Existing progress was not intentionally changed. Retry after checking browser storage.');}
    finally {if(mounted.current&&ticket===request.current){pending.current=false;setBusy(false);}}
  }
  function keys(event:KeyboardEvent<HTMLDivElement>) {
    event.stopPropagation();
    if(event.key==='Escape'){event.preventDefault();cancel();return;}
    if(event.key!=='Tab')return;
    const targets=Array.from(panel.current?.querySelectorAll<HTMLElement>('a[href],button:not([disabled]),input:not([disabled]),summary,[tabindex="0"]')||[]).filter(n=>!n.closest('[hidden],[inert]')&&(!n.closest('details:not([open])')||n.tagName==='SUMMARY'));
    if(!targets.length){event.preventDefault();panel.current?.focus();return;}
    const first=targets[0],last=targets[targets.length-1];
    if(event.shiftKey&&(document.activeElement===first||document.activeElement===panel.current||!panel.current?.contains(document.activeElement))){event.preventDefault();last.focus();}
    else if(!event.shiftKey&&(document.activeElement===last||document.activeElement===panel.current||!panel.current?.contains(document.activeElement))){event.preventDefault();first.focus();}
  }
  const renderGeneration=generation.current,renderOwner=profile?.key;
  const access:SimulatorProfileAccess|null=profile?{profile,choose,registerSuspend:fn=>{suspend.current=fn;},guard:()=>{
    if(!mounted.current||opened.current||renderGeneration!==generation.current||owner.current?.key!==renderOwner)return false;
    const next=read();if(!next.ok||next.active?.key!==renderOwner){invalidate(next);return false;}return true;
  }}:null;
  return <>
    {access&&<div key={`${profile!.key}:${renderGeneration}`} hidden={open} inert={open}>{children(access)}</div>}
    {open&&<div className="learner-profile-entry" role="dialog" aria-modal="true" aria-labelledby="learner-profile-title" aria-describedby="learner-profile-description" tabIndex={-1} ref={panel} onKeyDown={keys}>
      <AppHeader section={section} current={current}/>
      <section className="learner-profile-card">
        <p className="eyebrow">LOCAL LEARNER PROFILE</p><h1 id="learner-profile-title">Choose your practice profile</h1>
        <p id="learner-profile-description">Every simulator needs a profile. Use a nickname—no email or password. Profiles stay in this browser; this is not a teacher login.</p>
        {profile&&<p>Choosing a different profile starts a fresh simulator attempt. Return to keep this attempt paused.</p>}
        {!ready?<p role="status">Checking saved profiles…</p>:<>
          {error&&<p className="error" role="alert">{error}</p>}
          {!snapshot.ok?<button className="quiet-button" onClick={()=>refresh()}>Retry profile storage</button>:<>
            {snapshot.profiles.length>0&&<div className="learner-profile-list" aria-label="Saved learner profiles">{snapshot.profiles.map(item=><button key={item.key} className="quiet-button" disabled={busy} onClick={()=>mutate('select',item.key)}>Use {item.name}{item.key===snapshot.active?.key?' · selected':''}</button>)}</div>}
            <form onSubmit={event=>{event.preventDefault();void mutate('create',name);}}><label htmlFor="learner-profile-name">New profile nickname</label><input id="learner-profile-name" ref={input} autoComplete="off" maxLength={32} value={name} disabled={busy} onChange={event=>setName(event.target.value)} required/><button className="primary-button" disabled={busy||!name.trim()} type="submit">{busy?'Saving profile…':'Create profile & enter'}</button></form>
          </>}
        </>}
        {profile&&<div className="learner-profile-actions"><button className="quiet-button" disabled={busy} onClick={cancel}>Return to {profile.name}</button></div>}
        <p className="muted">Existing Market Direction profiles and history are shared here. Clearing browser storage removes local profiles.</p>
      </section>
    </div>}
  </>;
}
