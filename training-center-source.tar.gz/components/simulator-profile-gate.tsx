'use client';

import {useEffect,useRef,useState,type ReactNode,type KeyboardEvent} from 'react';
import Profiles from '../public/modules/learner-profiles.js';
import AppHeader from './app-navigation';

type Profile={key:string;name:string;learnerId?:string};
type IdentifiedProfile=Profile&{learnerId:string};
const identified=(profile:Profile|null):profile is IdentifiedProfile=>!!profile&&Profiles.validLearnerId(profile.learnerId);
const same=(a:Profile|null|undefined,b:Profile|null|undefined)=>!!a&&!!b&&a.key===b.key&&a.learnerId===b.learnerId;
type Snapshot={ok:boolean;profiles:Profile[];active:Profile|null;error:string|null;code?:string|null};
export type SimulatorProfileAccess={mode?:'local'|'account'|'guest';store?:ReturnType<typeof import('../lib/learner/trade-adapter.mjs').createAccountTradeAdapter>;profile:IdentifiedProfile;guard:()=>boolean;choose:()=>void;registerSuspend:(fn:(()=>void)|null)=>void;registerHistory?:(fn:(()=>void)|null)=>void;registerNavigationGuard?:(fn:(()=>boolean)|null)=>void};
const empty:Snapshot={ok:false,profiles:[],active:null,error:null};

/** Shared local-profile entry boundary. No simulator is mounted before validation. */
export default function SimulatorProfileGate({children,section,current}:{children:(access:SimulatorProfileAccess)=>ReactNode;section:string;current:string}) {
  const [snapshot,setSnapshot]=useState<Snapshot>(empty),[profile,setProfile]=useState<IdentifiedProfile|null>(null),[open,setOpen]=useState(true),[ready,setReady]=useState(false),[busy,setBusy]=useState(false),[name,setName]=useState(''),[error,setError]=useState(''),[view,setView]=useState<'choose'|'details'>('choose');
  const owner=useRef<IdentifiedProfile|null>(null),opened=useRef(true),mounted=useRef(false),pending=useRef(false),generation=useRef(0),request=useRef(0),suspend=useRef<(()=>void)|null>(null),panel=useRef<HTMLDivElement>(null),input=useRef<HTMLInputElement>(null),closeButton=useRef<HTMLButtonElement>(null),mode=useRef<'choose'|'details'>('choose'),history=useRef<(()=>void)|null>(null),navigation=useRef<(()=>boolean)|null>(null);
  const readCache=useRef<{storage:Storage;sourceKey:string|null;raw:string|null;snapshot:Snapshot}|null>(null);
  const read=():Snapshot=>{
    try {
      const storage=window.localStorage,primary=storage.getItem(Profiles.KEY);let sourceKey:string|null=primary===null?null:Profiles.KEY,raw=primary;
      if(primary===null)for(const key of Profiles.LEGACY_KEYS){const value=storage.getItem(key);if(value!==null){sourceKey=key;raw=value;break;}}
      const cached=readCache.current;if(cached&&cached.storage===storage&&cached.sourceKey===sourceKey&&cached.raw===raw)return cached.snapshot;
      // Validate the exact just-read bytes once. Unchanged pointer moves need no large JSON reparse.
      const snapshot=Profiles.read({getItem:(key:string)=>key===Profiles.KEY?primary:key===sourceKey?raw:null}) as Snapshot;
      readCache.current={storage,sourceKey,raw,snapshot};return snapshot;
    }catch{readCache.current=null;return{...empty,error:'Local profile storage is unavailable. Enable browser storage, then Retry.'};}
  };
  function invalidate(next:Snapshot) {suspend.current?.();generation.current+=1;owner.current=null;opened.current=true;mode.current='choose';suspend.current=null;history.current=null;navigation.current=null;setView('choose');setProfile(null);setOpen(true);setSnapshot(next);setError(next.error||'Choose a learner profile to continue.');}
  function refresh(initial=false) {
    const next=read();setReady(true);setSnapshot(next);
    if(!next.ok||!identified(next.active)){invalidate(next);return;}
    if(initial){owner.current=next.active;opened.current=false;setProfile(next.active);setOpen(false);setError('');return;}
    if(!same(owner.current,next.active)){invalidate(next);return;}
    setError('');
  }
  useEffect(()=>{
    mounted.current=true;refresh(true);
    const storage=(event:StorageEvent)=>{if(event.key===null||event.key===Profiles.KEY||['price-action-always-in-v3','price-action-always-in-v2','logans-always-in-v1'].includes(event.key)){suspend.current?.();refresh();}};
    const restore=()=>{suspend.current?.();refresh();};
    const visible=()=>{if(document.hidden)suspend.current?.();else restore();};
    window.addEventListener('storage',storage);window.addEventListener('pageshow',restore);window.addEventListener('focus',restore);window.addEventListener('pagehide',restore);document.addEventListener('visibilitychange',visible);
    return()=>{mounted.current=false;opened.current=true;request.current+=1;suspend.current?.();window.removeEventListener('storage',storage);window.removeEventListener('pageshow',restore);window.removeEventListener('focus',restore);window.removeEventListener('pagehide',restore);document.removeEventListener('visibilitychange',visible);};
  },[]);
  useEffect(()=>{if(open&&ready){if(view==='details')closeButton.current?.focus();else if(snapshot.ok)input.current?.focus();else panel.current?.focus();}},[open,ready,snapshot.ok,view]);
  const renderGeneration=generation.current,renderOwner=profile;
  function ownsCurrent() {return mounted.current&&renderGeneration===generation.current&&same(owner.current,renderOwner);}
  function verifyOwner() {
    if(!ownsCurrent())return false;
    const next=read();setSnapshot(next);if(!next.ok||!same(next.active,renderOwner)){invalidate(next);return false;}return true;
  }
  function navigationReady() {try{return navigation.current?.()===true;}catch{return false;}}
  function navigationAllowed() {
    if(!verifyOwner())return false;
    if(!navigationReady()){setError('This attempt is not safely saved yet. Close this panel and retry the save before switching profiles or opening another simulator.');return false;}return true;
  }
  function choose() {
    if(!verifyOwner())return;
    suspend.current?.();opened.current=true;mode.current='details';setView('details');setOpen(true);setName('');setError('');
  }
  function closeOwned(restoreFocus=true) {
    if(pending.current||!opened.current||!verifyOwner())return false;
    opened.current=false;setOpen(false);setError('');request.current+=1;
    if(restoreFocus)window.requestAnimationFrame(()=>document.querySelector<HTMLButtonElement>('[data-learner-profile-control]')?.focus());
    return true;
  }
  function cancel() {closeOwned();}
  function switchProfile() {
    if(!opened.current||mode.current!=='details'||!navigationAllowed())return;
    mode.current='choose';setView('choose');setName('');setError('');
  }
  function showHistory() {
    if(!opened.current||mode.current!=='details'||!verifyOwner())return;
    const callback=history.current;if(!callback){setError('Trade Simulator history is not ready yet. Close this panel and try again.');return;}
    // Reopen the current instance's read guard BEFORE its local History handler runs.
    if(closeOwned(false))callback();
  }
  function navigatePanel(event:{preventDefault:()=>void;stopPropagation:()=>void}) {
    event.stopPropagation();if(owner.current&&(!opened.current||!navigationAllowed()))event.preventDefault();
  }
  function navigateHistory(event:{preventDefault:()=>void;stopPropagation:()=>void}) {
    event.stopPropagation();if(!opened.current||mode.current!=='details'||!navigationAllowed())event.preventDefault();
  }
  async function mutate(kind:'create'|'select',value:string) {
    if(pending.current||!opened.current||!mounted.current||mode.current!=='choose')return;
    if(owner.current&&(!ownsCurrent()||!navigationAllowed()))return;
    pending.current=true;setBusy(true);setError('');const ticket=++request.current;
    try {
      const options={storage:window.localStorage,locks:window.navigator.locks};
      const before=read();
      // Identified same-profile entry stays read-only; explicit legacy entry acquires the writer lock.
      const next=(kind==='select'&&before.ok&&before.active?.key===value&&identified(before.active)?before:await(kind==='create'?Profiles.create(value,options):Profiles.select(value,options))) as Snapshot;
      if(!mounted.current||ticket!==request.current)return;
      if(!next.ok||!identified(next.active)){setSnapshot(read());setError(next.error||'The profile could not be selected. Try again.');return;}
      setSnapshot(next);
      const verified=read();if(!verified.ok||!identified(verified.active)||!same(verified.active,next.active)){invalidate(verified);return;}
      if(!same(owner.current,verified.active)){generation.current+=1;suspend.current=null;history.current=null;navigation.current=null;}
      owner.current=verified.active;setProfile(verified.active);opened.current=false;setOpen(false);setError('');setName('');
    } catch {if(mounted.current&&ticket===request.current)setError('The profile could not be saved safely. Existing progress was not intentionally changed. Retry after checking browser storage.');}
    finally {if(mounted.current&&ticket===request.current){pending.current=false;setBusy(false);}}
  }
  function keys(event:KeyboardEvent<HTMLDivElement>) {
    event.stopPropagation();
    if(event.key==='Escape'){event.preventDefault();cancel();return;}
    if(event.key!=='Tab')return;
    const targets=Array.from(panel.current?.querySelectorAll<HTMLElement>('a[href],button:not([disabled]),input:not([disabled]),summary,[tabindex="0"]')||[]).filter(n=>!n.closest('[hidden],[inert]')&&(!n.closest('details:not([open])')||n.tagName==='SUMMARY'));
    if(!targets.length){event.preventDefault();panel.current?.focus();return;}
    const first=targets[0],last=targets[targets.length-1];
    if(event.shiftKey&&(document.activeElement===first||document.activeElement===panel.current||!panel.current?.contains(document.activeElement))){event.preventDefault();last.focus();}
    else if(!event.shiftKey&&(document.activeElement===last||document.activeElement===panel.current||!panel.current?.contains(document.activeElement))){event.preventDefault();first.focus();}
  }
  const access:SimulatorProfileAccess|null=profile?{profile,choose,registerSuspend:fn=>{if(ownsCurrent())suspend.current=fn;},registerHistory:fn=>{if(ownsCurrent())history.current=fn;},registerNavigationGuard:fn=>{if(ownsCurrent())navigation.current=fn;},guard:()=>{
    if(!mounted.current||opened.current||renderGeneration!==generation.current||!same(owner.current,renderOwner))return false;
    const next=read();if(!next.ok||!same(next.active,renderOwner)){invalidate(next);return false;}return true;
  }}:null;
  const details=view==='details'&&!!profile,canNavigate=details&&navigationReady();
  return <>
    {access&&<div key={`${profile!.learnerId}:${renderGeneration}`} hidden={open} inert={open}>{children(access)}</div>}
    {open&&<div className="learner-profile-entry" role="dialog" aria-modal="true" aria-labelledby="learner-profile-title" aria-describedby="learner-profile-description" tabIndex={-1} ref={panel} onKeyDown={keys}>
      <div onAuxClickCapture={navigatePanel} onContextMenuCapture={navigatePanel}><AppHeader section={section} current={current} onNavigate={navigatePanel}/></div>
      <section className="learner-profile-card">
        {details?<>
          <div style={{display:'flex',alignItems:'start',justifyContent:'space-between',gap:12}}>
            <div><p className="eyebrow">LOCAL BROWSER PROFILE</p><h1 id="learner-profile-title">{profile.name}</h1></div>
            <button ref={closeButton} className="quiet-button" type="button" aria-label="Close profile details" title="Close profile details" style={{minWidth:44,minHeight:44,flexShrink:0}} onClick={cancel}>×</button>
          </div>
          <p id="learner-profile-description">Your practice belongs to this local browser profile—not a teacher account. Your current attempt stays paused while you view profile details.</p>
          {error&&<p className="error" role="alert">{error}</p>}
          {!canNavigate&&<p role="status">A save is pending or needs attention. You can close this panel or view local Trade history. Close and retry the save before leaving this attempt.</p>}
          <div className="learner-profile-actions">
            <button className="primary-button" type="button" onClick={showHistory}>Trade Simulator history</button>
            <a className="quiet-button" href={canNavigate?'/market-direction?history=1':undefined} aria-disabled={!canNavigate} onClick={navigateHistory} onAuxClick={navigateHistory} onContextMenu={event=>{if(!navigationAllowed())event.preventDefault();}}>Market Direction history</a>
          </div>
          <p className="muted">History stays in this browser. Opening Market Direction leaves this simulator. Saved attempts stay in this browser and remain available when you return.</p>
          <div className="learner-profile-actions"><button className="quiet-button" type="button" aria-disabled={!canNavigate} onClick={switchProfile}>Switch profile</button></div>
        </>:<>
          <p className="eyebrow">LOCAL LEARNER PROFILE</p><h1 id="learner-profile-title">Choose your practice profile</h1>
          <p id="learner-profile-description">Every simulator needs a profile. Use a nickname—no email or password. Profiles stay in this browser; this is not a teacher login.</p>
          {profile&&<p>Choosing another profile keeps its practice separate. Return to keep this attempt paused.</p>}
          {!ready?<p role="status">Checking saved profiles…</p>:<>
            {error&&<p className="error" role="alert">{error}</p>}
            {!snapshot.ok?<button className="quiet-button" onClick={()=>refresh()}>Retry profile storage</button>:<>
              {snapshot.profiles.length>0&&<div className="learner-profile-list" aria-label="Saved learner profiles">{snapshot.profiles.map(item=><button key={item.key} className="quiet-button" disabled={busy} onClick={()=>mutate('select',item.key)}>Use {item.name}{item.key===snapshot.active?.key?' · selected':''}</button>)}</div>}
              <form onSubmit={event=>{event.preventDefault();void mutate('create',name);}}><label htmlFor="learner-profile-name">New profile nickname</label><input id="learner-profile-name" ref={input} autoComplete="off" maxLength={32} value={name} disabled={busy} onChange={event=>setName(event.target.value)} required/><button className="primary-button" disabled={busy||!name.trim()} type="submit">{busy?'Saving profile…':'Create profile & enter'}</button></form>
            </>}
          </>}
          {profile&&<div className="learner-profile-actions"><button className="quiet-button" disabled={busy} onClick={cancel}>Return to {profile.name}</button></div>}
          <p className="muted">Existing Market Direction profiles and history are shared here. Clearing browser storage removes local profiles.</p>
        </>}
      </section>
    </div>}
  </>;
}
