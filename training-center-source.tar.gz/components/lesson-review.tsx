"use client";

import { useEffect, useState } from 'react';
import { loadLessonReview } from './lesson-review-data.mjs';
import type { Lesson } from './portal';

type Point = { bar: number; t: string; price: number };
type Preview = {
  lesson: { title: string; purpose: string; notes: string; session: { date: string }; lines: { id: string; a: Point; b: Point; label: string }[]; annotations: { id: string; at: Point; text: string }[] };
  candles: { t: string; o: number; h: number; l: number; c: number }[];
};

function Chart({ data }: { data: Preview }) {
  const { lesson, candles } = data;
  const W = 960, H = 470, L = 66, R = 20, T = 24, B = 42;
  const marks = [...lesson.lines.flatMap(line => [line.a.price, line.b.price]), ...lesson.annotations.map(mark => mark.at.price)];
  const minimum = Math.min(...candles.map(c => c.l), ...marks), maximum = Math.max(...candles.map(c => c.h), ...marks);
  const padding = Math.max((maximum - minimum) * 0.08, 0.5), lo = minimum - padding, hi = maximum + padding;
  const x = (bar: number) => L + (bar + 0.5) / candles.length * (W - L - R);
  const y = (price: number) => T + (hi - price) / (hi - lo) * (H - T - B);
  const barWidth = Math.max(1.2, (W - L - R) / candles.length * 0.65);
  const short = (value: string) => value.length > 42 ? value.slice(0, 39) + '…' : value;
  return <svg className="saved-chart" viewBox={`0 0 ${W} ${H}`} role="img" aria-label={`${lesson.title}: original price candles with ${lesson.lines.length} saved lines and ${lesson.annotations.length} labels`}>
    <title>{lesson.title} — {lesson.session.date}</title>
    <rect width={W} height={H} fill="#091521" rx="9" />
    {Array.from({ length: 6 }, (_, i) => { const price = lo + (hi - lo) * i / 5, level = y(price); return <g key={i}><line x1={L} x2={W - R} y1={level} y2={level} stroke="#243749" /><text x={L - 9} y={level + 4} textAnchor="end" fill="#9bb3c9" fontSize="12">{price.toFixed(2)}</text></g>; })}
    {candles.map((candle, i) => { const color = candle.c >= candle.o ? '#8dd6b3' : '#f09b9b'; return <g key={candle.t}><line x1={x(i)} x2={x(i)} y1={y(candle.h)} y2={y(candle.l)} stroke={color} strokeWidth="1.3" /><rect x={x(i) - barWidth / 2} y={Math.min(y(candle.o), y(candle.c))} width={barWidth} height={Math.max(1.2, Math.abs(y(candle.o) - y(candle.c)))} fill={color} /><title>{candle.t} · O {candle.o} H {candle.h} L {candle.l} C {candle.c}</title></g>; })}
    {lesson.lines.map(line => <g key={line.id}><line x1={x(line.a.bar)} y1={y(line.a.price)} x2={x(line.b.bar)} y2={y(line.b.price)} stroke="#ffd17f" strokeWidth="2.6" /><circle cx={x(line.a.bar)} cy={y(line.a.price)} r="3.4" fill="#ffd17f" /><circle cx={x(line.b.bar)} cy={y(line.b.price)} r="3.4" fill="#ffd17f" />{line.label && <text x={Math.min(W - 260, Math.max(L + 5, x(line.b.bar) + 6))} y={Math.max(T + 14, y(line.b.price) - 9)} fill="#ffe1a9" fontSize="13" paintOrder="stroke" stroke="#091521" strokeWidth="4" strokeLinejoin="round">{short(line.label)}</text>}<title>{line.label || 'Saved line'}</title></g>)}
    {lesson.annotations.map(mark => <g key={mark.id}><circle cx={x(mark.at.bar)} cy={y(mark.at.price)} r="3" fill="#9bd1ff" /><text x={Math.min(W - 280, Math.max(L + 5, x(mark.at.bar) + 7))} y={Math.max(T + 14, y(mark.at.price) - 9)} fill="#b4ddff" fontSize="13" paintOrder="stroke" stroke="#091521" strokeWidth="4" strokeLinejoin="round">{short(mark.text)}</text><title>{mark.text}</title></g>)}
    {Array.from(new Set([0, Math.floor((candles.length - 1) / 4), Math.floor((candles.length - 1) / 2), Math.floor((candles.length - 1) * 3 / 4), candles.length - 1])).map(i => <text key={i} x={x(i)} y={H - 16} fill="#9bb3c9" fontSize="12" textAnchor="middle">{candles[i].t.slice(-5)}</text>)}
  </svg>;
}

export default function SavedLessonReview({ lesson }: { lesson: Lesson }) {
  const [preview, setPreview] = useState<Preview | null>(null);
  const [error, setError] = useState('');
  useEffect(() => {
    const controller = new AbortController();
    setPreview(null); setError('');
    loadLessonReview(lesson, { signal: controller.signal }).then(value => { if (!controller.signal.aborted) setPreview(value as Preview); }).catch(problem => { if (!controller.signal.aborted) setError(problem instanceof Error ? problem.message : 'The saved preview could not be loaded.'); });
    return () => controller.abort();
  }, [lesson]);
  if (error) return <p className="notice error" role="alert">{error} Your saved text has not been changed.</p>;
  if (!preview) return <p className="notice info" role="status">Recreating the chart from the saved lesson text…</p>;
  return <section className="saved-lesson-review" aria-label="Saved chart and lesson notes"><p className="review-purpose">{preview.lesson.purpose} · {preview.lesson.session.date}</p><div className="saved-chart-scroll"><Chart data={preview} /></div><p className="field-help">{preview.lesson.lines.length} lines · {preview.lesson.annotations.length} labels · recreated in your browser, no stored image.</p><h3>Lesson notes</h3><p className="saved-lesson-notes">{preview.lesson.notes || 'No notes were added.'}</p>{(preview.lesson.lines.some(line => line.label) || preview.lesson.annotations.length > 0) && <details className="review-mark-list"><summary>All line labels & annotations</summary><ul>{preview.lesson.lines.filter(line => line.label).map(line => <li key={line.id}>{line.label}</li>)}{preview.lesson.annotations.map(mark => <li key={mark.id}>{mark.text}</li>)}</ul></details>}</section>;
}
