'use client';
import {useId} from 'react';
import {DAY_TYPE_FILTERS,DAY_TYPE_CATALOG} from '../lib/day-types.mjs';
import {dayTypeHistoryCounts} from '../lib/day-type-history.mjs';
export default function DayTypeHistoryFilter({value,onChange,rows,total,firstRuns=false}:{value:string;onChange:(value:string)=>void;rows:any[];total:number;firstRuns?:boolean}){
 const id=useId(),counts=dayTypeHistoryCounts(rows);
 return <section aria-labelledby={id} style={{margin:'16px 0',padding:12,border:'1px solid #405c72',borderRadius:10}} onKeyDown={event=>{if(event.key!=='Escape')event.stopPropagation();}}>
 <h4 id={id} style={{margin:'0 0 8px'}}>Filter by day type</h4>
 <div role="group" aria-label="Day type" style={{display:'flex',flexWrap:'wrap',gap:6}}>{DAY_TYPE_FILTERS.map(({id,label}:{id:string;label:string})=><button type="button" key={id} aria-pressed={value===id} onClick={()=>onChange(id)} style={{minHeight:44,padding:'7px 10px',borderRadius:8,border:value===id?'2px solid #9fcfff':'1px solid #405c72',background:value===id?'#26435e':'#142638',color:'#e2edf7',cursor:'pointer'}}>{label}</button>)}</div>
 <p role="status" style={{fontSize:13}}>{counts.attempts} of {total} completed {firstRuns?'first-run results':'attempts'} · {counts.uniqueDays} unique classified source days{counts.undated?` · ${counts.undated} unclassified / undated results`:''}. {!firstRuns&&'Replays count as separate attempts, not independent days.'}</p>
 <p style={{fontSize:12}}>Full-day heuristic labels ({DAY_TYPE_CATALOG.algorithmVersion}), not verified trading signals. Upper/lower ranges overlaps trending trading range; category totals are not additive. {counts.uniqueDays<20?'Small sample: avoid judging a strength or weakness from a few days.':'Compare across many distinct days; repeated practice can bias results.'} <a href="/day-type-search">Explore day types</a></p>
 </section>;
}
