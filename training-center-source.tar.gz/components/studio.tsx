"use client";
import TeacherWorkspace from "./teacher-workspace";
export default function Studio(){return <TeacherWorkspace current="/studio"/>;}
