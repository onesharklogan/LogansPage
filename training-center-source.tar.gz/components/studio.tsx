"use client";

import { useCallback, useEffect, useRef, useState, type MouseEvent } from "react";
import { api, Brand, Icon, type PortalStatus } from "./portal";

type EditorApi = { pause?: () => void; resume?: () => void; setMode: (mode: string) => void; configureAuthorLibrary: (config: { enabled: boolean; folderId?: string; lessonId?: string }) => unknown };
type EditorWindow = Window & { Trendlines?: EditorApi };

function safeId(value: string | null) { return value && /^[a-zA-Z0-9_-]{1,90}$/.test(value) ? value : undefined; }

export default function Studio() {
  const [status, setStatus] = useState<PortalStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [ready, setReady] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [saved, setSaved] = useState("");
  const frame = useRef<HTMLIFrameElement>(null);
  const configured = useRef(false);
  const mounted = useRef(false);
  const navigating = useRef(false);
  const lifecycle = useRef(0);
  const dirtyRef = useRef(false);
  const configRef = useRef<{ enabled: boolean; folderId?: string; lessonId?: string }>({ enabled: true });

  useEffect(() => {
    mounted.current = true; navigating.current = false;
    const generation = ++lifecycle.current;
    const request = new AbortController();
    const params = new URLSearchParams(window.location.search);
    configRef.current = { enabled: true, folderId: safeId(params.get("folderId")), lessonId: safeId(params.get("lessonId")) };
    const active = () => mounted.current && !navigating.current && lifecycle.current === generation;
    api<PortalStatus>("/api/status", { signal: request.signal }).then(value => { if (active()) setStatus(value); }).catch(error => { if (active() && !request.signal.aborted) setError(error.message); }).finally(() => { if (active()) setLoading(false); });
    return () => { mounted.current = false; lifecycle.current += 1; configured.current = false; request.abort(); };
  }, []);

  const configure = useCallback(async () => {
    if (configured.current || !mounted.current || navigating.current) return;
    const generation = lifecycle.current;
    const child = frame.current?.contentWindow as EditorWindow | null;
    const active = () => mounted.current && !navigating.current && generation === lifecycle.current && frame.current?.contentWindow === child;
    try {
      const editor = child?.Trendlines;
      if (!editor?.configureAuthorLibrary) return;
      configured.current = true; editor.setMode("studio");
      await editor.configureAuthorLibrary(configRef.current);
      if (!active()) return;
      editor.resume?.(); setReady(true);
    } catch {
      if (!active()) return;
      configured.current = false; setError("The editor could not initialize its online library. Reload this page before making changes.");
    }
  }, []);

  useEffect(() => {
    function onMessage(event: MessageEvent) {
      if (!mounted.current || navigating.current || event.origin !== window.location.origin || event.source !== frame.current?.contentWindow || !event.data || typeof event.data !== "object") return;
      if (event.data.type === "priceaction:editor-ready") configure();
      if (event.data.type === "priceaction:editor-dirty" && typeof event.data.dirty === "boolean") { dirtyRef.current = event.data.dirty; setDirty(event.data.dirty); if (event.data.dirty) setSaved(""); }
      if (event.data.type === "priceaction:editor-saved" && typeof event.data.lessonId === "string" && Number.isSafeInteger(event.data.revision) && event.data.revision > 0) {
        const remainsDirty = event.data.dirty === true;
        dirtyRef.current = remainsDirty; setDirty(remainsDirty); setSaved(remainsDirty ? "" : `Saved online · revision ${event.data.revision}`);
      }
    }
    function beforeUnload(event: BeforeUnloadEvent) { if (dirtyRef.current) { event.preventDefault(); event.returnValue = ""; } }
    window.addEventListener("message", onMessage); window.addEventListener("beforeunload", beforeUnload);
    return () => { window.removeEventListener("message", onMessage); window.removeEventListener("beforeunload", beforeUnload); };
  }, [configure]);

  function leave(event: MouseEvent<HTMLAnchorElement>) {
    if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
    if (dirtyRef.current) {
      if (!window.confirm("This lesson has changes that are not saved online. Leave the editor anyway?")) { event.preventDefault(); return; }
      dirtyRef.current = false;
    }
    navigating.current = true; lifecycle.current += 1;
  }

  return <div className="editor-shell"><header className="topbar editor-topbar"><Brand onClick={leave} /><nav aria-label="Editor navigation"><a className="quiet-button" href="/" onClick={leave}><Icon name="arrow" /> Lesson library</a><a className="return-link" href="https://priceaction.onrender.com/" onClick={leave}>PriceAction ↗</a></nav></header>
    {loading ? <main className="editor-gate panel"><p className="eyebrow">AUTHOR WORKSPACE</p><h1>Checking author access…</h1><p>Confirming your session before opening the editor.</p></main> : error ? <main className="editor-gate panel"><h1>The editor isn’t ready yet</h1><p className="notice error" role="alert">{error}</p><a className="primary-button" href="/">Return to library</a></main> : !status?.author ? <main className="editor-gate panel"><p className="eyebrow">AUTHOR ACCESS</p><h1>{status?.googleConfigured ? "Sign in to create lessons." : "Author sign-in is not available yet."}</h1><p>{status?.googleConfigured ? "Sign in with an approved Google account on the library page. Google handles sign-in, and the server checks author access on every online save." : "Google author sign-in has not been configured. You can still review the saved public lessons."}</p><a className="primary-button" href={status?.googleConfigured ? "/?signin=1" : "/"}>{status?.googleConfigured ? "Open Google sign-in →" : "Return to public library"}</a></main> : !status.storageReady ? <main className="editor-gate panel"><h1>Online storage isn’t ready.</h1><p>Saving is disabled. Return to the library to check the connection before creating a lesson.</p><a className="primary-button" href="/">Return to library</a></main> : <main className="editor-workspace"><div className="editor-statusbar"><span><span className={`status-dot ${dirty ? "unsaved" : ""}`} />{dirty ? "Changes not saved online" : saved || (ready ? "Author mode · save inside the editor" : "Opening lesson editor…")}</span><span>Chart reference, lines, labels and notes saved as text</span></div><iframe ref={frame} src="/editor/index.html?mode=studio&online=1" title="Teacher Studio lesson editor" className="editor-frame" onLoad={configure} allow="fullscreen" /></main>}
  </div>;
}
