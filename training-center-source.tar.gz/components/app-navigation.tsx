'use client';

import { useEffect, useRef, type MouseEvent, type ReactNode } from 'react';

export type NavigateHandler = (event: MouseEvent<HTMLAnchorElement>) => void;
const destinations = [
  ['/', 'Home'], ['/market-direction', 'Market Direction Simulator'], ['/trade-simulator', 'Trade Simulator'],
  ['/library', 'Module Library'], ['/studio', 'Teacher Studio'], ['/admin', 'Admin'],
] as const;

export function CandleMark() {
  return <svg className="app-candle-mark" viewBox="0 0 52 48" aria-hidden="true" focusable="false"><g fill="none" strokeWidth="1"><path d="M7 11v30M20 1v39M33 20v27M46 1v34" stroke="#9ad1ff"/><path d="M20 1v39" stroke="#ffcf7c"/></g><path fill="#9ad1ff" d="M3 20h8v14H3zM29 28h8v14h-8zM42 8h8v21h-8z"/><path fill="#ffcf7c" d="M16 7h8v27h-8z"/></svg>;
}

/** Navigation only: no account lookup, storage writes, or inferred student profile. */
export default function AppHeader({ section, current, onNavigate, children, className = '' }: {
  section: string; current?: string; onNavigate?: NavigateHandler; children?: ReactNode; className?: string;
}) {
  const menu = useRef<HTMLDetailsElement>(null);
  useEffect(() => {
    const outside = (event: globalThis.PointerEvent) => { if (menu.current?.open && !menu.current.contains(event.target as Node)) menu.current.open = false; };
    document.addEventListener('pointerdown', outside);
    return () => document.removeEventListener('pointerdown', outside);
  }, []);
  function navigate(event: MouseEvent<HTMLAnchorElement>) {
    onNavigate?.(event);
    if (!event.defaultPrevented && menu.current) menu.current.open = false;
  }
  return <header className={`app-header ${className}`}>
    <div className="app-nav-left">
      <a className="app-brand" href="/" aria-label="Home" title="Home" onClick={navigate}><CandleMark /><span className="app-brand-text"><strong>Price Action Center</strong><small>{section}</small></span></a>
      <details className="app-nav-menu" ref={menu} onKeyDown={event => { if (event.key === 'Escape' && menu.current?.open) { event.preventDefault(); event.stopPropagation(); menu.current.open = false; menu.current.querySelector<HTMLElement>('summary')?.focus(); } }}>
        <summary aria-label="Navigation menu" title="Navigation menu"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true"><path d="M4 6h16M4 12h16M4 18h16" /></svg></summary>
        <nav aria-label="Site navigation">{destinations.map(([href, label]) => <a key={href} href={href} aria-current={current === href ? 'page' : undefined} onClick={navigate}>{label}</a>)}</nav>
      </details>
    </div>
    {children && <div className="app-account" aria-label="Account">{children}</div>}
  </header>;
}
