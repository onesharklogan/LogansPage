export class ApiError extends Error {
  constructor(message: string, public status: number, public code?: string) { super(message); }
}

export async function api<T>(path: string, init?: RequestInit): Promise<T> {
  let response: Response;
  try { response = await fetch(path, { ...init, cache: "no-store", credentials: "same-origin" }); }
  catch (error) { if (init?.signal?.aborted) throw error; throw new ApiError(init?.method ? "The server could not be reached. The change may or may not have saved; refresh the Lessons before trying again." : "The Lessons could not be reached. Check your connection and try Refresh.", 0); }
  const parsed: unknown = await response.json().catch(() => ({}));
  const data = parsed && typeof parsed === "object" ? parsed as Record<string, unknown> : {};
  if (!response.ok) {
    const fallback = response.status === 409 ? "Someone changed this item. Refresh the Lessons and review the newest revision before trying again." : response.status === 401 ? "Your author session has ended. Sign in again to make changes." : response.status === 429 ? "Too many attempts. Please wait before trying again." : "The request could not be completed.";
    throw new ApiError(init?.method && response.status >= 500 ? "The server response could not confirm whether this change saved. Refresh the Lessons before trying again." : response.status === 409 ? fallback : typeof data.error === "string" ? data.error : fallback, response.status, typeof data.code === "string" ? data.code : undefined);
  }
  return data as T;
}

