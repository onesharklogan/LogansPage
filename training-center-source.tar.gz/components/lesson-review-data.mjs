import Model from '../lib/portal/lesson-model.cjs';

async function boundedText(path, maxBytes, { signal, fetcher }) {
  const response = await fetcher(path, { signal, credentials: 'same-origin', cache: 'no-store' });
  if (!response.ok) throw new Error('This saved slide is not available. Refresh the Module Library and try again.');
  const advertised = response.headers.get('content-length');
  if (advertised && (!/^\d+$/.test(advertised) || Number(advertised) > maxBytes)) throw new Error('The saved slide response is too large.');
  const reader = response.body?.getReader();
  if (!reader) throw new Error('The saved slide response is empty.');
  const chunks = []; let total = 0;
  try {
    while (true) {
      const { done, value } = await reader.read(); if (done) break;
      total += value.byteLength;
      if (total > maxBytes) { await reader.cancel(); throw new Error('The saved slide response is too large.'); }
      chunks.push(value);
    }
  } finally { reader.releaseLock(); }
  const bytes = new Uint8Array(total); let at = 0;
  for (const chunk of chunks) { bytes.set(chunk, at); at += chunk.length; }
  return { bytes, text: new TextDecoder('utf-8', { fatal: true }).decode(bytes) };
}
async function sha256(bytes) {
  return [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))].map(value => value.toString(16).padStart(2, '0')).join('');
}

/**
 * Recreate a view from verified editable text and the existing static chart, never a stored image.
 * @param {any} manifest
 * @param {{ signal?: AbortSignal, fetcher?: typeof fetch }} [options]
 */
export async function loadLessonReview(manifest, { signal, fetcher = fetch } = {}) {
  if (!manifest || !/^\/api\/(author|public)\/lessons\/[A-Za-z0-9_-]{1,90}\/versions\/[A-Za-z0-9_-]{1,90}\/pack$/.test(manifest.packUrl || '') ||
      !/^[a-f0-9]{64}$/.test(manifest.pack?.sha256 || '') || !Number.isInteger(manifest.pack?.bytes) || manifest.pack.bytes < 1 || manifest.pack.bytes > Model.MAX_BYTES) throw new Error('The saved slide metadata is invalid.');
  const pack = await boundedText(manifest.packUrl, Model.MAX_BYTES, { signal, fetcher });
  if (pack.bytes.length !== manifest.pack.bytes || await sha256(pack.bytes) !== manifest.pack.sha256) throw new Error('The saved slide integrity check failed.');
  const parsed = Model.pack(pack.text);
  if (parsed.lessons.length !== 1) throw new Error('A saved preview must contain one slide.');
  const lesson = parsed.lessons[0];
  const catalog = JSON.parse((await boundedText('/charts/catalog.json', 256 * 1024, { signal, fetcher })).text);
  if (catalog.version !== 1 || !Array.isArray(catalog.sessions) || catalog.sessions.length > 1000) throw new Error('The chart catalog is invalid.');
  const reference = Model.verifyCatalog(lesson, catalog.sessions);
  const chartPath = '/charts/' + lesson.session.id + '.json';
  if (reference.url !== chartPath) throw new Error('The chart reference is invalid.');
  const source = await boundedText(chartPath, 2 * 1024 * 1024, { signal, fetcher });
  if (await sha256(source.bytes) !== lesson.session.sha256) throw new Error('The original chart integrity check failed.');
  const chart = JSON.parse(source.text);
  if (chart.id !== lesson.session.id || chart.date !== lesson.session.date || !Array.isArray(chart.current) || !chart.current.length || chart.current.length > 2000 ||
      chart.current.some(c => typeof c.t !== 'string' || ![c.o, c.h, c.l, c.c].every(Number.isFinite) || c.h < Math.max(c.o, c.l, c.c) || c.l > Math.min(c.o, c.h, c.c))) throw new Error('The original chart data is invalid.');
  Model.verifyPoints(lesson, chart);
  const settings = Model.indicatorSettings(lesson);
  const indicatorSeries = settings.ema20 || settings.pivotDiamonds ? Model.chartIndicators(chart, lesson.range?.endBar ?? chart.current.length - 1) : undefined;
  return { lesson, candles: chart.current, chart, indicatorSeries };
}
