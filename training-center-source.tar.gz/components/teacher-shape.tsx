import Geometry from '../lib/portal/teacher-shape-geometry.cjs';
export type ShapeStyle={rotation?:number;skewX?:number;skewY?:number;opacity?:number};
export type ShapeKind='rectangle'|'circle'|'triangle';
export function ShapeFill({shape,rect,fill,style={}}:{shape:ShapeKind;rect:{x:number;y:number;width:number;height:number};fill:string;style?:ShapeStyle}){let points;try{points=Geometry.polygon(shape,rect,style)}catch{return null}return <polygon points={points.map((p:{x:number;y:number})=>`${p.x},${p.y}`).join(' ')} fill={fill} fillOpacity={style.opacity??1} stroke="none"/>}
