#!/usr/bin/env python3
"""Deterministic code-native extension of app-navigation.tsx CandleMark (no external art).
Four same-palette candles gently shift over exactly five equal-duration GIF frames.
"""
from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'public' / 'brand'
SIZE, SCALE, INSET = 136, 2, 8
BLUE, GOLD = (154, 209, 255), (255, 207, 124)
# Original mark: x/body top/body bottom/wick top/wick bottom/color.
CANDLES = [(7,20,34,11,41,BLUE),(20,7,34,1,39,GOLD),(33,28,42,20,47,BLUE),(46,8,29,1,34,BLUE)]
# Two-pixel maximum step at SVG scale, no opacity/color changes or flashing.
WAVE = [0, -2, -3, -2, 0]
frames=[]
for phase in range(5):
    image=Image.new('P',(SIZE,SIZE),0)
    image.putpalette([0,0,0,*BLUE,*GOLD]+[0,0,0]*253)
    draw=ImageDraw.Draw(image)
    for index,(x,top,bottom,wtop,wbottom,color) in enumerate(CANDLES):
        dy=WAVE[(phase+index)%5]
        X=lambda n:int((n+INSET)*SCALE)
        Y=lambda n:int((n+INSET+2+dy)*SCALE)
        ink=1 if color==BLUE else 2
        draw.line((X(x),Y(wtop),X(x),Y(wbottom)),fill=ink,width=2)
        draw.rounded_rectangle((X(x-4),Y(top),X(x+4)-1,Y(bottom)-1),radius=2,fill=ink)
    image.info['transparency']=0
    frames.append(image)
OUT.mkdir(parents=True,exist_ok=True)
frames[0].save(OUT/'candle-loading.gif',save_all=True,append_images=frames[1:],duration=[220]*5,loop=0,transparency=0,disposal=2,optimize=False)
frames[0].convert('RGBA').save(OUT/'candle-loading.png',optimize=True)
with Image.open(OUT/'candle-loading.gif') as check:
    assert check.n_frames == 5
    assert check.info['loop'] == 0
    assert all(check.seek(i) is None and check.info['duration']==220 for i in range(5))
print('5 frames · 1100 ms loop · transparent · 136 × 136')
