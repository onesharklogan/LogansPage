import { existsSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

// Release-only utility. Temporary QA pages are never part of a public stage.
export function temporaryQaAssets(directory) {
  const root = directory instanceof URL ? fileURLToPath(directory) : directory;
  if (!existsSync(root)) return [];
  const found = [];
  function walk(relative = '') {
    for (const entry of readdirSync(join(root, relative), { withFileTypes: true })) {
      const path = relative ? `${relative}/${entry.name}` : entry.name;
      if (entry.isDirectory()) walk(path);
      else if (entry.isFile() && /^qa.*\.html$/i.test(entry.name)) found.push(path);
    }
  }
  walk();
  return found.sort();
}
export function requireQaPrivateStage(setupEnabled, ...directories) {
  const found = directories.flatMap(directory => temporaryQaAssets(directory).map(path => `${directory}/${path}`));
  if (!setupEnabled && found.length) throw new Error('Remove ALL temporary qa*.html pages before public promotion: ' + found.join(', '));
  return found;
}
