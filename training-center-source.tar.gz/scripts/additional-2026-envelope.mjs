import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';

export const BATCH = 'mes-2026-additional-20261103';
export const COMPLETED_THROUGH = '2026-11-02';
export const CANDIDATE_DATES = Object.freeze([
  '2026-01-02', '2026-10-26', '2026-10-27', '2026-10-28',
  '2026-10-29', '2026-10-30', '2026-11-02',
]);
export const CLOSED_RTH_DATES = Object.freeze([
  '2026-01-01', '2026-01-19', '2026-02-16', '2026-04-03',
  '2026-05-25', '2026-06-19', '2026-07-03', '2026-09-07',
]);
export const BASELINE_CATALOG_SHA256 = '952c78fb7fccef5694d2a1a940a4ee4143ac806d30b9c3304ba46250378e5ed6';
export const BASELINE_REFERENCES_SHA256 = 'e627c7398af22733ab8beab95c51b05c628861a83609af3b053f2b2d2f73c1f4';
export const BASELINE_MANIFEST_SHA256 = '54123b5a8511c80486b2d4eb3345f70f84a4fc3feb2218d40e2f453b6faa0963';
export const sha = value => createHash('sha256').update(value).digest('hex');
export const json = value => JSON.stringify(value, null, 2) + '\n';
export const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
export const fail = message => { throw Error(message); };
const digest = value => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value);

export function validateFrozenBaseline({ catalog, references, manifest, readChart }) {
  if (manifest?.version !== 1 || manifest.baseline !== 'v82-frozen450' ||
      manifest.existingCount !== 450 || !Array.isArray(manifest.existingCharts) ||
      manifest.existingCharts.length !== 450 ||
      manifest.baselineCatalogSha256 !== BASELINE_CATALOG_SHA256 ||
      manifest.baselineReferencesSha256 !== BASELINE_REFERENCES_SHA256) fail('Invalid frozen450 manifest.');
  if (catalog?.version !== 1 || !Array.isArray(catalog.sessions) || catalog.sessions.length !== 450 ||
      !Array.isArray(references) || references.length !== 450 ||
      sha(json(catalog)) !== BASELINE_CATALOG_SHA256 ||
      sha(JSON.stringify(references) + '\n') !== BASELINE_REFERENCES_SHA256) fail('Frozen450 catalog or references changed.');
  const identities = catalog.sessions.map(({ id, date, sha256 }) => ({ id, date, sha256 }));
  if (!same(identities, manifest.existingCharts)) fail('Frozen450 manifest identities differ.');
  const charts = new Map();
  for (const entry of catalog.sessions) {
    const bytes = readChart(entry.id);
    if (sha(bytes) !== entry.sha256) fail('Frozen chart bytes changed: ' + entry.id);
    const chart = JSON.parse(String(bytes));
    const ref = references.find(row => row.id === entry.id);
    if (chart.id !== entry.id || chart.date !== entry.date || !ref || ref.date !== entry.date ||
        ref.sha256 !== entry.sha256 || !same(ref.timestamps, chart.current.map(b => b.t))) fail('Frozen chart identity differs: ' + entry.id);
    charts.set(entry.date, chart);
  }
  return { catalog, references, charts };
}

/** Remove only this exact bounded batch before running unchanged historical validators. */
export function peelAdditional2026({ catalog, references, manifest, provenance, readChart }) {
  const known = new Set(manifest.existingCharts.map(row => row.id));
  if (!Array.isArray(catalog?.sessions) || !Array.isArray(references) ||
      new Set(catalog.sessions.map(r => r.id)).size !== catalog.sessions.length ||
      new Set(catalog.sessions.map(r => r.date)).size !== catalog.sessions.length ||
      new Set(references.map(r => r.id)).size !== references.length ||
      new Set(references.map(r => r.date)).size !== references.length) fail('Duplicate or invalid catalog identities.');
  const extraCatalog = catalog.sessions.filter(row => !known.has(row.id));
  const extraReferences = references.filter(row => !known.has(row.id));
  const baselineCatalog = { ...catalog, sessions: catalog.sessions.filter(row => known.has(row.id)) };
  const baselineReferences = references.filter(row => known.has(row.id));
  const frozen = validateFrozenBaseline({ catalog: baselineCatalog, references: baselineReferences, manifest, readChart });
  if (!provenance) {
    if (extraCatalog.length || extraReferences.length) fail('Undeclared additional2026 sessions.');
    return { ...frozen, baselineCatalog, baselineReferences, extraCatalog, extraReferences };
  }
  const p = provenance;
  if (p.version !== 1 || p.batch !== BATCH || p.completedThrough !== COMPLETED_THROUGH ||
      p.readiness !== 'VERIFIED_BOUNDED_ADDITION' ||
      p.baselineManifestSha256 !== BASELINE_MANIFEST_SHA256 ||
      !Array.isArray(p.selectedDates) || !p.selectedDates.length ||
      p.selectedCount !== p.selectedDates.length || !Array.isArray(p.newCharts) ||
      p.newCharts.length !== p.selectedCount ||
      !same(p.selectedDates, [...new Set(p.selectedDates)].sort()) ||
      p.selectedDates.some(date => !CANDIDATE_DATES.includes(date))) fail('Invalid bounded2026 provenance.');
  if (extraCatalog.length !== p.selectedCount || extraReferences.length !== p.selectedCount) fail('Additional2026 identity count differs.');
  for (let i = 0; i < p.selectedCount; i++) {
    const row = p.newCharts[i], date = p.selectedDates[i], id = `mes1-${date}-81`;
    if (!row || !same(Object.keys(row).sort(), ['date', 'id', 'sha256']) ||
        row.id !== id || row.date !== date || !digest(row.sha256)) fail('Invalid additional2026 identity.');
    const entry = extraCatalog.find(x => x.id === id), ref = extraReferences.find(x => x.id === id);
    if (!entry || !ref || entry.date !== date || ref.date !== date ||
        entry.sha256 !== row.sha256 || ref.sha256 !== row.sha256 || entry.url !== `/charts/${id}.json`) fail('Additional2026 catalog/reference mismatch.');
    const bytes = readChart(id);
    if (sha(bytes) !== row.sha256) fail('Additional2026 chart bytes differ.');
    const chart = JSON.parse(String(bytes));
    if (chart.id !== id || chart.date !== date || chart.source?.batch !== BATCH ||
        !Array.isArray(chart.current) || chart.current.length !== 81 ||
        !same(ref.timestamps, chart.current.map(b => b.t))) fail('Additional2026 source identity differs.');
  }
  return { ...frozen, baselineCatalog, baselineReferences, extraCatalog, extraReferences };
}

export function mergeAdditional2026({ catalog, references }, envelope) {
  return {
    catalog: { ...catalog, sessions: [...catalog.sessions, ...envelope.extraCatalog].sort((a, b) => a.date.localeCompare(b.date)) },
    references: [...references, ...envelope.extraReferences].sort((a, b) => a.date.localeCompare(b.date)),
  };
}

/** Historical normalizers remain unchanged unless this reviewed additive batch is present. */
export function loadAdditional2026Envelope(root, catalog, references, readChart) {
  const provenancePath = path.join(root, 'data/mes-2026-additional-provenance.json');
  if (!fs.existsSync(provenancePath)) return { baselineCatalog: catalog, baselineReferences: references, extraCatalog: [], extraReferences: [] };
  const manifestBytes = fs.readFileSync(path.join(root, 'data/mes-2026-additional-baseline.json'));
  if (sha(manifestBytes) !== BASELINE_MANIFEST_SHA256) fail('Frozen450 manifest bytes changed.');
  return peelAdditional2026({ catalog, references, manifest: JSON.parse(String(manifestBytes)), provenance: JSON.parse(fs.readFileSync(provenancePath, 'utf8')), readChart });
}
