-- Run read-only AFTER the expected marker and confirmed atomic rollback. Expected: 0.
SELECT count(*)::integer AS synthetic_accounts_remaining FROM learner_app.accounts WHERE provider_issuer='urn:price-action:rollback-probe:4417b7d1-ac1c-47bd-9ffb-13e7f0e741dd';
