-- Operator-only isolated probe; use the verified learner_runtime connection.
-- A deliberate terminal exception rolls back every synthetic row and preference.
-- Only an error containing DIRECTION_BRACKET_RUNTIME_ROLLBACK_PASS is success.
DO $probe$
DECLARE
 a uuid:=gen_random_uuid(); b uuid:=gen_random_uuid(); issuer text:='urn:price-action:bracket-rollback:'||gen_random_uuid()::text;
 stamp bigint:=(extract(epoch from clock_timestamp())*1000)::bigint;
 tag text:=replace(gen_random_uuid()::text,'-','')||replace(gen_random_uuid()::text,'-','');
 n integer; before_b jsonb; after_b jsonb; saved jsonb; invalid numeric; rejected boolean;
BEGIN
 IF current_user <> 'learner_runtime' OR session_user <> 'learner_runtime' OR current_database() <> 'teacher_studio' THEN RAISE EXCEPTION 'Incorrect actual runtime identity or database'; END IF;
 INSERT INTO learner_app.accounts(id,provider_issuer,provider_subject,display_name,created_at) VALUES(a,issuer,'a','Bracket rollback probe',stamp),(b,issuer,'b','Bracket rollback probe',stamp);
 GET DIAGNOSTICS n=ROW_COUNT; IF n IS DISTINCT FROM 2 THEN RAISE EXCEPTION 'Synthetic account insert count'; END IF;
 INSERT INTO learner_app.sessions(session_tag,account_id,expires_at,created_at) VALUES(tag,a,stamp+60000,stamp);
 GET DIAGNOSTICS n=ROW_COUNT; IF n IS DISTINCT FROM 1 THEN RAISE EXCEPTION 'Synthetic session insert count'; END IF;
 SELECT to_jsonb(x) INTO before_b FROM learner_app.accounts x WHERE id=b;
 IF before_b IS NULL OR before_b->'use_exit_bracket' IS DISTINCT FROM 'false'::jsonb OR before_b->'exit_bracket_distance' IS DISTINCT FROM '5'::jsonb THEN RAISE EXCEPTION 'Default bracket preferences'; END IF;
 UPDATE learner_app.accounts SET equal_tp_sl=true,lesson_completions='{"folder:bracket_rollback":true}'::jsonb WHERE id=a;
 GET DIAGNOSTICS n=ROW_COUNT; IF n IS DISTINCT FROM 1 THEN RAISE EXCEPTION 'Existing preference setup count'; END IF;
 UPDATE learner_app.accounts SET use_exit_bracket=true,exit_bracket_distance=7.25 WHERE id=a;
 GET DIAGNOSTICS n=ROW_COUNT; IF n IS DISTINCT FROM 1 THEN RAISE EXCEPTION 'Bracket preference update count'; END IF;
 SELECT to_jsonb(x) INTO saved FROM learner_app.accounts x WHERE id=a;
 IF saved IS NULL OR saved->'use_exit_bracket' IS DISTINCT FROM 'true'::jsonb OR saved->'exit_bracket_distance' IS DISTINCT FROM '7.25'::jsonb OR saved->'equal_tp_sl' IS DISTINCT FROM 'true'::jsonb OR saved->'lesson_completions' IS DISTINCT FROM '{"folder:bracket_rollback":true}'::jsonb THEN RAISE EXCEPTION 'Bracket or prior preferences readback'; END IF;
 FOREACH invalid IN ARRAY ARRAY[0.25::numeric,100000::numeric,5.75::numeric] LOOP
  UPDATE learner_app.accounts SET exit_bracket_distance=invalid WHERE id=a;
  GET DIAGNOSTICS n=ROW_COUNT; IF n IS DISTINCT FROM 1 THEN RAISE EXCEPTION 'Valid boundary update count'; END IF;
  SELECT to_jsonb(x) INTO saved FROM learner_app.accounts x WHERE id=a;
  IF saved->'exit_bracket_distance' IS DISTINCT FROM to_jsonb(invalid) THEN RAISE EXCEPTION 'Valid boundary readback'; END IF;
 END LOOP;
 rejected:=false;
 BEGIN UPDATE learner_app.accounts SET use_exit_bracket=NULL WHERE id=a;
 EXCEPTION WHEN not_null_violation THEN rejected:=true; END;
 IF rejected IS DISTINCT FROM true THEN RAISE EXCEPTION 'Null bracket flag accepted'; END IF;
 FOREACH invalid IN ARRAY ARRAY[NULL::numeric,0,-1,0.1,5.1,100000.25,'NaN'::numeric,'Infinity'::numeric,'-Infinity'::numeric] LOOP
  rejected:=false;
  BEGIN UPDATE learner_app.accounts SET exit_bracket_distance=invalid WHERE id=a;
  EXCEPTION WHEN check_violation OR not_null_violation THEN rejected:=true; END;
  IF rejected IS DISTINCT FROM true THEN RAISE EXCEPTION 'Invalid bracket distance accepted: %',invalid; END IF;
 END LOOP;
 UPDATE learner_app.accounts SET use_exit_bracket=false WHERE id=a;
 GET DIAGNOSTICS n=ROW_COUNT; IF n IS DISTINCT FROM 1 THEN RAISE EXCEPTION 'Disable bracket update count'; END IF;
 SELECT to_jsonb(x) INTO saved FROM learner_app.accounts x WHERE id=a;
 IF saved IS NULL OR saved->'use_exit_bracket' IS DISTINCT FROM 'false'::jsonb OR saved->'exit_bracket_distance' IS DISTINCT FROM '5.75'::jsonb OR saved->'equal_tp_sl' IS DISTINCT FROM 'true'::jsonb OR saved->'lesson_completions' IS DISTINCT FROM '{"folder:bracket_rollback":true}'::jsonb THEN RAISE EXCEPTION 'Final bracket or prior preferences changed'; END IF;
 SELECT to_jsonb(x) INTO after_b FROM learner_app.accounts x WHERE id=b;
 IF after_b IS DISTINCT FROM before_b THEN RAISE EXCEPTION 'Other synthetic account changed'; END IF;
 SELECT count(*)::integer INTO n FROM learner_app.accounts WHERE provider_issuer=issuer;
 IF n IS DISTINCT FROM 2 THEN RAISE EXCEPTION 'Synthetic account count changed'; END IF;
 SELECT count(*)::integer INTO n FROM learner_app.sessions WHERE account_id IN (a,b);
 IF n IS DISTINCT FROM 1 THEN RAISE EXCEPTION 'Synthetic session count changed'; END IF;
 RAISE EXCEPTION 'DIRECTION_BRACKET_RUNTIME_ROLLBACK_PASS';
END $probe$;
