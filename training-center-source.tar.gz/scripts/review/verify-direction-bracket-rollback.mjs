/** Operator-only isolated verification. No connection/credential discovery.
 * Supply the explicitly approved learner runtime pool (never an owner pool).
 * Two unique synthetic accounts, one session; the entire probe is rolled back.
 */
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {LearnerRepository} from '../../lib/learner/repository.mjs';
export async function verifyDirectionBracketRollback({pool,expectedRuntimeRole,expectedDatabase}){
 if(!pool||!expectedRuntimeRole||!expectedDatabase)throw Error('Verified actual runtime pool, role and database required.');
 const db=await pool.connect(),nonce=randomUUID(),issuer='urn:price-action:bracket-rollback:'+nonce,now=Date.now();let transaction=false;
 try{
 const identity=(await db.query('SELECT current_user AS role,session_user AS session_role,current_database() AS database')).rows[0];assert.equal(identity.role,expectedRuntimeRole);assert.equal(identity.session_role,expectedRuntimeRole);assert.equal(identity.database,expectedDatabase);
 await db.query('BEGIN');transaction=true;
 const repository=new LearnerRepository({transaction:fn=>fn(db)}),principal={issuer,subject:'a',name:'Bracket rollback probe',sessionTag:nonce.replaceAll('-','')+randomUUID().replaceAll('-',''),expiresAt:now+60000};
 const first=await repository.session(principal,now),other=randomUUID();
 assert.deepEqual(first.preferences,{equalTpSl:false,useExitBracket:false,exitBracketDistance:5});
 assert.equal((await db.query('INSERT INTO learner_app.accounts(id,provider_issuer,provider_subject,display_name,created_at) VALUES($1,$2,$3,$4,$5)',[other,issuer,'b','Bracket rollback probe',now])).rowCount,1);
 const before=(await db.query('SELECT equal_tp_sl,lesson_completions,use_exit_bracket,exit_bracket_distance FROM learner_app.accounts WHERE id=$1',[other])).rows;assert.equal(before.length,1);
 await repository.preferences(principal,first.context,true,now);await repository.setLessonCompletion(principal,first.context,'folder:bracket_rollback',true,now);
 assert.deepEqual((await repository.directionPreferences(principal,first.context,true,7.25,now)).preferences,{equalTpSl:true,useExitBracket:true,exitBracketDistance:7.25});
 assert.deepEqual((await repository.readProfile(principal,now)).preferences,{equalTpSl:true,useExitBracket:true,exitBracketDistance:7.25});assert.deepEqual((await repository.lessonCompletions(principal,now)).completedLessons,['folder:bracket_rollback']);
 assert.deepEqual((await db.query('SELECT equal_tp_sl,lesson_completions,use_exit_bracket,exit_bracket_distance FROM learner_app.accounts WHERE id=$1',[other])).rows,before);
 for(const invalid of [null,0,-1,.1,100000.25,'NaN','Infinity']){await db.query('SAVEPOINT invalid_distance');let rejected=false;try{await db.query('UPDATE learner_app.accounts SET exit_bracket_distance=$2 WHERE id=$1',[first.profile.id,invalid]);}catch{rejected=true;}await db.query('ROLLBACK TO SAVEPOINT invalid_distance');assert.equal(rejected,true);await db.query('RELEASE SAVEPOINT invalid_distance');}
 assert.equal((await db.query('SELECT count(*)::int n FROM learner_app.accounts WHERE provider_issuer=$1',[issuer])).rows[0]?.n,2);assert.equal((await db.query('SELECT count(*)::int n FROM learner_app.sessions WHERE account_id IN (SELECT id FROM learner_app.accounts WHERE provider_issuer=$1)',[issuer])).rows[0]?.n,1);
 await db.query('ROLLBACK');transaction=false;assert.equal((await db.query('SELECT count(*)::int n FROM learner_app.accounts WHERE provider_issuer=$1',[issuer])).rows[0]?.n,0);
 return{marker:'DIRECTION_BRACKET_RUNTIME_ROLLBACK_PASS',passed:true,rolledBack:true,syntheticAccountsRemaining:0};
 }finally{if(transaction)await db.query('ROLLBACK');db.release();}
}
