-- Review-only actual-runtime SQL probe. The caller must use the approved atomic transaction tool.
-- Expected terminal error PAC_LESSON_COMPLETION_ROLLBACK_4417b7d1ac1c47bd9ffb13e7f0e741dd is SUCCESS evidence only when rollback is confirmed.
-- Never retry this packet outside an atomic transaction. No SET ROLE, credentials, live profiles or lessons.
DO $probe$
DECLARE a uuid := 'ae8ed658-7580-4cc7-bf64-939339c2c62c'; b uuid := '3954dffa-1136-4601-a2df-03621d4789b4'; v jsonb; owner_id uuid; n integer;
BEGIN
 IF current_user IS DISTINCT FROM 'learner_runtime' OR session_user IS DISTINCT FROM 'learner_runtime' OR current_database() IS DISTINCT FROM 'teacher_studio' THEN RAISE EXCEPTION 'Probe target mismatch'; END IF;
 SELECT count(*) INTO n FROM learner_app.accounts WHERE provider_issuer='urn:price-action:rollback-probe:4417b7d1-ac1c-47bd-9ffb-13e7f0e741dd';
 IF n IS DISTINCT FROM 0 THEN RAISE EXCEPTION 'Probe namespace already exists'; END IF;
 INSERT INTO learner_app.accounts(id,provider_issuer,provider_subject,display_name,created_at) VALUES
 (a,'urn:price-action:rollback-probe:4417b7d1-ac1c-47bd-9ffb-13e7f0e741dd','a','Rollback probe',0),
 (b,'urn:price-action:rollback-probe:4417b7d1-ac1c-47bd-9ffb-13e7f0e741dd','b','Rollback probe',0);
 INSERT INTO learner_app.sessions(session_tag,account_id,expires_at,created_at) VALUES('7f96f6fc1b664e7294c2c4f110cdb505bdd438ec36b54d6dbc6113bd5ba8dc38',a,4102444800000,0);
 SELECT id,lesson_completions INTO owner_id,v FROM learner_app.accounts WHERE provider_issuer='urn:price-action:rollback-probe:4417b7d1-ac1c-47bd-9ffb-13e7f0e741dd' AND provider_subject='a' FOR UPDATE;
 IF owner_id IS DISTINCT FROM a OR v IS DISTINCT FROM '{}'::jsonb THEN RAISE EXCEPTION 'Account default/ownership mismatch'; END IF;
 PERFORM session_tag FROM learner_app.sessions WHERE session_tag='7f96f6fc1b664e7294c2c4f110cdb505bdd438ec36b54d6dbc6113bd5ba8dc38' AND account_id=a AND NOT revoked FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'Owned session missing'; END IF;
 UPDATE learner_app.accounts SET lesson_completions='{"folder:probe":true,"sequence:probe":true}'::jsonb WHERE id=a;
 GET DIAGNOSTICS n = ROW_COUNT;
 IF n IS DISTINCT FROM 1 THEN RAISE EXCEPTION 'Expected exactly one owned account update'; END IF;
 SELECT lesson_completions INTO v FROM learner_app.accounts WHERE id=a;
 IF v IS DISTINCT FROM '{"folder:probe":true,"sequence:probe":true}'::jsonb THEN RAISE EXCEPTION 'Completion write mismatch'; END IF;
 UPDATE learner_app.accounts SET lesson_completions='{"sequence:probe":true}'::jsonb WHERE id=a;
 GET DIAGNOSTICS n = ROW_COUNT;
 IF n IS DISTINCT FROM 1 THEN RAISE EXCEPTION 'Expected exactly one owned account update'; END IF;
 UPDATE learner_app.accounts SET lesson_completions='{"sequence:probe":true}'::jsonb WHERE id=a;
 GET DIAGNOSTICS n = ROW_COUNT;
 IF n IS DISTINCT FROM 1 THEN RAISE EXCEPTION 'Expected exactly one owned account update'; END IF;
 SELECT lesson_completions INTO v FROM learner_app.accounts WHERE id=a;
 IF v IS DISTINCT FROM '{"sequence:probe":true}'::jsonb THEN RAISE EXCEPTION 'Uncheck mismatch'; END IF;
 SELECT lesson_completions INTO v FROM learner_app.accounts WHERE id=b;
 IF v IS DISTINCT FROM '{}'::jsonb THEN RAISE EXCEPTION 'Other account changed'; END IF;
 -- Constraint failures must leave the synthetic row untouched (subtransaction rollback).
 BEGIN
  UPDATE learner_app.accounts SET lesson_completions='[]'::jsonb WHERE id=a;
  RAISE EXCEPTION 'Expected array CHECK violation';
 EXCEPTION WHEN check_violation THEN NULL;
 END;
 BEGIN
  UPDATE learner_app.accounts SET lesson_completions=jsonb_build_object('oversize',repeat('x',600001)) WHERE id=a;
  RAISE EXCEPTION 'Expected size CHECK violation';
 EXCEPTION WHEN check_violation THEN NULL;
 END;
 BEGIN
  UPDATE learner_app.accounts SET lesson_completions=NULL WHERE id=a;
  RAISE EXCEPTION 'Expected NOT NULL violation';
 EXCEPTION WHEN not_null_violation THEN NULL;
 END;
 SELECT lesson_completions INTO v FROM learner_app.accounts WHERE id=a;
 IF v IS DISTINCT FROM '{"sequence:probe":true}'::jsonb THEN RAISE EXCEPTION 'Constraint probe modified saved marks'; END IF;
 UPDATE learner_app.accounts SET lesson_completions='{}'::jsonb WHERE id=a;
 GET DIAGNOSTICS n = ROW_COUNT;
 IF n IS DISTINCT FROM 1 THEN RAISE EXCEPTION 'Expected exactly one owned account update'; END IF;
 SELECT lesson_completions INTO v FROM learner_app.accounts WHERE id=a;
 IF v IS DISTINCT FROM '{}'::jsonb THEN RAISE EXCEPTION 'Clear marks persistence mismatch'; END IF;
 RAISE EXCEPTION 'PAC_LESSON_COMPLETION_ROLLBACK_4417b7d1ac1c47bd9ffb13e7f0e741dd';
END $probe$;
