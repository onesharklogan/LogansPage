/** Reviewed operator-only packet. Does not open connections or read credentials.
 * Call only with the already-approved actual learner runtime pool, NEVER an owner pool.
 * All synthetic data is rolled back; no live accounts, lessons or auth tables touched.
 */
import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {LearnerRepository} from '../../lib/learner/repository.mjs';
export async function verifyLessonCompletionRollback({pool,expectedRuntimeRole,expectedDatabase}){
 if(!pool||typeof expectedRuntimeRole!=='string'||!expectedRuntimeRole||typeof expectedDatabase!=='string'||!expectedDatabase)throw Error('An explicitly verified actual runtime pool/role/database is required.');
 const db=await pool.connect(),nonce=randomUUID(),now=Date.now();let transaction=false;
 try{
  const identity=(await db.query('SELECT current_user AS role,current_database() AS database')).rows[0];
  assert.equal(identity.role,expectedRuntimeRole);assert.equal(identity.database,expectedDatabase);
  await db.query('BEGIN');transaction=true;
  const repository=new LearnerRepository({transaction:fn=>fn(db)});
  const principal=suffix=>({issuer:'urn:price-action:rollback-probe:'+nonce,subject:suffix,name:'Rollback probe',sessionTag:(nonce.replaceAll('-','')+randomUUID().replaceAll('-','')),expiresAt:now+60000});
  const a=principal('a'),b=principal('b');
  const first=await repository.session(a,now),other=await repository.session(b,now),key='sequence:rollback_'+nonce.replaceAll('-',''),second='folder:rollback_'+nonce.replaceAll('-','');
  assert.deepEqual((await repository.lessonCompletions(a,now)).completedLessons,[]);
  assert.deepEqual((await repository.setLessonCompletion(a,first.context,key,true,now)).completedLessons,[key]);
  assert.deepEqual((await repository.setLessonCompletion(a,first.context,key,true,now)).completedLessons,[key]);
  assert.deepEqual((await repository.setLessonCompletion(a,first.context,second,true,now)).completedLessons,[second,key]);
  assert.deepEqual((await repository.lessonCompletions(b,now)).completedLessons,[]);
  await assert.rejects(repository.setLessonCompletion(b,first.context,key,true,now),e=>e.code==='account_changed');
  assert.deepEqual((await repository.setLessonCompletion(a,first.context,key,false,now)).completedLessons,[second]);
  assert.deepEqual((await repository.setLessonCompletion(a,first.context,key,false,now)).completedLessons,[second]);
  assert.equal(other.context.accountId===first.context.accountId,false);
  await db.query('ROLLBACK');transaction=false;
  const remaining=(await db.query('SELECT count(*)::int AS n FROM learner_app.accounts WHERE provider_issuer=$1',['urn:price-action:rollback-probe:'+nonce])).rows[0].n;
  assert.equal(remaining,0);
  return {passed:true,rolledBack:true,syntheticAccountsRemaining:0};
 }finally{if(transaction)await db.query('ROLLBACK');db.release();}
}
