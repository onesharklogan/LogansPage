/** Read-only verification against a started production build. No learner API calls. */
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const origin=new URL(process.argv[2]||'http://127.0.0.1:4321');
if(!['http:','https:'].includes(origin.protocol)||origin.username||origin.password||origin.pathname!=='/'||origin.search||origin.hash)throw Error('Pass a plain HTTP(S) origin.');
const manifest=JSON.parse(readFileSync(new URL('../data/history-candle-retention.json',import.meta.url))),results=[];
async function get(path){const url=new URL(path,origin).href,response=await fetch(url,{credentials:'omit',redirect:'error',cache:'no-store',signal:AbortSignal.timeout(10000)});if(response.url!==url)throw Error('Unexpected response URL.');return response;}
for(const pin of manifest.sha256)for(const path of ['/modules/history-candle-index/'+pin+'.json','/modules/history-candle-index.json?sha256='+pin]){
 const response=await get(path),bytes=Buffer.from(await response.arrayBuffer()),sha256=createHash('sha256').update(bytes).digest('hex');
 if(response.status!==200||sha256!==pin||response.headers.get('cache-control')!=='no-store')throw Error('History HTTP verification failed: '+path);
 results.push({path,status:response.status,sha256,cache:response.headers.get('cache-control')});
}
for(const path of ['/modules/history-candle-data.js','/modules/history-candle-index.json']){const response=await get(path);if(response.status!==200||response.headers.get('cache-control')!=='no-store')throw Error('Mutable module cache policy failed.');results.push({path,status:response.status,cache:response.headers.get('cache-control')});await response.arrayBuffer();}
const missing=await get('/modules/history-candle-index.json?sha256='+'0'.repeat(64));if(missing.status!==404)throw Error('Unknown history digest did not fail closed.');results.push({missingHashStatus:missing.status});await missing.arrayBuffer();
console.log(JSON.stringify(results,null,2));
