import { readFileSync } from 'node:fs';
import pg from 'pg';
import { poolConfiguration } from '../lib/portal/postgres-storage.mjs';
let pool;
try {
  const value = process.env.MIGRATION_DATABASE_URL;
  const url = new URL(value);
  if (url.hostname.includes('-pooler')) throw new Error('A direct admin connection is required for migrations.');
  pool = new pg.Pool({ ...poolConfiguration(value), max: 1 });
  const client = await pool.connect();
  try { for (const name of ['001_initial.sql','003_password_auth.sql']) await client.query(readFileSync(new URL('../migrations/' + name, import.meta.url), 'utf8')); }
  finally { client.release(); }
  console.log('Teacher Studio schema migration completed. Runtime grants are a separate administrator action.');
} catch {
  console.error('Migration failed. Verify the direct admin connection and schema compatibility; no credential details were logged.');
  process.exitCode = 1;
} finally { await pool?.end(); }
