import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {ALGORITHM_VERSION,classifyDay} from '../lib/day-type-classifier.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const sourceBytes=await readFile(path.join(root,'data/chart-references.json'));
const refs=JSON.parse(sourceBytes);
const days=[];
for(const ref of [...refs].sort((a,b)=>a.date.localeCompare(b.date))){
  if(!/^mes1-\d{4}-\d{2}-\d{2}-81$/.test(ref.id))throw new Error('Unexpected source id');
  const bytes=await readFile(path.join(root,`public/charts/${ref.id}.json`));
  const sourceSha256=sha(bytes),data=JSON.parse(bytes);
  if(sourceSha256!==ref.sha256||data.date!==ref.date||data.current.length!==81)throw new Error(`Source integrity mismatch: ${ref.id}`);
  const tuple=b=>[b.t,b.o,b.h,b.l,b.c];
  const normalizedSourceSha256=sha(JSON.stringify({current:data.current.map(tuple),prior:data.prior.map(tuple)}));
  days.push({normalizedSourceSha256,id:ref.id,date:ref.date,title:`MES · ${ref.date}`,barCount:data.current.length,sourceSha256,...classifyDay(data.current)});
}
const mapping={'Bull trend day':'bull-trend','Bear trend day':'bear-trend','Trading range day':'trading-range','Trending trading range day':'trending-trading-range','Upper range / lower range day':'trending-trading-range','Reversal day':'reversal','Mixed / unclear day':'mixed-unclear'};
const referenceBytes=await readFile(path.join(root,'tests/fixtures/day-types/lesson-references.json'));
const referenceEvaluation=JSON.parse(referenceBytes).examples.map(e=>{
 const day=days.find(d=>d.date===e.date);if(!day||day.sourceSha256!==e.sourceSha256)throw new Error(`Reference integrity mismatch: ${e.date}`);
 const expectedPrimaryType=mapping[e.category],expectedTag=e.category==='Upper range / lower range day'?'upper-lower-ranges':null;
 return {date:e.date,referenceCategory:e.category,referenceReason:e.reason,sourceSha256:e.sourceSha256,expectedPrimaryType,expectedTag,actualPrimaryType:day.primaryType,actualTags:day.tags,agrees:day.primaryType===expectedPrimaryType&&(!expectedTag||day.tags.includes(expectedTag))};
});
const counts=Object.fromEntries([...new Set(days.map(d=>d.primaryType))].sort().map(k=>[k,days.filter(d=>d.primaryType===k).length]));
const manifest={count:days.length,sourceCatalogSha256:sha(sourceBytes),combinedSourceSha256:sha(days.map(d=>`${d.id}:${d.sourceSha256}\n`).join('')),algorithmSourceSha256:sha(await readFile(path.join(root,'lib/day-type-classifier.mjs'))),referenceFixtureSha256:sha(referenceBytes),sessionConvention:'81 five-minute bars; bar-open timestamps 08:30–15:10 America/Chicago; final bar ends 15:15.',primaryCounts:counts,tagCounts:{'upper-lower-ranges':days.filter(d=>d.tags.includes('upper-lower-ranges')).length}};
const catalog={schemaVersion:1,algorithmVersion:ALGORITHM_VERSION,status:'Retrospective heuristic educational interpretations; not expert-verified labels or a forecast.',manifest,days,referenceEvaluation,referenceEvaluationNote:'These 14 lesson examples informed the design. Agreement is a reference regression check, not independent classification accuracy.'};
await writeFile(path.join(root,'data/day-type-catalog.json'),JSON.stringify(catalog,null,2)+'\n');
const publicBytes=JSON.stringify({schemaVersion:1,algorithmVersion:ALGORITHM_VERSION,manifest,days:days.map(({id,date,sourceSha256,normalizedSourceSha256,primaryType,tags,status})=>({id,date,sourceSha256,normalizedSourceSha256,primaryType,tags,status}))})+'\n';
await writeFile(path.join(root,'public/day-types.json'),publicBytes);
await writeFile(path.join(root,'public/modules/day-type-catalog-version.js'),`// Generated with the public catalog; do not hand-edit.\nexport const DAY_TYPE_CATALOG_SHA256 = '${sha(publicBytes)}';\n`);
console.log(JSON.stringify({count:days.length,counts,referenceDisagreements:referenceEvaluation.filter(e=>!e.agrees)},null,2));
