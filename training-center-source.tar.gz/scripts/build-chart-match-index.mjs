import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import Model from '../lib/portal/lesson-model.cjs';
import {historicalPrefix,historicalGap,matchSessionDate} from '../lib/chart-match.mjs';
const root=new URL('../',import.meta.url),sha=bytes=>createHash('sha256').update(bytes).digest('hex');
/** Deterministic projection of the existing, hash-verified source assets. No downloads/new candles. */
export function buildChartMatchIndex(base=root){
 const catalogBytes=readFileSync(new URL('public/charts/catalog.json',base)),catalog=JSON.parse(catalogBytes),seen=new Set();
 if(catalog.version!==1||!Array.isArray(catalog.sessions)||!catalog.sessions.length)throw Error('Invalid source catalog.');
 const originals=catalog.sessions.map(reference=>{
  const date=matchSessionDate(reference.id);
  if(reference.date!==date||reference.url!==`/charts/${reference.id}.json`||seen.has(date)||!/^[a-f0-9]{64}$/.test(reference.sha256))throw Error('Invalid source reference.');seen.add(date);
  const bytes=readFileSync(new URL('public'+reference.url,base));if(sha(bytes)!==reference.sha256)throw Error('Original chart source hash mismatch.');
  const chart=JSON.parse(bytes);if(chart.id!==reference.id||chart.date!==date||chart.instrument!=='MES'||chart.intervalMinutes!==5||!Array.isArray(chart.warmup)||!chart.warmup.length)throw Error('Unexpected source chart.');
  historicalPrefix(chart,chart.current.length,{useEma:true});historicalGap(chart);
  return {reference,chart};
 }).sort((a,b)=>a.reference.date.localeCompare(b.reference.date));
 const byDate=new Map(originals.map(row=>[row.reference.date,row.chart]));
 let crossCheckedPriorSessions=0;
 const sessions=originals.map(({reference,chart})=>{
  const gap=historicalGap(chart),prior=chart.prior.at(-1),final=chart.warmup.at(-1),previous=byDate.get(gap.priorSessionDate);
  // Check actual preceding catalog session when present; no weekday/calendar guesses.
  const priorCatalogDate=[...byDate.keys()].filter(date=>date<reference.date).at(-1);
  if(priorCatalogDate&&priorCatalogDate!==gap.priorSessionDate)throw Error('Prior exported-session final close is not the previous catalog trading session.');
  if(previous){const actual=previous.current.at(-1);if(!actual||actual.t!==final.t||actual.c!==final.c||actual.t.slice(11)!=='15:10')throw Error('Prior exported-session final close differs from the previous real session final candle.');crossCheckedPriorSessions++;}
  const current=chart.current.map(({t,o,h,l,c})=>({t,o,h,l,c}));
  const projected={id:chart.id,title:chart.title,date:chart.date,instrument:'MES',intervalMinutes:5,current,previousSessionFinal:{t:final.t,c:final.c,source:'original-warmup-final',sourceChartSha256:reference.sha256,crossCheckedSessionId:previous?.id??null},prior:[{t:prior.t,o:prior.o,h:prior.h,l:prior.l,c:prior.c}],warmup:{value:Model.emaSequence(chart.warmup).at(-1)}};
  // Exact all-prefix equivalence follows from identical bars and identical causal pre-open EMA seed.
  const actual=Model.chartIndicators(chart,chart.current.length-1).ema,derived=Model.chartIndicators(projected,projected.current.length-1).ema;
  if(actual.some((v,i)=>v!==derived[i]))throw Error('Derived EMA differs from source.');
  return {reference:{id:reference.id,title:reference.title,date:reference.date,url:reference.url,sha256:reference.sha256},chart:projected};
 });
 return JSON.stringify({version:1,sourceCatalogSha256:sha(catalogBytes),derivation:'Exact original OHLC; previous exported us_regular session final15:10 timestamp/close from original chronological warmup, cross-checked against preceding catalog session final candle when available. EMA20 pre-open seed from that original warmup. No invented OHLC or inferred market data.',crossCheckedPriorSessions,sessions})+'\n';
}
if(process.argv[1]&&fileURLToPath(import.meta.url)===fileURLToPath(new URL('file://'+process.argv[1]))){
 const text=buildChartMatchIndex(),asset=new URL('public/modules/chart-match-index.json',root),loader=new URL('components/chart-match-data.mjs',root),digest=sha(text);
 if(process.argv.includes('--check')){
  if(readFileSync(asset,'utf8')!==text||!readFileSync(loader,'utf8').includes(`MATCH_INDEX_SHA256='${digest}'`))throw Error('Matching index or pinned hash is stale.');
 }else{
  writeFileSync(asset,text);const source=readFileSync(loader,'utf8');if(!/MATCH_INDEX_SHA256='[a-f0-9]{64}'/.test(source))throw Error('Missing index hash pin.');writeFileSync(loader,source.replace(/MATCH_INDEX_SHA256='[a-f0-9]{64}'/,`MATCH_INDEX_SHA256='${digest}'`));
 }
 console.log(JSON.stringify({asset:'public/modules/chart-match-index.json',bytes:Buffer.byteLength(text),sha256:digest,sessions:JSON.parse(text).sessions.length,check:process.argv.includes('--check')}));
}
