import {loadAdditional2026Envelope,mergeAdditional2026} from './additional-2026-envelope.mjs';
import {validateRemainingEnvelope,mergeRemainingEnvelope} from './remaining-batch-envelope.mjs';
import {readFileSync,writeFileSync,mkdirSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
export const sha=value=>createHash('sha256').update(value).digest('hex');
const validDate=value=>/^2025-\d{2}-\d{2}$/.test(value)&&new Date(value+'T00:00:00Z').toISOString().slice(0,10)===value;
const fail=message=>{throw Error(message);};
export function parseObservedCsv(text){
 const lines=text.trim().split(/\r?\n/);if(lines.shift()!=='timestamp,open,high,low,close')fail('Unexpected observed CSV header.');
 const seen=new Map(),rows=[];
 for(const line of lines){const m=/^(2025-\d{2}-\d{2}) (\d{2}:\d{2}):00,(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)$/.exec(line);if(!m||!validDate(m[1]))fail('Invalid observed timestamp or CSV row.');const [o,h,l,c]=m.slice(3).map(Number),t=m[1]+' '+m[2];if(![o,h,l,c].every(v=>Number.isFinite(v)&&v>0&&v<1e9&&Number.isInteger(v*4))||l>Math.min(o,c)||h<Math.max(o,c)||l>h)fail('Invalid observed OHLC or quarter tick.');const bar={t,o,h,l,c};if(seen.has(t))fail('Duplicate observed timestamp.');seen.set(t,bar);rows.push(bar);}
 if(rows.some((r,i)=>i&&r.t<=rows[i-1].t))fail('Observed rows are not strictly chronological.');return rows;
}
export function groupObserved(rows){
 const days=new Map();for(const row of rows){const date=row.t.slice(0,10);if(!days.has(date))days.set(date,[]);days.get(date).push(row);}
 for(const [date,bars]of days){if(![45,81].includes(bars.length))fail('Observed session is incomplete: '+date);for(let i=0;i<bars.length;i++){const minute=510+5*i,want=date+' '+String(Math.floor(minute/60)).padStart(2,'0')+':'+String(minute%60).padStart(2,'0');if(bars[i].t!==want)fail('Observed session has a missing or shifted bar: '+date);}}
 return days;
}
export function canonicalCsv(rows){return 'timestamp,open,high,low,close\n'+rows.map(r=>r.t+':00,'+[r.o,r.h,r.l,r.c].map(x=>x.toFixed(2)).join(',')).join('\n')+'\n';}
const json=value=>JSON.stringify(value,null,2)+'\n';
/** Raw source is the separately verified, sanitized observation table; no downloads or synthetic bars. */
export function normalizeObserved({csv,dates,baseCatalog,baseReferences,template,sourceHashes,existingCount=203,expectedRows=null}){
 const rows=parseObservedCsv(csv),days=groupObserved(rows),allDates=[...days.keys()];
 if(expectedRows!==null&&rows.length!==expectedRows)fail('Unexpected acquisition row count.');
 if(!Array.isArray(dates)||dates.length<1||dates.length>1000||new Set(dates).size!==dates.length||dates.some((d,i)=>!validDate(d)||i&&d<=dates[i-1]))fail('Invalid selected dates.');
 const selected=new Set(dates);if(dates.some(d=>days.get(d)?.length!==81))fail('Selected date is not a complete full session.');
 const newest=[...days].filter(([,b])=>b.length===81).map(([d])=>d).slice(-dates.length);if(JSON.stringify(dates)!==JSON.stringify(newest))fail('Selection differs from newest selected full observed days.');
 const old=baseCatalog.sessions.filter(r=>!selected.has(r.date)),oldRefs=baseReferences.filter(r=>!selected.has(r.date));
 if(baseCatalog.version!==1||old.length!==existingCount||oldRefs.length!==existingCount)fail('Existing catalog shape changed.');
 if(!Array.isArray(sourceHashes)||sourceHashes.length<1||sourceHashes.length>50||sourceHashes.some(h=>!/^[a-f0-9]{64}$/.test(h)))fail('Missing source export hashes.');
 const files=new Map(),newRefs=[],newCatalog=[];
 for(const date of dates){
  const current=days.get(date),previousDate=allDates[allDates.indexOf(date)-1],previous=days.get(previousDate);if(!previous)fail('Selected day lacks actual previous-session context.');
  const warmup=rows.filter(r=>r.t.slice(0,10)<date).map(({t,c})=>({t,c}));if(warmup.length<81||warmup.length>20000||warmup.at(-1).t!==previous.at(-1).t)fail('Invalid chronological warmup boundary.');
  const id=`mes1-${date}-81`,title=`MES1! · ${date} · 81 bars`,prior=previous.slice(-12).map(b=>({...b}));
  const chart={version:1,id,title,date,range:'extended',instrument:'MES',intervalMinutes:5,timezone:'America/Chicago',source:{...template.source,label:`Owner-directed TradingView MES1! 5m export; continuous, non-back-adjusted; settlement-as-close; ${allDates[0]}–${allDates.at(-1)} observed bars`,batch:'mes-2025-20261030',sourceExportSha256s:sourceHashes},rights:{...template.rights},current:current.map(b=>({...b})),prior,warmup,previousSession:{date:previousDate,barCount:previous.length,endTime:previous.at(-1).t.slice(11),bars:previous.map(b=>({...b})),source:'observed-export-session',sourceRowsSha256:sha(JSON.stringify(previous))}};
  const text=json(chart),digest=sha(text);files.set('public/charts/'+id+'.json',text);newCatalog.push({id,title,date,kind:'historical',range:'extended',instrument:'MES',intervalMinutes:5,url:'/charts/'+id+'.json',sha256:digest});newRefs.push({id,date,sha256:digest,timestamps:current.map(b=>b.t)});
 }
 const catalog={...baseCatalog,sessions:[...newCatalog,...old].sort((a,b)=>a.date.localeCompare(b.date))},references=[...newRefs,...oldRefs].sort((a,b)=>a.date.localeCompare(b.date));files.set('public/charts/catalog.json',json(catalog));files.set('data/chart-references.json',JSON.stringify(references)+'\n');
 return {files,catalog,references,rows,days,dates,newCatalog,oldCatalog:old,oldReferences:oldRefs};
}
export function run(root,{check=false}={}){
 const read=name=>readFileSync(path.join(root,name),'utf8'),provenance=JSON.parse(read('data/mes-2025-provenance.json')),baseCatalog=JSON.parse(read('public/charts/catalog.json')),baseReferences=JSON.parse(read('data/chart-references.json')),template=JSON.parse(read('public/charts/mes1-2026-01-05-81.json'));
 const additionalEnvelope=loadAdditional2026Envelope(root,baseCatalog,baseReferences,id=>readFileSync(path.join(root,'public/charts/'+id+'.json')));
 if(provenance.selectedCount!==provenance.selectedDates.length)fail('Selected count differs from provenance.');
 const csv=read('data/mes-2025-observed.csv');if(sha(csv)!==provenance.observedCsvSha256)fail('Observed CSV hash differs from provenance.');
 const remainingFile=path.join(root,'data/mes-2025-remaining-provenance.json'),envelope=validateRemainingEnvelope({catalog:additionalEnvelope.baselineCatalog,references:additionalEnvelope.baselineReferences,originalProvenance:provenance,remainingProvenance:existsSync(remainingFile)?JSON.parse(readFileSync(remainingFile,'utf8')):null,readChart:id=>readFileSync(path.join(root,'public/charts/'+id+'.json'))});
 const plan=normalizeObserved({csv,dates:provenance.selectedDates,baseCatalog:envelope.baselineCatalog,baseReferences:envelope.baselineReferences,template,sourceHashes:provenance.sourceExports.map(x=>x.sha256),existingCount:provenance.existingCharts.length,expectedRows:provenance.observedRows});
 const originalCatalog={...envelope.baselineCatalog,sessions:plan.oldCatalog};if(sha(json(originalCatalog))!==provenance.originalCatalogSha256||sha(JSON.stringify(plan.oldReferences)+'\n')!==provenance.originalChartReferencesSha256)fail('Existing catalog/reference entries were altered.');
 if(JSON.stringify(plan.newCatalog.map(({id,date,sha256})=>({id,date,sha256})))!==JSON.stringify(provenance.newCharts))fail('Normalized chart hashes differ from provenance.');
 for(const record of provenance.existingCharts){const bytes=readFileSync(path.join(root,'public/charts/'+record.id+'.json'));if(sha(bytes)!==record.sha256)fail('Existing chart was altered: '+record.id);}
 if(envelope.extras.length){const merged=mergeRemainingEnvelope(plan,envelope);plan.files.set('public/charts/catalog.json',json(merged.catalog));plan.files.set('data/chart-references.json',JSON.stringify(merged.references)+'\n');}
 if(additionalEnvelope.extraCatalog.length){const merged=mergeAdditional2026({catalog:JSON.parse(plan.files.get('public/charts/catalog.json')),references:JSON.parse(plan.files.get('data/chart-references.json'))},additionalEnvelope);plan.files.set('public/charts/catalog.json',json(merged.catalog));plan.files.set('data/chart-references.json',JSON.stringify(merged.references)+'\n');}
 for(const [name,text]of plan.files){const file=path.join(root,name);if(check){if(!existsSync(file)||readFileSync(file,'utf8')!==text)fail('Normalized asset is stale: '+name);}else{mkdirSync(path.dirname(file),{recursive:true});writeFileSync(file,text);}}
 return {status:'PASS',newSessions:plan.dates.length,totalSessions:plan.catalog.sessions.length+envelope.extras.length+additionalEnvelope.extraCatalog.length,observedRows:plan.rows.length,fullObservedDays:[...plan.days.values()].filter(x=>x.length===81).length,halfDayContext:[...plan.days].filter(([,r])=>r.length===45).map(([date,bars])=>({date,barCount:bars.length,endTime:bars.at(-1).t.slice(11)})),existingChartsPreserved:provenance.existingCharts.length,check};
}
if(process.argv[1]&&fileURLToPath(import.meta.url)===path.resolve(process.argv[1])){const root=process.argv.includes('--root')?process.argv[process.argv.indexOf('--root')+1]:fileURLToPath(new URL('../',import.meta.url));console.log(JSON.stringify(run(root,{check:process.argv.includes('--check')}),null,2));}
