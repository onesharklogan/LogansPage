/** Append-only public source archive. Never reads learner data. */
import {readFileSync,writeFileSync,existsSync,readdirSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {validateHistoryCandleIndex} from '../public/modules/history-candle-data.js';
const digest=bytes=>createHash('sha256').update(bytes).digest('hex');
const hex=/^[a-f0-9]{64}$/;
// First retained releases are part of the compatibility contract, not optional assets.
export const REQUIRED_HISTORY_DIGESTS=Object.freeze([
 '5171f568abcdbcc88852f84791eaa9dd2a3101119d0eef9df9c8067529dca68f',
 'd5e987bca98cc2f7a313d9ca209686b0754233b35b2e8990ded44f4c68976489',
]);
const manifestURL=base=>new URL('data/history-candle-retention.json',base);
const baselineURL=base=>new URL('data/history-candle-retention-baseline.json',base);
const directoryURL=base=>new URL('public/modules/history-candle-index/',base);
export function verifyHistoryRetention(base,{currentBytes,previousManifest}={}){
 const manifest=JSON.parse(readFileSync(manifestURL(base),'utf8'));
 if(!manifest||Object.keys(manifest).sort().join('|')!=='sha256|version'||manifest.version!==1||!Array.isArray(manifest.sha256)||!manifest.sha256.length||manifest.sha256.some(value=>typeof value!=='string'||!hex.test(value))||new Set(manifest.sha256).size!==manifest.sha256.length)throw Error('Invalid history retention manifest.');
 for(const pin of REQUIRED_HISTORY_DIGESTS)if(!manifest.sha256.includes(pin))throw Error('Required historical source was removed.');
 const baseline=JSON.parse(readFileSync(baselineURL(base),'utf8'));
 if(baseline.version!==1||!Array.isArray(baseline.sha256)||baseline.sha256.some(pin=>typeof pin!=='string'||!hex.test(pin))||REQUIRED_HISTORY_DIGESTS.some(pin=>!baseline.sha256.includes(pin)))throw Error('Invalid history retention baseline.');
 for(const pin of baseline.sha256)if(!manifest.sha256.includes(pin))throw Error('Previously supported history source was removed.');
 // CI/release tooling can supply the prior release's manifest for an append-only comparison.
 if(previousManifest){if(previousManifest.version!==1||!Array.isArray(previousManifest.sha256)||previousManifest.sha256.some(pin=>!hex.test(pin)))throw Error('Invalid prior history retention manifest.');for(const pin of previousManifest.sha256)if(!manifest.sha256.includes(pin))throw Error('Previously supported history source was removed.');}
 const files=readdirSync(directoryURL(base)).sort(),expected=manifest.sha256.map(pin=>pin+'.json').sort();
 if(JSON.stringify(files)!==JSON.stringify(expected))throw Error('History archive and retention manifest differ.');
 for(const pin of manifest.sha256){const bytes=readFileSync(new URL(pin+'.json',directoryURL(base)));if(bytes.length>4*1024*1024||digest(bytes)!==pin)throw Error('Retained history source integrity failed.');validateHistoryCandleIndex(JSON.parse(bytes.toString('utf8')));}
 if(currentBytes&&!manifest.sha256.includes(digest(currentBytes)))throw Error('Current history source has not been retained.');
 return manifest;
}
export function retainHistoryIndex(base,bytes){
 // Validate all retained bytes before touching any generated output. Never overwrite archive files.
 const manifest=verifyHistoryRetention(base);validateHistoryCandleIndex(JSON.parse(Buffer.from(bytes).toString('utf8')));
 if(Buffer.byteLength(bytes)>4*1024*1024)throw Error('History source exceeds its retention size limit.');
 const pin=digest(bytes),asset=new URL(pin+'.json',directoryURL(base));
 if(existsSync(asset)){if(digest(readFileSync(asset))!==pin)throw Error('Retained history source integrity failed.');return pin;}
 // Freeze every already-supported version before appending the next one. The ordinary
 // release guard checks this baseline even when no external prior manifest is supplied.
 writeFileSync(baselineURL(base),JSON.stringify(manifest,null,2)+'\n');
 mkdirSync(directoryURL(base),{recursive:true});writeFileSync(asset,bytes,{flag:'wx'});
 // On interruption between writes, verification fails closed; no prior asset is removed.
 writeFileSync(manifestURL(base),JSON.stringify({...manifest,sha256:[...manifest.sha256,pin]},null,2)+'\n');
 return pin;
}
