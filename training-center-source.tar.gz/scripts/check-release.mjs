import { readFileSync, existsSync, readdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { requireQaPrivateStage } from './qa-assets.mjs';
const root = new URL('../', import.meta.url);
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const fail = message => { throw new Error(message); };
function inspect(directory) {
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    const path = new URL(entry.name + (entry.isDirectory() ? '/' : ''), directory);
    if (entry.isDirectory()) inspect(path);
    else if (/^qa.*\.html$/i.test(entry.name) || /\.(sqlite|db)(-|\.|$)/i.test(entry.name)) fail('Unsafe public asset: ' + entry.name);
  }
}
requireQaPrivateStage(false, new URL('public/', root));
inspect(new URL('public/', root));
for (const name of ['.openai/hosting.json', 'app/setup/page.tsx', 'components/setup-form.tsx', 'app/chatgpt-auth.ts']) if (existsSync(new URL(name, root))) fail('Native setup/publication artifact retained: ' + name);
for (const name of ['lib/portal/google-auth.mjs','components/google-sign-in.tsx','components/google-gis.mjs']) if (existsSync(new URL(name, root))) fail('Removed identity provider retained: ' + name);
if (JSON.parse(readFileSync(new URL('package.json', root), 'utf8')).dependencies['google-auth-library']) fail('Unused Google dependency retained.');
const editorHash = hash(readFileSync(new URL('public/editor/index.html', root)));
// Reviewed optional cover art, study-only reveal, adaptive bar labels, and standalone branded navigation; chart/auth/data contracts remain protected below.
if (editorHash !== '6814745c4478fd01fae1d365959a6c87a06123ca9a74d7035007b276fd17d9b5') fail('Actual editor changed; review and deliberately update provenance.');
const bias = JSON.parse(readFileSync(new URL('data/bias-provenance.json', root), 'utf8'));
if (hash(readFileSync(new URL('public/modules/market-direction.html', root))) !== bias.moduleSha256) fail('Reviewed Market Direction Simulator differs from its recorded provenance.');
const accuracyHelper = bias.directionAccuracyHelper;
if (!accuracyHelper || accuracyHelper.path !== 'public/modules/direction-accuracy.js') fail('Direction Accuracy helper provenance is missing.');
const accuracyBytes = readFileSync(new URL(accuracyHelper.path, root));
if (accuracyBytes.length !== accuracyHelper.bytes || hash(accuracyBytes) !== accuracyHelper.sha256) fail('Direction Accuracy rules differ from their reviewed provenance.');
const profileHelper = bias.learnerProfilesHelper;
if (!profileHelper || profileHelper.path !== 'public/modules/learner-profiles.js') fail('Shared learner profile helper provenance is missing.');
const profileBytes = readFileSync(new URL(profileHelper.path, root));
if (profileBytes.length !== profileHelper.bytes || hash(profileBytes) !== profileHelper.sha256) fail('Shared learner profile rules differ from their reviewed provenance.');
if (bias.upstreamModuleSha256 !== '8454075ad9c856b871edeec16a7c2a1fccb51655a72b1b8fec170ce649c20249') fail('Original Bias module provenance changed.');
const catalog = JSON.parse(readFileSync(new URL('public/charts/catalog.json', root), 'utf8'));
if (catalog.sessions.length !== 203 || readdirSync(new URL('public/charts/', root)).length !== 204) fail('Unexpected chart count.');
for (const reference of catalog.sessions) if (hash(readFileSync(new URL('public/charts/' + reference.id + '.json', root))) !== reference.sha256) fail('Immutable chart hash mismatch.');
const server = readFileSync(new URL('lib/portal/server.mjs', root), 'utf8');
if (server.includes('oai-authenticated-') || /path\[1\]\s*===\s*['"]setup/.test(server)) fail('Spoofable native setup path retained.');
console.log(JSON.stringify({ sourceCheck: 'passed', target: 'Render Node service', verifiedCharts: 203, jsonOnlyEditorReviewed: true, reviewedBiasModuleMatchesProvenance: true, originalBiasProvenanceRetained: true, webBootstrap: false, note: 'Not evidence of deployment, configured credentials, or live Neon or real-user activation verification.' }, null, 2));
