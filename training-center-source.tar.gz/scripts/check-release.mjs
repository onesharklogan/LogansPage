import { readFileSync, existsSync, readdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { requireQaPrivateStage } from './qa-assets.mjs';
const root = new URL('../', import.meta.url);
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const fail = message => { throw new Error(message); };
function inspect(directory) {
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    const path = new URL(entry.name + (entry.isDirectory() ? '/' : ''), directory);
    if (entry.isDirectory()) inspect(path);
    else if (/^qa.*\.html$/i.test(entry.name) || /\.(sqlite|db)(-|\.|$)/i.test(entry.name)) fail('Unsafe public asset: ' + entry.name);
  }
}
requireQaPrivateStage(false, new URL('public/', root));
inspect(new URL('public/', root));
for (const name of ['.openai/hosting.json', 'app/setup/page.tsx', 'components/setup-form.tsx', 'app/chatgpt-auth.ts']) if (existsSync(new URL(name, root))) fail('Native setup/publication artifact retained: ' + name);
for (const name of ['lib/portal/google-auth.mjs','components/google-sign-in.tsx','components/google-gis.mjs']) if (existsSync(new URL(name, root))) fail('Removed identity provider retained: ' + name);
if (JSON.parse(readFileSync(new URL('package.json', root), 'utf8')).dependencies['google-auth-library']) fail('Unused Google dependency retained.');
const editorHash = hash(readFileSync(new URL('public/editor/index.html', root)));
// Reviewed additive lesson types/reference markup; original chart and auth contracts remain protected below.
if (editorHash !== '7900600e2af5f5e4d640e736d3227389eb24146e33eb77aca1dc3bcedcf5aa3e') fail('Actual editor changed; review and deliberately update provenance.');
const bias = JSON.parse(readFileSync(new URL('data/bias-provenance.json', root), 'utf8'));
if (hash(readFileSync(new URL('public/modules/market-direction.html', root))) !== bias.moduleSha256) fail('Verified Market Direction Bias module changed.');
const catalog = JSON.parse(readFileSync(new URL('public/charts/catalog.json', root), 'utf8'));
if (catalog.sessions.length !== 203 || readdirSync(new URL('public/charts/', root)).length !== 204) fail('Unexpected chart count.');
for (const reference of catalog.sessions) if (hash(readFileSync(new URL('public/charts/' + reference.id + '.json', root))) !== reference.sha256) fail('Immutable chart hash mismatch.');
const server = readFileSync(new URL('lib/portal/server.mjs', root), 'utf8');
if (server.includes('oai-authenticated-') || /path\[1\]\s*===\s*['"]setup/.test(server)) fail('Spoofable native setup path retained.');
console.log(JSON.stringify({ sourceCheck: 'passed', target: 'Render Node service', verifiedCharts: 203, jsonOnlyEditorReviewed: true, exactBiasModulePreserved: true, webBootstrap: false, note: 'Not evidence of deployment, configured credentials, or live Neon or real-user activation verification.' }, null, 2));
