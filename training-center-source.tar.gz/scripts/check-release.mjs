import { readFileSync, existsSync, readdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { requireQaPrivateStage } from './qa-assets.mjs';
const root = new URL('../', import.meta.url);
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const fail = message => { throw new Error(message); };
function inspect(directory) {
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    const path = new URL(entry.name + (entry.isDirectory() ? '/' : ''), directory);
    if (entry.isDirectory()) inspect(path);
    else if (/^qa.*\.html$/i.test(entry.name) || /\.(sqlite|db)(-|\.|$)/i.test(entry.name)) fail('Unsafe public asset: ' + entry.name);
  }
}
requireQaPrivateStage(false, new URL('public/', root));
inspect(new URL('public/', root));
for (const name of ['.openai/hosting.json', 'app/setup/page.tsx', 'components/setup-form.tsx', 'app/chatgpt-auth.ts']) if (existsSync(new URL(name, root))) fail('Native setup/publication artifact retained: ' + name);
for (const name of ['lib/portal/google-auth.mjs','components/google-sign-in.tsx','components/google-gis.mjs']) if (existsSync(new URL(name, root))) fail('Removed identity provider retained: ' + name);
if (JSON.parse(readFileSync(new URL('package.json', root), 'utf8')).dependencies['google-auth-library']) fail('Unused Google dependency retained.');
const editorHash = hash(readFileSync(new URL('public/editor/index.html', root)));
// Reviewed optional cover art, study-only reveal, adaptive bar labels, and standalone branded navigation; chart/auth/data contracts remain protected below.
if (editorHash !== '0c228fb9f7e9c4f65690fdbefeb4840b4901ec221f88434227148d42729c2f4c') fail('Actual editor changed; review and deliberately update provenance.');
const bias = JSON.parse(readFileSync(new URL('data/bias-provenance.json', root), 'utf8'));
if (hash(readFileSync(new URL('public/modules/market-direction.html', root))) !== bias.moduleSha256) fail('Reviewed Market Direction Simulator differs from its recorded provenance.');
const marker = JSON.parse(readFileSync(new URL('data/chart-marker-provenance.json', root), 'utf8'));
if (marker.originalLibraryFileId !== 'libfile_35b27bbb09808191aeb3108da7015456' || marker.originalBytes !== 42795 || marker.originalSha256 !== '812c13bce8f15a082316089f685a04ee67445aae2d750c96275a1cb698007c13') fail('Chart Marker reference provenance changed.');
if (marker.modulePath !== 'public/modules/chart-marker.html') fail('Unexpected Chart Marker module path.');
const markerBytes = readFileSync(new URL(marker.modulePath, root));
if (markerBytes.length !== marker.moduleBytes || hash(markerBytes) !== marker.moduleSha256) fail('Reviewed Chart Marker differs from its recorded provenance.');
if (!Array.isArray(marker.features) || marker.features.length < 12 || !Array.isArray(marker.nativeApiLimitations) || marker.nativeApiLimitations.length < 4) fail('Chart Marker feature/limitation record is incomplete.');
const accuracyHelper = bias.directionAccuracyHelper;
if (!accuracyHelper || accuracyHelper.path !== 'public/modules/direction-accuracy.js') fail('Direction Accuracy helper provenance is missing.');
const accuracyBytes = readFileSync(new URL(accuracyHelper.path, root));
if (accuracyBytes.length !== accuracyHelper.bytes || hash(accuracyBytes) !== accuracyHelper.sha256) fail('Direction Accuracy rules differ from their reviewed provenance.');
const profileHelper = bias.learnerProfilesHelper;
if (!profileHelper || profileHelper.path !== 'public/modules/learner-profiles.js') fail('Shared learner profile helper provenance is missing.');
const profileBytes = readFileSync(new URL(profileHelper.path, root));
if (profileBytes.length !== profileHelper.bytes || hash(profileBytes) !== profileHelper.sha256) fail('Shared learner profile rules differ from their reviewed provenance.');
if (bias.upstreamModuleSha256 !== '8454075ad9c856b871edeec16a7c2a1fccb51655a72b1b8fec170ce649c20249') fail('Original Bias module provenance changed.');
const catalog = JSON.parse(readFileSync(new URL('public/charts/catalog.json', root), 'utf8'));
const acquisition = JSON.parse(readFileSync(new URL('data/mes-2025-provenance.json', root), 'utf8'));
if (catalog.sessions.length !== 353 || readdirSync(new URL('public/charts/', root)).length !== 354) fail('Unexpected chart count.');
if (acquisition.existingCharts.length !== 203 || acquisition.newCharts.length !== 150 || acquisition.selectedCount !== 150) fail('Unexpected acquisition count.');
const originalIds = new Set(acquisition.existingCharts.map(row => row.id));
const originalCatalog = { ...catalog, sessions: catalog.sessions.filter(row => originalIds.has(row.id)) };
if (hash(JSON.stringify(originalCatalog, null, 2) + '\n') !== 'ca24cacc01ecb7e654009509dd007e1fa5478ddab4067468b10c263b743b5e60') fail('Original 203 catalog entries changed.');
const originalReferences = JSON.parse(readFileSync(new URL('data/chart-references.json', root), 'utf8')).filter(row => originalIds.has(row.id));
if (hash(JSON.stringify(originalReferences) + '\n') !== '6d12dff52a623ab14a3c780fd165428d2d6038c96dacd41dfd92a70c2ce64f83') fail('Original 203 chart references changed.');
const expectedCharts = [...acquisition.existingCharts, ...acquisition.newCharts];
if (new Set(expectedCharts.map(row => row.id)).size !== 353) fail('Duplicate acquisition chart id.');
for (const expected of expectedCharts) {
  const reference = catalog.sessions.find(row => row.id === expected.id);
  if (!reference || reference.sha256 !== expected.sha256 || reference.date !== expected.date) fail('Immutable original or acquired chart reference changed.');
}
if (hash(readFileSync(new URL(acquisition.observedCsv, root))) !== acquisition.observedCsvSha256) fail('Observed source CSV changed.');
for (const reference of catalog.sessions) if (hash(readFileSync(new URL('public/charts/' + reference.id + '.json', root))) !== reference.sha256) fail('Immutable chart hash mismatch.');
const server = readFileSync(new URL('lib/portal/server.mjs', root), 'utf8');
if (server.includes('oai-authenticated-') || /path\[1\]\s*===\s*['"]setup/.test(server)) fail('Spoofable native setup path retained.');
console.log(JSON.stringify({ sourceCheck: 'passed', target: 'Render Node service', verifiedCharts: 353, preservedOriginalCharts: 203, acquired2025Charts: 150, jsonOnlyEditorReviewed: true, reviewedBiasModuleMatchesProvenance: true, originalBiasProvenanceRetained: true, webBootstrap: false, note: 'Not evidence of deployment, configured credentials, or live Neon or real-user activation verification.' }, null, 2));
