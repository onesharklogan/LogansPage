import {fileURLToPath} from 'node:url';
import {run as verifyAdditional2026} from './normalize-2026-additional-sessions.mjs';
import { readFileSync, existsSync, readdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { requireQaPrivateStage } from './qa-assets.mjs';
import { buildHistoryCandleIndex } from './build-history-candle-index.mjs';
import ts from 'typescript';
import {verifyHistoryRetention} from './history-candle-retention.mjs';
const root = new URL('../', import.meta.url);
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const fail = message => { throw new Error(message); };
function inspect(directory) {
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    const path = new URL(entry.name + (entry.isDirectory() ? '/' : ''), directory);
    if (entry.isDirectory()) inspect(path);
    else if (/^qa.*\.html$/i.test(entry.name) || /\.(sqlite|db)(-|\.|$)/i.test(entry.name)) fail('Unsafe public asset: ' + entry.name);
  }
}
requireQaPrivateStage(false, new URL('public/', root));
inspect(new URL('public/', root));
for (const name of ['.openai/hosting.json', 'app/setup/page.tsx', 'components/setup-form.tsx', 'app/chatgpt-auth.ts']) if (existsSync(new URL(name, root))) fail('Native setup/publication artifact retained: ' + name);
for (const name of ['lib/portal/google-auth.mjs','components/google-sign-in.tsx','components/google-gis.mjs']) if (existsSync(new URL(name, root))) fail('Removed identity provider retained: ' + name);
if (JSON.parse(readFileSync(new URL('package.json', root), 'utf8')).dependencies['google-auth-library']) fail('Unused Google dependency retained.');
const editorHash = hash(readFileSync(new URL('public/editor/index.html', root)));
// Successor review additionally pins raw Teacher six-week padding and empty-row sizing.
// Reviewed optional cover art, study-only reveal, adaptive bar labels, and standalone branded navigation; chart/auth/data contracts remain protected below.
if (editorHash !== '327b2781a23c4d2e7e62075a7dabc968bd3139ca6089f38715a9bae80ff6ed96') fail('Actual editor changed; review and deliberately update provenance.');
// Reviewed shared loading assets; each raw iframe uses the same root-relative files.
const loading = JSON.parse(readFileSync(new URL('data/candlestick-loading-provenance.json', root), 'utf8'));
if (loading.frames !== 5 || loading.durationMs !== 1100) fail('Unexpected loading motion contract.');
for (const entry of loading.assets) { const bytes = readFileSync(new URL(entry.path, root)); if (bytes.length !== entry.bytes || hash(bytes) !== entry.sha256) fail('Loading asset differs from reviewed provenance: ' + entry.path); }
const shapeGeometryBytes=readFileSync(new URL('lib/portal/teacher-shape-geometry.cjs',root));
if(hash(shapeGeometryBytes)!=='a8d481697ee970df62a0832e5dec234bf9625bc1499b97468a5ec0e5fbb2c068')fail('Teacher shape geometry changed; review shared transform semantics.');
for(const entry of ['public/editor/index.html','public/modules/chart-marker.html'])if(!readFileSync(new URL(entry,root),'utf8').includes(shapeGeometryBytes.toString('utf8')))fail('Teacher shape geometry embed differs: '+entry);
const bias = JSON.parse(readFileSync(new URL('data/bias-provenance.json', root), 'utf8'));
if (hash(readFileSync(new URL('public/modules/market-direction.html', root))) !== bias.moduleSha256) fail('Reviewed Market Direction Simulator differs from its recorded provenance.');
const marker = JSON.parse(readFileSync(new URL('data/chart-marker-provenance.json', root), 'utf8'));
if (marker.originalLibraryFileId !== 'libfile_35b27bbb09808191aeb3108da7015456' || marker.originalBytes !== 42795 || marker.originalSha256 !== '812c13bce8f15a082316089f685a04ee67445aae2d750c96275a1cb698007c13') fail('Chart Marker reference provenance changed.');
if (marker.modulePath !== 'public/modules/chart-marker.html') fail('Unexpected Chart Marker module path.');
const markerBytes = readFileSync(new URL(marker.modulePath, root));
if (markerBytes.length !== marker.moduleBytes || hash(markerBytes) !== marker.moduleSha256) fail('Reviewed Chart Marker differs from its recorded provenance.');
if (!Array.isArray(marker.features) || marker.features.length < 12 || !Array.isArray(marker.nativeApiLimitations) || marker.nativeApiLimitations.length < 4) fail('Chart Marker feature/limitation record is incomplete.');
const accuracyHelper = bias.directionAccuracyHelper;
if (!accuracyHelper || accuracyHelper.path !== 'public/modules/direction-accuracy.js') fail('Direction Accuracy helper provenance is missing.');
const accuracyBytes = readFileSync(new URL(accuracyHelper.path, root));
if (accuracyBytes.length !== accuracyHelper.bytes || hash(accuracyBytes) !== accuracyHelper.sha256) fail('Direction Accuracy rules differ from their reviewed provenance.');
const practiceHelper = bias.practiceEvidenceHelper;
if (!practiceHelper || practiceHelper.path !== 'public/modules/practice-evidence.js') fail('Neutral practice evidence helper provenance is missing.');
const practiceBytes = readFileSync(new URL(practiceHelper.path, root));
if (practiceBytes.length !== practiceHelper.bytes || hash(practiceBytes) !== practiceHelper.sha256) fail('Neutral practice evidence differs from its reviewed provenance.');
// Learner account public modules: fixed paths and exact reviewed bytes; readiness stays separate.
for (const [key, expectedPath] of [['learnerAccountBridge', 'public/modules/learner-account-bridge.js'], ['learnerAccountClient', 'public/modules/learner-client.js'], ['learnerAccountStats', 'public/modules/learner-stats.js']]) {
  const helper = bias[key];
  if (!helper || helper.path !== expectedPath) fail('Learner account module provenance is missing or has an unexpected path: ' + key);
  const bytes = readFileSync(new URL(expectedPath, root));
  if (bytes.length !== helper.bytes || hash(bytes) !== helper.sha256) fail('Learner account module differs from its reviewed provenance: ' + key);
}
for(const [key,path] of [['directionExitBracket','public/modules/direction-exit-bracket.js'],['directionExitBracketUI','public/modules/direction-exit-bracket-ui.js'],['directionExitBracketStyles','public/modules/direction-exit-bracket-ui.css']]){const record=bias[key],bytes=readFileSync(new URL(path,root));if(record?.path!==path||record.bytes!==bytes.length||record.sha256!==hash(bytes))fail('Exit bracket provenance mismatch: '+key);}
// End learner account public-module provenance guard.
const profileHelper = bias.learnerProfilesHelper;
if (!profileHelper || profileHelper.path !== 'public/modules/learner-profiles.js') fail('Shared learner profile helper provenance is missing.');
const profileBytes = readFileSync(new URL(profileHelper.path, root));
if (profileBytes.length !== profileHelper.bytes || hash(profileBytes) !== profileHelper.sha256) fail('Shared learner profile rules differ from their reviewed provenance.');
if (bias.upstreamModuleSha256 !== '8454075ad9c856b871edeec16a7c2a1fccb51655a72b1b8fec170ce649c20249') fail('Original Bias module provenance changed.');
const catalog = JSON.parse(readFileSync(new URL('public/charts/catalog.json', root), 'utf8'));
const acquisition = JSON.parse(readFileSync(new URL('data/mes-2025-provenance.json', root), 'utf8'));
const remaining = JSON.parse(readFileSync(new URL('data/mes-2025-remaining-provenance.json', root), 'utf8'));
const additional2026 = JSON.parse(readFileSync(new URL('data/mes-2026-additional-provenance.json', root), 'utf8'));
const verifiedAdditional2026 = verifyAdditional2026(fileURLToPath(root), {check:true});
if (verifiedAdditional2026.status !== 'PASS' || verifiedAdditional2026.addedSessions !== 7 || verifiedAdditional2026.existingPreserved !== 450 || additional2026.notAddedDates.length) fail('Bounded2026 acquisition or frozen450 preservation is incomplete.');
if (remaining.readiness !== 'YEAR_COVERAGE_VERIFIED' || remaining.selectedCount !== 97 || remaining.newCharts.length !== 97 || remaining.existingCharts.length !== 353 || remaining.knownMissingObservedDates.length || remaining.incompleteObservedSessions.length) fail('Remaining-year acquisition is incomplete.');
if (catalog.sessions.length !== 457 || readdirSync(new URL('public/charts/', root)).length !== 458) fail('Unexpected chart count.');
if (acquisition.existingCharts.length !== 203 || acquisition.newCharts.length !== 150 || acquisition.selectedCount !== 150) fail('Unexpected acquisition count.');
const originalIds = new Set(acquisition.existingCharts.map(row => row.id));
const originalCatalog = { ...catalog, sessions: catalog.sessions.filter(row => originalIds.has(row.id)) };
if (hash(JSON.stringify(originalCatalog, null, 2) + '\n') !== 'ca24cacc01ecb7e654009509dd007e1fa5478ddab4067468b10c263b743b5e60') fail('Original 203 catalog entries changed.');
const originalReferences = JSON.parse(readFileSync(new URL('data/chart-references.json', root), 'utf8')).filter(row => originalIds.has(row.id));
if (hash(JSON.stringify(originalReferences) + '\n') !== '6d12dff52a623ab14a3c780fd165428d2d6038c96dacd41dfd92a70c2ce64f83') fail('Original 203 chart references changed.');
const v32Ids = new Set(remaining.existingCharts.map(row => row.id));
const v32Catalog = { ...catalog, sessions: catalog.sessions.filter(row => v32Ids.has(row.id)) };
if (hash(JSON.stringify(v32Catalog, null, 2) + '\n') !== remaining.baselineCatalogSha256) fail('Published353 catalog entries changed.');
const v32References = JSON.parse(readFileSync(new URL('data/chart-references.json', root), 'utf8')).filter(row => v32Ids.has(row.id));
if (hash(JSON.stringify(v32References) + '\n') !== remaining.baselineReferencesSha256) fail('Published353 chart references changed.');
for (const record of remaining.existingCharts) if (hash(readFileSync(new URL('public/charts/' + record.id + '.json', root))) !== record.sha256) fail('Published353 chart bytes changed.');
const frozen450Charts = [...acquisition.existingCharts, ...acquisition.newCharts, ...remaining.newCharts];
if (new Set(frozen450Charts.map(row => row.id)).size !== 450) fail('Duplicate frozen450 acquisition chart id.');
const expectedCharts = [...frozen450Charts, ...additional2026.newCharts];
if (new Set(expectedCharts.map(row => row.id)).size !== 457 || catalog.sessions.filter(row => row.date.startsWith('2026-')).length !== 210) fail('Duplicate or missing bounded2026 acquisition chart id.');
for (const expected of expectedCharts) {
  const reference = catalog.sessions.find(row => row.id === expected.id);
  if (!reference || reference.sha256 !== expected.sha256 || reference.date !== expected.date) fail('Immutable original or acquired chart reference changed.');
}
if (hash(readFileSync(new URL(acquisition.observedCsv, root))) !== acquisition.observedCsvSha256) fail('Observed source CSV changed.');
if (hash(readFileSync(new URL(remaining.observedCsv, root))) !== remaining.observedCsvSha256 || hash(readFileSync(new URL(remaining.coverageFile, root))) !== remaining.coverageSha256) fail('Remaining-year source or coverage hash changed.');
for (const reference of catalog.sessions) if (hash(readFileSync(new URL('public/charts/' + reference.id + '.json', root))) !== reference.sha256) fail('Immutable chart hash mismatch.');
const historyIndex = buildHistoryCandleIndex(root);
const previousHistoryAt=process.argv.indexOf('--previous-history-manifest');
if(previousHistoryAt>=0&&!process.argv[previousHistoryAt+1])fail('Missing prior history manifest path.');
verifyHistoryRetention(root,{currentBytes:historyIndex,...(previousHistoryAt>=0?{previousManifest:JSON.parse(readFileSync(process.argv[previousHistoryAt+1],'utf8'))}:{})});
const historyLoader = ts.createSourceFile('history-candle-data.js', readFileSync(new URL('public/modules/history-candle-data.js', root), 'utf8'), ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
const historyPins = historyLoader.statements.filter(s => ts.isVariableStatement(s) && s.modifiers?.some(m => m.kind === ts.SyntaxKind.ExportKeyword) && (s.declarationList.flags & ts.NodeFlags.Const)).flatMap(s => s.declarationList.declarations).filter(d => ts.isIdentifier(d.name) && d.name.text === 'HISTORY_INDEX_SHA256');
if (readFileSync(new URL('public/modules/history-candle-index.json', root), 'utf8') !== historyIndex || historyPins.length !== 1 || !historyPins[0].initializer || !ts.isStringLiteral(historyPins[0].initializer) || historyPins[0].initializer.text !== hash(historyIndex)) fail('History close index or pin differs from verified original chart sources.');
const server = readFileSync(new URL('lib/portal/server.mjs', root), 'utf8');
if (server.includes('oai-authenticated-') || /path\[1\]\s*===\s*['"]setup/.test(server)) fail('Spoofable native setup path retained.');
console.log(JSON.stringify({ sourceCheck: 'passed', target: 'Render Node service', verifiedCharts: 457, preservedFrozenCharts: 450, added2026Charts: 7, total2026Charts: 210, preservedPublishedCharts: 353, preservedOriginalCharts: 203, acquired2025Charts: 247, genuine2025ShortContextDays: 3, jsonOnlyEditorReviewed: true, reviewedBiasModuleMatchesProvenance: true, originalBiasProvenanceRetained: true, webBootstrap: false, note: 'Not evidence of deployment, configured credentials, or live Neon or real-user activation verification.' }, null, 2));
