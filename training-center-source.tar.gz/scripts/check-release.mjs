import { readFileSync, existsSync, readdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { requireQaPrivateStage } from './qa-assets.mjs';
const root = new URL('../', import.meta.url);
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const fail = message => { throw new Error(message); };
function inspect(directory) {
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    const path = new URL(entry.name + (entry.isDirectory() ? '/' : ''), directory);
    if (entry.isDirectory()) inspect(path);
    else if (/^qa.*\.html$/i.test(entry.name) || /\.(sqlite|db)(-|\.|$)/i.test(entry.name)) fail('Unsafe public asset: ' + entry.name);
  }
}
requireQaPrivateStage(false, new URL('public/', root));
inspect(new URL('public/', root));
for (const name of ['.openai/hosting.json', 'app/setup/page.tsx', 'components/setup-form.tsx', 'app/chatgpt-auth.ts']) if (existsSync(new URL(name, root))) fail('Native setup/publication artifact retained: ' + name);
for (const name of ['lib/portal/google-auth.mjs','components/google-sign-in.tsx','components/google-gis.mjs']) if (existsSync(new URL(name, root))) fail('Removed identity provider retained: ' + name);
if (JSON.parse(readFileSync(new URL('package.json', root), 'utf8')).dependencies['google-auth-library']) fail('Unused Google dependency retained.');
const editorHash = hash(readFileSync(new URL('public/editor/index.html', root)));
// Independently reviewed optional allowlisted cover art, study-only reveal and adaptive global bar labels; chart/auth/data contracts remain protected below.
if (editorHash !== '7fd6779d82b609e78a85ed920e234e21f32ed76419ccedb5f79837c26a4f200b') fail('Actual editor changed; review and deliberately update provenance.');
const bias = JSON.parse(readFileSync(new URL('data/bias-provenance.json', root), 'utf8'));
if (hash(readFileSync(new URL('public/modules/market-direction.html', root))) !== bias.moduleSha256) fail('Reviewed Market Direction Bias module differs from its recorded provenance.');
if (bias.upstreamModuleSha256 !== '8454075ad9c856b871edeec16a7c2a1fccb51655a72b1b8fec170ce649c20249') fail('Original Bias module provenance changed.');
const catalog = JSON.parse(readFileSync(new URL('public/charts/catalog.json', root), 'utf8'));
if (catalog.sessions.length !== 203 || readdirSync(new URL('public/charts/', root)).length !== 204) fail('Unexpected chart count.');
for (const reference of catalog.sessions) if (hash(readFileSync(new URL('public/charts/' + reference.id + '.json', root))) !== reference.sha256) fail('Immutable chart hash mismatch.');
const server = readFileSync(new URL('lib/portal/server.mjs', root), 'utf8');
if (server.includes('oai-authenticated-') || /path\[1\]\s*===\s*['"]setup/.test(server)) fail('Spoofable native setup path retained.');
console.log(JSON.stringify({ sourceCheck: 'passed', target: 'Render Node service', verifiedCharts: 203, jsonOnlyEditorReviewed: true, reviewedBiasModuleMatchesProvenance: true, originalBiasProvenanceRetained: true, webBootstrap: false, note: 'Not evidence of deployment, configured credentials, or live Neon or real-user activation verification.' }, null, 2));
