import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  BATCH, COMPLETED_THROUGH, CANDIDATE_DATES, CLOSED_RTH_DATES,
  BASELINE_MANIFEST_SHA256, sha, json, same, fail,
  validateFrozenBaseline, peelAdditional2026,
} from './additional-2026-envelope.mjs';
export { sha };
const dateValid = value => typeof value === 'string' && /^(2025|2026)-\d{2}-\d{2}$/.test(value) &&
  Number.isFinite(Date.parse(value + 'T00:00:00Z')) && new Date(value + 'T00:00:00Z').toISOString().slice(0, 10) === value;
const validPrice = value => Number.isFinite(value) && value > 0 && value < 1e9 && Number.isInteger(value * 4);
const closeRow = ({ t, c }) => ({ t, c });
const dayKeys = (start, end) => {
  const dates = [];
  for (let d = new Date(start + 'T00:00:00Z'); d.toISOString().slice(0, 10) <= end; d.setUTCDate(d.getUTCDate() + 1)) {
    const date = d.toISOString().slice(0, 10);
    if (![0, 6].includes(d.getUTCDay()) && !CLOSED_RTH_DATES.includes(date)) dates.push(date);
  }
  return dates;
};

export function parseObservedCsv(text) {
  const lines = text.trim().split(/\r?\n/);
  if (lines.shift() !== 'timestamp,open,high,low,close' || !lines.length) fail('Unexpected or empty observed CSV.');
  const rows = [];
  for (const line of lines) {
    const m = /^((?:2025|2026)-\d{2}-\d{2}) (\d{2}:\d{2}):00,(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)$/.exec(line);
    if (!m || !dateValid(m[1]) || m[1] > COMPLETED_THROUGH) fail('Invalid or unfinished observed timestamp.');
    const [o, h, l, c] = m.slice(3).map(Number), t = m[1] + ' ' + m[2];
    if (![o, h, l, c].every(validPrice) || l > Math.min(o, c) || h < Math.max(o, c) || l > h) fail('Invalid observed OHLC or quarter tick.');
    if (rows.length && t <= rows.at(-1).t) fail('Duplicate or nonchronological observed timestamp.');
    rows.push({ t, o, h, l, c });
  }
  return rows;
}

export const canonicalCsv = rows => 'timestamp,open,high,low,close\n' + rows.map(b =>
  b.t + ':00,' + [b.o, b.h, b.l, b.c].map(x => x.toFixed(2)).join(',')).join('\n') + '\n';

export function groupObserved(rows) {
  const days = new Map();
  for (const row of rows) {
    const date = row.t.slice(0, 10);
    if (!days.has(date)) days.set(date, []);
    days.get(date).push(row);
  }
  for (const [date, bars] of days) {
    if (![45, 81].includes(bars.length) || [0, 6].includes(new Date(date + 'T00:00:00Z').getUTCDay())) fail('Incomplete or weekend observed session: ' + date);
    for (let i = 0; i < bars.length; i++) {
      const minute = 510 + i * 5;
      const expected = date + ' ' + String(Math.floor(minute / 60)).padStart(2, '0') + ':' + String(minute % 60).padStart(2, '0');
      if (bars[i].t !== expected) fail('Missing or shifted five-minute slot: ' + date);
    }
  }
  return days;
}

/** Every overlap is compared, including retained closes for unpublished Jan2. */
export function auditOverlap(rows, charts) {
  const knownCloses = new Map(), knownBars = new Map();
  for (const chart of charts.values()) {
    for (const bar of [...chart.current, ...chart.prior, ...(chart.previousSession?.bars || [])]) {
      const prior = knownBars.get(bar.t);
      if (prior && !same(prior, bar)) fail('Frozen baseline has conflicting retained OHLC: ' + bar.t);
      knownBars.set(bar.t, bar);
    }
    // Published legacy rolling histories can repeat the same source observations.
    for (const { t, c } of [...chart.warmup, ...chart.current, ...chart.prior]) {
      if (knownCloses.has(t) && knownCloses.get(t) !== c) fail('Frozen baseline has conflicting retained close: ' + t);
      knownCloses.set(t, c);
    }
  }
  let overlapOhlcRows = 0, overlapCloseRows = 0;
  for (const bar of rows) {
    if (knownBars.has(bar.t)) {
      if (!same(knownBars.get(bar.t), bar)) fail('Observed OHLC conflicts with preserved source: ' + bar.t);
      overlapOhlcRows++;
    }
    if (knownCloses.has(bar.t)) {
      if (knownCloses.get(bar.t) !== bar.c) fail('Observed close conflicts with preserved source: ' + bar.t);
      overlapCloseRows++;
    }
  }
  return { overlapOhlcRows, overlapCloseRows, conflictingRows: 0 };
}

function validateSourceExports(exports) {
  if (!Array.isArray(exports) || !exports.length || exports.length > 50 ||
      new Set(exports.map(r => r.sha256)).size !== exports.length || exports.some(r =>
        !r || !same(Object.keys(r).sort(), ['name', 'sha256']) ||
        typeof r.name !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9._-]{0,119}$/.test(r.name) ||
        !/^[a-f0-9]{64}$/.test(r.sha256))) fail('Invalid sanitized source export identities.');
}

export function planAdditional2026({ csv, dates, baseCatalog, baseReferences, manifest, readChart, sourceExports }) {
  validateSourceExports(sourceExports);
  if (!Array.isArray(dates) || !dates.length || !same(dates, [...new Set(dates)].sort()) ||
      dates.some(date => !CANDIDATE_DATES.includes(date))) fail('Selection is outside the bounded missing2026 dates.');
  const frozen = validateFrozenBaseline({ catalog: baseCatalog, references: baseReferences, manifest, readChart });
  const rows = parseObservedCsv(csv);
  const overlapAudit = auditOverlap(rows, frozen.charts);
  const days = groupObserved(rows);
  const files = new Map(), newCatalog = [], newReferences = [], contexts = [];
  for (const date of dates) {
    const current = days.get(date);
    if (current?.length !== 81) fail('Missing complete current81: ' + date);
    const seedDate = date === '2026-01-02' ? '2025-12-31' : '2026-10-23';
    const seed = frozen.charts.get(seedDate);
    const seedEntry = baseCatalog.sessions.find(r => r.date === seedDate);
    if (!seed || !seedEntry || seed.current.length !== 81 || !seed.warmup.length) fail('Missing genuine retained seed.');
    const warmup = [...seed.warmup.map(closeRow), ...seed.current.map(closeRow)];
    let previous = seed.current, previousDate = seedDate;
    for (const day of dayKeys(seedDate, date).slice(1, -1)) {
      const observed = days.get(day);
      if (observed?.length !== 81) fail('Acquisition gap in causal warmup: ' + day);
      warmup.push(...observed.map(closeRow));
      previous = observed;
      previousDate = day;
    }
    if (warmup.length < 81 || warmup.length > 20000 || warmup.some((b, i) =>
      !dateValid(b.t.slice(0, 10)) || !validPrice(b.c) || b.t.slice(0, 10) >= date || (i && b.t <= warmup[i - 1].t)) ||
      !same(warmup.slice(-previous.length), previous.map(closeRow)) || previous.at(-1).t !== previousDate + ' 15:10') fail('Invalid retained/observed causal warmup.');
    const id = `mes1-${date}-81`, title = `MES1! · ${date} · 81 bars`;
    const emaSeed = {
      initialization: 'first-observed-close',
      period: 20,
      firstTimestamp: warmup[0].t,
      firstClose: warmup[0].c,
      retainedChartId: seed.id,
      retainedChartSha256: seedEntry.sha256,
      retainedThrough: seed.current.at(-1).t,
      retainedRows: seed.warmup.length + seed.current.length,
      appendedObservedRows: warmup.length - seed.warmup.length - seed.current.length,
    };
    const chart = {
      version: 1, id, title, date, range: 'extended', instrument: 'MES', intervalMinutes: 5, timezone: 'America/Chicago',
      source: {
        ...seed.source,
        label: 'Owner-directed TradingView MES1! 5m export; continuous, non-back-adjusted; settlement-as-close; bounded additional2026 sessions',
        exportMethod: 'Authenticated TradingView Pine Logs supplied by account owner',
        batch: BATCH,
        sourceExportSha256s: sourceExports.map(r => r.sha256),
        warmupSeed: emaSeed,
      },
      rights: { ...seed.rights },
      current: current.map(b => ({ ...b })),
      prior: previous.slice(-12).map(b => ({ ...b })),
      warmup,
      previousSession: {
        date: previousDate, barCount: previous.length, endTime: previous.at(-1).t.slice(11),
        bars: previous.map(b => ({ ...b })), source: 'observed-export-session', sourceRowsSha256: sha(JSON.stringify(previous)),
      },
    };
    const text = json(chart), sha256 = sha(text);
    files.set(`public/charts/${id}.json`, text);
    newCatalog.push({ id, title, date, kind: 'historical', range: 'extended', instrument: 'MES', intervalMinutes: 5, url: `/charts/${id}.json`, sha256 });
    newReferences.push({ id, date, sha256, timestamps: current.map(b => b.t) });
    contexts.push({ id, date, currentBars: 81, previousDate, previousBars: previous.length, priorStart: chart.prior[0].t, priorEnd: chart.prior.at(-1).t, warmupRows: warmup.length, ...emaSeed });
  }
  const catalog = { ...baseCatalog, sessions: [...baseCatalog.sessions, ...newCatalog].sort((a, b) => a.date.localeCompare(b.date)) };
  const references = [...baseReferences, ...newReferences].sort((a, b) => a.date.localeCompare(b.date));
  files.set('public/charts/catalog.json', json(catalog));
  files.set('data/chart-references.json', JSON.stringify(references) + '\n');
  return { files, catalog, references, rows, days, newCatalog, newReferences, contexts, overlapAudit };
}

export function makeProvenance(plan, { csv, dates, sourceExports }) {
  return {
    version: 1, batch: BATCH, readiness: 'VERIFIED_BOUNDED_ADDITION', completedThrough: COMPLETED_THROUGH,
    baselineManifest: 'data/mes-2026-additional-baseline.json', baselineManifestSha256: BASELINE_MANIFEST_SHA256,
    selectedDates: dates, selectedCount: dates.length,
    observedCsvSha256: sha(csv), observedRows: plan.rows.length, observedDates: [...plan.days.keys()],
    publicVerification: 'Reconstruct canonical observations from the hash-pinned full source chart JSON for observedDates; private CSV and raw browser snapshots are not distributed.',
    sourceExports, newCharts: plan.newCatalog.map(({ id, date, sha256 }) => ({ id, date, sha256 })),
    overlapAudit: plan.overlapAudit, contexts: plan.contexts,
    warmupPolicy: 'Replay retained observed closes from the explicit first-close seed, then append every observed complete session through the actual previous session. No rolling-window restart, resampling, synthetic bars, or in-progress sessions.',
    expectedMissingFullDatesAtBaseline: CANDIDATE_DATES,
    closedRthDatesThroughCompletedThrough: CLOSED_RTH_DATES,
    notAddedDates: CANDIDATE_DATES.filter(date => !dates.includes(date)),
    marketDataCaveat: 'Owner-authenticated TradingView observations, not independently exchange-verified. Redistribution rights are not independently verified.',
  };
}

/** Public verification needs only the already-published normalized chart JSON. */
export function reconstructObservedCsv(observedDates, readChart) {
  if (!Array.isArray(observedDates) || !observedDates.length ||
      !same(observedDates, [...new Set(observedDates)].sort()) ||
      observedDates.some(date => !dateValid(date) || date > COMPLETED_THROUGH)) fail('Invalid reconstruction dates.');
  const rows = observedDates.flatMap(date => {
    const chart = JSON.parse(String(readChart(`mes1-${date}-81`)));
    if (chart.date !== date || !Array.isArray(chart.current) || chart.current.length !== 81) fail('Missing full source JSON for reconstruction: ' + date);
    return chart.current.map(({ t, o, h, l, c }) => ({ t, o, h, l, c }));
  });
  groupObserved(rows);
  return canonicalCsv(rows);
}

export function run(root, { check = false, observedCsvPath = null } = {}) {
  const read = name => fs.readFileSync(path.join(root, name), 'utf8');
  const p = JSON.parse(read('data/mes-2026-additional-provenance.json'));
  if (p.baselineManifest !== 'data/mes-2026-additional-baseline.json') fail('Unexpected additional2026 manifest path.');
  const manifestText = read(p.baselineManifest);
  if (sha(manifestText) !== BASELINE_MANIFEST_SHA256) fail('Frozen manifest hash differs.');
  const manifest = JSON.parse(manifestText), catalog = JSON.parse(read('public/charts/catalog.json')), references = JSON.parse(read('data/chart-references.json'));
  const readChart = id => fs.readFileSync(path.join(root, `public/charts/${id}.json`));
  if (!check && !observedCsvPath) fail('Generation requires --observed-csv with a private local CSV path. Never distribute raw acquisition files.');
  const csv = observedCsvPath ? fs.readFileSync(observedCsvPath, 'utf8') : reconstructObservedCsv(p.observedDates, readChart);
  if (sha(csv) !== p.observedCsvSha256) fail('Private or reconstructed observation hash differs.');
  const installed = catalog.sessions.some(r => CANDIDATE_DATES.includes(r.date));
  const envelope = peelAdditional2026({ catalog, references, manifest, provenance: installed ? p : null, readChart });
  const plan = planAdditional2026({ csv, dates: p.selectedDates, baseCatalog: envelope.baselineCatalog, baseReferences: envelope.baselineReferences, manifest, readChart, sourceExports: p.sourceExports });
  if (!same(p, makeProvenance(plan, { csv, dates: p.selectedDates, sourceExports: p.sourceExports }))) fail('Additional2026 provenance differs from regenerated evidence.');
  for (const [name, text] of plan.files) {
    const file = path.join(root, name);
    if (check) {
      if (!fs.existsSync(file) || read(name) !== text) fail('Generated file is absent or stale: ' + name);
    } else {
      fs.mkdirSync(path.dirname(file), { recursive: true });
      fs.writeFileSync(file, text);
    }
  }
  return { status: 'PASS', check, addedSessions: plan.newCatalog.length, totalSessions: plan.catalog.sessions.length, existingPreserved: 450, observedRows: plan.rows.length, ...plan.overlapAudit };
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  const at = process.argv.indexOf('--root');
  const root = at >= 0 ? process.argv[at + 1] : fileURLToPath(new URL('../', import.meta.url));
  if (!root) fail('--root requires a directory.');
  const csvAt = process.argv.indexOf('--observed-csv');
  const observedCsvPath = csvAt >= 0 ? process.argv[csvAt + 1] : null;
  if (csvAt >= 0 && !observedCsvPath) fail('--observed-csv requires a private file path.');
  console.log(JSON.stringify(run(root, { check: process.argv.includes('--check'), observedCsvPath }), null, 2));
}
