#!/usr/bin/env python3
"""Render the public, historical Chart Match example. Requires Python 3 + Pillow and Node 24.
No screenshots, credentials or future candles are used; all EMA values come from the shared model.
"""
from pathlib import Path
import hashlib,json,math,subprocess
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1]
SOURCE_ID='mes1-2026-10-19-81'; PRIOR_SOURCE_ID='mes1-2026-10-16-81'; COUNT=20; WIDTH,HEIGHT=1000,620
source=ROOT/'public/charts'/f'{SOURCE_ID}.json'
prior_source=ROOT/'public/charts'/f'{PRIOR_SOURCE_ID}.json'
node="const fs=require('node:fs'),M=require('./lib/portal/lesson-model.cjs');const c=JSON.parse(fs.readFileSync(process.argv[1])),p=JSON.parse(fs.readFileSync(process.argv[2]));console.log(JSON.stringify({prior:p.current.at(-1),bars:c.current.slice(0,20),ema:M.chartIndicators(c,19).ema}));"
observed=json.loads(subprocess.check_output(['node','-e',node,str(source),str(prior_source)],cwd=ROOT,text=True))
bars,ema,prior=observed['bars'],observed['ema'],observed['prior']; assert len(bars)==len(ema)==COUNT
assert prior['t']=='2026-10-16 15:10'
bull=(38,166,154);bear=(239,83,80);line=(41,98,255);navy=(17,37,55);muted=(83,105,124)
first_x,last_x,previous_x=150,862,64; top,bottom=126,478
minimum=min(prior['l'],*(b['l'] for b in bars)); maximum=max(prior['h'],*(b['h'] for b in bars))
minimum=min(minimum,*ema); maximum=max(maximum,*ema)
pad=(maximum-minimum)*.10; low,high=math.floor((minimum-pad)/5)*5,math.ceil((maximum+pad)/5)*5
x=lambda i:round(first_x+i*(last_x-first_x)/(COUNT-1))
y=lambda p:round(top+(high-p)/(high-low)*(bottom-top))
image=Image.new('RGBA',(WIDTH,HEIGHT),'white');draw=ImageDraw.Draw(image)
def font(size,bold=False):
 path=Path('/usr/share/fonts/truetype/dejavu')/('DejaVuSans-Bold.ttf' if bold else 'DejaVuSans.ttf')
 return ImageFont.truetype(str(path),size) if path.exists() else ImageFont.load_default(size=size)
def text(at,value,size=15,color=navy,bold=False,anchor=None):draw.text(at,value,font=font(size,bold),fill=color,anchor=anchor)
text((28,19),'A screenshot like this',25,bold=True)
text((28,55),'Historical example · MES1! · 19 Oct 2026 · Prior: 16 Oct, 15:10 Chicago',15,color=muted)
text((28,83),'White background  ·  Filled 5-minute candles  ·  EMA20 Close / offset 0',16,bold=True)
text((966,83),'Price axis ↓',14,color=muted,anchor='ra')
# Only neutral grid and the observed prefix are inside the recognition crop.
for i in range(6):
 price=low+(high-low)*i/5; yy=y(price)
 draw.line((40,yy,900,yy),fill=(232,236,240),width=1)
 draw.line((900,yy,908,yy),fill=(149,162,173),width=1)
 text((916,yy),f'{price:,.2f}',12,color=muted,anchor='lm')
for xx,b in [(previous_x,prior)]+[(x(i),b) for i,b in enumerate(bars)]:
 color=bull if b['c']>=b['o'] else bear
 draw.line((xx,y(b['h']),xx,y(b['l'])),fill=color,width=2)
 o,c=y(b['o']),y(b['c']); body_top,body_bottom=min(o,c),max(o,c)
 draw.rectangle((xx-7,body_top,xx+7,body_bottom),fill=color)
# EMA is an observed line, not reseeded from the opening candle. Its overlap is left intact.
draw.line([(x(i),y(value)) for i,value in enumerate(ema)],fill=line,width=3,joint='curve')
draw.line((900,112,900,496),fill=(162,172,182),width=1)
for yy in range(112,496,10):draw.line((108,yy,108,min(yy+4,495)),fill=(180,190,200),width=1)
text((previous_x,505),'15:10',12,color=muted,anchor='mt')
for i in [0,5,10,15,19]:text((x(i),505),bars[i]['t'][-5:],12,color=muted,anchor='mt')
# Calibration callouts stay outside the chart crop.
draw.line((first_x,523,first_x,544),fill=navy,width=2)
draw.polygon([(first_x,519),(first_x-4,526),(first_x+4,526)],fill=navy)
text((135,550),'Opening bar',15,bold=True)
text((135,571),'19 Oct',12,color=muted)
draw.line((previous_x,523,previous_x,544),fill=navy,width=2)
draw.polygon([(previous_x,519),(previous_x-4,526),(previous_x+4,526)],fill=navy)
text((28,550),'Prior final',14,bold=True)
text((28,571),'16 Oct close',12,color=muted)
draw.line((last_x,523,last_x,544),fill=navy,width=2)
draw.polygon([(last_x,519),(last_x-4,526),(last_x+4,526)],fill=navy)
text((970,550),'20th closed bar',15,bold=True,anchor='ra')
text((28,595),'Include the prior session’s final candle. Review recognition and the price labels before matching.',14,color=muted)
out=ROOT/'public/chart-match';out.mkdir(parents=True,exist_ok=True)
image.save(out/'example.png',format='PNG',compress_level=9)
meta={'version':1,'sourceId':SOURCE_ID,'sourceDate':'2026-10-19','sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'count':COUNT,'caption':'Historical MES1! five-minute example: 19 October 2026, the first 20 closed opening bars, plus the actual prior exported session final candle at 15:10 Chicago on 16 October 2026. Not today’s market.','width':WIDTH,'height':HEIGHT,'calibration':{'crop':{'x':36,'y':112,'width':858,'height':384},'firstX':first_x,'lastX':last_x,'previousX':previous_x,'previousSpacing':(last_x-first_x)/(COUNT-1),'count':COUNT,'bullColor':list(bull),'bearColor':list(bear),'emaColor':list(line),'tolerance':48,'includeEma':True},'priceCalibration':{'upper':{'y':top,'price':high},'lower':{'y':bottom,'price':low}},'prior':{'timestamp':prior['t'],'sourceId':PRIOR_SOURCE_ID,'sourceSha256':hashlib.sha256(prior_source.read_bytes()).hexdigest(),'source':'Actual final full OHLC candle from the previous exported regular session, not the 14:55 cash-window context candle','includedInOpeningCount':False},'rendering':{'plotTop':top,'plotBottom':bottom,'priceLow':low,'priceHigh':high,'bodyHalfWidth':7,'wickWidth':2,'emaWidth':3,'emaSource':'Model.chartIndicators(chart,19).ema, including supplied pre-open warmup','observedBarCount':COUNT},'imageSha256':hashlib.sha256((out/'example.png').read_bytes()).hexdigest()}
(out/'example.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps({'image':str(out/'example.png'),'metadata':str(out/'example.json'),'imageSha256':meta['imageSha256'],'sourceSha256':meta['sourceSha256']}))
