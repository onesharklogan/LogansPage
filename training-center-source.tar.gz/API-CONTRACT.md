# API contract

Author mutations require active approved membership, an eight-hour HttpOnly Secure SameSite=Strict session, exact same origin and `X-CSRF-Token`. Membership/session is rechecked inside serialized mutation transactions. Public data endpoints are read-only.

- `GET /api/status`: readiness plus current caller's role/email.
- `GET /api/auth/csrf`: short-lived, single-use preauth cookie and CSRF token.
- `POST /api/auth/login` `{email,password}`: generic failures; scrypt verified server-side. No claim-by-email.
- `POST /api/auth/enroll` `{token,password}`: one-use, expiring capability bound to an existing active member; atomically sets/reset credential, consumes token and revokes older sessions. No raw token or password is retained/logged.
- `POST /api/auth/logout`: revoke session.
- `GET /api/author/members`: admins only.
- `POST /api/author/members` `{email,role}`: explicit grant/reactivation; default Author, no invitation.
- `PATCH /api/author/members/:encodedEmail` `{role}`.
- `POST /api/author/members/:encodedEmail/remove` `{}`: revoke sessions, enrollment tokens and password; protect last admin.
- `POST /api/author/members/:encodedEmail/enrollment` `{}`: admin-confirmed setup/reset capability; `{enrollmentUrl,expiresAt}` returned once, private/no-store. One-hour expiry, 10 issuances per admin per hour; invalidates prior unused links.
- `/api/author/folders`: GET list, POST `{name}`.
- `PATCH /api/author/folders/:id` `{name,expectedRevision}`.
- `POST /api/author/lessons` `{folderId,requestId,pack,lessonId?,expectedRevision?}`: exact pack JSON text, no images. Update requires ID+expected revision.
- `GET /api/author/save-status?requestId=...`: recover uncertain saves; reuse exact ID/text only for the same save.
- `GET /api/{public|author}/lessons`, `/folders`, `/lessons/:id/manifest`, `/lessons/:id/versions/:versionId/pack`.
- `GET /api/author/lessons/:id/versions`: immutable history.
- `POST /api/author/lessons/:id/{trash|restore}` `{expectedRevision}`.

Conflicts return 409, not overwrite. Version text, revision and request result commit atomically. Limits: 100 folders, 1,000 lessons, 200 versions per lesson, 3MiB per pack, 100MiB retained JSON. Chart references must match bundled catalog. No Google, public setup, shared-password, or image-upload endpoint exists.

## Additive lesson JSON fields (pack version 1)

- `prompt` is the initial question/action; existing `notes` is final-only explanation.
- Lines optionally carry `color` (`#rrggbb`) and `style` (`solid` or `dotted`); text annotations optionally carry `color` and `size` (14, 18, 22 or 26).
- `arrows` contains up to 80 `{id,at,direction,study,crossed}` point marks. Direction is `up` or `down`; `at` is a normal chart point.
- `exercise` is `{type:"reveal-drawings"}`, `{type:"candle-picker",correctBars:[...]}`, or `{type:"clickable-areas",targets:[{id,a,b},...]}`. Candle indices are zero-based in JSON and one-based in the UI. Rectangular targets use the same bar/time/price points as line endpoints.

Missing optional keys remain absent when normalizing legacy lessons. Missing exercise means Reveal Drawings. Candle Picker and Clickable Areas require a nonempty prompt and a nonempty valid answer set on final save. Answer indices, point timestamps, unique mark IDs and nondegenerate/unique target rectangles are validated against the selected immutable chart. Overlapping targets are allowed. Incomplete answers may exist only in local author drafts, never in saved packs.

The server stores exact pack text and immutable prior versions; no data migration or student-state endpoint is introduced. The client conceals teacher marks/explanation in the initial rendered UI, but public JSON is not an assessment-security boundary.
