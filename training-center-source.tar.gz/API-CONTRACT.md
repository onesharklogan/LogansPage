# API contract

All author mutations require an eight-hour HttpOnly Secure SameSite=Strict session, exact same-origin request and `X-CSRF-Token`. Every author request checks current active membership; writes recheck membership/session inside a serialized transaction. Public data endpoints are read-only.

- `GET /api/status`: readiness and current caller's role/email, not other members.
- `GET /api/auth/csrf`: short-lived single-use preauth cookie and nonce/CSRF token.
- `POST /api/auth/google` `{credential}`: official Google ID token, server nonce, verified email, issuer, audience, expiry and signature checked. Only active approved members can bind/sign in; the Google subject is retained to prevent email reassignment from silently changing identity.
- `POST /api/auth/logout`: revoke the current session.
- `GET /api/author/members`: admins only.
- `POST /api/author/members` `{email,role}`: explicit grant/reactivation, default Author, no invitation.
- `PATCH /api/author/members/:encodedEmail` `{role}`: Admin or Author.
- `POST /api/author/members/:encodedEmail/remove` `{}`: revoke all sessions; never remove last admin.
- `/api/author/folders`: GET list, POST `{name}`.
- `PATCH /api/author/folders/:id` `{name,expectedRevision}`.
- `POST /api/author/lessons` `{folderId,requestId,pack,lessonId?,expectedRevision?}`: `pack` is exact lesson-pack JSON text. No image fields/files. An update requires both lesson ID and expected revision.
- `GET /api/author/save-status?requestId=...`: recover uncertain saves. Reuse the exact request ID and text only for retries of the same save.
- `GET /api/{public|author}/lessons`, `/folders`, `/lessons/:id/manifest`, `/lessons/:id/versions/:versionId/pack`.
- `GET /api/author/lessons/:id/versions`: immutable history.
- `POST /api/author/lessons/:id/{trash|restore}` `{expectedRevision}`.

Optimistic conflicts return 409, not silent overwrite. JSON version, current revision and idempotency result commit atomically. Limits: 100 folders, 1,000 lessons, 200 versions per lesson, 3 MiB per pack, 100 MiB total retained JSON. Chart IDs and hashes must match the bundled 203-chart catalog. The app does not accept arbitrary remote chart URLs or store uploaded images. No `/setup`, shared-password login or image-upload API exists.
