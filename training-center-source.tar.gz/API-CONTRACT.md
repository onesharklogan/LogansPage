# API contract

The interface calls shared collections **Modules** and saved records **Slides**. Existing `folders`/`lessons` routes, JSON field names and `price-action-lessons` format remain unchanged for compatibility; these are internal names, not UI labels.

Author mutations require active approved membership, an eight-hour HttpOnly Secure SameSite=Strict session, exact same origin and `X-CSRF-Token`. Membership/session is rechecked inside serialized mutation transactions. Public data endpoints are read-only.

- `GET /api/status`: readiness plus current caller's role/email.
- `GET /api/auth/csrf`: short-lived, single-use preauth cookie and CSRF token.
- `POST /api/auth/login` `{email,password}`: generic failures; scrypt verified server-side. No claim-by-email.
- `POST /api/auth/enroll` `{token,password}`: one-use, expiring capability bound to an existing active member; atomically sets/reset credential, consumes token and revokes older sessions. No raw token or password is retained/logged.
- `POST /api/auth/logout`: revoke session.
- `GET /api/author/members`: admins only.
- `POST /api/author/members` `{email,role}`: explicit grant/reactivation; default Author, no invitation.
- `PATCH /api/author/members/:encodedEmail` `{role}`.
- `POST /api/author/members/:encodedEmail/remove` `{}`: revoke sessions, enrollment tokens and password; protect last admin.
- `POST /api/author/members/:encodedEmail/enrollment` `{}`: admin-confirmed setup/reset capability; `{enrollmentUrl,expiresAt}` returned once, private/no-store. One-hour expiry, 10 issuances per admin per hour; invalidates prior unused links.
- `/api/author/folders`: GET list, POST `{name}`.
- `PATCH /api/author/folders/:id` `{name,expectedRevision}`.
- `POST /api/author/lessons` `{folderId,requestId,pack,lessonId?,expectedRevision?}`: exact pack JSON text, no images. Update requires ID+expected revision.
- `GET /api/author/save-status?requestId=...`: recover uncertain saves; reuse exact ID/text only for the same save.
- `GET /api/{public|author}/lessons`, `/folders`, `/lessons/:id/manifest`, `/lessons/:id/versions/:versionId/pack`.
- `GET /api/author/lessons/:id/versions`: immutable history.
- `POST /api/author/lessons/:id/{trash|restore}` `{expectedRevision}`.

Conflicts return 409, not overwrite. Version text, revision and request result commit atomically. Limits: 100 modules, 1,000 slides, 200 versions per slide, 3MiB per pack, 100MiB retained JSON. Chart references must match bundled catalog. No Google, public setup, shared-password, or image-upload endpoint exists.

## Additive Slide JSON fields (pack version 1)

- Optional `coverArtwork` is one allowlisted preset ID: `ema-touch`, `trend`, `breakout`, `waves`, `fin`, or `sailboat`. Missing legacy values remain absent in stored/exported JSON and display the `ema-touch` cover. Unknown or non-string values are rejected on save/import; summary rendering safely falls back to `ema-touch`. Public/author summaries derive this one ID from the current immutable version, while history uses each version’s own value. These fixed bundled SVG illustrations are decorative card covers, not previews of saved price data, user SVG, or uploaded images. No database migration or backfill is required.
- Optional `indicators: {ema20, pivotDiamonds}` contains exactly two boolean settings. Missing settings remain absent but resolve to EMA20 on/pivots off. Explicit false values stay off; new author drafts explicitly default to EMA20 on/pivots off. Learner EMA20 hide/show state is transient, does not alter these settings or slide bytes, and does not affect teacher PNG exports. No migration or backfill is performed. Values are derived from the existing verified chart, never saved as extra chart data. EMA20 uses alpha 2/21 with historical warmup once; pivots use current-session candles only, with confirmation and five-bar strength bounded by the saved range end (no future candles after it). Settings affect content/dedup identity but require no migration.
- `prompt` is the initial question/action; existing `notes` is final-only explanation.
- Optional `range: {startBar, endBar}` uses global zero-based inclusive candle indices (UI 8–20 means 7–19, 13 candles). Missing range remains absent and means the original full session. Bounds must be ordered integers within the chosen chart; a single-bar range is valid. All original mark anchors/timestamps remain global and unchanged. Final saves require every correct Candle Picker bar and each entire Clickable Areas target extent inside the range. Incomplete local drafts may retain incompatible answers with an actionable warning; saved packs may not.
- Lines optionally carry `color` (`#rrggbb`) and `style` (`solid` or `dotted`); text annotations optionally carry `color` and `size` (14, 18, 22 or 26).
- `arrows` contains up to 80 `{id,at,direction,study,crossed}` point marks. Direction is `up` or `down`; `at` is a normal chart point.
- `exercise` is `{type:"reveal-drawings"}`, `{type:"candle-picker",correctBars:[...]}`, or `{type:"clickable-areas",targets:[{id,a,b},...]}`. Candle indices are zero-based in JSON and one-based in the UI. Rectangular targets use the same bar/time/price points as line endpoints.

Missing optional keys remain absent when normalizing legacy slides. Missing exercise means Reveal Drawings. Candle Picker and Clickable Areas require a nonempty prompt and a nonempty valid answer set on final save. Answer indices, point timestamps, unique mark IDs and nondegenerate/unique target rectangles are validated against the selected immutable chart. Overlapping targets are allowed. Incomplete answers may exist only in local author drafts, never in saved packs.

Candle Picker **Reveal Answer** is a transient study state: it displays the correct candle numbers and explanation without recording a correct check or enabling Next. Replay clears it; only the exact chosen set passes Check Answer. This changes no saved exercise keys or server state. Visible bar labels retain original 1-based current-session indices after crops and adapt spacing to available width.

The server stores exact pack text and immutable prior versions; no data migration or student-state endpoint is introduced. The client conceals teacher marks/explanation in the initial rendered UI, but public JSON is not an assessment-security boundary.
