import type { Metadata } from "next";
import {learnerConfiguration} from '../../lib/learner/google-config.mjs';
import PublicLibrary from "@/components/public-library";
export const metadata: Metadata = { title: "Lessons · Price Action Center", description: "Browse slides organized in shared modules." };
export const dynamic = "force-dynamic";
export default function Home() { return <PublicLibrary accountsEnabled={!!learnerConfiguration()} />; }
