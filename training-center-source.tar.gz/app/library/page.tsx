import type { Metadata } from "next";
import Portal from "@/components/portal";
export const metadata: Metadata = { title: "Module Library · Price Action Center", description: "Browse slides organized in shared modules." };
export const dynamic = "force-dynamic";
export default function Home() { return <Portal />; }
