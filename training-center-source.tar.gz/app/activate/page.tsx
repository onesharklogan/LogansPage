import type { Metadata } from 'next';
import ActivateAccount from '@/components/activate';
export const metadata: Metadata = { title: 'Set Password · Price Action Center', robots: { index: false, follow: false } };
export default function ActivatePage() { return <ActivateAccount />; }
