import {learnerConfiguration} from '../../../lib/learner/google-config.mjs';
export const dynamic='force-dynamic';
import ChartMatchFull from '../../../components/chart-match-full';
import {parseFullChartRequest,type FullChartRequest} from '../../../lib/chart-match-full.mjs';
export const metadata={title:'Full Chart · Chart Match · Price Action Center',description:'Read-only MES chart review. Matched opening prefix first; remaining candles appear only when explicitly revealed.'};
export default async function ChartMatchFullPage({searchParams}:{searchParams:Promise<Record<string,string|string[]|undefined>>}){
  let request:FullChartRequest|null=null,error='';
  try{request=parseFullChartRequest(await searchParams)}catch{error='This chart link is invalid. Open a full chart from a Chart Match result.'}
  return <ChartMatchFull request={request} initialError={error} learnerAccounts={!!learnerConfiguration()}/>;
}
