import {learnerConfiguration} from '../../lib/learner/google-config.mjs';
export const dynamic='force-dynamic';
import ChartMatch from '../../components/chart-match-automatic';
export const metadata={title:'Chart Match · Price Action Center',description:'Experimental browser-local screenshot recognition and historical opening-shape comparison. Similarity is not a forecast.'};
export default function ChartMatchPage(){return <ChartMatch learnerAccounts={!!learnerConfiguration()}/>;}
