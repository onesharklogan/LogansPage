import ChartMatch from '../../components/chart-match';
export const metadata={title:'Chart Match · Price Action Center',description:'Experimental browser-local screenshot recognition and historical opening-shape comparison. Similarity is not a forecast.'};
export default function ChartMatchPage(){return <ChartMatch/>;}
