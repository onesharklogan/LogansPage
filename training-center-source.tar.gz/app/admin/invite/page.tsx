import AdminInviteAccept from '@/components/admin-invite-accept';
export const metadata={title:'Admin invitation | Price Action Center',referrer:'no-referrer',robots:{index:false,follow:false}};
export default function AdminInvitePage(){return <AdminInviteAccept/>;}
