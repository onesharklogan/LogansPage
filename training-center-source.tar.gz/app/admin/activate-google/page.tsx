import AdminOwnerActivate from '@/components/admin-owner-activate';
export const metadata={title:'Google admin activation | Price Action Center',referrer:'no-referrer',robots:{index:false,follow:false}};
export default function AdminOwnerActivationPage(){return <AdminOwnerActivate/>;}
