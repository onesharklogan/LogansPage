import type { Metadata } from 'next';
import AdminArea from '@/components/admin-area';
export const metadata: Metadata = { title: 'Admin Login · Price Action Training Center' };
export const dynamic = 'force-dynamic';
export default function AdminPage() { return <AdminArea />; }
