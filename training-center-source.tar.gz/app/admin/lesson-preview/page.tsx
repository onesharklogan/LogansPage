import type {Metadata} from 'next';
import TeacherLessonPreview from '@/components/teacher-lesson-preview';

export const dynamic = 'force-dynamic';
export const metadata: Metadata = {title: 'Try this lesson · Price Action Center', robots: {index: false, follow: false}};

export default async function LessonPreviewPage({searchParams}: {searchParams: Promise<{lessonKey?: string | string[]}>}) {
  const params = await searchParams;
  return <TeacherLessonPreview requestedLesson={typeof params.lessonKey === 'string' ? params.lessonKey : null}/>;
}
