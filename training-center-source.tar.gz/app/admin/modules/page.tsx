import type {Metadata} from 'next';
import Portal from '@/components/portal';
export const metadata:Metadata={title:'Teacher Modules · Price Action Center'};
export const dynamic='force-dynamic';
export default function TeacherModules(){return <Portal/>;}
