import type {Metadata} from 'next';
import Portal from '@/components/portal';
export const metadata:Metadata={title:'Teacher Lessons · Price Action Center'};
export const dynamic='force-dynamic';
export default function TeacherModules(){return <Portal/>;}
