import AdminTraderHistory from '@/components/admin-trader-history';
export const dynamic='force-dynamic';
export const metadata={title:'Trader history · Price Action Center'};
export default function Page(){return <AdminTraderHistory/>;}
