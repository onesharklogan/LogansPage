import './simulator.css';
import ProfiledTradeSimulator from '../../components/profiled-trade-simulator';
import {learnerConfiguration} from '../../lib/learner/google-config.mjs';
export const dynamic='force-dynamic';
export const metadata = { title: 'Trade Simulator · Price Action Center', description: 'Practice limit entries with a stop and target, one candle at a time.' };
export default function TradeSimulatorPage() { return <ProfiledTradeSimulator accountsEnabled={!!learnerConfiguration()}/>; }
