import TradeSimulator from '../../components/trade-simulator';
export const metadata = { title: 'Trade Simulator · Price Action Training Center', description: 'Practice limit entries with a stop and target, one candle at a time.' };
export default function TradeSimulatorPage() { return <TradeSimulator />; }
