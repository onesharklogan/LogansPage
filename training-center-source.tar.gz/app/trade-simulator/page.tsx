import './simulator.css';
import ProfiledTradeSimulator from '../../components/profiled-trade-simulator';
export const metadata = { title: 'Trade Simulator · Price Action Center', description: 'Practice limit entries with a stop and target, one candle at a time.' };
export default function TradeSimulatorPage() { return <ProfiledTradeSimulator />; }
