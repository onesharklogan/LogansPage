import ChartMarkerWorkspace from '../../components/chart-marker-workspace';
export const metadata = { title: 'Chart Marker · Price Action Center', description: 'Mark up your own chart images with arrows, lines, labels and a study reveal. Images stay on your device.' };
export default function ChartMarkerPage() { return <ChartMarkerWorkspace />; }
