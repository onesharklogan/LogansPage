import LoadingIndicator from '../components/loading-indicator';

/** Route suspense only: removed by Next as soon as the requested page is ready. */
export default function Loading() {
  return <main className="training-main" aria-busy="true"><p role="status"><LoadingIndicator label="Opening Price Action Center…" /></p></main>;
}
