import {learnerConfiguration} from '../../../lib/learner/google-config.mjs';
import LearnerSignInReturn from '../../../components/learner-sign-in-return';
export const dynamic='force-dynamic';
export const metadata={title:'Learner sign-in',robots:{index:false,follow:false},referrer:'no-referrer' as const};
export default function Page(){if(!learnerConfiguration())return <main className="training-main"><h1>Learner sign-in is not ready yet</h1><p role="status">Online learner accounts have not been activated. Your existing browser-local profiles still work and have not been imported.</p><a href="/">Return to Price Action Center</a></main>;return <LearnerSignInReturn/>;}
