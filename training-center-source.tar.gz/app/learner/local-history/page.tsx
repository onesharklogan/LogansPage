import LearnerLocalHistory from '../../../components/learner-local-history';
export const metadata={title:'Read-only browser history · Price Action Center'};
export default function LocalHistoryPage(){return <LearnerLocalHistory/>;}
