import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "Price Action Center",
  description: "Practice Market Direction Simulator. More price-action training modules are coming soon.",
  robots: { index: false, follow: false },
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
