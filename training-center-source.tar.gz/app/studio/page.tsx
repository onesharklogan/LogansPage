import Studio from "@/components/studio";
export const dynamic = "force-dynamic";
export default function StudioPage() { return <Studio />; }
