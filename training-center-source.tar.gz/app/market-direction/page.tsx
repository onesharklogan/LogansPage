export const metadata = { title: 'Market Direction Simulator · Price Action Center' };
export default async function MarketDirectionPage({searchParams}:{searchParams?:Promise<{history?:string|string[]}>}={}) {
  const params=await searchParams;
  const source=params?.history==='1'?'/modules/market-direction.html?history=1':'/modules/market-direction.html';
  return <main className="training-module-shell market-direction-shell">
    <h1 className="sr-only">Market Direction Simulator</h1>
    <iframe className="market-direction-frame" src={source} title="Market Direction Simulator practice" allow="fullscreen" />
    <footer className="module-footer"><details><summary>Saved progress</summary><p>Practice progress stays in this browser. Progress from the previous site remains there; it is not automatically transferred between website addresses.</p></details></footer>
  </main>;
}
