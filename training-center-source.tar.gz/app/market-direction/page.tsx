export const metadata = { title: 'Market Direction Simulator · Price Action Center' };
export default function MarketDirectionPage() {
  return <main className="training-module-shell market-direction-shell">
    <h1 className="sr-only">Market Direction Simulator</h1>
    <iframe className="market-direction-frame" src="/modules/market-direction.html" title="Market Direction Simulator practice" allow="fullscreen" />
    <footer className="module-footer"><details><summary>Saved progress</summary><p>Practice progress stays in this browser. Progress from the previous site remains there; it is not automatically transferred between website addresses.</p></details></footer>
  </main>;
}
