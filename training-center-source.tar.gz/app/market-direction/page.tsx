import Link from 'next/link';
export const metadata = { title: 'Market Direction Bias · Price Action Training Center' };
export default function MarketDirectionPage() {
  return <main className="training-module-shell">
    <header>
      <h1>Market Direction Bias Module</h1>
      <nav className="workspace-navigation" aria-label="Module navigation">
        <Link className="quiet-button" href="/">Home</Link>
        <Link className="primary-button" href="/studio">Teacher Studio</Link>
        <Link className="quiet-button" href="/admin">Admin</Link>
      </nav>
    </header>
    <iframe src="/modules/market-direction.html" title="Market Direction Bias practice" allow="fullscreen" />
    <footer className="module-footer"><p>Practice progress stays in this browser. Progress from the previous site remains there; it is not automatically transferred between website addresses.</p><a href="https://priceaction.onrender.com/" target="_blank" rel="noopener noreferrer">Previous site &amp; saved progress ↗</a></footer>
  </main>;
}
