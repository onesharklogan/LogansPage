import DayTypeSearch from '../../components/day-type-search';
export const metadata={title:'Day Type Search · Price Action Center',description:'Browse historical MES day structures with full-session charts and explanatory boxes. Heuristic study labels, not forecasts.'};
export default function DayTypeSearchPage(){return <DayTypeSearch/>;}
