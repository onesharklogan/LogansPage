import {redirect} from 'next/navigation';

// Retired feature: old bookmarks lead back to the available tools.
export default function RetiredDayTypeSearchPage(){redirect('/');}
