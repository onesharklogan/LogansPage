import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {loadHistoryWithRetry} from '../lib/history-load.mjs';
const read=p=>readFileSync(new URL('../'+p,import.meta.url),'utf8');
const failure=(status,code)=>Object.assign(Error(code),{status,code});
test('transient read failures retry once and authentication, cancellation and invalid histories never retry',async()=>{
 for(const error of [failure(429,'stats_busy'),failure(503,'stats_budget'),new TypeError('network')]){
  let calls=0;assert.equal(await loadHistoryWithRetry(async()=>{if(++calls===1)throw error;return 'loaded';},{signal:new AbortController().signal,current:()=>true,pause:async()=>{}}),'loaded');
  assert.equal(calls,2);
 }
 for(const error of [failure(401,'session_expired'),failure(503,'stats_unavailable'),failure(503,'auth_unavailable'),new DOMException('cancelled','AbortError')]){
  let calls=0;await assert.rejects(()=>loadHistoryWithRetry(async()=>{calls++;throw error;},{signal:new AbortController().signal,current:()=>true,pause:async()=>{}}));assert.equal(calls,1);
 }
 let calls=0,owner=true;
 await assert.rejects(()=>loadHistoryWithRetry(async()=>{calls++;throw failure(502,'temporary');},{signal:new AbortController().signal,current:()=>owner,pause:async()=>{owner=false;}}),{name:'AbortError'});
 assert.equal(calls,1);
});
test('history renders before optional markup work and mobile replay is skipped only for Daily Balance',()=>{
 const ui=read('components/learner-trader-stats.tsx');
 assert.ok(ui.indexOf('loadHistoryWithRetry(()=>client.getStats')<ui.indexOf('setLoaded({data:pcTrackingStats'));
 assert.ok(ui.indexOf('setLoaded({data:pcTrackingStats')<ui.indexOf('void client.getPractice'));
 assert.match(read('lib/learner/server.mjs'),/origin===DAILY_BALANCE_ORIGIN\?records\.filter\(record=>record\.payload\?\.isMobile!==true\):records/);
 assert.doesNotMatch(read('components/learner-account-control.tsx'),/Your saved practice belongs to this learner account/);
});
