'use client';
import FailedChartsBook from './failed-charts-book';
import {chartTrades} from '../lib/failed-chart-trades.mjs';
import {accountBookRows} from '../lib/failed-charts-book.mjs';
import LoadingIndicator from './loading-indicator';
import {loadHistoryWithRetry} from '../lib/history-load.mjs';
import PracticeInsights from './practice-insights';
import TodayHistorySummary from './today-history-summary';
import TodayAccountSummary from './today-account-summary';
import {useEffect,useLayoutEffect,useMemo,useRef,useState,type MouseEvent} from 'react';
import {createLearnerClient} from '../lib/learner/client.mjs';
import {deriveStatsPage,formatProfitFactor,pcTrackingStats} from '../public/modules/learner-stats.js';
import {observeHistoryWidth,historyPointAxis,formatHistoryPoints} from '../lib/trade-history-chart.mjs';
import {cumulativeDeviceChart} from '../lib/cumulative-device-chart.mjs';
import styles from './learner-trader-stats.module.css';
const number=(v:number|null)=>v===null?'N/A':v.toLocaleString('en-US',{maximumFractionDigits:2});
function Arrow({next=false}:{next?:boolean}){return <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d={next?'M9 5l7 7-7 7':'M15 5l-7 7 7 7'} stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/></svg>;}
/** One guarded snapshot, local presentation pages. Never mounts or changes a simulator. */
export default function LearnerTraderStats({client,page:requestedPage,onPage,onBack,onReplay,canAct,refreshKey=0,backLabel="Back to account"}:{client:ReturnType<typeof createLearnerClient>;page:number|null;onPage:(page:number)=>void;onBack:()=>void;onReplay:(event:MouseEvent<HTMLAnchorElement>)=>void;canAct:()=>boolean;refreshKey?:number;backLabel?:string}){
 const page:number|null=requestedPage===null?null:Number(2);
 const [loaded,setLoaded]=useState<{data:any;practice:any;capture:any;revision:number;refreshKey:number}|null>(null),[failure,setFailure]=useState(false),[revision,setRevision]=useState(0),[selected,setSelected]=useState<string|null>(null),[section,setSection]=useState(0);
 const device='all';
 const [plotElement,setPlotElement]=useState<HTMLDivElement|null>(null),[plotWidth,setPlotWidth]=useState(300);
 useEffect(()=>observeHistoryWidth(plotElement,setPlotWidth),[plotElement]);
 const epoch=useRef(0),alive=useRef(false),latest=useRef({page,loaded}),heading=useRef<HTMLHeadingElement>(null);
 const [,redraw]=useState(0),display=useRef<object>({}),displayed={};const invalidateDisplay=()=>{display.current={};redraw(n=>n+1);};
 // Only committed UI owns actions; an abandoned render must not revoke the visible controls.
 useLayoutEffect(()=>{display.current=displayed;latest.current={page,loaded};return()=>{if(display.current===displayed)display.current={};};});
 const capture=client.captureContext(),ownerKey=capture?.mode==='account'?`${capture.epoch}:${capture.context?.accountId}:${capture.context?.generation}:${capture.context?.sessionTag}`:null;
 useEffect(()=>{alive.current=true;const token=++epoch.current,controller=new AbortController(),current=client.captureContext();let timeout:ReturnType<typeof setTimeout>|undefined;setLoaded(null);setFailure(false);
  if(current?.mode==='account'&&client.guard(current)){
   const currentRequest=()=>alive.current&&token===epoch.current&&!controller.signal.aborted&&client.guard(current);
   // Both reads can need the same account locks. Start optional insights only
   // after history resolves; spending the history timeout on insights is avoidable.
   timeout=setTimeout(()=>{if(currentRequest()){setFailure(true);controller.abort();}},20000);
   void loadHistoryWithRetry(()=>client.getStats(current,{signal:controller.signal}),{signal:controller.signal,current:currentRequest}).then(data=>{
    if(!currentRequest())return;
    setLoaded({data:pcTrackingStats(data),practice:null,capture:current,revision,refreshKey});
    void client.getPractice(current,{signal:controller.signal}).then(practice=>{if(currentRequest())setLoaded(previous=>previous&&previous.capture===current?{...previous,practice}:previous);}).catch(()=>{});
   }).catch(()=>{if(currentRequest())setFailure(true);}).finally(()=>clearTimeout(timeout));
  }
  return()=>{alive.current=false;epoch.current++;clearTimeout(timeout);controller.abort();};
 },[client,ownerKey,revision,refreshKey]);
 useEffect(()=>{setSelected(null);setSection(0);if(page!==null)heading.current?.focus();},[page]);
 const valid=loaded&&loaded.revision===revision&&loaded.refreshKey===refreshKey&&client.guard(loaded.capture)?loaded:null;
 const filtered=useMemo(()=>valid?valid.data:null,[valid,device]);
 const pages=useMemo(()=>filtered?[0,1,2].map(p=>deriveStatsPage(filtered,p)):null,[filtered]);
 const allowed=()=>alive.current&&display.current===displayed&&canAct()&&!!valid&&latest.current.loaded===loaded&&latest.current.page===page&&client.guard(valid.capture);
 function choose(next:number){if(!allowed())return;invalidateDisplay();onPage(next);}
 if(!pages)return <div className={styles.status}>{page!==null&&<button type="button" onClick={()=>{if(alive.current&&canAct()){invalidateDisplay();onBack();}}}>{backLabel}</button>}{failure?<><p role="alert">Trade History could not be loaded. Your saved trades have not changed.</p><button type="button" onClick={()=>{if(alive.current&&canAct())setRevision(n=>n+1);}}>Retry history</button></>:<p role="status"><LoadingIndicator label="Loading Trade History…" /></p>}</div>;
 if(page===null)return <div className={styles.overview}><TodayAccountSummary stats={valid!.data}/><div className={styles.entries}><button type="button" onClick={()=>choose(2)}>Trade History<Arrow next/></button></div></div>;
 const stats=pages[page],chart=cumulativeDeviceChart(valid!.data,plotWidth),windowed=chart.windowed,axis=historyPointAxis(windowed),chosen=chart.stats.series.points.find((p:any)=>p.id===selected),max=Math.max(1,...stats.barGroups.map((b:any)=>typeof b.profitFactor==='number'?b.profitFactor:0));
 function selectPoint(id:string){if(allowed()){invalidateDisplay();setSelected(id);}}
 const replay=(event:MouseEvent<HTMLAnchorElement>)=>{if(!allowed()){event.preventDefault();return;}onReplay(event);};
 return <div className={styles.dashboard}>
  <div className={styles.pager}><h3 ref={heading} tabIndex={-1}>Trade History</h3></div>
  <div className={styles.toolbar}><button type="button" onClick={()=>{if(allowed()){invalidateDisplay();onBack();}}}>{backLabel}</button><button type="button" onClick={()=>{if(allowed()){invalidateDisplay();setRevision(n=>n+1);}}}>Refresh stats</button></div>
  <p className={styles.caption}>PC history · Older sessions without device information are retained. Mobile practice is not saved.</p>
  <FailedChartsBook rows={accountBookRows(filtered)} canAct={allowed} loadTrades={async(row,source)=>{if(!allowed())throw Error('Account changed');const attempt=await client.getAttempt(row.attemptId,valid!.capture);if(!allowed())throw Error('Account changed');return chartTrades(attempt,source);}}/>
  <TodayHistorySummary stats={filtered} page={page}/>
  <h4 className={styles.historyHeading}>PC saved history</h4>
  <dl className={styles.kpis}>{[['All-time net points',stats.complete?formatHistoryPoints(stats.series.total):'N/A'],['Win Rate',stats.winRate===null?'N/A':`${number(stats.winRate*100)}%`],['Avg Win',number(stats.averageWin)],['Avg Loss',number(stats.averageLoss)],['Biggest Win',number(stats.complete?stats.totals.biggestWin:null)],['Biggest Loss',number(stats.complete?stats.totals.biggestLoss:null)],['Profit Factor',formatProfitFactor(stats)],['Completed Sessions',String(stats.count)],['Total trades',stats.complete?String(stats.samples):'N/A']].map(([label,value])=><div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl>
  <p className={styles.caption}>{page===0?'Closed legs':page===1?'Closed trades':'Closed legs / trades'} · Flats count in win rate</p>
  <p className={styles.caption}>All finished attempts · Replays included · Snapshot {new Date(valid!.data.asOf).toLocaleTimeString()}</p>
  {!stats.complete&&<p className={styles.coverage} role="status">Verified outcomes: {stats.covered} / {stats.count} attempts. KPIs unavailable; graphs show verified attempts only.</p>}
  {stats.carry&&<p className={styles.caption}>Order points include saved Finish carry through Final Bar.</p>}
  {page!==1&&<p className={styles.caption}>{page===2?'Order Neutral':'Practiced Neutral'}: {stats.neutralCovered===stats.neutralTotal&&stats.practiced?`${number(100*stats.neutral/stats.practiced)}%`:'N/A'}{stats.neutralCovered!==stats.neutralTotal?` · Evidence ${stats.neutralCovered} / ${stats.neutralTotal}`:''}</p>}
  <PracticeInsights stats={filtered} accountStats={valid!.data} practice={valid!.practice} page={page} device={device} totalAttempts={valid!.data.attempts.length}/><section className={styles.graph}><h4>Cumulative points</h4>{chart.stats.series.points.length?<>
   <div className={styles.lineLegend} aria-label="Cumulative points legend">{chart.lines.filter(line=>line.key==='combined').map(line=><span key={line.key}><i style={{background:line.color}} aria-hidden="true"/>PC + legacy: {formatHistoryPoints(Number(line.total))}{!line.count?' (no recorded attempts)':''}</span>)}</div>
   <div className={styles.plotRow}><svg width={axis.width} height="244" aria-hidden="true" className={styles.axis}>{axis.ticks.map((t:any)=><text key={t.value} x={axis.width-8} y={t.y+4} textAnchor="end">{t.label}</text>)}</svg><div ref={setPlotElement} className={styles.plotScroll}><svg width="100%" height="244" viewBox={`0 0 ${windowed.width} 244`} role="group" aria-label="Accumulated points by attempt completion"><path d={`M0 ${windowed.zeroY}H${windowed.width}`} stroke="currentColor" opacity=".3"/>{chart.lines.filter(line=>line.key==='combined').map(line=><path key={line.key} data-device-line={line.key} d={line.path} fill="none" stroke={String(line.color)} strokeWidth={line.key==='combined'?3:2} strokeDasharray={line.key==='mobile'?'7 4':line.key==='pc'?'3 3':undefined} pointerEvents="none"/>)}{windowed.points.map((p:any,i:number)=><g key={p.id} role="button" tabIndex={chosen?chosen.id===p.id?0:-1:i===0?0:-1} aria-label={`Attempt ${p.index+1}, ${p.module==='market-direction'?'Order':'Order'}, ${formatHistoryPoints(p.netPoints)} points; accumulated ${formatHistoryPoints(p.cumulative)}`} aria-pressed={chosen?.id===p.id} onClick={()=>selectPoint(p.id)} onKeyDown={e=>{if(!allowed())return;if(e.key==='Enter'||e.key===' '){e.preventDefault();selectPoint(p.id);}else if(['ArrowLeft','ArrowRight','Home','End'].includes(e.key)){e.preventDefault();const all=Array.from(e.currentTarget.parentElement?.querySelectorAll<SVGGElement>('[role="button"]')||[]),index=e.key==='Home'?0:e.key==='End'?all.length-1:Math.max(0,Math.min(all.length-1,i+(e.key==='ArrowRight'?1:-1)));all[index]?.focus();}}}><rect x={p.x-windowed.hitWidth/2} y="10" width={windowed.hitWidth} height="210" rx="8" fill={chosen?.id===p.id?'var(--appearance-ink-ffffff12, #ffffff12)':'transparent'}/><circle cx={p.x} cy={p.y} r={chosen?.id===p.id?windowed.selectedRadius:windowed.radius} fill="var(--appearance-ink-69c7ff, #69c7ff)"/>{p.showLabel&&<text x={p.x} y="238" textAnchor={i===windowed.points.length-1?"end":i===0?"start":"middle"}>{p.index+1}</text>}</g>)}</svg></div></div>
   <p className={styles.caption}>All {chart.stats.covered} verified attempts shown · PC and legacy sessions share completion order. Select a dot for details.</p>
   <p className={styles.caption}>{chart.unknown>0?`${chart.unknown} older attempts have no device information and are retained.`:''}</p>
   {!chart.stats.complete&&<p className={styles.coverage}>Graph includes {chart.stats.covered} of {chart.stats.count} attempts with verified outcomes.</p>}
   {chosen&&<div className={styles.selection}><strong>{chosen.sessionDate} · {chosen.module==='market-direction'?'Order':'Order'}</strong><span>{formatHistoryPoints(chosen.netPoints)} points · {new Date(chosen.completedAt).toLocaleString()}</span><a href={`/${chosen.module}?replay=${encodeURIComponent(chosen.attemptId)}`} onClick={replay} onAuxClick={replay} onContextMenu={replay}>Replay</a></div>}
  </>:<p>No verified closed outcomes yet.</p>}</section>
  <section className={styles.graph}><h4>Profit factor by bar group</h4>{stats.samples?<><p className={styles.caption}>Whole closed {page===0?'legs':page===1?'trades':'legs / trades'} grouped by exit bar · All finished attempts, including replays</p><p className={styles.caption}>Numeric scale: 0 to {number(max)} PF. No losses, Flat only and N/A are labels, not bar heights.</p><div className={styles.buckets}>{stats.barGroups.map((b:any,i:number)=><button type="button" key={b.id} aria-label={`${b.label}: ${formatProfitFactor(b)} profit factor, ${b.samples} closed outcomes`} aria-pressed={section===i} onClick={()=>{if(allowed()){invalidateDisplay();setSection(i);}}}><span className={styles.pfBarTrack} aria-hidden="true">{typeof b.profitFactor==='number'?<span style={{height:`${b.profitFactor/max*100}%`}}/>:<i>{b.profitFactor==='no-losses'?'◇':b.profitFactor==='flat-only'?'○':'–'}</i>}</span><strong>{formatProfitFactor(b)}</strong><small>{b.label}</small></button>)}</div><p className={styles.selectedSection} role="status">{stats.barGroups[section].label}: {formatProfitFactor(stats.barGroups[section])} PF · {stats.barGroups[section].samples} verified closed outcomes · Gross winning points {number(stats.barGroups[section].grossProfit)} / gross losing points {number(stats.barGroups[section].grossLoss)} · Allocation verified for {stats.barGroups[section].covered} / {stats.barGroups[section].count} attempts.</p>{!stats.barGroups[section].complete&&<p className={styles.coverage}>Bar-group PF is unavailable because some saved outcomes cannot be allocated reliably. Known outcomes are not used to imply a complete result.</p>}<p className={styles.caption}>PF = gross winning points ÷ gross losing points, never net points or an average of ratios. Each whole closed outcome belongs to the group containing its exit bar; crossing outcomes are not split. No outcomes in a group means N/A. Order Finish carry stays included where saved evidence verifies it.</p></>:<p>No verified closed outcomes yet. Bar-group profit factor is unavailable.</p>}</section>
 </div>;
}
