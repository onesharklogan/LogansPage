import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import ts from 'typescript';
const source=fs.readFileSync(new URL('../components/improvements-notes.tsx',import.meta.url),'utf8');
test('notes UI is explicit save with bounded multiline input and no automatic execution',()=>{
 assert.match(source,/<textarea/);assert.match(source,/maxLength=\{20000\}/);
 assert.match(source,/Save notes/);assert.match(source,/does not make changes to the app/);
 assert.match(source,/'X-CSRF-Token':token.current/);assert.match(source,/revision:saved.revision/);
 assert.doesNotMatch(source,/localStorage|setInterval|\/api\/.*execute/);
});
test('conflicts block overwrite and reload requires explicit draft discard confirmation',()=>{
 assert.match(source,/e.status===409/);assert.match(source,/setConflict\(true\)/);
 assert.match(source,/locked.current\|\|conflict/);
 assert.match(source,/dirty&&!window.confirm/);assert.match(source,/navigator.clipboard.writeText\(text\)/);
 assert.match(source,/beforeunload/);
 const catchBody=source.slice(source.indexOf('}catch(e){if(alive.current){if(e instanceof NotesError'));
 assert.doesNotMatch(catchBody.slice(0,catchBody.indexOf('finally')),/setText\(/);
});
test('notes stay mounted when dashboard refresh temporarily clears daily data',()=>{
 const dashboard=fs.readFileSync(new URL('../components/daily-dashboard.tsx',import.meta.url),'utf8');
 const tree=ts.createSourceFile('daily-dashboard.tsx',dashboard,ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
 const nodes=[];function visit(node){if(ts.isJsxSelfClosingElement(node)&&node.tagName.getText(tree)==='ImprovementsNotes')nodes.push(node);ts.forEachChild(node,visit);}visit(tree);assert.equal(nodes.length,1);
 for(let parent=nodes[0].parent;parent;parent=parent.parent)assert(!ts.isConditionalExpression(parent)&&!(ts.isBinaryExpression(parent)&&parent.operatorToken.kind===ts.SyntaxKind.AmpersandAmpersandToken),'Notes must remain outside loading/category conditions.');
});
