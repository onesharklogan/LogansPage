import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {pcTrackingStats,outcomeTotals,deriveStatsPage} from '../public/modules/learner-stats.js';
const row=(n,isMobile)=>({id:`12345678-1234-4234-8234-${String(n).padStart(12,'0')}`,module:'trade-simulator',chartId:'mes1-2025-01-02-81',startedAt:`2026-11-01T10:0${n}:00.000Z`,completedAt:`2026-11-01T10:0${n}:01.000Z`,outcomes:outcomeTotals([n]),buckets:[n,0,0,0],practiced:null,neutral:null,carry:false,...(isMobile===undefined?{}:{isMobile})});
test('PC tracking retains PC and unknown legacy without mutating mobile evidence',()=>{
 const input={version:1,context:{accountId:'12345678-1234-4234-8234-123456789012',generation:1,sessionTag:'a'.repeat(64)},snapshot:'b'.repeat(64),asOf:'2026-11-01T12:00:00.000Z',attempts:[row(1,true),row(2,false),row(3)]};
 const before=JSON.stringify(input),filtered=pcTrackingStats(input);
 assert.equal(JSON.stringify(input),before);assert.deepEqual(filtered.attempts.map(x=>x.isMobile),[false,undefined]);assert.equal(deriveStatsPage(filtered,2).series.total,5);
});
test('direct history route opens without waiting on simulator controller readiness',()=>{
 const text=readFileSync(new URL('../components/combined-simulator.tsx',import.meta.url),'utf8');
 assert.match(text,/\[history,setHistory\]=useState\(initialHistory\)/);assert.match(text,/historyVisible=useRef\(initialHistory\)/);
 const history=readFileSync(new URL('../components/combined-simulator-history.tsx',import.meta.url),'utf8');assert.match(history,/void learnerClient.refresh\(\)/);assert.match(history,/Retry account check/);
});
test('stats and optional insights fetch independently, with owner guards',()=>{
 const text=readFileSync(new URL('../components/learner-trader-stats.tsx',import.meta.url),'utf8');
 assert.doesNotMatch(text,/Promise.all/);assert.match(text,/client.getStats/);assert.match(text,/client.getPractice/);assert.match(text,/client.guard\(current\)/);assert.match(text,/pcTrackingStats\(data\)/);
});
