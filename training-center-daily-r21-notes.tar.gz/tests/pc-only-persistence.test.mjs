import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {practiceIsMobile} from '../public/modules/practice-device.js';
import {projectScoredDatabase} from '../public/modules/market-preview-isolation.js';
import {createMarketDirectionAccountBridge,memoryStorage} from '../public/modules/learner-account-bridge.js';
import {createAccountTradeAdapter} from '../lib/learner/trade-adapter.mjs';
import * as History from '../lib/trade-simulator-history.mjs';
import {initialState,advanceCandle,finishSession} from '../lib/trade-simulator.mjs';

const aid='12345678-1234-4234-8234-123456789012';
const profile={learnerId:aid,key:'synthetic',name:'Synthetic'};
const hash='a'.repeat(64), started='2026-11-14T10:00:00.000Z',completed='2026-11-14T10:10:00.000Z';
const chart={id:'mes1-2025-01-02-81',title:'Synthetic',current:[{t:'2025-01-02T08:30',o:100,h:102,l:99,c:101},{t:'2025-01-02T08:35',o:101,h:103,l:100,c:102}]};
const first=()=>initialState(0,chart.current[0]);
const done=()=>finishSession(advanceCandle(first(),chart.current[1],1));
const options={chart,sessionHash:hash,guard:()=>true,now:completed};

test('device policy does not treat a narrow PC as mobile and includes desktop-UA iPads',()=>{
 assert.equal(practiceIsMobile({userAgent:'Chrome Linux',maxTouchPoints:2}),false);
 assert.equal(practiceIsMobile({userAgent:'Mozilla Macintosh',maxTouchPoints:5}),true);
 assert.equal(practiceIsMobile({userAgent:'Android Tablet'}),true);
});
test('new local mobile session is valid at completion without requesting storage or locks',async()=>{
 const record=History.newAttempt(profile,chart,first(),{isMobile:true,sessionHash:hash,now:started});
 const result=await History.checkpoint(profile,record,done(),{...options,get storage(){assert.fail('mobile accessed storage');},get locks(){assert.fail('mobile accessed locks');}});
 assert.equal(result.ok,true,result.error);assert.equal(result.record.state.ended,true);assert.equal(result.record.isMobile,true);
 assert.equal(History.summarize([result.record]).completedAttempts,0);
});
test('local history omits only identifiable mobile and does not mutate storage',()=>{
 const storage=memoryStorage();
 for(const mobile of [true,false,undefined]){
  const record=History.newAttempt(profile,chart,done(),{isMobile:mobile,sessionHash:hash,now:started});if(mobile===undefined)delete record.isMobile;
  record.revision=1;storage.setItem(History.attemptKey(profile,record.id),JSON.stringify(record));
 }
 const before=Array.from({length:storage.length},(_,i)=>storage.getItem(storage.key(i)));
 const history=History.load(profile,{storage,guard:()=>true});
 assert.equal(history.ok,true,history.error);assert.equal(history.completed.length,2);assert(history.completed.every(r=>r.isMobile!==true));
 assert.deepEqual(Array.from({length:storage.length},(_,i)=>storage.getItem(storage.key(i))),before);
});
test('account brackets preserve PC saves but never send or list mobile completion',async()=>{
 for(const mobile of [true,false]){
  const posts=[],client={getSnapshot:()=>({}),guard:()=>true,exportHistory:async()=>({attempts:[]}),saveAttempt:async payload=>{posts.push(payload)}};
  const adapter=createAccountTradeAdapter({client,capture:{mode:'account'},profile,now:()=>started,detectMobile:()=>mobile});
  await adapter.loadRemote();
  const record=adapter.newAttempt(profile,chart,first(),{sessionHash:hash});
  assert.equal(record.isMobile,mobile);
  assert.equal(adapter.canCommit(record,done()).ok,true);
  const result=await adapter.checkpoint(profile,record,done(),options);
  assert.equal(result.ok,true,result.error);assert.equal(result.record.state.ended,true);
  assert.equal(adapter.load(profile,options).completed.length,mobile?0:1);
  assert.equal(posts.length,mobile?0:1);if(!mobile)assert.equal(posts[0].isMobile,false);
 }
});
test('market mobile practice does not POST or queue, and can continue normally',async()=>{
 let posts=0;const durable=memoryStorage();
 const client={getSnapshot:()=>({ready:true,authConfigured:true,mode:'account',profile:{id:aid,name:'Synthetic'}}),captureContext:()=>({}),guard:()=>true,subscribe:()=>()=>{},saveAttempt:async()=>{posts++}};
 const bridge=createMarketDirectionAccountBridge({client,detectMobile:()=>true,outboxStorage:durable});
 bridge.rememberSource({kind:'historical',id:chart.id,sha256:hash});
 bridge.start('mobile-practice',chart.id);
 assert.deepEqual(await bridge.complete('mobile-practice',{},2,completed),{mobile:true,saved:false});
 assert.equal(bridge.navigationReady(),true);assert.equal(bridge.status().retryAvailable,false);assert.equal(posts,0);assert.equal(durable.length,0);
 bridge.dispose();
});
test('market projection keeps old checkpoints, no mobile state enters disk or export',()=>{
 const before={profiles:[{...profile,mode:'real',chart:{id:1,source:null},realChart:{id:2},demoChart:null}]};
 const mobile={...profile,mode:'demo',chart:{id:3,isMobile:true},realChart:{id:4,isMobile:true},demoChart:{id:5,isMobile:true}};
 const projected=projectScoredDatabase({profiles:[mobile]},before);
 assert.deepEqual(projected,before);assert.equal(mobile.chart.id,3);
});
test('market HTML finishes normally but suppresses mobile tracking and exposes no future preview',()=>{
 const source=fs.readFileSync(new URL('../public/modules/market-direction.html',import.meta.url),'utf8');
 for(const script of source.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/g)){if(script[1].trim())new vm.Script(script[1]);}
 assert.match(source,/function recordResult\(\)\{if\(previewRun\(\)\|\|mobileRun\(\)\)return;/);
 assert.match(source,/function accountSaveCompleted\(chart\)\{if\(previewRun\(chart\)\|\|mobileRun\(chart\)\)return;/);
 assert.match(source,/Mobile practice · results are not saved/);
});
