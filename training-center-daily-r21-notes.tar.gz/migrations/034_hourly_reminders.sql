-- Additive only. Apply on publication approval, never reset existing history.
BEGIN;
CREATE TABLE IF NOT EXISTS learner_app.hourly_reminders (
 account_id uuid PRIMARY KEY REFERENCES learner_app.accounts(id),
 notes text NOT NULL DEFAULT '' CHECK(length(notes)<=20000),
 revision integer NOT NULL DEFAULT 1 CHECK(revision>0),
 updated_at bigint NOT NULL
);
COMMENT ON TABLE learner_app.hourly_reminders IS 'Private recurring hourly reminders, shared across days. Independent of check-ins and trading history resets.';
REVOKE ALL ON learner_app.hourly_reminders FROM PUBLIC;
GRANT SELECT,INSERT ON learner_app.hourly_reminders TO learner_runtime;
GRANT UPDATE(notes,revision,updated_at) ON learner_app.hourly_reminders TO learner_runtime;
COMMIT;
