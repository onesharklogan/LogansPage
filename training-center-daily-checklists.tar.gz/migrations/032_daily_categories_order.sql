-- Additive only: legacy point values and all prior daily/trading rows remain intact.
BEGIN;
CREATE TABLE IF NOT EXISTS learner_app.daily_categories (
 account_id uuid NOT NULL REFERENCES learner_app.accounts(id),
 category text NOT NULL CHECK(category IN ('family','fitness','trading','career','self','meditation')),
 name text NOT NULL CHECK(length(name) BETWEEN 1 AND 60),
 active boolean NOT NULL DEFAULT true,
 revision integer NOT NULL DEFAULT 1 CHECK(revision>0),
 PRIMARY KEY(account_id,category),
 CHECK(category <> 'trading' OR (name='Trading' AND active=true))
);
ALTER TABLE learner_app.daily_tasks ADD COLUMN IF NOT EXISTS position integer NOT NULL DEFAULT 0;
ALTER TABLE learner_app.daily_items ADD COLUMN IF NOT EXISTS position integer NOT NULL DEFAULT 0;
-- One-time initial ordering. Reruns never overwrite existing nonzero positions.
WITH ranked AS (SELECT account_id,task_id,row_number() OVER(PARTITION BY account_id,category ORDER BY created_at,task_id)::integer AS n FROM learner_app.daily_tasks)
UPDATE learner_app.daily_tasks t SET position=r.n FROM ranked r WHERE t.account_id=r.account_id AND t.task_id=r.task_id AND t.position=0;
UPDATE learner_app.daily_items i SET position=t.position FROM learner_app.daily_tasks t WHERE i.account_id=t.account_id AND i.task_id=t.task_id AND i.position=0;
REVOKE ALL ON learner_app.daily_categories FROM PUBLIC;
GRANT SELECT,INSERT ON learner_app.daily_categories TO learner_runtime;
GRANT UPDATE(name,active,revision) ON learner_app.daily_categories TO learner_runtime;
GRANT UPDATE(position) ON learner_app.daily_tasks,learner_app.daily_items TO learner_runtime;
COMMIT;
