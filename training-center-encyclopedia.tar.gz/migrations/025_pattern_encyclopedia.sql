-- PREPARED ONLY. Requires separately approved schema-owner execution, direct connection.
BEGIN;
SET LOCAL lock_timeout = '5s';
CREATE TABLE learner_app.pattern_entries (
 account_id uuid NOT NULL REFERENCES learner_app.accounts(id) ON DELETE RESTRICT,
 pattern_id uuid NOT NULL,
 metadata jsonb NOT NULL CHECK(jsonb_typeof(metadata)='object'),
 snapshot jsonb NOT NULL CHECK(jsonb_typeof(snapshot)='object' AND jsonb_array_length(snapshot->'matches') BETWEEN 0 AND 48),
 revision integer NOT NULL CHECK(revision>=1),
 created_at bigint NOT NULL CHECK(created_at>=0),
 updated_at bigint NOT NULL CHECK(updated_at>=0),
 deleted_at bigint CHECK(deleted_at>=0),
 payload_bytes integer NOT NULL CHECK(payload_bytes>0),
 PRIMARY KEY(account_id,pattern_id)
);
CREATE INDEX pattern_entries_page ON learner_app.pattern_entries(account_id,created_at DESC,pattern_id DESC);
CREATE TABLE learner_app.pattern_receipts (
 account_id uuid NOT NULL REFERENCES learner_app.accounts(id) ON DELETE RESTRICT,
 request_id uuid NOT NULL,
 fingerprint text NOT NULL CHECK(fingerprint ~ '^[a-f0-9]{64}$'),
 response jsonb NOT NULL,
 PRIMARY KEY(account_id,request_id)
);
REVOKE ALL ON learner_app.pattern_entries,learner_app.pattern_receipts FROM PUBLIC;
INSERT INTO learner_app.schema_migrations(version,description) VALUES(8,'Private account Pattern Encyclopedia with immutable snapshots and recoverable trash');
COMMIT;
