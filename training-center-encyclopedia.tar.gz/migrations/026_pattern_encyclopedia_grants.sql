-- PREPARED ONLY: approve these exact additive grants separately. No teacher/admin grants.
BEGIN;
GRANT SELECT,INSERT ON learner_app.pattern_entries,learner_app.pattern_receipts TO learner_runtime;
GRANT UPDATE(metadata,revision,updated_at,deleted_at,payload_bytes) ON learner_app.pattern_entries TO learner_runtime;
-- No DELETE, snapshot UPDATE, receipt UPDATE, schema ownership, or public grants.
COMMIT;
