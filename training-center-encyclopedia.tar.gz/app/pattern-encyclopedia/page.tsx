import PatternEncyclopedia from '../../components/pattern-encyclopedia';
export const metadata={title:'Pattern Encyclopedia · Price Action Center',description:'Your private catalog of historical candle patterns, chart examples and study notes.'};
export default function Page(){return <PatternEncyclopedia/>;}
