import PatternEncyclopedia from '../../../components/pattern-encyclopedia';
export const metadata={title:'Saved pattern · Price Action Center'};
export default async function Page({params}:{params:Promise<{id:string}>}){const {id}=await params;return <PatternEncyclopedia id={id}/>;}
