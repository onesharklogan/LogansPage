'use client';

import {useEffect,useMemo,useRef,useState,type PointerEvent,type KeyboardEvent} from 'react';
import AppHeader from './app-navigation';
import PatternCandles from './pattern-candles';
import TradeSessionCalendar from './trade-session-calendar';
import {PatternSavePanel,type PatternSnapshot} from './pattern-encyclopedia';
import {patternStudySnapshot} from '../lib/pattern-study-snapshot.mjs';
import LearnerAccountControl from './learner-account-control';
import {loadChartMatchSessions} from './chart-match-data.mjs';
import {historicalPrefix} from '../lib/chart-match.mjs';
import {buildPatternWindow,rankPatternMatches} from '../lib/pattern-match.mjs';
import {validPatternSelection,placePatternSelection,draggedPatternSelection,patternPointerBar} from '../lib/pattern-selection.mjs';
import styles from './pattern-match.module.css';

type Session=Awaited<ReturnType<typeof loadChartMatchSessions>>[number];
type Match=Awaited<ReturnType<typeof rankPatternMatches>>['matches'][number];
type Gesture={pointer:number;source:string;anchor:number;x:number;original:{start:string;end:string};moved:boolean};
const errorMessage=(error:unknown)=>error instanceof Error?error.message:'The comparison could not be completed. Please try again.';
const visibleCandles=(source:Session,count:number)=>historicalPrefix(source.chart,count,{useEma:true}).map((c,i)=>({...c,t:source.chart.current[i].t}));

/** Read-only catalog study. No simulator, stored account state, uploads or outcome ranking. */
export default function PatternMatch(){
 const [candidate,setCandidate]=useState<PatternSnapshot|null>(null),[selected,setSelected]=useState<string[]>([]),[previewCharts,setPreviewCharts]=useState<Record<string,any>>({});const dirtyDraft=useRef(false),pendingSave=useRef(false);
 const [sessions,setSessions]=useState<Session[]>([]),[loadState,setLoadState]=useState('Loading historical charts…'),[loadError,setLoadError]=useState(''),[retry,setRetry]=useState(0);
 const [sourceId,setSourceId]=useState(''),[range,setRange]=useState({start:'1',end:'15'}),[limit,setLimit]=useState(24);
 const [matches,setMatches]=useState<Match[]>([]),[status,setStatus]=useState(''),[error,setError]=useState(''),[busy,setBusy]=useState(false),[searched,setSearched]=useState(false),[inspected,setInspected]=useState<Match|null>(null);
 const job=useRef<AbortController|null>(null),epoch=useRef(0),alive=useRef(true),gesture=useRef<Gesture|null>(null),svg=useRef<SVGSVGElement>(null),viewer=useRef<HTMLElement>(null),viewerTrigger=useRef<HTMLButtonElement|null>(null),latestSource=useRef(sourceId);latestSource.current=sourceId;
 const [calendar,setCalendar]=useState<number|null>(null),calendarRequest=useRef<number|null>(null),calendarSequence=useRef(0),calendarTrigger=useRef<HTMLButtonElement>(null),calendarFocus=useRef(false);
 const calendarEntries=useMemo(()=>sessions.map(session=>session.reference),[sessions]);
 const source=useMemo(()=>sessions.find(s=>s.reference.id===sourceId),[sessions,sourceId]),total=source?.chart.current.length??0,start=Number(range.start),end=Number(range.end),valid=validPatternSelection(start,end,total);
 const query=useMemo(()=>{if(!source||!valid)return null;try{return buildPatternWindow(source,start,end);}catch{return null;}},[source,start,end,valid]);
 const sourceBars=useMemo(()=>source?visibleCandles(source,total):[],[source,total]);
 const resultSessions=useMemo(()=>new Map(matches.map(match=>{const candidate=sessions.find(s=>s.reference.id===match.id);return [match.id,candidate?visibleCandles(candidate,candidate.chart.current.length):[]];})),[sessions,matches]);
 const inspection=useMemo(()=>{if(!inspected)return null;const candidate=sessions.find(s=>s.reference.id===inspected.id);return candidate?{candidate,candles:visibleCandles(candidate,candidate.chart.current.length)}:null;},[sessions,inspected]);
 function releaseGesture(){const g=gesture.current;gesture.current=null;if(g&&svg.current?.hasPointerCapture?.(g.pointer))svg.current.releasePointerCapture(g.pointer);}
 function cancelGesture(){const g=gesture.current;releaseGesture();if(g&&g.source===latestSource.current)setRange(g.original);}
 function stop(){epoch.current++;job.current?.abort();job.current=null;setBusy(false);}
 function invalidate(){stop();setMatches([]);setSearched(false);setInspected(null);setError('');setStatus('');}
 function openCalendar(){if(!alive.current||calendarRequest.current!==null)return;cancelGesture();const token=++calendarSequence.current;calendarRequest.current=token;setCalendar(token);}
 function closeCalendar(token:number){if(!alive.current||calendarRequest.current!==token)return;calendarRequest.current=null;calendarFocus.current=true;setCalendar(null);}
 function chooseSource(id:string,token:number){if(!alive.current||calendarRequest.current!==token||!sessions.some(session=>session.reference.id===id))return;cancelGesture();invalidate();setSourceId(id);setRange({start:'1',end:'15'});closeCalendar(token);}
 useEffect(()=>{if(calendar===null&&calendarFocus.current){calendarFocus.current=false;calendarTrigger.current?.focus({preventScroll:true});}},[calendar]);
 function setSelection(next:{start:number;end:number}){invalidate();setRange({start:String(next.start),end:String(next.end)});}
 useEffect(()=>{alive.current=true;return()=>{alive.current=false;calendarRequest.current=null;epoch.current++;job.current?.abort();releaseGesture();}},[]);
 useEffect(()=>{
  const controller=new AbortController();let current=true;setLoadError('');setLoadState('Loading and verifying historical charts…');
  const timeout=setTimeout(()=>{controller.abort();if(current){setLoadError('Chart loading timed out. Please retry.');setLoadState('');}},15000);
  loadChartMatchSessions({signal:controller.signal}).then(rows=>{if(!current||controller.signal.aborted)return;setSessions(rows);setSourceId(rows.at(-1)?.reference.id??'');setLoadState('');}).catch(err=>{if(current&&!controller.signal.aborted){setLoadError(errorMessage(err));setLoadState('');}}).finally(()=>clearTimeout(timeout));
  return()=>{current=false;clearTimeout(timeout);controller.abort();};
 },[retry]);
 useEffect(()=>{const cancel=()=>cancelGesture(),hidden=()=>{if(document.hidden)cancel();};window.addEventListener('blur',cancel);window.addEventListener('pagehide',cancel);document.addEventListener('visibilitychange',hidden);return()=>{window.removeEventListener('blur',cancel);window.removeEventListener('pagehide',cancel);document.removeEventListener('visibilitychange',hidden);};},[]);
 useEffect(()=>{if(inspected){viewer.current?.focus({preventScroll:true});viewer.current?.scrollIntoView?.({block:'start'});}},[inspected]);
 async function search(){
  if(!query||!alive.current||gesture.current)return;stop();const token=epoch.current,controller=new AbortController();job.current=controller;setBusy(true);setMatches([]);setInspected(null);setError('');setSearched(false);setStatus('Comparing candle patterns…');
  try{const result=await rankPatternMatches(query,sessions,{earlierOnly:false,limit,signal:controller.signal,onProgress:progress=>{if(alive.current&&epoch.current===token)setStatus(`Comparing patterns… ${progress.scanned.toLocaleString()} windows checked`);}});
   if(!alive.current||controller.signal.aborted||epoch.current!==token)return;
   setMatches(result.matches);setSelected(result.matches.map(m=>`${m.id}:${m.startBar}`));setSearched(true);setStatus(`${result.matches.length} closest patterns from ${result.eligibleSessions} eligible sessions · ${result.scanned.toLocaleString()} windows compared${result.skippedSessions?` · ${result.skippedSessions} unavailable sessions skipped`:''}.`);
  }catch(err){if(alive.current&&epoch.current===token&&!controller.signal.aborted){setError(errorMessage(err));setStatus('');}}finally{if(alive.current&&epoch.current===token){job.current=null;setBusy(false);}}
 }
 function pointerDown(event:PointerEvent<SVGSVGElement>){
  if(!source||event.button!==0||gesture.current)return;const anchor=patternPointerBar(event.clientX,event.currentTarget.getBoundingClientRect(),total);if(anchor===null)return;
  const g:Gesture={pointer:event.pointerId,source:sourceId,anchor,x:event.clientX,original:{...range},moved:false};
  try{event.currentTarget.setPointerCapture(event.pointerId);}catch{return;}
  gesture.current=g;event.currentTarget.focus({preventScroll:true});invalidate();
 }
 function pointerMove(event:PointerEvent<SVGSVGElement>){
  const g=gesture.current;if(!g||g.pointer!==event.pointerId||g.source!==latestSource.current)return;
  if(Math.abs(event.clientX-g.x)>4)g.moved=true;if(!g.moved)return;
  const rect=event.currentTarget.getBoundingClientRect(),clamped=Math.max(rect.left+rect.width*.024,Math.min(rect.left+rect.width*.928,event.clientX)),bar=patternPointerBar(clamped,rect,total);
  if(bar!==null){event.preventDefault();const next=draggedPatternSelection(g.anchor,bar,total);setRange({start:String(next.start),end:String(next.end)});}
 }
 function pointerUp(event:PointerEvent<SVGSVGElement>){
  const g=gesture.current;if(!g||g.pointer!==event.pointerId)return;if(g.source!==latestSource.current){releaseGesture();return;}
  pointerMove(event);if(!g.moved){const length=Number(g.original.end)-Number(g.original.start)+1,next=placePatternSelection(g.anchor,Number.isFinite(length)?length:15,total);setRange({start:String(next.start),end:String(next.end)});}releaseGesture();
 }
 function chartKeys(event:KeyboardEvent<SVGSVGElement>){
  if(event.defaultPrevented||event.nativeEvent.isComposing||event.ctrlKey||event.metaKey||event.altKey)return;
  if(event.key==='Escape'){event.preventDefault();cancelGesture();return;}
  if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key)||!source)return;event.preventDefault();cancelGesture();
  setSelection(placePatternSelection(event.key==='Home'?1:event.key==='End'?total:start+(event.key==='ArrowLeft'?-1:1),valid?end-start+1:15,total));
 }
 function prepareSave(){if(!query||candidate)return;try{const chosen=matches.filter(m=>selected.includes(`${m.id}:${m.startBar}`));const frozen=patternStudySnapshot(query,chosen,sessions,{earlierOnly:false,limit});setCandidate(frozen as PatternSnapshot);setPreviewCharts(Object.fromEntries(sessions.filter(s=>[frozen.source,...frozen.matches].some(e=>e.chartId===s.reference.id)).map(s=>[s.reference.id,s.chart])));}catch(e){setError(errorMessage(e));}}
 function closeInspection(){setInspected(null);viewerTrigger.current?.focus();}
 return <div className={styles.page}><AppHeader section="PATTERN MATCH" current="/pattern-match"><LearnerAccountControl onBeforeNavigate={()=>!pendingSave.current&&(!dirtyDraft.current||window.confirm('Discard unsaved pattern notes?'))} navigationWarning="Signing in leaves this page. Unsaved pattern selections and notes are not stored."/></AppHeader><main className={styles.main}>
  <header className={styles.intro}><div><p className={styles.eyebrow}>SMALL PATTERNS · BIG LIBRARY</p><h1>Pattern Match</h1><p className={styles.notice}>Find a pattern, choose matching windows, then save a private study.</p><p>Highlight a small stretch of chart. Find the same kind of price action across historical sessions.</p></div><div><a href="/chart-match">Screenshot matching ↗</a></div></header>
  {loadState&&<p role="status" className={styles.notice}>{loadState}</p>}{loadError&&<div role="alert" className={styles.error}><p>{loadError}</p><button onClick={()=>setRetry(n=>n+1)}>Retry charts</button></div>}
  {source&&<>
   <section className={styles.panel} aria-labelledby="pattern-select-title"><div className={styles.sectionHeader}><h2 id="pattern-select-title"><span>1</span> Select your pattern</h2><span className={styles.instrument}>MES · 5 minute · EMA20</span></div>
    <div className={styles.controls}><label>Source session<button ref={calendarTrigger} type="button" aria-haspopup="dialog" aria-expanded={calendar!==null} onClick={openCalendar}>{source.reference.date} · Choose date</button></label><label>Start bar<input type="number" min="1" max={total-9} step="1" value={range.start} onChange={event=>{cancelGesture();invalidate();setRange(r=>({...r,start:event.target.value}));}}/></label><label>End bar<input type="number" min="10" max={total} step="1" value={range.end} onChange={event=>{cancelGesture();invalidate();setRange(r=>({...r,end:event.target.value}));}}/></label><div className={styles.lengths} aria-label="Pattern length">{[10,15,20].map(n=><button key={n} aria-pressed={valid&&end-start+1===n} onClick={()=>{cancelGesture();setSelection(placePatternSelection(Number.isFinite(start)?start:1,n,total));}}>{n} bars</button>)}</div></div>
    <p className={styles.small}>{source.reference.title}</p>
    <p id="pattern-selection-help" className={styles.help}>Drag across 10–20 candles, or tap a candle to place the selected length. Use the bar fields or slider for precise selection on a phone. Arrow keys move the selection.</p>
    <div className={styles.sourceChart}><PatternCandles ref={svg} candles={sourceBars} selection={Number.isInteger(start)&&Number.isInteger(end)&&start>=1&&end>=start&&end<=total?{start,end}:undefined} label={`${source.reference.date} source chart. Highlight 10 to 20 consecutive bars.`} interactive tabIndex={0} aria-describedby="pattern-selection-help" onPointerDown={pointerDown} onPointerMove={pointerMove} onPointerUp={pointerUp} onPointerCancel={cancelGesture} onLostPointerCapture={cancelGesture} onKeyDown={chartKeys}/></div>
    <label className={styles.slider}>Move pattern <input type="range" min="1" max={Math.max(1,total-(valid?end-start+1:15)+1)} value={Math.min(Math.max(1,Number.isFinite(start)?start:1),total-(valid?end-start+1:15)+1)} onChange={event=>{cancelGesture();setSelection(placePatternSelection(Number(event.target.value),valid?end-start+1:15,total));}} aria-label="Move pattern start bar"/><span>{valid?`Bars ${start}–${end}`:'Choose 10–20 bars'}</span></label>
    {!valid&&<p role="alert" className={styles.error}>Choose 10–20 consecutive bars within this session. The highlighted range is not searched until it is valid.</p>}
   </section>
   <section className={styles.queryRow} aria-label="Selected pattern and search options"><div className={styles.queryPreview}><div className={styles.sectionHeader}><h2>Your pattern</h2><span>{valid?`${end-start+1} bars · ${source.reference.date}`:'No valid selection'}</span></div>{query?<PatternCandles candles={query.candles} startBar={start} label={`Selected pattern, bars ${start} to ${end}`} compact/>:<p>Select a valid range above to preview it here.</p>}</div><div className={styles.searchPanel}><h2><span>2</span> Find similar patterns</h2><p>Matches can start anywhere in a session. Price level and size are normalized, while candle direction, bodies, wicks and EMA shape stay meaningful.</p><p className={styles.warning}>All other chart sessions are searched, including later dates, for study. This is not a historical backtest.</p><label className={styles.resultCount}>Show<select value={limit} onChange={event=>{invalidate();setLimit(Number(event.target.value));}}>{[12,24,48].map(n=><option key={n} value={n}>{n} matches</option>)}</select></label><div className={styles.actions}><button className={styles.primary} disabled={!query||busy} onClick={()=>void search()}>{busy?'Finding patterns…':'Find similar patterns'}</button>{busy&&<button onClick={()=>{stop();setStatus('Search canceled. Your selection is unchanged.');}}>Cancel search</button>}</div><p className={styles.small}>The source session is excluded. Matching does not change charts or practice history. Save selected examples to your private encyclopedia.</p></div></section>
   <p className={styles.status} role="status" aria-live="polite">{status}</p>{error&&<p role="alert" className={styles.error}>{error}</p>}
   {searched&&<section aria-labelledby="pattern-results-title"><div className={styles.resultsHeading}><h2 id="pattern-results-title">Closest patterns</h2><span>Distance ↓ lower is closer · 0 = identical features</span></div><p className={styles.help}>These are the closest available examples, not guaranteed lookalikes. At most two nonoverlapping patterns per session. Similarity is not a probability, forecast or evidence of a trading edge.</p>{matches.length===0&&<div className={styles.notice}>No eligible patterns were found. Try another range or source session.</div>}
    <div className={styles.actions}><button disabled={!!candidate} onClick={prepareSave}>{`Save selected patterns (${selected.length})`}</button><a href="/pattern-encyclopedia">Open encyclopedia</a></div><div className={styles.grid}>{matches.map((match,index)=><article className={styles.card} key={`${match.id}:${match.startBar}`}><label className={styles.checkbox}><input type="checkbox" checked={selected.includes(`${match.id}:${match.startBar}`)} onChange={e=>setSelected(old=>e.target.checked?[...old,`${match.id}:${match.startBar}`]:old.filter(key=>key!==`${match.id}:${match.startBar}`))}/>Include in saved study</label><div className={styles.cardHeading}><div><span className={styles.rank}>#{index+1}</span> <time dateTime={match.date}>{match.date}</time></div><span className={styles.score} title="Feature distance, not confidence or probability">{match.distance.toFixed(3)} <small>distance</small></span></div><div className={styles.fullChart} tabIndex={0} role="region" aria-label={`${match.date} full session chart; scroll horizontally on smaller screens`}><PatternCandles candles={resultSessions.get(match.id)??[]} startBar={1} selection={{start:match.startBar,end:match.endBar}} label={`Historical match ${index+1}, ${match.date}. Full historical session, ${resultSessions.get(match.id)?.length??0} observed bars. Box: bars ${match.startBar} to ${match.endBar}.`} fullSession/></div><div className={styles.cardFooter}><span>Bars {match.startBar}–{match.endBar} · {match.startTime.slice(11,16)}–{match.endTime.slice(11,16)}</span><button onClick={event=>{viewerTrigger.current=event.currentTarget;setInspected(match);}}>Inspect context</button></div><details className={styles.breakdown}><summary>Why this match?</summary><p>Distance by feature, lower is closer. Features use only the pattern and preceding context.</p><ul>{Object.entries(match.components).filter(([,value])=>typeof value==='number').map(([name,value])=><li key={name}>{name}: {(value as number).toFixed(3)}</li>)}</ul></details></article>)}</div>
   </section>}
   {candidate&&<><p className={styles.notice}>This study captures your selection when you opened the editor. Changing the search will not change this draft.</p><PatternSavePanel candidateSnapshot={candidate} previewCharts={previewCharts} onClose={()=>{setCandidate(null);setPreviewCharts({});dirtyDraft.current=false;pendingSave.current=false;}} onDirtyChange={value=>{dirtyDraft.current=value;}} onPendingChange={value=>{pendingSave.current=value;}}/></>}
   {inspected&&inspection&&<section ref={viewer} tabIndex={-1} className={styles.viewer} aria-labelledby="pattern-context-title" onKeyDown={event=>{if(event.key==='Escape'){event.preventDefault();closeInspection();}}}><div className={styles.sectionHeader}><h2 id="pattern-context-title">{inspected.date} · bars {inspected.startBar}–{inspected.endBar}</h2><button onClick={closeInspection}>Close context</button></div><p>Full historical session shown, including later bars. The box marks the matched segment; later outcomes never enter its score.</p><div className={styles.fullChart} tabIndex={0} role="region" aria-label={`${inspected.date} full session chart; scroll horizontally on smaller screens`}><PatternCandles candles={inspection.candles} selection={{start:inspected.startBar,end:inspected.endBar}} label={`${inspected.date} chart context. Full historical session. Box: matched bars ${inspected.startBar} to ${inspected.endBar}.`} fullSession/></div><button onClick={()=>{const id=inspected.id,next={start:String(inspected.startBar),end:String(inspected.endBar)};cancelGesture();invalidate();setSourceId(id);setRange(next);window.scrollTo?.({top:0,behavior:'smooth'});}}>Use as new pattern</button></section>}
   <p className={styles.small}>The 2024 charts use TradeStation @MES data. Continuous-contract adjustment and Chicago timezone are not independently verified. July 18, 2024 is missing, and EMA uses available bars only. Similarity across sources is a study aid.</p>
   <details className={styles.method}><summary>How matching works</summary><p>Each candidate has the same number of bars as your selection. The search compares the close path, relative candle bodies and wicks, bullish/bearish direction, EMA20 position and slope, and up to five preceding candles. Price translation and positive scale are removed; bearish patterns are not flipped into bullish ones.</p><p>EMA20 retains the original historical warmup. No candles after a candidate’s last matched bar, later returns, trade results or future pivots enter its distance. Scores describe feature similarity only and are not calibrated probabilities. Results stay in this page’s memory and are cleared when you leave. Saved studies stay in your private encyclopedia.</p></details>
  </>}
 </main>{calendar!==null&&<TradeSessionCalendar key={calendar} entries={calendarEntries} initialId={sourceId} title="Choose source session" helpText="Choose an available date to load its chart and reset the pattern to bars 1–15. Close keeps your current pattern and results. Arrow keys or W A S D move between dates; Enter or Space opens the focused date." onChoose={id=>chooseSource(id,calendar)} onClose={()=>closeCalendar(calendar)}/>}</div>;
}
