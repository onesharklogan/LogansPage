'use client';
import {useEffect,useRef,useState} from 'react';
import LoadingIndicator from './loading-indicator';
import styles from './improvements-notes.module.css';

type Notes={context:{accountId:string;generation:number;sessionTag:string};text:string;revision:number;updatedAt:string|null};
class NotesError extends Error {constructor(message:string,public status:number){super(message);}}
async function request(url:string,init?:RequestInit){
 const response=await fetch(url,{...init,cache:'no-store',credentials:'same-origin'});
 let value;try{value=await response.json();}catch{throw new NotesError('Unable to confirm the save. Your typed notes are still here.',response.status);}
 if(!response.ok)throw new NotesError(value.error||'Unable to save notes. Your typed notes are still here.',response.status);
 return value;
}
export default function ImprovementsNotes(){
 const [saved,setSaved]=useState<Notes|null>(null),[text,setText]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState(''),[status,setStatus]=useState(''),[conflict,setConflict]=useState(false);
 const alive=useRef(true),locked=useRef(false),token=useRef('');
 const dirty=saved!==null&&text!==saved.text;
 async function load(){
  if(locked.current)return;
  if(dirty&&!window.confirm('Reloading will replace your unsaved notes with the latest saved version. Copy your notes first if you want to keep them. Reload anyway?'))return;
  locked.current=true;setBusy(true);setError('');setStatus('');
  try{
   const session=await request('/api/learner/session');
   if(!session.profile)throw new NotesError('Sign in to load your private notes.',401);
   const next=await request('/api/learner/improvements');
   if(alive.current){token.current=session.csrfToken;setSaved(next);setText(next.text);setConflict(false);setStatus('Notes loaded.');}
  }catch(e){if(alive.current)setError(e instanceof Error?e.message:'Could not load notes.');}
  finally{locked.current=false;if(alive.current)setBusy(false);}
 }
 useEffect(()=>{alive.current=true;void load();return()=>{alive.current=false;};},[]);
 useEffect(()=>{if(!dirty)return;const warn=(event:BeforeUnloadEvent)=>{event.preventDefault();event.returnValue='';};window.addEventListener('beforeunload',warn);return()=>window.removeEventListener('beforeunload',warn);},[dirty]);
 async function save(){
  if(!saved||locked.current||conflict||text.length>20000)return;
  locked.current=true;setBusy(true);setError('');setStatus('');
  try{
   const next=await request('/api/learner/improvements',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':token.current},body:JSON.stringify({context:saved.context,text,revision:saved.revision})});
   if(alive.current){setSaved(next);setText(next.text);setStatus('Saved to your account.');}
  }catch(e){if(alive.current){if(e instanceof NotesError&&e.status===409){setConflict(true);setError('These notes changed on another screen. Your draft is still here. Copy it, then reload the latest version before editing again.');}else setError(e instanceof Error?e.message:'Save not confirmed. Your typed notes are still here.');}}
  finally{locked.current=false;if(alive.current)setBusy(false);}
 }
 async function copy(){try{await navigator.clipboard.writeText(text);if(alive.current)setStatus('Notes copied.');}catch{if(alive.current)setStatus('Copy unavailable. Select the notes and copy them manually.');}}
 if(!saved)return <section className={styles.panel} aria-labelledby="improvements-heading"><h2 id="improvements-heading">Improvements</h2>{error?<><p role="alert" className={styles.error}>{error}</p><button type="button" disabled={busy} onClick={()=>void load()}>Retry notes</button></>:<p role="status"><LoadingIndicator size="small" label="Loading notes…" /></p>}</section>;
 return <section className={styles.panel} aria-labelledby="improvements-heading">
  <div className={styles.heading}><div><h2 id="improvements-heading">Improvements</h2><p>Ideas for later. Saving notes does not make changes to the app.</p></div><span className={styles.state}>{dirty?'Unsaved changes':'Saved notes'}</span></div>
  <label className={styles.label} htmlFor="improvements-notes">What would you like to improve?</label>
  <textarea id="improvements-notes" value={text} onChange={e=>{setText(e.target.value);setStatus('');}} disabled={busy||!saved} maxLength={20000} rows={7} placeholder="Keep your ideas, fixes and requests here…" />
  <div className={styles.actions}><button type="button" onClick={()=>void save()} disabled={busy||!saved||!dirty||conflict}>Save notes</button><button type="button" onClick={()=>void copy()} disabled={!text}>Copy notes</button><button type="button" onClick={()=>void load()} disabled={busy}>Reload latest</button><span>{text.length.toLocaleString()} / 20,000</span></div>
  {error&&<p className={styles.error} role="alert">{error}</p>}<p className={styles.status} role="status">{busy?'Syncing notes…':status}</p>
 </section>;
}
