import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {cumulativeDeviceChart} from '../lib/cumulative-device-chart.mjs';
import {outcomeTotals,deriveStatsPage,filterStatsByDevice} from '../public/modules/learner-stats.js';
const row=(n,points,device)=>({id:`12345678-1234-4234-8234-${String(n).padStart(12,'0')}`,module:n%2?'market-direction':'trade-simulator',chartId:'mes1-2025-01-02-81',startedAt:`2026-11-01T10:${String(n).padStart(2,'0')}:00.000Z`,completedAt:`2026-11-01T10:${String(n).padStart(2,'0')}:01.000Z`,outcomes:outcomeTotals([points]),buckets:[points,0,0,0],practiced:n%2?1:null,neutral:n%2?0:null,carry:false,...(device===undefined?{}:{isMobile:device})});
const snapshot=attempts=>({version:1,context:{accountId:'12345678-1234-4234-8234-123456789012',generation:1,sessionTag:'a'.repeat(64)},snapshot:'b'.repeat(64),asOf:'2026-11-01T12:00:00.000Z',attempts});
const coords=path=>path.split(' ').filter((_,i)=>i%2===1).map(Number);
test('combined and device totals use saved outcomes, shared order, held device totals and preserve input',()=>{
 const s=snapshot([row(4,-5,false),row(2,-8,false),row(3,2),row(1,10,true)]),before=JSON.stringify(s);
 const c=cumulativeDeviceChart(s,300);
 assert.equal(JSON.stringify(s),before);assert.deepEqual(c.lines.map(l=>l.total),[-1,10,-13]);assert.equal(c.unknown,1);
 assert.deepEqual(c.stats.series.points.map(p=>p.netPoints),[10,-8,2,-5]);
 const mobile=coords(c.lines[1].path),pc=coords(c.lines[2].path);
 assert.equal(mobile[1],mobile[2]);assert.equal(mobile[2],mobile[3]);assert.equal(mobile[3],mobile[4]);assert.equal(pc[0],pc[1]);assert.equal(pc[2],pc[3]);
 assert.ok(c.windowed.low<-13);assert.ok(c.windowed.high>10);
 const xs=l=>l.path.split(' ').filter((_,i)=>i%2===0).map(s=>s.slice(1));
 assert.deepEqual(xs(c.lines[0]),xs(c.lines[1]));assert.deepEqual(xs(c.lines[0]),xs(c.lines[2]));
});
test('unknown devices are never classified as PC; no device history stays at zero',()=>{
 const c=cumulativeDeviceChart(snapshot([row(1,5)]));assert.deepEqual(c.lines.map(l=>l.total),[5,0,0]);assert.deepEqual(c.lines.map(l=>l.count),[1,0,0]);
 assert.equal(new Set(coords(c.lines[1].path)).size,1);assert.equal(new Set(coords(c.lines[2].path)).size,1);
});
test('empty, flat, partial verified, narrow and wide views remain finite',()=>{
 const missing={...row(2,0,false),outcomes:null,buckets:null,practiced:null,neutral:null,carry:null};
 for(const width of [1,120,300,900])for(const s of [snapshot([]),snapshot([row(1,0,true)]),snapshot([row(1,1,true),missing])]){
  const c=cumulativeDeviceChart(s,width);for(const l of c.lines)assert.ok(coords(l.path).every(Number.isFinite));assert.equal(c.windowed.width,width);
 }
 const c=cumulativeDeviceChart(snapshot([row(1,1,true),missing]));assert.equal(c.stats.complete,false);assert.equal(c.stats.covered,1);assert.equal(c.stats.count,2);
});
test('negative values, replays and device-only series are retained',()=>{
 const c=cumulativeDeviceChart(snapshot([row(1,-3,true),row(2,-2,true),row(3,0,true)]));assert.equal(c.stats.covered,3);assert.deepEqual(c.lines.map(l=>l.total),[-5,-5,0]);assert.equal(c.lines[0].path,c.lines[1].path);
});
test('unverified snapshot fails closed',()=>{assert.throws(()=>cumulativeDeviceChart(snapshot([row(1,2,'mobile')])));});
test('account graph shows all three labeled lines, retains guarded dot actions, removes attempt buttons',()=>{
 const ui=readFileSync(new URL('../components/learner-trader-stats.tsx',import.meta.url),'utf8');
 assert.ok(ui.includes('cumulativeDeviceChart(valid!.data,plotWidth)'));assert.ok(ui.includes('data-device-line={line.key}'));assert.ok(ui.includes('lineLegend'));assert.ok(ui.includes("['All-time net points',stats.complete?formatHistoryPoints(stats.series.total):'N/A']"));assert.ok(ui.includes('if(allowed())'));assert.ok(ui.includes('onClick={()=>selectPoint(p.id)}'));
 for(const name of ['learner-trader-stats.tsx','trade-history-chart.tsx'])assert.doesNotMatch(readFileSync(new URL('../components/'+name,import.meta.url),'utf8'),/Previous attempt|Next attempt|attempt controls/);
});

test('all-time net KPI follows device filter, includes past days, and is withheld for incomplete outcomes',()=>{
 const s=snapshot([row(1,10,true),row(2,-8,false),row(3,2)]);
 assert.deepEqual(['all','mobile','pc'].map(d=>deriveStatsPage(filterStatsByDevice(s,d),2).series.total),[4,10,-8]);
 const missing={...row(4,0,false),outcomes:null,buckets:null,practiced:null,neutral:null,carry:null};
 assert.equal(deriveStatsPage(snapshot([...s.attempts,missing]),2).complete,false);
});
