'use client';

import {useEffect,useId,useMemo,useRef,useState,type KeyboardEvent} from 'react';
import {deriveHistorySeries,formatHistoryPoints,HISTORY_PAGE_SIZE,fitHistoryChart,observeHistoryWidth,historyPointAxis,type HistorySeries} from '../lib/trade-history-chart.mjs';
import type {Attempt} from '../lib/trade-simulator-history.mjs';

export type TradeHistoryChartProps={records:Attempt[];learnerId?:string};
type Selection={model:HistorySeries|null;index:number};
const css=`
.trade-history-chart{margin:16px 0;padding:12px;border:1px solid #355267;border-radius:12px;background:#0a1825;color:#e2edf7;min-width:0}.trade-history-chart *{box-sizing:border-box}.trade-history-chart h3{font-size:17px;margin:0 0 4px}.trade-history-chart p{margin:5px 0;font-size:13px;color:#adc2d5}.trade-history-chart .thc-frame{display:flex;min-width:0;max-width:100%;border:1px solid #2e465c;border-radius:8px;background:#091420;overflow:hidden}.trade-history-chart .thc-axis{flex:none;pointer-events:none}.trade-history-chart .thc-scroll{flex:1;min-width:0;overflow:hidden}.trade-history-chart svg{display:block;max-width:none}.trade-history-chart [data-history-dot]{cursor:pointer;outline:none}.trade-history-chart [data-history-dot] .thc-hit{fill:transparent;stroke:transparent;stroke-width:2}.trade-history-chart [data-history-dot]:focus-visible .thc-hit{stroke:#ffcf7c}.trade-history-chart .thc-pages{display:flex;align-items:center;justify-content:space-between;gap:8px;margin:8px 0}.trade-history-chart button{min-width:44px;min-height:44px;border:1px solid #405c72;border-radius:7px;background:#142638;color:#e2edf7;font:inherit;padding:6px 10px;cursor:pointer}.trade-history-chart button:disabled{opacity:.4;cursor:default}.trade-history-chart button:focus-visible{outline:2px solid #ffcf7c;outline-offset:2px}.trade-history-chart .thc-details{padding:10px;border-radius:8px;background:#102436;overflow-wrap:anywhere;min-height:112px}.trade-history-chart .thc-details strong{display:block}.trade-history-chart .thc-note{font-size:12px}.trade-history-chart .thc-summary{display:flex;flex-wrap:wrap;justify-content:space-between;gap:4px 12px}.trade-history-chart .thc-error{color:#ffc4cc}
`;
const utc=(value:string)=>value.slice(0,10)+' '+value.slice(11,19)+' UTC';

/** Local display state only. Parent owns loading, profile guards and all saved-history mutations. */
export default function TradeHistoryChart({records,learnerId}:TradeHistoryChartProps){
  const parsed=useMemo(()=>{try{return {model:deriveHistorySeries(records,learnerId),error:false}}catch{return {model:null,error:true}}},[records,learnerId]);
  const model=parsed.model,titleId=useId(),helpId=useId();
  const [selection,setSelection]=useState<Selection>({model:null,index:-1});
  const index=model?Math.max(0,Math.min(model.points.length-1,selection.model===model?selection.index:model.points.length-1)):-1;
  const [plotElement,setPlotElement]=useState<HTMLDivElement|null>(null),[plotWidth,setPlotWidth]=useState(300);
  useEffect(()=>observeHistoryWidth(plotElement,setPlotWidth),[plotElement]);
  const selected=model?.points[index],window=model?fitHistoryChart(model,plotWidth):null;
  const axis=window?historyPointAxis(window):null;
  const root=useRef<HTMLElement>(null),latest=useRef(model),alive=useRef(true),focusNext=useRef(false);latest.current=model;
  useEffect(()=>{alive.current=true;return()=>{alive.current=false}},[]);
  useEffect(()=>{const dot=root.current?.querySelector<SVGGElement>(`[data-history-index="${index}"]`);if(focusNext.current){dot?.focus({preventScroll:true});focusNext.current=false}},[model,index]);
  function select(next:number,focus=false){if(!model||!alive.current||latest.current!==model||!model.points.length)return;focusNext.current=focus;setSelection({model,index:Math.max(0,Math.min(model.points.length-1,next))})}
  function dotKey(event:KeyboardEvent<SVGGElement>,pointIndex:number){
    event.stopPropagation();if(event.defaultPrevented||event.nativeEvent.isComposing||event.nativeEvent.keyCode===229||event.ctrlKey||event.metaKey||event.altKey||event.shiftKey)return;
    const key=event.key.toLowerCase(),moves:{[key:string]:number}={arrowleft:-1,a:-1,arrowup:-1,w:-1,arrowright:1,d:1,arrowdown:1,s:1,pageup:-HISTORY_PAGE_SIZE,pagedown:HISTORY_PAGE_SIZE};
    if(key==='enter'||key===' '){event.preventDefault();select(pointIndex);return}
    if(key==='home'||key==='end'||Object.hasOwn(moves,key)){event.preventDefault();select(key==='home'?0:key==='end'?(model?.points.length||1)-1:pointIndex+moves[key],true)}
  }
  return <section ref={root} className="trade-history-chart" aria-labelledby={titleId} onKeyDown={event=>event.stopPropagation()}>
    <style>{css}</style><div className="thc-summary"><h3 id={titleId}>Accumulated points</h3>{model&&<strong data-history-total={model.total}>{formatHistoryPoints(model.total)} points</strong>}</div>
    {parsed.error?<p className="thc-error" role="alert">Accumulated points are unavailable because this saved history could not be verified. Reload the history to try again.</p>:!model?.points.length?<p role="status">Complete a Limit Orders Simulator session to see your accumulated points.</p>:<>
      <p id={helpId}>One dot per completed attempt, in completion order. Replays count as separate attempts.</p>
      <div className="thc-frame">
        <svg className="thc-axis" width={axis!.width} height={window!.height} viewBox={`0 0 ${axis!.width} ${window!.height}`} role="img" aria-label={`Vertical axis in points: ${axis!.ticks.map(tick=>tick.label).join(', ')}.`}>
          {axis!.ticks.map(tick=><text key={tick.value} data-history-axis-value={tick.value} x={axis!.width-8} y={tick.y+4} textAnchor="end" fill="#adc2d5" fontSize={12}>{tick.label}</text>)}
        </svg>
        <div ref={setPlotElement} className="thc-scroll" role="group" aria-label="All loaded accumulated points">
        <svg width="100%" height={window!.height} viewBox={`0 0 ${window!.width} ${window!.height}`} role="group" aria-label="Completed session accumulated points" aria-describedby={helpId}>
          {axis!.ticks.map(tick=><line key={tick.value} data-history-grid-value={tick.value} x1={0} x2={window!.width} y1={tick.y} y2={tick.y} stroke={tick.value===0?'#6e879e':'#253b4d'} strokeDasharray={tick.value===0?'4 4':undefined} pointerEvents="none"/>)}
          <path d={window!.path} fill="none" stroke="#8ac5ff" strokeWidth={2.5}/>
          <circle cx={window!.origin.x} cy={window!.origin.y} r={window!.radius} fill="#adc2d5"><title>Starting baseline: {formatHistoryPoints(window!.origin.cumulative)} points</title></circle>
          {window!.points.map(point=><g key={point.id} role="button" data-history-dot={point.id} data-history-index={point.index} data-history-points={point.netPoints} data-history-cumulative={point.cumulative} tabIndex={point.index===index?0:-1} aria-pressed={point.index===index} aria-label={`Attempt ${point.index+1}. ${point.sessionTitle}. Completed ${utc(point.completedAt)}. Session ${formatHistoryPoints(point.netPoints)} points. Accumulated ${formatHistoryPoints(point.cumulative)} points.`} aria-keyshortcuts="ArrowLeft ArrowRight ArrowUp ArrowDown A D W S Home End PageUp PageDown" onClick={event=>{event.stopPropagation();select(point.index)}} onKeyDown={event=>dotKey(event,point.index)}>
            <rect className="thc-hit" x={point.x-window!.hitWidth/2} y={10} width={window!.hitWidth} height={210} rx={8}/>
            <circle cx={point.x} cy={point.y} r={point.index===index?window!.selectedRadius:window!.radius} fill={point.netPoints>0?'#9fe0bd':point.netPoints<0?'#f6a5ad':'#c6d6e6'} stroke={point.index===index?'#fff':'#091420'} strokeWidth={Math.min(2,window!.radius*.4)} pointerEvents="none"/>
            {point.showLabel&&<text x={point.x} y={232} textAnchor={point.index===model.points.length-1?"end":point.index===0?"start":"middle"} fill="#adc2d5" fontSize={11} pointerEvents="none">{point.index+1}</text>}
          </g>)}
        </svg>
        </div>
      </div>
      <p>All {model.points.length} loaded attempts shown.</p>

      <div className="thc-details" role="status" aria-live="polite" aria-atomic="true" data-history-selected={selected!.id}><strong>{selected!.sessionTitle}</strong><p>Session date: {selected!.sessionDate||'Not recorded'} · Completed {utc(selected!.completedAt)}</p><p>Session: <b>{formatHistoryPoints(selected!.netPoints)} points</b> · Accumulated: <b>{formatHistoryPoints(selected!.cumulative)} points</b></p></div>
      <p className="thc-note">Tap a dot for details. Focus a dot and use arrows or W A S D to move. Points, not cash.</p>
    </>}
  </section>;
}
