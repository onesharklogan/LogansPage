import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import {createRequire} from 'node:module';import ts from 'typescript';import React from 'react';import {renderToStaticMarkup} from 'react-dom/server';
import {historicalPrefix} from '../lib/chart-match.mjs';import {patternPointerBar} from '../lib/pattern-selection.mjs';import {buildPatternWindow} from '../lib/pattern-match.mjs';
const source=fs.readFileSync(new URL('../components/pattern-candles.tsx',import.meta.url),'utf8');const compiled=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,jsx:ts.JsxEmit.ReactJSX}}).outputText;const module={exports:{}};new Function('require','module','exports',compiled)(createRequire(import.meta.url),module,module.exports);const Chart=module.exports.default;
const session=JSON.parse(fs.readFileSync(new URL('../public/modules/chart-match-index.json',import.meta.url))).sessions.at(-1),prior=session.chart.prior,current=historicalPrefix(session.chart,15,{useEma:true});
const render=props=>renderToStaticMarkup(React.createElement(Chart,{candles:current,label:'Test',...props}));
test('prior bars render separately, preserving current numbering and prefix-only handoff',()=>{
 const before=JSON.stringify(session),query=JSON.stringify(buildPatternWindow(session,1,15));const html=render({priorCandles:prior,selection:{start:1,end:15}});
 assert.equal((html.match(/data-prior-bar=/g)||[]).length,12);assert.equal((html.match(/data-pattern-bar=/g)||[]).length,15);assert.match(html,/data-pattern-bar="1"/);assert.doesNotMatch(html,/data-pattern-bar="(?:0|-\d+|16)"/);assert.match(html,/data-session-divider/);assert.match(html,/Prior session/);
 assert.equal(JSON.stringify(session),before);assert.equal(JSON.stringify(buildPatternWindow(session,1,15)),query);
 const x=Number(html.match(/data-pattern-highlight="true" x="([^"]+)/)[1]);assert.ok(Math.abs(x-(24+12*904/27))<1e-8);
});
test('desktop and mobile pointer mapping rejects context and maps every current candle correctly',()=>{
 for(const width of [390,1440]){const rect={left:30,width},total=81,n=12;for(let slot=0;slot<total+n;slot++){
 const client=rect.left+width*(24+904*(slot+.5)/(total+n))/1000;
 assert.equal(patternPointerBar(client,rect,total,1000,24,72,n),slot<n?null:slot-n+1);
 }}assert.equal(patternPointerBar(100,{left:0,width:1000},81,1000,24,72,-1),null);
});
test('selected preview crops current bars only with the combined source scale; other charts remain context-free',()=>{
 const html=render({candles:current.slice(2,5),referenceCandles:[...prior,...current],compact:true,startBar:3,referenceWidth:1000});
 assert.doesNotMatch(html,/data-prior-bar=/);assert.equal((html.match(/data-pattern-bar=/g)||[]).length,3);const width=Number(html.match(/viewBox="0 0 ([^ ]+)/)[1]);assert.ok(Math.abs(width-(96+904*3/27))<1e-8);
 assert.doesNotMatch(render({}),/data-prior-bar=|data-session-divider/);
});
