import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import vm from 'node:vm';
import {webcrypto} from 'node:crypto';
import {createHistoryCandleLoader,HISTORY_INDEX_URL} from '../public/modules/history-candle-data.js';
const origin='https://dailybalancelogan.onrender.com';
const html=await fs.readFile(new URL('../public/modules/market-direction.html',import.meta.url),'utf8');
function simulatorReader(fetch){
 const source=html.match(/function hostedURL\(path\)\{[^\n]+/)[0]+'\n'+html.match(/async function readPublicJSON\(url,signal,limit\)\{[^\n]+/)[0];
 const context=vm.createContext({URL,document:{baseURI:origin+'/modules/market-direction.html'},fetch,Uint8Array,TextDecoder});
 vm.runInContext(source,context);return context.readPublicJSON;
}
test('simulator catalog and session fetches send same-origin credentials and reject redirects',async()=>{
 const read=simulatorReader(async(url,options)=>{assert.equal(new URL(url).origin,origin);assert.equal(options.credentials,'same-origin');assert.equal(options.redirect,'error');return Response.json({ok:true});});
 for(const path of ['/charts/catalog.json','/charts/es1-2026-11-17-81.json'])assert.equal((await read(path,undefined,1024)).data.ok,true);
 await assert.rejects(read('https://evil.test/charts/catalog.json',undefined,1024),/this site/);
});
test('simulator denied or failed private asset fetch stays blocked, no fallback data',async()=>{
 await assert.rejects(simulatorReader(async()=>new Response(null,{status:403}))('/charts/catalog.json',undefined,1024),/HTTP 403/);
 await assert.rejects(simulatorReader(async()=>{throw new TypeError('Failed to fetch');})('/charts/catalog.json',undefined,1024),/Failed to fetch/);
});
test('history index loader authenticates private fetch and still verifies exact hash',async()=>{
 const bytes=await fs.readFile(new URL('../public'+HISTORY_INDEX_URL,import.meta.url));
 const loader=createHistoryCandleLoader({cryptoProvider:webcrypto,fetcher:async(url,options)=>{assert.equal(url,HISTORY_INDEX_URL);assert.equal(options.credentials,'same-origin');assert.equal(options.redirect,'error');return new Response(bytes,{headers:{'content-type':'application/json'}});}});
 const index=await loader();assert(index.sessions.length>0);
 const corrupt=createHistoryCandleLoader({cryptoProvider:webcrypto,fetcher:async()=>new Response('{}',{headers:{'content-type':'application/json'}})});
 await assert.rejects(corrupt());
});
test('failed charts EMA fetch retains same-origin authentication, redirect rejection and source hash validation',async()=>{
 const source=await fs.readFile(new URL('../components/failed-charts-book.tsx',import.meta.url),'utf8');
 assert.match(source,/fetch\('\/charts\/'/);assert.match(source,/credentials:'same-origin',redirect:'error'/);assert.match(source,/if\(hash!==source.sourceSha256\)return/);
});
