'use client';
import {useEffect,useMemo,useRef,useState} from 'react';
import {loadHistoryCandleIndex} from '../public/modules/history-candle-data.js';
import {failedChartDays} from '../lib/failed-charts-book.mjs';
import {tradeMarkers} from '../lib/failed-chart-trades.mjs';
import Model from '../lib/portal/lesson-model.cjs';
import styles from './failed-charts-book.module.css';
const points=(n:number)=>`${n>0?'+':''}${n.toLocaleString('en-US',{maximumFractionDigits:2})}`;
function Chart({source,large=false,trades=[]}:{source:any;large?:boolean;trades?:any[]}){
 const [indicator,setIndicator]=useState<{id:string;hash:string;values:number[]} | null>(null);
 useEffect(()=>{const controller=new AbortController();setIndicator(null);void(async()=>{try{
  if(!/^(?:mes1|es1)-\d{4}-\d{2}-\d{2}-(42|45|81)$/.test(source.id))return;
  const response=await fetch('/charts/'+source.id+'.json',{signal:controller.signal,credentials:'same-origin',redirect:'error'});if(!response.ok)return;
  const bytes=await response.arrayBuffer();if(bytes.byteLength>2*1024*1024)return;
  const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),b=>b.toString(16).padStart(2,'0')).join('');if(hash!==source.sourceSha256)return;
  const chart=JSON.parse(new TextDecoder().decode(bytes));if(chart.id!==source.id||chart.current.length!==source.candles.length)return;
  const values=Model.chartEma10(chart).ema10;if(!controller.signal.aborted)setIndicator({id:source.id,hash,values});
 }catch{}})();return()=>controller.abort();},[source.id,source.sourceSha256,source.candles]);
 const ema10=indicator&&indicator.id===source.id&&indicator.hash===source.sourceSha256?indicator.values:[];
 const bars=source.candles;
 if(!bars?.length)return <p>Original OHLC chart unavailable. No replacement candles generated.</p>;
 const low=Math.min(...bars.map((b:any)=>b.l)),high=Math.max(...bars.map((b:any)=>b.h)),pad=Math.max((high-low)*.08,.5),bottom=low-pad,top=high+pad;
 const x=(i:number)=>12+(i+.5)*640/bars.length,y=(p:number)=>24+(top-p)/(top-bottom)*240;
 return <svg viewBox="0 0 720 300" role="img" aria-label={`Full historical candlestick chart for ${source.id}. ${bars.length} original candles.`} className={large?styles.largeChart:styles.chart}>
 {[bottom,(bottom+top)/2,top].map(p=><g key={p}><line x1="12" x2="652" y1={y(p)} y2={y(p)} stroke="var(--appearance-line-263c50, #263c50)"/><text x="662" y={y(p)+4} fill="var(--appearance-ink-adc2d5, #adc2d5)" fontSize="12">{p.toFixed(2)}</text></g>)}
 {bars.map((b:any,i:number)=><g key={i} stroke={b.c>=b.o?'var(--appearance-ink-69d5ad, #69d5ad)':'var(--appearance-ink-ff819c, #ff819c)'}><line x1={x(i)} x2={x(i)} y1={y(b.h)} y2={y(b.l)}/><rect x={x(i)-2.4} y={y(Math.max(b.o,b.c))} width="4.8" height={Math.max(1,Math.abs(y(b.o)-y(b.c)))} fill={b.c>=b.o?'var(--appearance-ink-69d5ad, #69d5ad)':'var(--appearance-ink-ff819c, #ff819c)'}/></g>)}
 <path data-indicator="ema10" d={ema10.map((value:number,i:number)=>`${i?'L':'M'}${x(i)},${y(value)}`).join(' ')} fill="none" stroke="var(--appearance-ink-f6c760, #f6c760)" strokeWidth=".7" opacity=".3" vectorEffect="non-scaling-stroke"/>
 {tradeMarkers(trades,bars).map((m:any)=>{const cx=x(m.index),tip=y(m.buy?bars[m.index].l:bars[m.index].h)+(m.buy?5:-5),end=tip+(m.buy?8:-8);return <g key={m.key} data-trade-marker={m.kind} fill="none" stroke={m.buy?'var(--appearance-ink-32c88a, #32c88a)':'var(--appearance-ink-f45c70, #f45c70)'} strokeWidth="1" strokeLinecap="round" strokeLinejoin="round"><title>{m.kind} · {m.buy?'Buy':'Sell'} · Bar {m.index+1}</title><path d={`M${cx},${end}V${tip}m-2.5,${m.buy?3:-3}L${cx},${tip}l2.5,${m.buy?3:-3}`}/></g>})}
 {[0,Math.floor(bars.length/2),bars.length-1].map(i=><text key={i} x={x(i)} y="289" textAnchor={i===0?'start':i===bars.length-1?'end':'middle'} fill="var(--appearance-ink-adc2d5, #adc2d5)" fontSize="12">Bar {i+1}</text>)}
 </svg>;
}
function ReviewChart({day,large=false,loadTrades,canAct,onOpen}:{day:any;large?:boolean;onOpen?:()=>void;loadTrades?:(row:any,source:any)=>Promise<any[]>;canAct:()=>boolean}){
 const [visible,setVisible]=useState(false),[trades,setTrades]=useState<any[]|null>(null),[error,setError]=useState(false);
 const pending=useRef(false),alive=useRef(true),touch=useRef(false);
 useEffect(()=>{alive.current=true;return()=>{alive.current=false;};},[]);
 async function show(){if(!canAct())return;setVisible(true);if(trades||pending.current)return;pending.current=true;setError(false);try{const rows=loadTrades?await loadTrades(day.attempts[0],day.source):day.attempts[0].trades||[];if(alive.current){if(canAct())setTrades(Array.isArray(rows)?rows:[]);else setError(true);}}catch{if(alive.current)setError(true);}finally{pending.current=false;}}
 return <div><button type="button" className={styles.viewTrades} aria-pressed={visible} onPointerEnter={e=>{if(e.pointerType==='mouse')void show();}} onPointerLeave={e=>{if(e.pointerType==='mouse')setVisible(false);}} onPointerDown={e=>{touch.current=e.pointerType!=='mouse';}} onFocus={e=>{if(e.currentTarget.matches(':focus-visible'))void show();}} onBlur={()=>setVisible(false)} onClick={e=>{e.stopPropagation();if(touch.current){if(visible)setVisible(false);else void show();}}}><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true"><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg> View trades</button>{visible&&error&&<span role="status">Trades unavailable. Try again.</span>}{visible&&!trades&&!error&&<span role="status">Loading trades…</span>}{visible&&trades?.length===0&&<span role="status">No saved trade details available.</span>}<button type="button" className={styles.chartButton} aria-label={`Enlarge chart ${day.date}`} onClick={onOpen} style={onOpen?undefined:{display:'none'}}>{onOpen&&<Chart source={day.source} trades={visible?trades||[]:[]}/>}</button>{!onOpen&&<Chart source={day.source} large={large} trades={visible?trades||[]:[]}/>}</div>;
}
/** Receives only the current guarded owner's completed history; no writes or simulator actions. */
export default function FailedChartsBook({rows,canAct,loadTrades}:{rows:any[];canAct:()=>boolean;loadTrades?:(row:any,source:any)=>Promise<any[]>}){
 const review=useRef<HTMLElement>(null);
 const [page,setPage]=useState(0),[open,setOpen]=useState(false),[index,setIndex]=useState<any>(null),[error,setError]=useState(''),[retry,setRetry]=useState(0),[selected,setSelected]=useState<string|null>(null);
 useEffect(()=>{if(!open)return;const controller=new AbortController();setError('');loadHistoryCandleIndex({signal:controller.signal}).then(data=>{if(!controller.signal.aborted)setIndex(data);}).catch(()=>{if(!controller.signal.aborted)setError('The verified chart library could not be loaded. Your history is unchanged.');});return()=>controller.abort();},[open,retry]);
 const book=useMemo(()=>failedChartDays(rows,index),[rows,index]),position=book.days.findIndex((d:any)=>d.id===selected),day=book.days[position],lastPage=Math.max(0,Math.ceil(book.days.length/12)-1),currentPage=Math.min(page,lastPage);
 useEffect(()=>{if(selected){review.current?.scrollIntoView({block:'nearest'});review.current?.focus({preventScroll:true});}},[selected]);
 function act(fn:()=>void){if(canAct())fn();}
 return <section className={styles.book} aria-label="Failed Charts Book">
 <button type="button" className={styles.launch} aria-expanded={open} onClick={()=>act(()=>setOpen(!open))}><span aria-hidden="true">▥</span> Failed Charts Book <span>{open?'Close book':'Open graphical review'}</span></button>
 {open&&<div className={styles.content}><h4>Failed Charts Book</h4><p>Each card is a completed practice session with a negative overall result, after netting all its winning and losing trades. Replays stay separate, so a later win never hides an earlier failed session. Dates on charts are historical market dates.</p>

 <p className={styles.note}>Points use each simulator’s original scoring, not cash P&amp;L. Full-day candles are for hindsight review. Shapes are not automatic day-type diagnoses.</p>
 {error?<p role="alert">{error} <button type="button" onClick={()=>act(()=>setRetry(n=>n+1))}>Retry charts</button></p>:!index?<p role="status">Loading verified historical charts…</p>:<>
 <p role="status"><strong>{book.days.length} losing sessions</strong> / {book.total} completed sessions in this history selection. {book.incomplete>0&&`${book.incomplete} session(s) excluded because outcomes are incomplete. `}{book.unresolved>0&&`${book.unresolved} losing session(s) have no verified chart match. `}</p>
 {!book.days.length?<p>No verified net-losing sessions in this selection.</p>:<>
 {day&&<article ref={review} tabIndex={-1} className={styles.review} aria-label="Selected failed chart"><div className={styles.controls}><button type="button" disabled={position===0} onClick={()=>act(()=>setSelected(book.days[position-1].id))}>← Previous</button><strong>{position+1} / {book.days.length} · {day.date}</strong><button type="button" disabled={position===book.days.length-1} onClick={()=>act(()=>setSelected(book.days[position+1].id))}>Next →</button><button type="button" onClick={()=>act(()=>setSelected(null))}>Close enlarged chart</button></div><div className={styles.chartScroll}><ReviewChart key={day.id} day={day} large loadTrades={loadTrades} canAct={canAct}/></div><p><strong className={styles.loss}>{points(day.points)} points</strong> · {day.attempts.length} completed attempts</p><details><summary>Session result details</summary><ul>{day.attempts.map((a:any)=><li key={a.id}>{a.mode==='market'?'Market':'Limit'} · {points(a.points)} points · {a.completedAt?new Date(a.completedAt).toLocaleString():'Completion date unavailable'}</li>)}</ul></details></article>}
 <div className={styles.controls}><button type="button" disabled={currentPage===0} onClick={()=>act(()=>setPage(currentPage-1))}>Previous page</button><span>Page {currentPage+1} of {lastPage+1} · All {book.days.length} sessions available</span><button type="button" disabled={currentPage===lastPage} onClick={()=>act(()=>setPage(currentPage+1))}>Next page</button></div><div className={styles.grid}>{book.days.slice(currentPage*12,(currentPage+1)*12).map((d:any)=><div key={d.id} className={styles.card}><button type="button" aria-pressed={selected===d.id} aria-label={`Enlarge ${d.date}, ${points(d.points)} points, ${d.attempts.length} attempts`} onClick={()=>act(()=>setSelected(d.id))}><div className={styles.cardTitle}><strong>{d.date}</strong><span className={styles.loss}>{points(d.points)} pts</span></div></button><ReviewChart day={d} loadTrades={loadTrades} canAct={canAct} onOpen={()=>act(()=>setSelected(d.id))}/><button type="button" onClick={()=>act(()=>setSelected(d.id))}><span>{d.attempts[0].mode==='market'?'Market':'Limit'} · {d.attempts[0].completedAt?new Date(d.attempts[0].completedAt).toLocaleString():'Date unavailable'} · Tap to enlarge</span></button></div>)}</div>
 </>}
 </>}
 </div>}
 </section>;
}
