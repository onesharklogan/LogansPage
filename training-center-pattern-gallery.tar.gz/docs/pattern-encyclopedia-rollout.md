# Private Pattern Encyclopedia rollout (prepared, not deployed)

This change is additive and **has not run against a live database**. Schema-owner migration and runtime grants require separate authorization. Do not use the ordinary migration script as evidence these migrations ran: it manages the teacher schema only.

1. Review and apply `025_pattern_encyclopedia.sql` using an approved direct (non-pooled) learner schema-owner connection, after verifying existing migrations through 024.
2. Separately approve/apply `026_pattern_encyclopedia_grants.sql`. Only the existing learner runtime receives SELECT/INSERT and mutable-column UPDATE. No DELETE, snapshot UPDATE, receipt UPDATE, teacher/admin permission, credentials, security changes, or schema ownership are added.
3. Set `LEARNER_PATTERN_ENCYCLOPEDIA_ENABLED=true` only after the migration and grants are verified in the approved environment. Default false; missing tables/permissions return 503 `pattern_unavailable` without an ephemeral fallback.
4. Verify two separate Google accounts, save/reload, edit conflict, same-request retry, Trash/Restore, history reset preservation, logout/identity-switch clearing. Turn the flag off to disable access without removing saved records. Rollback must not drop these tables.

## API

All routes use the existing `/api/learner` verified identity, fixed origin, session CSRF and server-derived account. POSTs require `x-csrf-token` plus `{context:{accountId,generation,sessionTag},requestId:<UUID>,...}`. Context is a consistency guard, never an ownership selector. History reset invalidates old contexts but does not delete encyclopedia rows or request receipts. Account foreign keys restrict account deletion rather than silently cascading saved patterns. Existing teacher/admin history routes and exports do not expose private catalog data.

- `GET /patterns?state=active|trash&limit=25&cursor=...` returns `{context,patterns,nextCursor}`. Server max 50; browser pages are 25. Stable creation-time keyset pagination. Summaries include id/title/description/expectation/tags/revision/createdAt/updatedAt/deletedAt/source/matchCount and cover. cover is {chartId,chartSha256,startBar,endBar,chartStartBar:1,candles:[{t,o,h,l,c,ema}]} with the entire actual 42/45/81-bar current source session. startBar/endBar identify the selected 10–20 bars to highlight, not the preview extent. EMA is derived with historicalPrefix from the frozen chart through its actual session length. Cover candle count must exactly match the chart identity suffix; no bars are fabricated. Browser pages remain bounded at 25 entries and client responses at 4 MiB. These finished-day previews do not change saved selection, ranking or score recomputation. No full snapshot, overall notes or per-example notes are returned for cards. The database query fetches only the archived source chart, not the entire match snapshot.
- `GET /patterns/:id` returns `{context,pattern}` (including a trashed entry owned by this account).
- `POST /patterns` adds `pattern:{id,title,description,expectation,notes,tags,exampleNotes,snapshot}` and returns `{context,pattern,duplicate}` with status 201.
- `POST /patterns/:id` adds `{revision,action:'update',changes:{title,description,expectation,notes,tags,exampleNotes}}` or `{revision,action:'delete'|'restore'}` and returns the same response shape with status 200. Metadata replacement is complete, not partial. Snapshot fields cannot be edited. Delete is recoverable Trash only. Clients should explicitly confirm moving an entry to Trash.

Snapshot create input:

```json
{"version":1,"algorithmVersion":"pattern-v1","matchedAt":"2026-11-10T00:00:00.000Z","searchOptions":{"earlierOnly":false,"limit":10},"source":{"chartId":"mes1-2025-01-03-81","chartSha256":"<64 lowercase hex>","startBar":1,"endBar":10},"matches":[{"chartId":"mes1-2025-01-02-81","chartSha256":"<64 lowercase hex>","startBar":1,"endBar":10,"score":0.25}]}
```

Supported source identities end in 42, 45 or 81, matching the actual session length. No short session is padded or given fabricated bars. Ranges are inclusive **one-based** 10–20 bars, equal length across examples. New searches show the 10 closest examples, or fewer when fewer are eligible, without an example-count selector or a separate context viewer. Each result already shows the finished session with its matching range boxed. New saved studies use searchOptions.limit:10 and may contain any subset of those results. Legacy saved limits 12/24/48 remain accepted and readable without truncation; all snapshots must contain no more than their recorded limit. Source day excluded. New UI searches include every eligible catalog date (earlierOnly:false); legacy saved earlier-only searches retain and enforce their original provenance. At most two nonoverlapping windows per candidate day. Scores are finite nonnegative normalized distances, recomputed against exact chart windows within numerical tolerance. They are not probabilities. Order/membership remain exactly as submitted: the server never reranks. `matchedAt` is canonical ISO, not milliseconds, bounded to 2020 through five minutes ahead. `exampleNotes` keys are `chartId:startBar:endBar`, including source if desired.

The server loads/hash-verifies actual catalog files and adds `snapshot.charts`, a map of chartId to full chart JSON. Arbitrary client chart data is rejected. This preserves later replay even if a future release removes a catalog file. Stored chart SHA is the original JSON file-byte hash, not a hash of a reserialized object. Snapshot is immutable through runtime grants. Public historical chart data are duplicated only once per distinct day per pattern, never per receipt. Reads and metadata edits do not need the current catalog or silently recalculate scores.

Legacy metadata reads default missing description to existing notes and missing expectation to an empty string, retaining notes unchanged. New writes send distinct description, expectation, and notes; empty description/expectation are valid.

Limits: title 120 characters, description/expectation/notes each 10,000, 20 unique tags of 40 each, 49 example notes of 2,000 each, 64 KiB HTTP body, 2 MiB immutable snapshot, 250 entries and 64 MiB account entry storage (including Trash). Up to 10,000 receipts / 16 MiB receipt metadata per account. No automatic pruning or hard deletion occurs at limits; failed writes roll back completely. Receipt storage contains only metadata/revision/timestamps and joins the immutable snapshot when replayed.

## Retry and conflict contract

Request UUID is scoped to authenticated account, retained independently of session/history generation. The canonical command fingerprint excludes session context so retries after a newly verified sign-in can use refreshed context, but the context guard still must pass. Reuse the exact request UUID and command after an uncertain response, never invent a replacement ID unless intentionally creating a distinct operation. A different command with an existing ID yields 409 `pattern_request_conflict`. A new command based on an old revision yields 409 `pattern_conflict`, never last-write-wins.

A replay returns the **original action's metadata/revision**, not necessarily the latest revision. After an uncertain request, reconcile through GET and avoid rendering a historical receipt over newer state. No-write retries bypass catalog resolution and cannot resurrect a trashed/deleted state. Account locking serializes duplicates and conflicting updates atomically with receipts. Auth errors, ownership misses and unknown query/body fields fail closed.

## Validation

`node --test tests/pattern-encyclopedia-server.test.mjs` uses local PGlite with actual chart catalog/hash verification and real migrations; it does not access Neon or credentials. It covers private ownership, CSRF/origin, snapshot and score tampering, revisions, idempotency, rollback, Trash/Restore, reset preservation, disabled/missing schema, and least-privilege grants. Existing learner tests must continue passing. Runtime flag and production schema availability remain an operator verification step, not something proven by local tests.

## Staged operator checklist (requires separate approval)

Preparation is local only. No production configuration or credentials were inspected; no production migrations, grants, writes, deployment or feature activation were performed by this work.

Before seeking execution approval, review the exact release and both SQL files, existing learner authentication/origin/CSRF configuration, schema migration state through file 024, the existing learner_runtime role, and a recoverable database backup. Confirm the current release supports all 718 catalog sessions and 42/45/81-bar identities. Keep LEARNER_PATTERN_ENCYCLOPEDIA_ENABLED unset or false throughout schema preparation. Schema migration filename 025 records learner schema version 8; filename and recorded version are not interchangeable.

Read-only preflight, by an authorized operator in the intended environment:
- Inspect learner_app.schema_migrations, current role and connection target. Confirm earlier migrations and check whether pattern_entries/pattern_receipts already exist before applying non-idempotent 025. If present, inspect their exact definitions instead of rerunning blindly.
- Inspect existing privileges for learner_runtime, PUBLIC and other roles. Verify runtime is not table owner, superuser, or inheriting broader grants. Confirm existing authentication transaction locking and account ownership are in place; these tables rely on the existing server-owned account queries, not new row-level security.
- After approved schema/grant execution, inspect columns, composite keys, foreign keys, index, recorded version, and privilege metadata without modifying application records.

025 creates two tables and the account/creation-time pagination index only. Account foreign keys use ON DELETE RESTRICT; account hard-deletion workflows must explicitly account for saved records rather than silently cascading them. Existing history/reset tables and teacher data are unchanged. 026 gives the existing runtime SELECT and INSERT on both tables, and UPDATE only on pattern_entries metadata, revision, updated_at, deleted_at and payload_bytes. It adds no role, credentials, schema-wide privileges, DELETE, TRUNCATE, snapshot UPDATE, or receipt UPDATE. Existing schema USAGE is a prerequisite; do not broaden grants to fix a failed preflight without review.

Only after separately approved migration and minimum grants pass preflight may the flag be enabled for the approved rollout. Test with two explicitly authorized test accounts:
1. A saves a short-session source and real matches; reload and verify cover, selected bars, description, expectation and per-example notes. B cannot list, read or mutate A's IDs, even with A's submitted context. B may independently use the same pattern/request UUIDs.
2. Reuse an unchanged request UUID after an uncertain response; verify one entry/action. Change its content and verify conflict. Edit in two tabs and verify stale revision conflict without overwriting.
3. Move to Trash and Restore, verify archived data and metadata, then verify history reset preserves entries/receipts while old generation requests fail.
4. Sign out, replace session, and switch accounts during an in-flight fetch/save. Confirm no old account cards/detail/drafts are displayed or stored. Verify direct navigation reloads the owned detail and no teacher/admin surface exposes these records.
5. Disable the flag and verify catalog operations return pattern_unavailable while ordinary history remains available. Re-enable only within approval and confirm saved entries persist.

Rollback is flag off, retaining both tables and all receipts. Do not drop tables, delete records, revoke unrelated privileges or roll back other learner migrations. Saved immutable snapshots remain compatible even if the public catalog later removes a chart. Local tests do not establish production readiness or authorize these operator actions.
