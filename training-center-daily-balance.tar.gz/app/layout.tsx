import type { Metadata } from "next";
import {headers} from 'next/headers';
import {requestAppearance} from '../lib/appearance-server.mjs';
import AppearanceProvider from "../components/appearance-provider";
import "./globals.css";
import "../public/profile-companion.css";
import "../public/appearance.css";
import "../public/loading-indicator.css";
export const metadata: Metadata = {
  title: "Daily Balance",
  description: "Balanced day goals and focused trading practice.",
  robots: { index: false, follow: false },
};
export default async function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  const appearance=await requestAppearance(await headers());
  return <html lang="en" data-appearance={appearance} suppressHydrationWarning><head><script dangerouslySetInnerHTML={{__html:"try{if(parent!==window&&parent.location.origin===location.origin){var t=parent.document.documentElement.dataset.appearance;if(t==='light'||t==='dark')document.documentElement.dataset.appearance=t;}}catch(e){}"}}/></head><body><AppearanceProvider/>{children}</body></html>;
}
