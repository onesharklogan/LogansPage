import DailyDashboard from '../components/daily-dashboard';
export const dynamic='force-dynamic';
export const metadata={title:'Daily Balance',description:'Balanced Day Goals'};
export default function Home(){return <DailyDashboard/>;}
