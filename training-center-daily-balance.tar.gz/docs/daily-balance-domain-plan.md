# Daily Balance URL migration (not performed)

Current service srv-dbgf3vkipgvc73cjb3h0 in confirmed Logan workspace tea-d62vh0chg0os73eui82g remains at https://priceaction-training-center.onrender.com.
Requested https://dailybalance.onrender.com returned404 on2026-11-18, which does NOT establish availability. Connector has no rename/slug/availability operation; cloud Render dashboard requires sign-in. Exact slug and whether the old hostname remains routed must be confirmed in authenticated Render UI before changes.

Safe sequence after explicit publication/migration approval:
1. Confirm provider-assigned exact target hostname and old-host redirect support. If rename breaks old links, prefer staging a second service with existing DB credentials (requires costs/plan review) and keep the old service as a path-preserving GET redirect only after target verification, or choose a user-owned custom domain. Do not promise automatic redirect from a removed provider hostname.
2. Allow the exact new app origin and /learner/sign-in callback in existing Neon Auth configuration. Keep auth issuer endpoint and Google subject identity unchanged; Google callback currently points to Neon Auth, not directly to app.
3. Update pinned LEARNER_ORIGIN in lib/learner/google-config.mjs and any hosting env origin assumptions with coordinated release. Do not broadly trust arbitrary Host headers. Existing CSRF/origin checks must remain.
4. Retain same database and least-privilege runtime role. No table resets, account reassignment, credential output, or data migration required.
5. Verify target health, actual owner Google login, denial of nonowner and signed-out data access, correct history/tasks/notes. Only then redirect old host if support verified. Keep rollback to prior origin/configuration available.
6. User updates bookmarks. Host-only login cookies and origin-scoped local caches/unfinished session state do not migrate. Saved server history/tasks/notes persist. Finish/save current work first. Do not erase browser data.

The UI rebrand can ship independently at the existing URL, avoiding authentication disruption while hosting access is arranged.
