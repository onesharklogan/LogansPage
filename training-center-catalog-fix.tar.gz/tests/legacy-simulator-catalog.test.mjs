import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const html=fs.readFileSync(new URL('../public/modules/market-direction.html',import.meta.url),'utf8');
const code=html.slice(html.indexOf('function normalizeCatalog('),html.indexOf('\n',html.indexOf('function normalizeHostedSession(')));
const context=vm.createContext({safeText:s=>s,hostedURL:s=>s,validCandle:b=>['o','h','l','c'].every(k=>Number.isFinite(b[k])),HOSTED_CATALOG:'/charts/catalog.json'});
vm.runInContext(code,context);
const raw=JSON.parse(fs.readFileSync(new URL('../public/charts/catalog.json',import.meta.url)));
test('legacy simulator accepts full mixed ES/MES catalog and preserves instrument for session validation',()=>{
 const entries=context.normalizeCatalog(raw);assert.equal(entries.length,725);
 for(const entry of entries){assert.ok(['ES','MES'].includes(entry.instrument));const data=JSON.parse(fs.readFileSync(new URL('../public'+entry.url,import.meta.url)));const chart=context.normalizeHostedSession(data,entry);assert.equal(chart.date,entry.date);assert.ok(chart.current.length>=42);}
});
test('legacy catalog still rejects unknown instruments and session/catalog instrument mismatch',()=>{
 const bad=structuredClone(raw);bad.sessions[0].instrument='NQ';assert.throws(()=>context.normalizeCatalog(bad),/Invalid session catalog metadata/);
 const entry=context.normalizeCatalog(raw)[0],data=JSON.parse(fs.readFileSync(new URL('../public'+entry.url,import.meta.url)));data.instrument=entry.instrument==='MES'?'ES':'MES';assert.throws(()=>context.normalizeHostedSession(data,entry),/metadata does not match/);
});
