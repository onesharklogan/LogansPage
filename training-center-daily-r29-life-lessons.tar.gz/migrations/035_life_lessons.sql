-- Additive only; an app rollback can leave this table and its rows in place.
BEGIN;
CREATE TABLE IF NOT EXISTS learner_app.life_lessons (
 account_id uuid NOT NULL REFERENCES learner_app.accounts(id),
 lesson_id uuid NOT NULL,
 lesson_text text NOT NULL CHECK(char_length(lesson_text) BETWEEN 1 AND 2000 AND length(btrim(lesson_text))>0),
 created_at bigint NOT NULL CHECK(created_at>0),
 PRIMARY KEY (account_id,lesson_id)
);
CREATE INDEX IF NOT EXISTS life_lessons_owner_order ON learner_app.life_lessons (account_id,created_at DESC,lesson_id DESC);
REVOKE ALL ON learner_app.life_lessons FROM PUBLIC;
GRANT SELECT, INSERT ON learner_app.life_lessons TO learner_runtime;
COMMIT;
