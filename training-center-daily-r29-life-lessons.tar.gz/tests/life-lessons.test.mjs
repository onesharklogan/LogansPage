import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {randomUUID} from 'node:crypto';
import {PGlite} from '@electric-sql/pglite';
import {LearnerRepository} from '../lib/learner/repository.mjs';
import {createLearnerService} from '../lib/learner/server.mjs';
import {DAILY_BALANCE_ORIGIN,LEARNER_ORIGIN} from '../lib/learner/google-config.mjs';
const read=p=>fs.readFileSync(new URL('../'+p,import.meta.url),'utf8');

test('additive migration is repeatable and gives runtime append/read only',async()=>{
 const db=new PGlite();
 try{
  await db.exec('CREATE ROLE learner_runtime');
  await db.exec(read('migrations/006_learner_accounts.sql'));
  const account=randomUUID(),id=randomUUID();
  await db.query('INSERT INTO learner_app.accounts(id,provider_issuer,provider_subject,display_name,created_at) VALUES ($1,$2,$3,$4,$5)',[account,'issuer','owner','Owner',10]);
  const before=(await db.query('SELECT * FROM learner_app.accounts')).rows;
  const ddl=read('migrations/035_life_lessons.sql');
  await db.exec(ddl);
  await db.query('INSERT INTO learner_app.life_lessons VALUES ($1,$2,$3,$4)',[account,id,'persistent',12]);
  await db.exec(ddl);
  assert.deepEqual((await db.query('SELECT * FROM learner_app.accounts')).rows,before);
  assert.equal((await db.query('SELECT lesson_text FROM learner_app.life_lessons')).rows[0].lesson_text,'persistent');
  const grant=(await db.query("SELECT has_table_privilege('learner_runtime','learner_app.life_lessons','SELECT') AS read, has_table_privilege('learner_runtime','learner_app.life_lessons','INSERT') AS append, has_table_privilege('learner_runtime','learner_app.life_lessons','UPDATE') AS edit, has_table_privilege('learner_runtime','learner_app.life_lessons','DELETE') AS remove")).rows[0];
  assert.deepEqual(grant,{read:true,append:true,edit:false,remove:false});
  await assert.rejects(db.query('INSERT INTO learner_app.life_lessons VALUES ($1,$2,$3,$4)',[account,randomUUID(),'   ',12]),{code:'23514'});
  await assert.rejects(db.query('INSERT INTO learner_app.life_lessons VALUES ($1,$2,$3,$4)',[randomUUID(),randomUUID(),'ordinary text',12]),{code:'23503'});
 }finally{await db.close();}
});
test('owner can append, retry and page permanent lessons; other owners and requests cannot alter them',async()=>{
 const db=new PGlite();let who='Account One',now=Date.parse('2026-11-20T15:00Z');
 try{
  await db.exec('CREATE ROLE learner_runtime');
  for(const file of ['006_learner_accounts','031_improvement_notes','035_life_lessons'])await db.exec(read('migrations/'+file+'.sql'));
  const issuer='https://fixture.test';
  const repository=new LearnerRepository({transaction:fn=>db.transaction(tx=>fn(tx))});
  const service=origin=>createLearnerService({origin,repository,identityProvider:{issuer,resolve:async()=>who?{issuer,subject:who,name:who,sessionId:'session-fixture-for-'+who,expiresAt:now+86400000,emailVerified:true}:null},csrfSecret:'synthetic-only-no-production-secret-123456789',charts:async()=>null,now:()=>now});
  const deployed=service(DAILY_BALANCE_ORIGIN),standalone=service(LEARNER_ORIGIN);
  const req=async(path,{body,csrf,origin=DAILY_BALANCE_ORIGIN}={})=>{
   const response=await (origin===DAILY_BALANCE_ORIGIN?deployed:standalone)(new Request(origin+'/api/learner/'+path,{method:body?'POST':'GET',headers:{host:new URL(origin).host,origin,'sec-fetch-site':'same-origin',...(body?{'content-type':'application/json'}:{}),...(csrf?{'x-csrf-token':csrf}:{})},...(body?{body:JSON.stringify(body)}:{})}));
   return {status:response.status,body:await response.json(),cache:response.headers.get('cache-control')};
  };
  const session=(await req('session')).body,id=randomUUID();
  const command={context:session.context,id,text:'  A useful thought\nStill plain <b>text</b>.  '};
  const post=(body=command,csrf=session.csrfToken)=>req('life-lessons',{body,csrf});
  assert.equal((await post(command,'invalid')).status,403);
  assert.equal((await post({...command,text:'   '})).status,400);
  assert.equal((await post({...command,text:'x'.repeat(2001)})).status,400);
  assert.equal((await post({...command,lesson_id:'unexpected'})).status,400);
  const created=await post();assert.equal(created.status,200);
  assert.equal(created.body.lesson.text,'A useful thought\nStill plain <b>text</b>.');
  assert.equal(created.cache,'private, no-store');
  assert.deepEqual(await post(),created);
  assert.equal((await post({...command,text:'another lesson'})).status,409);
  const imp=(text,revision)=>req('improvements',{body:{context:session.context,text,revision},csrf:session.csrfToken});
  assert.equal((await imp('Not a life lesson',0)).status,200);assert.equal((await imp('',1)).status,200);
  assert.deepEqual((await req('life-lessons')).body.lessons,[created.body.lesson]);
  for(let i=0;i<31;i++){now+=i%2;assert.equal((await post({...command,id:randomUUID(),text:'lesson '+i})).status,200);}
  const first=(await req('life-lessons')).body;assert.equal(first.lessons.length,30);assert.ok(first.nextCursor);
  const last=(await req('life-lessons?cursor='+encodeURIComponent(first.nextCursor))).body;assert.equal(last.lessons.length,2);assert.equal(last.nextCursor,null);
  assert.equal(new Set([...first.lessons,...last.lessons].map(x=>x.id)).size,32);
  assert.equal((await req('life-lessons?cursor=invalid')).status,400);
  assert.equal((await req('life-lessons',{origin:LEARNER_ORIGIN})).status,404);
  who='Account Two';const second=(await req('session')).body;assert.deepEqual((await req('life-lessons')).body.lessons,[]);
  assert.equal((await post(command,second.csrfToken)).status,409);
  who=null;assert.equal((await req('life-lessons')).status,401);
  who='Account One';await req('session');assert.equal((await req('life-lessons')).body.lessons.length,30);
 }finally{await db.close();}
});
test('new section and catalog hide unloaded controls on Daily Balance',()=>{
 const page=read('app/page.tsx'),dash=read('components/daily-dashboard.tsx'),ui=read('components/life-lessons.tsx');
 assert.match(page,/lifeLessonsEnabled=\{process.env.LEARNER_APP_ORIGIN===DAILY_BALANCE_ORIGIN\}/);
 assert.match(dash,/lifeLessonsEnabled&&<LifeLessons owner=\{data\?\.context\}/);
 assert.match(ui,/<h2 id="life-lessons-heading">New life lessons<\/h2>/);
 assert.match(ui,/!visible\?.*Retry lessons.*LoadingIndicator/);
 assert.match(ui,/More|Show older lessons/);
 assert.match(read('components/pattern-encyclopedia.tsx'),/data-daily-catalog-pending=\{initialPending/);
 assert.match(read('components/pattern-encyclopedia.module.css'),/data-daily-nav="true".*data-daily-catalog-pending="true".*display:none/);
});
