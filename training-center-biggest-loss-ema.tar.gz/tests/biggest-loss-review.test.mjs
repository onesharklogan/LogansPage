import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {biggestLoss} from '../public/modules/biggest-loss.mjs';
test('review selects exactly the most negative finite result without altering history',()=>{
 const trades=Object.freeze([5,-2,0,-9,-4,-9,Infinity,NaN].map((points,id)=>Object.freeze({id,points})));
 assert.equal(biggestLoss(trades),trades[3]);assert.equal(trades.length,8);assert.equal(trades[1].points,-2);
});
test('no trades, all wins, flats and invalid results have no loss to review',()=>{
 for(const points of [[],[1,5],[0,0],[NaN,Infinity,-Infinity]])assert.equal(biggestLoss(points.map(points=>({points}))),null);
});
test('both post-session review implementations use the shared selector, including preview practice',()=>{
 const limit=readFileSync(new URL('../components/limit-trade-review.tsx',import.meta.url),'utf8');
 const market=readFileSync(new URL('../public/modules/completed-trade-review.js',import.meta.url),'utf8');
 assert.match(limit,/trade=biggestLoss\(trades\)/);assert.doesNotMatch(limit,/Next loss|Next trade|setIndex|previewTrading\?trades/);
 assert.match(market,/worst=biggestLoss\(trades\),copy=worst\?\[\{\.\.\.worst\}\]:\[\]/);
 for(const source of [limit,market]){assert.match(source,/Biggest loss/);assert.match(source,/No losing trades/);}
});
import {createCompletedTradeReview,renderTradeChart,reviewWindow} from '../public/modules/completed-trade-review.js';
function fakeDocument(){
 class Node{constructor(tag){this.tag=tag;this.children=[];this.style={};this.dataset={};this.attributes={};this.isConnected=true;}setAttribute(k,v){this.attributes[k]=v;}append(...nodes){this.children.push(...nodes);}replaceChildren(){this.children=[];}focus(){}showModal(){}close(){}remove(){}addEventListener(){}querySelector(tag){return this.children.find(n=>n.tag===tag)||this.children.map(n=>n.querySelector?.(tag)).find(Boolean);}}
 return {body:new Node('body'),head:new Node('head'),activeElement:null,getElementById(){return null;},createElement:tag=>new Node(tag),createElementNS:(_,tag)=>new Node(tag)};
}
test('market modal shows one worst loss; account guard blocks finish and repeated clicks finish once',()=>{
 const document=fakeDocument();let valid=false,finished=0;const review=createCompletedTradeReview({document,isValid:()=>valid,onDone:()=>finished++});
 const candles=Array.from({length:5},()=>({o:10,h:12,l:7,c:11}));
 const trades=[-1,-4,-2].map(points=>({entryIndex:0,exitIndex:3,entryPrice:11,exitPrice:11+points,points,side:'long'}));
 assert.equal(review.open({candles,trades}),true);assert.deepEqual(review.progress(),{index:0,total:1});
 const dialog=document.body.children.at(-1),button=dialog.querySelector('button');assert.equal(dialog.children[0].textContent,'Biggest loss');assert.match(dialog.children[1].textContent,/-4.00/);
 button.onclick({detail:1});assert.equal(finished,0);valid=true;button.onclick({detail:1});button.onclick({detail:1});assert.equal(finished,1);assert.equal(review.active(),false);assert.equal(trades.length,3);
});
test('winning-only market session remains dismissible without displaying a trade chart',()=>{
 const document=fakeDocument();let finished=0;const review=createCompletedTradeReview({document,onDone:()=>finished++});review.open({candles:[],trades:[{points:1}]});
 const dialog=document.body.children.at(-1);assert.equal(dialog.children[0].textContent,'No losing trades');assert.equal(dialog.children[3].children.length,0);dialog.querySelector('button').onclick({detail:1});assert.equal(finished,1);
});
test('biggest loss chart plots both distinct moving averages within the scale and below the trade marks',()=>{
 const doc=fakeDocument(),trade={entryIndex:0,exitIndex:3,entryPrice:11,exitPrice:7,points:-4,side:'long'};
 const candles=Array.from({length:5},()=>({o:10,h:12,l:7,c:11}));
 const indicators={ema10:[15,13,12,11,10],ema20:[6,7,8,9,10,1]};
 const {low,high}=reviewWindow(candles,trade,indicators);
 assert.ok(high>15);assert.ok(low<6);assert.ok(low>1);
 const svg=renderTradeChart(doc,candles,trade,indicators),[ten,twenty]=svg.children.filter(n=>n.attributes['data-indicator']);
 assert.equal(ten.attributes['data-indicator'],'ema10');
 assert.equal(twenty.attributes['data-indicator'],'ema20');
 assert.notEqual(ten.attributes.stroke,twenty.attributes.stroke);
 assert.equal(ten.attributes['stroke-dasharray'],undefined);
 assert.equal(twenty.attributes['stroke-dasharray'],'4 3');
 for(const path of [ten,twenty]){
  assert.match(path.attributes.d,/^M .* L .* L .* L .* L /);
  assert.equal(path.attributes['vector-effect'],'non-scaling-stroke');
 }
 assert.equal(renderTradeChart(doc,candles,trade).children.filter(n=>n.attributes['data-indicator']).length,0);
});
test('both review wiring paths feed full session indicator arrays and leave replay paths unchanged',()=>{
 const react=readFileSync(new URL('../components/trade-simulator.tsx',import.meta.url),'utf8');
 const limit=readFileSync(new URL('../components/limit-trade-review.tsx',import.meta.url),'utf8');
 const market=readFileSync(new URL('../public/modules/market-direction.html',import.meta.url),'utf8');
 assert.match(react,/reviewIndicators=useMemo\(\(\)=>tradeReview&&chart\?Model.chartIndicators\(chart\)/);
 assert.match(react,/ema10=\{reviewIndicators\?\.ema10\} ema20=\{reviewIndicators\?\.ema\}/);
 assert.match(limit,/name:'ema20',values:ema20,stroke:.*dash:'4 3'/);
 assert.match(market,/reviewData=source\|\|\{current:bars,prior:context\},ema10=chartEMA10\(reviewData,bars.length\).current,ema20=emaSequence\(bars,/);
 assert.match(market,/completedTradeReview.open\(\{candles:bars,ema10,ema20,trades:/);
});
