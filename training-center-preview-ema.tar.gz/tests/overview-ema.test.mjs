import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {sessionOverviewSvg} from '../public/modules/session-overview.js';
import Model from '../lib/portal/lesson-model.cjs';
const bars=[{o:100,h:102,l:99,c:101},{o:101,h:104,l:100,c:103},{o:103,h:105,l:102,c:104}];
test('overview seeded EMA10/20 agrees with shared chart indicators',()=>{
 const chart={current:bars,prior:[{t:'before',o:90,h:92,l:89,c:91}],warmup:{value:95,ema10Value:97}};
 const values=Model.chartIndicators(chart,1);
 assert.equal(values.ema[0],95+(2/21)*6);assert.equal(values.ema10[0],97+(2/11)*4);
 const html=sessionOverviewSvg(bars,2,false,{ema20:values.ema,ema10:values.ema10});
 assert.match(html,/data-indicator="ema20"/);assert.match(html,/data-indicator="ema10"/);assert.match(html,/stroke-width="0.7" opacity="0.3"/);
});
test('hidden indicator and candle values cannot leak into paths or axis bounds',()=>{
 const ema20=[98,99],ema10=[99,100];Object.defineProperty(ema20,2,{get(){throw Error('future EMA read')},enumerable:true});Object.defineProperty(ema10,2,{get(){throw Error('future EMA read')},enumerable:true});
 const got=sessionOverviewSvg(bars,2,false,{ema20,ema10});
 assert.equal(got,sessionOverviewSvg(bars.slice(0,2),2,false,{ema20:[98,99],ema10:[99,100]}));
});
test('full-preview indicators extend to whole session; absent series remain hidden',()=>{
 const html=sessionOverviewSvg(bars,1,true,{ema20:[98,99,100],ema10:[99,100,101]});assert.match(html,/data-overview-bars="3"/);
 assert.doesNotMatch(sessionOverviewSvg(bars,2,false),/data-indicator/);
 assert.doesNotMatch(sessionOverviewSvg(bars,2,false,{ema10:[NaN,Infinity]}),/data-indicator/);
});
test('both simulator overview callers preserve seeded math and main visibility settings',()=>{
 const trade=fs.readFileSync(new URL('../components/trade-simulator.tsx',import.meta.url),'utf8');
 assert.match(trade,/chart&&showEma\?Model.chartIndicators\(chart,previewTrading\?chart.current.length-1:state.index\)/);
 assert.match(trade,/ema20=\{overviewIndicators.ema\} ema10=\{overviewIndicators.ema10\}/);
 const market=fs.readFileSync(new URL('../public/modules/market-direction.html',import.meta.url),'utf8');
 assert.match(market,/ema20:p.ema20On!==false\?emaSequence\(bars.slice\(0,shown\),seed\):\[\]/);
 assert.match(market,/ema10:chartEMA10\(d\|\|\{current:bars,prior:context\},shown\).current/);
 assert.match(market,/overviewEma!==p.ema20On/);
});
