// Session-so-far inset. Slice before validation, scaling or rendering; never inspect future candles.
export function sessionOverviewSvg(candles, revealed = 0, preview = false, indicators = {}) {
 const count=preview===true&&Array.isArray(candles)?candles.length:Number.isFinite(revealed)?Math.max(0,Math.floor(revealed)):0;
 const bars=Array.isArray(candles)?candles.slice(0,count):[];
 if(!bars.length||bars.some(b=>![b.o,b.h,b.l,b.c].every(Number.isFinite)))return '';
 // Truncate each series before reading its values, including for axis bounds.
 const series=[['ema20',indicators.ema20,1.2,.85],['ema10',indicators.ema10,.7,.3]].map(([name,values,stroke,opacity])=>({name,values:Array.isArray(values)?values.slice(0,bars.length):[],stroke,opacity}));
 const visibleValues=series.flatMap(s=>s.values.filter(Number.isFinite));
 const width=320,height=180,pad=8,lo=Math.min(...bars.map(b=>b.l),...visibleValues),hi=Math.max(...bars.map(b=>b.h),...visibleValues);
 const span=Math.max(hi-lo,.25),step=(width-pad*2)/bars.length;
 const y=v=>+(height-pad-(v-lo)/span*(height-pad*2)).toFixed(3);
 const number=v=>+v.toFixed(3);
 const paths=bars.map((b,i)=>{const x=number(pad+(i+.5)*step),w=number(Math.max(.45,step*.62)),color=b.c>=b.o?'#67dfb3':'#f18da6';return `<g><path d="M${x} ${y(b.h)}V${y(b.l)}" stroke="${color}" stroke-width=".7"/><rect x="${number(x-w/2)}" y="${Math.min(y(b.o),y(b.c))}" width="${w}" height="${Math.max(.7,Math.abs(y(b.o)-y(b.c)))}" fill="${color}"/></g>`;}).join('');
 const emaPaths=series.map(s=>{let connected=false;const d=s.values.map((v,i)=>{if(!Number.isFinite(v)){connected=false;return ''}const command=connected?'L':'M';connected=true;return `${command}${number(pad+(i+.5)*step)} ${y(v)}`}).join(' ').trim();return d?`<path data-indicator="${s.name}" d="${d}" fill="none" stroke="#f6c760" stroke-width="${s.stroke}" opacity="${s.opacity}" vector-effect="non-scaling-stroke" pointer-events="none"/>`:''}).join('');
 return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" preserveAspectRatio="none" role="img" aria-label="${preview===true?'Preview: entire session including future candles':'Session from first bar through current bar'}" data-overview-bars="${bars.length}"><rect width="320" height="180" fill="#101a27"/>${paths}${emaPaths}</svg>`;
}
