import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import ts from 'typescript';
const account=fs.readFileSync(new URL('../components/learner-account-control.tsx',import.meta.url),'utf8');
const combined=fs.readFileSync(new URL('../components/combined-simulator.tsx',import.meta.url),'utf8');
test('history menu allows navigation only for the current account with no pending save',()=>{
 const source=account.slice(account.indexOf(' function navigateHistory('),account.indexOf(' function navigateReplay('));
 for(const current of [false,true])for(const saved of [false,true]){
  let prevented=false,error='',saveChecks=0;
  const context=vm.createContext({actionAllowed:()=>current,onBeforeNavigate:()=>{saveChecks++;return saved;},setLocalError:v=>error=v});
  vm.runInContext(ts.transpile(source),context);
  context.navigateHistory({preventDefault:()=>{prevented=true;}});
  assert.equal(prevented,!(current&&saved));assert.equal(saveChecks,current?1:0);
  assert.equal(!!error,prevented);
 }
});
test('combined history menu blocks leaving during an unresolved save',()=>{
 const source=combined.match(/section="TRADE HISTORY" onNavigate=\{(event=>\{.*?\})\}\/\>/)[1];
 for(const ready of [false,true]){
  let prevented=false,notice='';const context=vm.createContext({canAct:()=>ready,setNotice:v=>notice=v});
  vm.runInContext('globalThis.navigate='+source,context);
  context.navigate({preventDefault:()=>{prevented=true;}});
  assert.equal(prevented,!ready);assert.equal(!!notice,!ready);
 }
});
