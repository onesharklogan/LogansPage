import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {readPreviewPreference,writePreviewPreference,subscribePreviewPreference} from '../public/modules/preview-trading-preference.js';
import {sessionOverviewSvg} from '../public/modules/session-overview.js';
import {deriveTodayHistory} from '../lib/today-history.mjs';
import {outcomeTotals} from '../public/modules/learner-stats.js';
test('retired preference ignores previously saved true without reading or writing private browser data',()=>{
 globalThis.window={get localStorage(){throw Error('storage must remain untouched')}};
 try{assert.equal(readPreviewPreference('existing-user'),false);assert.equal(writePreviewPreference('existing-user',true),false);subscribePreviewPreference('existing-user',()=>{throw Error('unexpected callback')})();}finally{delete globalThis.window;}
});
test('future candles and EMA values remain unreadable even with legacy preview=true',()=>{
 const bars=[{o:100,h:102,l:99,c:101}],ema=[100];
 Object.defineProperty(bars,1,{get(){throw Error('future candle read')}});Object.defineProperty(ema,1,{get(){throw Error('future EMA read')}});
 const output=sessionOverviewSvg(bars,1,true,{ema20:ema,ema10:ema});
 assert.match(output,/data-overview-bars="1"/);assert.doesNotMatch(output,/entire session|future candles/);
 assert.equal(output,sessionOverviewSvg([bars[0]],1,false,{ema20:[100],ema10:[100]}));
});
test('combined today summary retains both order engines and does not mutate saved attempts',()=>{
 const attempts=['market-direction','trade-simulator'].map((module,i)=>({id:`12345678-1234-4234-8234-${String(i+1).padStart(12,'0')}`,module,chartId:'mes1-2025-01-02-81',startedAt:'2026-11-17T10:00:00Z',completedAt:'2026-11-17T10:01:00Z',outcomes:outcomeTotals([i? -2:5]),buckets:[i?-2:5,0,0,0],practiced:i?null:1,neutral:i?null:0,carry:false}));
 const snapshot={version:1,context:{accountId:'12345678-1234-4234-8234-123456789012',generation:1,sessionTag:'a'.repeat(64)},snapshot:'b'.repeat(64),asOf:'2026-11-17T12:00:00Z',attempts},before=JSON.stringify(snapshot);
 const combined=deriveTodayHistory(snapshot,2,{now:snapshot.asOf,timeZone:'UTC'});
 assert.equal(combined.count,2);assert.equal(combined.samples,2);assert.equal(combined.series.total,3);assert.equal(JSON.stringify(snapshot),before);
});
test('profile companion is contained, decorative and respects reduced motion',()=>{
 const css=readFileSync(new URL('../public/profile-companion.css',import.meta.url),'utf8');
 assert.match(css,/pointer-events:none/);assert.match(css,/overflow:hidden/);assert.match(css,/prefers-reduced-motion:reduce/);assert.match(css,/animation:none!important/);
 const react=readFileSync(new URL('../components/profile-companion.tsx',import.meta.url),'utf8');assert.match(react,/aria-hidden="true"/);
});
