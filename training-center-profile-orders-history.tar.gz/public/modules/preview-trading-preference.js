// Preview trading is retired. Old settings are ignored without modifying browser data.
export function readPreviewPreference(_owner){return false}
export function writePreviewPreference(_owner,_enabled){return false}
export function subscribePreviewPreference(_owner,_callback){return ()=>{}}
