'use client';
/** Retired control retained as a compatibility no-op. */
export default function PreviewTradingOption(_props:{owner:string;canChange:()=>boolean;disabled?:boolean}){return null;}
