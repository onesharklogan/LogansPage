"use client";
import {useEffect,useState} from 'react';
const companions=['🐕','🐧','☃️','🐦'];
/** Decorative only: no storage, account data, hit targets, or timers. */
export default function ProfileCompanion(){
 const [friend,setFriend]=useState(0);
 useEffect(()=>{setFriend(Math.floor(Math.random()*companions.length));},[]);
 return <span className="profile-companion" aria-hidden="true"><span className="profile-companion-walk"><span className="profile-companion-dance">{companions[friend]}</span></span></span>;
}
