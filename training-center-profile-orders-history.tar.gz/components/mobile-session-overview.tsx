'use client';
import {useMemo,useState} from 'react';
import {sessionOverviewSvg} from '../public/modules/session-overview.js';
export default function MobileSessionOverview({candles,revealed,ema20=[],ema10=[]}:{ema20?:number[];ema10?:number[];preview?:boolean;candles:{o:number;h:number;l:number;c:number}[];revealed:number}){
 const preview=false;
 const [collapsed,setCollapsed]=useState(false);
 const image=useMemo(()=>sessionOverviewSvg(candles,revealed,preview,{ema20,ema10}),[candles,revealed,preview,ema20,ema10]);
 if(!image)return null;
 return <aside className={`mobile-session-overview${preview?' is-preview':''}${collapsed?' is-collapsed':''}`} aria-label={preview?'Unscored preview overview':'Session-so-far overview'} onPointerDown={e=>e.stopPropagation()} onPointerMove={e=>e.stopPropagation()} onPointerUp={e=>e.stopPropagation()} onClick={e=>e.stopPropagation()} onContextMenu={e=>e.stopPropagation()}>
 <button type="button" aria-expanded={!collapsed} aria-label={collapsed?(preview?'Show full-session preview':'Show session overview through current bar'):'Hide session overview'} onClick={()=>setCollapsed(v=>!v)}><span className="overview-heading"><span>{preview?'Full-session preview':'Session so far'}<small>{preview?'Unscored · not saved':'First bar to current bar'}</small></span><span aria-hidden="true">{collapsed?'+':'−'}</span></span>
 {!collapsed&&<span className="overview-image" dangerouslySetInnerHTML={{__html:image}}/>}</button>
 </aside>;
}
