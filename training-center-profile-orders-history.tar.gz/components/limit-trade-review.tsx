'use client';

import {useId,useLayoutEffect,useRef} from 'react';
import type {Trade} from '../lib/trade-simulator.mjs';
import {biggestLoss} from '../public/modules/biggest-loss.mjs';
import {EXIT_LABELS} from '../lib/trade-simulator-view.mjs';

type Candle={t?:string;o:number;h:number;l:number;c:number};
type Props={trades:Trade[];candles:Candle[];ema10?:number[];title:string;previewTrading?:boolean;active?:boolean;canAcknowledge?:()=>boolean;onComplete:()=>void};
const price=(n:number)=>n.toFixed(2);
const css=`.limit-trade-review{box-sizing:border-box;width:min(1100px,calc(100vw - 24px));max-height:calc(100dvh - 24px);overflow:auto;margin:auto;padding:14px 16px;border:1px solid var(--appearance-line-47647d, #47647d);border-radius:16px;background:var(--appearance-surface-0c1927, #0c1927);color:var(--appearance-ink-e5eff8, #e5eff8);box-shadow:0 24px 90px var(--appearance-shadow-0009, #0009)}.limit-trade-review::backdrop{background:var(--appearance-surface-020812cc, #020812cc)}.limit-trade-review h2{font-size:20px;margin:4px 0}.limit-trade-review p{color:var(--appearance-ink-adc2d5, #adc2d5);line-height:1.4;margin:6px 0;font-size:13px}.limit-trade-review svg{display:block;width:100%;height:auto;max-height:56dvh;background:var(--appearance-surface-08121e, #08121e);border:1px solid var(--appearance-line-30465a, #30465a);border-radius:10px}.limit-trade-review dl{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin:8px 0}.limit-trade-review dl div{padding:8px;background:var(--appearance-surface-132639, #132639);border-radius:8px}.limit-trade-review dt{color:var(--appearance-ink-adc2d5, #adc2d5);font-size:12px}.limit-trade-review dd{margin:4px 0 0;font-weight:600;overflow-wrap:anywhere}.limit-trade-review small{display:block;color:var(--appearance-ink-adc2d5, #adc2d5);font-weight:400}.limit-trade-review button{width:100%;min-height:48px;border:1px solid var(--appearance-line-8ac7ff, #8ac7ff);border-radius:9px;background:var(--appearance-surface-285d89, #285d89);color:var(--appearance-ink-white, white);font:inherit;font-weight:700;cursor:pointer}.limit-trade-review button:focus-visible{outline:3px solid var(--appearance-line-ffcf7c, #ffcf7c);outline-offset:3px}.limit-trade-review .ltr-positive{color:var(--appearance-ink-9ee5bc, #9ee5bc)}.limit-trade-review .ltr-negative{color:var(--appearance-ink-ff9aa9, #ff9aa9)}@media(max-width:440px){.limit-trade-review{padding:10px}.limit-trade-review h2{font-size:18px}.limit-trade-review dl{gap:6px;grid-template-columns:repeat(2,minmax(0,1fr))}.limit-trade-review dd{font-size:14px}}`;

/** Review is presentation only: no simulator advances, scoring or history writes. */
export default function LimitTradeReview({trades,candles,ema10=[],title,previewTrading=false,active=true,canAcknowledge=()=>true,onComplete}:Props){
  const dialog=useRef<HTMLDialogElement>(null),ok=useRef<HTMLButtonElement>(null),done=useRef(false),lastClick=useRef(-Infinity);
  const titleId=useId(),helpId=useId(),trade=biggestLoss(trades);
  useLayoutEffect(()=>{
    if(!active)return;
    const node=dialog.current!,previous=document.activeElement as HTMLElement|null,overflow=document.body.style.overflow;
    document.body.style.overflow='hidden';node.showModal();ok.current?.focus({preventScroll:true});
    return()=>{node.close();document.body.style.overflow=overflow;if(previous?.isConnected&&!previous.closest('[inert]'))previous.focus({preventScroll:true});};
  },[active]);
  function acknowledge(){
    const now=performance.now();
    // Stale handlers, key repeat, and double clicks must never acknowledge this review twice.
    if(!active||!canAcknowledge()||done.current||now-lastClick.current<350)return;
    lastClick.current=now;
    done.current=true;onComplete();
  }
  const start=0,end=candles.length-1,rows=trade?candles:[],entryIsLong=trade?.side==='buy',entryColor=entryIsLong?'var(--appearance-ink-4ade80, #4ade80)':'var(--appearance-ink-f87171, #f87171)';
  const values=rows.flatMap(c=>[c.h,c.l]).concat(trade?[trade.entryPrice,trade.exitPrice]:[]),low=values.length?Math.min(...values):0,high=values.length?Math.max(...values):1,pad=Math.max((high-low)*.12,.5),arrowPad=Math.max(pad,(high-low+pad)*36/(289-36)),lo=low-(entryIsLong?arrowPad:pad),hi=high+(entryIsLong?pad:arrowPad);
  const left=58,right=940,top=30,bottom=319,labelEvery=Math.max(1,Math.ceil(rows.length/10));
  const x=(i:number)=>left+(i+.5)*(right-left)/Math.max(1,rows.length),y=(p:number)=>bottom-(p-lo)/(hi-lo)*(bottom-top);
  // Reserve 36 plot units at the entry arrow's edge, clear of wick and labels.
  // The dashed trade line still starts at the exact recorded fill price.
  const entryX=trade?x(trade.entryIndex):0,entryTop=trade?(entryIsLong?y(candles[trade.entryIndex].l)+8:y(candles[trade.entryIndex].h)-30):0,entryBottom=entryTop+22;
  const headHalf=Math.min(5,(right-left)/Math.max(1,rows.length)*.325),tipY=trade?.side==='buy'?entryTop:entryBottom,headY=tipY+(trade?.side==='buy'?7:-7);
  const entryArrow=`M ${entryX} ${entryTop} L ${entryX} ${entryBottom} M ${entryX-headHalf} ${headY} L ${entryX} ${tipY} L ${entryX+headHalf} ${headY}`;
  const anchor=(i:number)=>i>end-4?'end':i<4?'start':'middle';
  return <dialog ref={dialog} className="limit-trade-review" aria-modal="true" aria-labelledby={titleId} aria-describedby={helpId} onCancel={e=>e.preventDefault()} onKeyDown={e=>{e.stopPropagation();if(e.key==='Escape'||e.key==='Tab'||((e.key==='Enter'||e.key===' ')&&e.repeat)){e.preventDefault();if(e.key==='Tab')ok.current?.focus();}}}>
    <style>{css}</style><small>{previewTrading?'PREVIEW COMPLETE · NOT SCORED OR SAVED':'SESSION COMPLETE · ORDERS'}</small><h2 id={titleId}>{trade?`Biggest loss · ${trade.side==='buy'?'Long':'Short'}`:trades.length?'No losing trades':'No executed trades'}</h2>
    <p id={helpId}>{title}. {trade?'Full session · only this trade is marked. Green up arrow below / red down arrow above: entry · gold dot: exit. Review it, then tap OK.':trades.length?'All executed trades were winning or breakeven. Tap OK to return to the completed chart.':'No order filled in this attempt. Tap OK to return to the completed chart.'}</p>
    {trade&&<div aria-live="polite" aria-atomic="true">
      <svg viewBox="0 0 960 370" role="img" data-review-bars={rows.length} aria-label={`Full session, bars ${start+1} to ${end+1}. Only the biggest loss is marked. Entry candle ${trade.entryIndex+1} at ${price(trade.entryPrice)}, exit candle ${trade.exitIndex+1} at ${price(trade.exitPrice)}. ${entryIsLong?'Green up arrow below':'Red down arrow above'} candle: entry. Gold dot: exit.`}>
        {[lo,lo+(hi-lo)/4,(lo+hi)/2,hi-(hi-lo)/4,hi].map(p=><g key={p}><line x1={left} x2={right} y1={y(p)} y2={y(p)} stroke="var(--appearance-line-263c50, #263c50)"/><text x={left-6} y={y(p)+4} textAnchor="end" fill="var(--appearance-ink-adc2d5, #adc2d5)" fontSize="10">{price(p)}</text></g>)}
        <rect x={x(trade.entryIndex)-(right-left)/rows.length*.42} y={top} width={Math.max((right-left)/rows.length*.84,x(trade.exitIndex)-x(trade.entryIndex)+(right-left)/rows.length*.84)} height={bottom-top} fill="var(--appearance-ink-e3769118, #e3769118)"/>
        {rows.map((c,i)=><g key={i} data-review-candle={i+1}><line x1={x(i)} x2={x(i)} y1={y(c.h)} y2={y(c.l)} stroke={c.c>=c.o?'var(--appearance-ink-9ee5bc, #9ee5bc)':'var(--appearance-ink-ff9aa9, #ff9aa9)'}/><rect x={x(i)-Math.min(8,(right-left)/rows.length*.325)} y={y(Math.max(c.o,c.c))} width={Math.min(16,(right-left)/rows.length*.65)} height={Math.max(1,Math.abs(y(c.o)-y(c.c)))} fill={c.c>=c.o?'var(--appearance-ink-9ee5bc, #9ee5bc)':'var(--appearance-ink-ff9aa9, #ff9aa9)'}/>{(i===0||(i+1)%labelEvery===0||i===end)&&<text x={x(i)} y={bottom+19} fill="var(--appearance-ink-adc2d5, #adc2d5)" fontSize="11" textAnchor="middle">{i+1}</text>}</g>)}
        <line x1={x(trade.entryIndex)} y1={y(trade.entryPrice)} x2={x(trade.exitIndex)} y2={y(trade.exitPrice)} stroke="var(--appearance-ink-ffcf7c, #ffcf7c)" strokeWidth="2" strokeDasharray="5 4"/>
        <line x1={x(trade.entryIndex)} x2={x(trade.entryIndex)} y1={top} y2={bottom} stroke={entryColor} strokeOpacity=".65" strokeDasharray="3 4"/>
        <line x1={x(trade.exitIndex)} x2={x(trade.exitIndex)} y1={top} y2={bottom} stroke="var(--appearance-ink-ffcf7c, #ffcf7c)" strokeOpacity=".65" strokeDasharray="3 4"/>
        <text x={x(trade.entryIndex)} y="18" textAnchor={anchor(trade.entryIndex)} fill={entryColor} fontSize="12" fontWeight="700">{trade.side==='buy'?'↑':'↓'} ENTRY {trade.entryIndex+1}</text>
        <text x={x(trade.exitIndex)} y="358" textAnchor={anchor(trade.exitIndex)} fill="var(--appearance-ink-ffcf7c, #ffcf7c)" fontSize="12" fontWeight="700">EXIT {trade.exitIndex+1}</text>
        <path data-trade-mark="entry" data-entry-direction={trade.side==='buy'?'long':'short'} d={entryArrow} fill="none" stroke={entryColor} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
        <circle data-trade-mark="exit" cx={x(trade.exitIndex)} cy={y(trade.exitPrice)} r="5" fill="var(--appearance-ink-ffcf7c, #ffcf7c)" stroke="var(--appearance-line-07101b, #07101b)" strokeWidth="2"/>
      <path data-indicator="ema10" d={rows.map((_,i)=>Number.isFinite(ema10[i])?`${i&&Number.isFinite(ema10[i-1])?'L':'M'} ${x(i)} ${y(ema10[i])}`:'').join(' ')} fill="none" stroke="var(--appearance-ink-f6c760, #f6c760)" strokeWidth=".7" opacity=".3" vectorEffect="non-scaling-stroke" pointerEvents="none"/>
      </svg>
      <dl><div><dt>Entry</dt><dd>{price(trade.entryPrice)}<small>Candle {trade.entryIndex+1} · {trade.entryTime||'Time unavailable'}</small></dd></div><div><dt>Exit · {EXIT_LABELS[trade.reason as keyof typeof EXIT_LABELS]||trade.reason}</dt><dd>{price(trade.exitPrice)}<small>Candle {trade.exitIndex+1} · {trade.exitTime||'Time unavailable'}</small></dd></div><div><dt>Stop / target</dt><dd>{price(trade.stop)} / {price(trade.target)}</dd></div>{!previewTrading&&<div><dt>Result · points, not cash</dt><dd className={trade.points<0?'ltr-negative':'ltr-positive'}>{trade.points>0?'+':''}{price(trade.points)} points</dd></div>}</dl>
      {trade.ambiguous&&<p>Both exits were touched in one candle. The simulator’s conservative stop-first result is unchanged.</p>}
    </div>}
    <p>{previewTrading?'Preview practice is not scored or saved.':'Full-session candles are for review only. Your recorded fills and score are unchanged.'}</p>
    <button ref={ok} type="button" onClick={acknowledge}>OK · Finish review</button>
  </dialog>;
}
