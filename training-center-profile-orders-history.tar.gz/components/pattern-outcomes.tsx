import {useMemo} from 'react';
import {patternOutcomes,summarizePatternOutcomes} from '../lib/pattern-outcomes.mjs';
type Match={id:string;date:string;startBar:number;endBar:number;distance:number};
type Session={reference:{id:string};chart:{current:{c:number;t:string}[]}};
export default function PatternOutcomes({matches,sessions,ready}:{matches:Match[];sessions:Session[];ready:boolean}){
 const model=useMemo(()=>patternOutcomes(matches,sessions),[matches,sessions]);
 const summary=useMemo(()=>summarizePatternOutcomes(model.lines),[model]);
 const color=(value:number)=>value>0?'var(--green, #62d9a5)':value<0?'var(--red, #f28ba8)':'var(--muted, #8ba1b6)';
 let low=0,high=0;for(const line of model.lines)for(const value of line.points){low=Math.min(low,value);high=Math.max(high,value);}
 const pad=Math.max(.02,(high-low)*.08),lo=low-pad,hi=high+pad;
 const longest=Math.max(1,...model.lines.map(line=>line.points.length-1));
 const x=(i:number)=>58+i/longest*870,y=(v:number)=>300-(v-lo)/(hi-lo)*260;
 return <section aria-labelledby="pattern-outcomes-title" style={{marginTop:20,minWidth:0}}><h3 id="pattern-outcomes-title">25 closest patterns</h3>
 <p>Change (%) from pattern end</p>
 {!ready?<p>Find matches to compare outcomes.</p>:<>{(model.noContinuation>0||model.unavailable>0||model.truncated>0||model.duplicates>0)&&<p role="status">Some matches have limited data:{model.noContinuation?` ${model.noContinuation} without later closes.`:''}{model.unavailable?` ${model.unavailable} unavailable.`:''}{model.truncated?` ${model.truncated} stopped at missing data.`:''}{model.duplicates?` ${model.duplicates} duplicate references omitted.`:''}</p>}
 {model.lines.length>0&&<><p>At +15 bars (75 min): {summary.horizon.count?`${summary.horizon.above} above · ${summary.horizon.below} below · ${summary.horizon.flat} flat out of ${summary.horizon.count} paths`:'No paths reach this point'}{summary.horizon.excluded?` · ${summary.horizon.excluded} shorter paths excluded`:''}.</p><p>Final available close: <span style={{color:color(1)}}>green above</span> · <span style={{color:color(-1)}}>red below</span> · gray flat. Bold gold: median (n={summary.median[0]?.count} at start → {summary.median.at(-1)?.count} at end).</p></>}
 {model.lines.length?<svg viewBox="0 0 960 350" role="img" aria-label={`${model.lines.length} historical continuation lines. Percent change from matched final close versus five-minute bars after pattern end.`} style={{width:'100%',height:'auto',minHeight:220,background:'var(--appearance-surface-08131f, #08131f)',borderRadius:8}}>
 {[0,.25,.5,.75,1].map(f=>{const v=lo+(hi-lo)*f;return <g key={f}><line x1="58" x2="928" y1={y(v)} y2={y(v)} stroke="var(--appearance-line-1c3042, #1c3042)"/><text x="52" y={y(v)+4} textAnchor="end" fontSize="12" fill="var(--appearance-ink-8ba1b6, #8ba1b6)">{v.toFixed(2)}%</text></g>;})}
 <line x1="58" x2="928" y1={y(0)} y2={y(0)} stroke="var(--appearance-ink-8ba1b6, #8ba1b6)" strokeDasharray="5 4" strokeWidth="2" vectorEffect="non-scaling-stroke"/>
 {model.lines.map(line=><polyline key={line.key} data-outcome-session={line.id} points={line.points.map((v,i)=>`${x(i)},${y(v)}`).join(' ')} fill="none" stroke={color(line.points.at(-1)??0)} strokeOpacity={.35} strokeWidth="1" vectorEffect="non-scaling-stroke"><title>{`${line.date} · pattern bars ${line.startBar}–${line.endBar} · ${line.points.length-1} later closes`}</title></polyline>)}
 <polyline data-outcome-median="true" points={summary.median.map(p=>`${x(p.bar)},${y(p.value)}`).join(' ')} fill="none" stroke="var(--gold, #e6bf66)" strokeWidth="3" vectorEffect="non-scaling-stroke"><title>Median at each bar; sample decreases as paths end</title></polyline>
 {summary.median.map(p=><circle key={p.bar} cx={x(p.bar)} cy={y(p.value)} r="4" fill="var(--gold, #e6bf66)" fillOpacity="0"><title>{`+${p.bar} bars · median ${p.value.toFixed(2)}% · ${p.count} paths`}</title></circle>)}
 <text x="58" y="327" fontSize="12" fill="var(--appearance-ink-8ba1b6, #8ba1b6)">Pattern end · 0</text><text x="928" y="327" textAnchor="end" fontSize="12" fill="var(--appearance-ink-8ba1b6, #8ba1b6)">{longest} bars later · 5 minutes/bar</text>
 </svg>:<p>No valid continuation data for these matches.</p>}
 <details><summary>About this chart</summary><p>Colors use each path’s last available close, which may occur before session end; they are retrospective, not a signal known at pattern end. The +15-bar count uses only the close exactly 15 bars after the pattern, irrespective of final color. Flat means exactly unchanged. The median uses available paths at each bar; its composition changes as shorter paths end, and it is not one observed trading path.</p><p>Up to 25 closest windows use the same ranking as the 10 previews, with no similarity cutoff or guarantee of a good match. Up to two nonoverlapping windows can come from one session; these are not independent days.</p><p>Each line starts at 0% at the matched pattern’s final close and stops at its last available close. Shorter paths are not extended. Horizontal alignment is elapsed bars, not clock time. Windows without later closes are counted but not replaced.</p><p>Re-checking keeps checked previews and replaces unchecked windows in both previews and this chart. Checkboxes alone control saving.</p></details></>}
 </section>;
}
